# Modèles 3D importés — BlockWorld

| Fichier du jeu | Modèle d'origine (nom du fichier fourni) | Traitement |
|---|---|---|
| `assets/statues/black-knight.bin` | `nickpanek-black-knight-1689.glb` (auteur indiqué : nickpanek) | allégé de 168 000 à ≈ 10 000 triangles, textures réduites puis reportées en nuances sur les sommets, rendu « bronze patiné » |
| `assets/statues/dark-knight.bin` | `pixellabs-dark-fantasy-knight-3471.glb` (auteur indiqué : pixellabs) | allégé de 50 000 à ≈ 13 000 triangles, même traitement |

Ces modèles ont été fournis comme « libres de droit ». Les fichiers ne contenaient aucune mention de licence :
**vérifier la licence sur la page de téléchargement de chacun avant toute diffusion publique du jeu**
(usage dans un jeu autorisé ? attribution demandée ? redistribution des fichiers bruts interdite ?).

Les huit personnages (`src/characters/CharacterFactory.js`) sont des créations originales générées par code.

## Personnages HD (Élevée / Ultra) — Microsoft Rocketbox, licence MIT

Source : https://github.com/microsoft/Microsoft-Rocketbox (bibliothèque d'avatars publiée sous licence MIT depuis novembre 2020).
Copyright (c) Microsoft Corporation. Licence MIT : utilisation, modification et redistribution autorisées, à condition de conserver
la mention de copyright et le texte de la licence (https://github.com/microsoft/Microsoft-Rocketbox/blob/master/LICENSE.md).

| Dossier du jeu | Avatar d'origine | Personnage |
|---|---|---|
| `assets/characters-hd/f03` | Female_Adult_03 | Maya, danseuse |
| `assets/characters-hd/f11` | Female_Adult_11 | Élise, avocate |
| `assets/characters-hd/f17` | Female_Adult_17 | Sarah, coach sportive |
| `assets/characters-hd/p01` | Female_Party_01 | Jade, musicienne |
| `assets/characters-hd/m01` | Male_Adult_01 | Tom, étudiant |
| `assets/characters-hd/m05` | Male_Adult_05 | Bernard, reporter |
| `assets/characters-hd/m10` | Male_Adult_10 | Jun, coureur |
| `assets/characters-hd/m16` | Male_Adult_16 | Marc, ingénieur |
| `assets/characters-hd/anims` | f/m_idle_neutral_01, f/m_walk_neutral_01, f/m_run_neutral_01 | repos, marche, course |

Traitement : conversion FBX → glTF (FBX2glTF), textures réduites de 2048 à 1024 px (WebP), rugosité dérivée des cartes de brillance,
animations rééchantillonnées et avancée horizontale de la racine neutralisée (le jeu déplace les personnages).
