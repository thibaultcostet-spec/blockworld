const CACHE_NAME='blockworld-v3.0-beta4.35';
const FILES=[
  './','./index.html','./styles.css','./manifest.webmanifest',
  './src/main.js','./src/boot.js',
  // Beta 4.21 : moteur 3D intégré, pour jouer hors ligne (application Android installée).
  './vendor/three/build/three.core.min.js','./vendor/three/build/three.module.min.js','./vendor/three/examples/jsm/math/SimplexNoise.js','./vendor/three/examples/jsm/postprocessing/EffectComposer.js','./vendor/three/examples/jsm/postprocessing/MaskPass.js','./vendor/three/examples/jsm/postprocessing/OutputPass.js','./vendor/three/examples/jsm/postprocessing/Pass.js','./vendor/three/examples/jsm/postprocessing/RenderPass.js','./vendor/three/examples/jsm/postprocessing/SSAOPass.js','./vendor/three/examples/jsm/postprocessing/ShaderPass.js','./vendor/three/examples/jsm/postprocessing/UnrealBloomPass.js','./vendor/three/examples/jsm/shaders/CopyShader.js','./vendor/three/examples/jsm/shaders/FXAAShader.js','./vendor/three/examples/jsm/shaders/LuminosityHighPassShader.js','./vendor/three/examples/jsm/shaders/OutputShader.js','./vendor/three/examples/jsm/shaders/SSAOShader.js','./vendor/three/examples/jsm/loaders/GLTFLoader.js','./vendor/three/examples/jsm/utils/BufferGeometryUtils.js','./vendor/three/examples/jsm/utils/SkeletonUtils.js','./src/characters/HDCharacters.js',
  './src/core/Game.js','./src/core/Input.js',
  './src/player/Player.js','./src/world/World.js','./src/world/BlockTypes.js','./src/world/GroundingSystem.js',
  './src/worlds/WorldRegistry.js','./src/worlds/TerrainBuilder.js','./src/worlds/ProceduralVegetation.js','./src/worlds/LandmarkBuilder.js',
  './src/worlds/continents/EuropeWorld.js','./src/worlds/continents/AfricaWorld.js','./src/worlds/continents/AsiaWorld.js','./src/worlds/continents/AmericasWorld.js','./src/worlds/continents/OceaniaWorld.js',
  './src/ui/Hud.js','./src/ui/TouchControls.js','./src/ui/HudContext.js','./src/ui/PauseMenu.js','./src/graphics/BuildFeedback.js','./src/graphics/BuildFeedbackRules.js','./src/world/Campfires.js','./src/graphics/NightLights.js','./src/systems/Fishing.js','./src/systems/FishingRules.js','./src/ui/PhotoMode.js','./src/ui/PhotoAlbum.js','./src/combat/SoftTools.js','./src/fauna/HerdRules.js','./src/fauna/CompanionRules.js','./src/fauna/Companion.js','./src/systems/Paragliding.js','./src/systems/ParaglidingRules.js','./src/exploration/BigMap.js','./src/exploration/TerrainMapRules.js','./src/ui/StartWizard.js','./src/ui/BlockIcons.js','./src/bridge/BridgeSolver.js','./src/bridge/BridgeChallenges.js','./src/bridge/BridgeChallengeSystem.js','./src/bridge/ConvoyModels.js','./src/entities/Monster.js','./src/entities/MonsterManager.js','./src/entities/MonsterTypes.js','./src/entities/MonsterModels.js',
  './src/items/ItemCatalog.js','./src/items/ToolTypes.js','./src/modes/ModeRegistry.js','./src/modes/BaseMode.js','./src/modes/CreativeMode.js',
  './src/modes/MissionMode.js','./src/modes/SurvivalMode.js','./src/modes/DefenseMode.js','./src/world/PlacementRules.js','./src/worlds/monuments/MonumentKit.js','./src/worlds/monuments/Colosseum.js','./src/worlds/monuments/Giza.js','./src/worlds/monuments/Bridges.js','./src/worlds/monuments/BigBen.js','./src/worlds/monuments/Sagrada.js','./src/caves/CaveGeometry.js','./src/caves/CavePlanner.js','./src/caves/CaveBuilder.js','./src/caves/CaveRules.js','./src/caves/CaveSystem.js','./src/audio/SpatialAudioRules.js','./src/audio/SpatialAmbience.js','./src/modes/DefenseRules.js','./src/modes/BarricadeRules.js','./src/entities/TelegraphRules.js','./src/entities/HealthBarRules.js','./src/entities/AttackWarning.js','./src/entities/MonsterHealthBars.js','./src/modes/BattleMode.js','./src/modes/ModeController.js',
  './src/missions/MissionLibrary.js','./src/missions/MissionManager.js','./src/missions/HeritageMissionMarker.js','./src/systems/SpawnProtection.js',
  './src/graphics/TextureFactory.js','./src/graphics/GraphicsQualityManager.js','./src/graphics/AtmosphereSystem.js','./src/graphics/RenderPipeline.js',
  './src/graphics/MonumentVisualEnhancer.js','./src/graphics/ScenicVegetationSystem.js','./src/graphics/MicroVoxelDecor.js','./src/graphics/MicroVoxelShapes.js','./src/combat/HitReactionProfiles.js','./src/combat/HitFeedback.js','./src/characters/CharacterFactory.js','./src/ui/CharacterSelector.js','./src/graphics/StatueDecor.js','./src/combat/CreatureCombat.js','./src/systems/HungerSystem.js','./src/core/GamepadInput.js','./src/ui/ControlsLegend.js','./src/graphics/AmbientDetailSystem.js',
  './src/network/MultiplayerClient.js','./src/network/RemotePlayer.js','./src/network/RemotePlayerManager.js',
  './src/weapons/WeaponSystem.js','./src/weapons/WeaponViewModel.js','./src/audio/AudioManager.js','./src/audio/SoundEffectsManager.js',
  './src/exploration/LandmarkPassport.js','./src/exploration/NavigationMap.js','./src/exploration/PassportView.js',
  './src/engineering/StructuralAnalyzer.js','./src/engineering/StabilitySystem.js','./src/disasters/DisasterManager.js','./src/fauna/FaunaManager.js',
  './src/life/LifeEngine.js','./src/life/AIManager.js','./src/life/NeedsSystem.js','./src/life/ScheduleSystem.js','./src/life/PathFinder.js','./src/life/InteractionSystem.js',
  './src/climate/ClimateSystem.js','./src/water/LivingWaterSystem.js','./src/movement/EntityMotionEngine.js','./assets/icons/icon-192.png','./assets/icons/icon-512.png'
];
self.addEventListener('install',(event)=>event.waitUntil(caches.open(CACHE_NAME).then((cache)=>cache.addAll(FILES)).then(()=>self.skipWaiting())));
self.addEventListener('activate',(event)=>event.waitUntil(caches.keys().then((keys)=>Promise.all(keys.filter((key)=>key!==CACHE_NAME).map((key)=>caches.delete(key)))).then(()=>self.clients.claim()).then(async()=>{for(const client of await self.clients.matchAll({type:'window'}))client.postMessage({type:'BLOCKWORLD_UPDATE_READY',version:'3.0-beta4.35'});}))); 
self.addEventListener('message',(event)=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
self.addEventListener('fetch',(event)=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin)return;
  const isCore=event.request.mode==='navigate'||['script','style','manifest'].includes(event.request.destination)||url.pathname.endsWith('.js')||url.pathname.endsWith('.css')||url.pathname.endsWith('.html');
  if(isCore){
    event.respondWith(fetch(event.request).then((response)=>{const copy=response.clone();caches.open(CACHE_NAME).then((cache)=>cache.put(event.request,copy));return response;}).catch(()=>caches.match(event.request).then((cached)=>cached||caches.match('./index.html'))));
    return;
  }
  event.respondWith(caches.match(event.request).then((cached)=>cached||fetch(event.request).then((response)=>{const copy=response.clone();caches.open(CACHE_NAME).then((cache)=>cache.put(event.request,copy));return response;})));
});
