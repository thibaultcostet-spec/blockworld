const ENABLED_KEY = 'blockworld-v1.4-music-enabled';
const VOLUME_KEY = 'blockworld-v1.4-music-volume';

const THEMES = {
  creative: {
    bpm: 72,
    wave: 'triangle',
    bassWave: 'sine',
    scale: [0, 4, 7, 11, 14, 11, 7, 4],
    bass: [0, 0, 5, 5, 7, 7, 5, 5],
    root: 196,
    brightness: 0.68,
  },
  missions: {
    bpm: 92,
    wave: 'triangle',
    bassWave: 'square',
    scale: [0, 3, 7, 10, 12, 10, 7, 3],
    bass: [0, 5, 3, 7, 0, 5, 8, 7],
    root: 174.61,
    brightness: 0.78,
  },
  survival: {
    bpm: 68,
    wave: 'sine',
    bassWave: 'sawtooth',
    scale: [0, 1, 7, 6, 0, 3, 8, 7],
    bass: [0, 0, 1, 1, -2, -2, 1, 1],
    root: 146.83,
    brightness: 0.42,
  },
  battle: {
    bpm: 116,
    wave: 'square',
    bassWave: 'sawtooth',
    scale: [0, 0, 7, 10, 0, 12, 10, 7],
    bass: [0, 0, -2, -2, 3, 3, 5, 5],
    root: 130.81,
    brightness: 0.88,
  },
};

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, Number(value) || 0));
}

function semitone(frequency, offset) {
  return frequency * (2 ** (offset / 12));
}

export class AudioManager extends EventTarget {
  constructor() {
    super();
    this.AudioContextClass = window.AudioContext || window.webkitAudioContext || null;
    this.supported = Boolean(this.AudioContextClass);
    this.enabled = localStorage.getItem(ENABLED_KEY) !== 'false';
    this.volume = clamp(localStorage.getItem(VOLUME_KEY) ?? 0.34, 0, 1);
    this.modeId = 'creative';
    this.context = null;
    this.masterGain = null;
    this.filter = null;
    this.compressor = null;
    this.scheduler = null;
    this.nextBeatAt = 0;
    this.step = 0;
    this.started = false;
    this.paused = true;
  }

  get state() {
    return {
      supported: this.supported,
      enabled: this.enabled,
      volume: this.volume,
      modeId: this.modeId,
      started: this.started,
      paused: this.paused,
    };
  }

  emitChange() {
    this.dispatchEvent(new CustomEvent('change', { detail: this.state }));
  }

  ensureContext() {
    if (!this.supported) return false;
    if (this.context) return true;
    this.context = new this.AudioContextClass({ latencyHint: 'interactive' });
    this.masterGain = this.context.createGain();
    this.filter = this.context.createBiquadFilter();
    this.compressor = this.context.createDynamicsCompressor();
    this.filter.type = 'lowpass';
    this.filter.frequency.value = 1600;
    this.filter.Q.value = 0.55;
    this.compressor.threshold.value = -24;
    this.compressor.knee.value = 20;
    this.compressor.ratio.value = 4;
    this.compressor.attack.value = 0.02;
    this.compressor.release.value = 0.28;
    this.masterGain.connect(this.filter);
    this.filter.connect(this.compressor);
    this.compressor.connect(this.context.destination);
    this.applyGain(true);
    return true;
  }

  async unlock() {
    if (!this.ensureContext()) return false;
    if (this.context.state === 'suspended') await this.context.resume();
    return this.context.state === 'running';
  }

  async start() {
    if (!this.enabled || !this.supported) return false;
    const unlocked = await this.unlock();
    if (!unlocked) return false;
    if (!this.started) {
      this.started = true;
      this.nextBeatAt = this.context.currentTime + 0.06;
      this.step = 0;
      this.scheduler = window.setInterval(() => this.scheduleAhead(), 80);
    }
    this.paused = false;
    this.applyTheme();
    this.applyGain();
    this.emitChange();
    return true;
  }

  stop() {
    if (this.scheduler) window.clearInterval(this.scheduler);
    this.scheduler = null;
    this.started = false;
    this.step = 0;
    if (this.masterGain && this.context) {
      this.masterGain.gain.cancelScheduledValues(this.context.currentTime);
      this.masterGain.gain.setTargetAtTime(0, this.context.currentTime, 0.06);
    }
    this.emitChange();
  }

  setMode(modeId) {
    this.modeId = THEMES[modeId] ? modeId : 'creative';
    this.step = 0;
    if (this.context) {
      this.nextBeatAt = this.context.currentTime + 0.08;
      this.applyTheme();
    }
    this.emitChange();
  }

  setPaused(paused) {
    this.paused = Boolean(paused);
    this.applyGain();
    this.emitChange();
  }

  async setEnabled(enabled) {
    this.enabled = Boolean(enabled);
    localStorage.setItem(ENABLED_KEY, String(this.enabled));
    if (this.enabled) await this.start();
    else this.applyGain();
    this.emitChange();
    return this.enabled;
  }

  async toggle() {
    return this.setEnabled(!this.enabled);
  }

  setVolume(value) {
    this.volume = clamp(value, 0, 1);
    localStorage.setItem(VOLUME_KEY, String(this.volume));
    this.applyGain();
    this.emitChange();
  }

  applyTheme() {
    if (!this.filter || !this.context) return;
    const theme = THEMES[this.modeId] || THEMES.creative;
    const cutoff = 650 + theme.brightness * 2550;
    this.filter.frequency.setTargetAtTime(cutoff, this.context.currentTime, 0.12);
  }

  applyGain(immediate = false) {
    if (!this.masterGain || !this.context) return;
    const target = this.enabled ? this.volume * (this.paused ? 0.18 : 0.42) : 0;
    const now = this.context.currentTime;
    this.masterGain.gain.cancelScheduledValues(now);
    if (immediate) this.masterGain.gain.setValueAtTime(target, now);
    else this.masterGain.gain.setTargetAtTime(target, now, 0.08);
  }

  scheduleAhead() {
    if (!this.context || !this.started || !this.enabled || this.context.state !== 'running') return;
    const theme = THEMES[this.modeId] || THEMES.creative;
    const beatDuration = 60 / theme.bpm / 2;
    const horizon = this.context.currentTime + 0.42;
    while (this.nextBeatAt < horizon) {
      this.scheduleStep(this.nextBeatAt, this.step, theme, beatDuration);
      this.nextBeatAt += beatDuration;
      this.step += 1;
    }
  }

  scheduleStep(time, step, theme, duration) {
    const melodyOffset = theme.scale[step % theme.scale.length];
    const bassOffset = theme.bass[Math.floor(step / 2) % theme.bass.length];
    const accent = step % 4 === 0;

    this.playTone({
      time,
      frequency: semitone(theme.root, melodyOffset + 12),
      duration: duration * 0.78,
      gain: accent ? 0.11 : 0.075,
      wave: theme.wave,
      detune: step % 2 ? 2 : -2,
    });

    if (step % 2 === 0) {
      this.playTone({
        time,
        frequency: semitone(theme.root / 2, bassOffset),
        duration: duration * 1.75,
        gain: this.modeId === 'battle' ? 0.12 : 0.08,
        wave: theme.bassWave,
        detune: 0,
      });
    }

    if (step % 8 === 0) {
      const chord = (this.modeId === 'survival' || this.modeId === 'defense') ? [0, 3, 7] : [0, 4, 7];
      chord.forEach((offset, index) => this.playTone({
        time: time + index * 0.018,
        frequency: semitone(theme.root, offset),
        duration: duration * 6.5,
        gain: 0.025,
        wave: 'sine',
        detune: index * 3 - 3,
      }));
    }
  }

  playTone({ time, frequency, duration, gain, wave, detune }) {
    if (!this.context || !this.masterGain) return;
    const oscillator = this.context.createOscillator();
    const envelope = this.context.createGain();
    oscillator.type = wave;
    oscillator.frequency.setValueAtTime(frequency, time);
    oscillator.detune.setValueAtTime(detune, time);
    envelope.gain.setValueAtTime(0.0001, time);
    envelope.gain.exponentialRampToValueAtTime(Math.max(0.0002, gain), time + Math.min(0.045, duration * 0.18));
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + Math.max(0.08, duration));
    oscillator.connect(envelope);
    envelope.connect(this.masterGain);
    oscillator.start(time);
    oscillator.stop(time + Math.max(0.1, duration) + 0.04);
  }
}
