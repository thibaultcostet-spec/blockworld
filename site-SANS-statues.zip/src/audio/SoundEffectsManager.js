const ENABLED_KEY = 'blockworld-v1.5-sfx-enabled';
const VOLUME_KEY = 'blockworld-v1.5-sfx-volume';

const WEAPON_PROFILES = {
  pistol: { noise: 0.075, noiseGain: 0.34, band: 1850, low: 150, lowGain: 0.21, tail: 0.08 },
  revolver: { noise: 0.13, noiseGain: 0.48, band: 1280, low: 92, lowGain: 0.34, tail: 0.16 },
  shotgun: { noise: 0.25, noiseGain: 0.62, band: 820, low: 62, lowGain: 0.48, tail: 0.24 },
  sniper: { noise: 0.19, noiseGain: 0.58, band: 2450, low: 72, lowGain: 0.42, tail: 0.27 },
  dmr: { noise: 0.14, noiseGain: 0.46, band: 1750, low: 104, lowGain: 0.31, tail: 0.17 },
  smg: { noise: 0.055, noiseGain: 0.28, band: 2050, low: 175, lowGain: 0.15, tail: 0.045 },
  carbine: { noise: 0.095, noiseGain: 0.38, band: 1580, low: 118, lowGain: 0.25, tail: 0.11 },
  ak47: { noise: 0.12, noiseGain: 0.46, band: 1230, low: 88, lowGain: 0.34, tail: 0.15 },
};

// Beta 4.27 : sons de construction par matériau et pas selon le sol (synthèse locale, aucun fichier audio).
export const BLOCK_MATERIAL = {
  grass: 'soil', dirt: 'soil', sand: 'sand', snow: 'snow', water: 'water', tall_grass: 'leaf', shrub: 'leaf', leaves: 'leaf',
  flower_red: 'leaf', flower_yellow: 'leaf', bamboo: 'wood', wood: 'wood', planks: 'wood', door: 'wood', ladder: 'wood',
  fence: 'wood', crate: 'wood', stone: 'stone', bricks: 'stone', concrete: 'stone', road: 'stone', roof: 'stone',
  obsidian: 'stone', glass: 'glass', window: 'glass', crystal: 'glass', lantern: 'metal', rail: 'metal', steel: 'metal'
};
export const MATERIAL_SOUNDS = {
  soil: { noise: 420, q: 0.7, tone: 0, gain: 0.10, duration: 0.07 },
  sand: { noise: 1500, q: 0.5, tone: 0, gain: 0.07, duration: 0.09 },
  snow: { noise: 2600, q: 0.6, tone: 0, gain: 0.06, duration: 0.10 },
  leaf: { noise: 3200, q: 0.9, tone: 0, gain: 0.05, duration: 0.08 },
  wood: { noise: 900, q: 2.4, tone: 210, gain: 0.11, duration: 0.09 },
  stone: { noise: 1250, q: 1.6, tone: 120, gain: 0.10, duration: 0.06 },
  glass: { noise: 4200, q: 3.5, tone: 1900, gain: 0.07, duration: 0.12 },
  metal: { noise: 2400, q: 6.0, tone: 880, gain: 0.07, duration: 0.14 },
  water: { noise: 700, q: 0.6, tone: 0, gain: 0.08, duration: 0.16 }
};
export function materialOf(blockType) { return BLOCK_MATERIAL[blockType] ?? 'stone'; }

function clamp(value, minimum, maximum) {
  return Math.min(maximum, Math.max(minimum, Number(value) || 0));
}

export class SoundEffectsManager extends EventTarget {
  constructor() {
    super();
    this.AudioContextClass = window.AudioContext || window.webkitAudioContext || null;
    this.supported = Boolean(this.AudioContextClass);
    this.enabled = localStorage.getItem(ENABLED_KEY) !== 'false';
    this.volume = clamp(localStorage.getItem(VOLUME_KEY) ?? 0.58, 0, 1);
    this.context = null;
    this.masterGain = null;
    this.compressor = null;
    this.noiseBuffer = null;
  }

  get state() {
    return { supported: this.supported, enabled: this.enabled, volume: this.volume };
  }

  emitChange() {
    this.dispatchEvent(new CustomEvent('change', { detail: this.state }));
  }

  ensureContext() {
    if (!this.supported) return false;
    if (this.context) return true;
    this.context = new this.AudioContextClass({ latencyHint: 'interactive' });
    this.masterGain = this.context.createGain();
    this.compressor = this.context.createDynamicsCompressor();
    this.compressor.threshold.value = -18;
    this.compressor.knee.value = 18;
    this.compressor.ratio.value = 6;
    this.compressor.attack.value = 0.003;
    this.compressor.release.value = 0.18;
    this.masterGain.connect(this.compressor);
    this.compressor.connect(this.context.destination);
    this.applyGain(true);
    return true;
  }

  async unlock() {
    if (!this.ensureContext()) return false;
    if (this.context.state === 'suspended') await this.context.resume();
    return this.context.state === 'running';
  }

  async setEnabled(enabled) {
    this.enabled = Boolean(enabled);
    localStorage.setItem(ENABLED_KEY, String(this.enabled));
    if (this.enabled) await this.unlock();
    this.applyGain();
    this.emitChange();
    return this.enabled;
  }

  toggle() {
    return this.setEnabled(!this.enabled);
  }

  setVolume(value) {
    this.volume = clamp(value, 0, 1);
    localStorage.setItem(VOLUME_KEY, String(this.volume));
    this.applyGain();
    this.emitChange();
  }

  applyGain(immediate = false) {
    if (!this.masterGain || !this.context) return;
    const target = this.enabled ? this.volume * 0.46 : 0;
    const now = this.context.currentTime;
    this.masterGain.gain.cancelScheduledValues(now);
    if (immediate) this.masterGain.gain.setValueAtTime(target, now);
    else this.masterGain.gain.setTargetAtTime(target, now, 0.035);
  }

  playWeapon(type) {
    if (!this.enabled) return;
    this.unlock().then((ready) => {
      if (!ready) return;
      if (WEAPON_PROFILES[type]) this.playGunshot(WEAPON_PROFILES[type]);
      else if (type === 'grenade') this.playExplosion({ strength: 0.8, duration: 0.48 });
      else if (type === 'fireball') this.playFireball();
      else if (type === 'icebolt') this.playIceBolt();
      else if (type === 'sword') this.playSword();
      else if (type === 'bow') { const now = this.context.currentTime; this.playTone({ time: now, frequency: 190, endFrequency: 120, duration: 0.18, gain: 0.10, wave: 'triangle' }); this.playNoise({ time: now, duration: 0.08, gain: 0.05, frequency: 2400, q: 1.2 }); }
      else if (type === 'slingshot') { const now = this.context.currentTime; this.playTone({ time: now, frequency: 520, endFrequency: 260, duration: 0.07, gain: 0.08, wave: 'square' }); }
      else if (type === 'net') { const now = this.context.currentTime; this.playNoise({ time: now, duration: 0.32, gain: 0.07, frequency: 900, q: 0.5, type: 'lowpass' }); }
      else this.playClick({ frequency: 620, duration: 0.045, gain: 0.11 });
    }).catch(() => {});
  }

  playGunshot(profile) {
    const now = this.context.currentTime;
    this.playNoise({
      time: now,
      duration: profile.noise,
      gain: profile.noiseGain,
      frequency: profile.band,
      q: 0.7,
      type: 'bandpass'
    });
    this.playTone({
      time: now,
      frequency: profile.low,
      endFrequency: Math.max(38, profile.low * 0.52),
      duration: profile.tail,
      gain: profile.lowGain,
      wave: 'sine'
    });
    this.playClick({ time: now + 0.012, frequency: profile.band * 1.7, duration: 0.018, gain: 0.09 });
  }

  // Beta 4.31 : annonce d'une attaque de monstre (grondement montant), au plus un toutes les 0,3 s.
  playTelegraph() {
    if (!this.enabled) return;
    const nowMs = performance.now();
    if (nowMs - (this.lastTelegraphMs ?? 0) < 300) return;
    this.lastTelegraphMs = nowMs;
    this.unlock().then((ready) => {
      if (!ready) return;
      const now = this.context.currentTime;
      this.playTone({ time: now, frequency: 150, endFrequency: 330, duration: 0.5, gain: 0.07, wave: 'sawtooth' });
      this.playNoise({ time: now, duration: 0.3, gain: 0.05, frequency: 900, q: 0.8, type: 'bandpass' });
    }).catch(() => {});
  }

  // Beta 4.32 : ouverture d'un coffre de grotte (cliquetis puis accord brillant).
  playChest() {
    if (!this.enabled) return;
    this.unlock().then((ready) => {
      if (!ready) return;
      const now = this.context.currentTime;
      this.playClick({ time: now, frequency: 760, duration: 0.03, gain: 0.14 });
      this.playClick({ time: now + 0.06, frequency: 520, duration: 0.04, gain: 0.12 });
      [523, 659, 784, 1046].forEach((frequency, index) => this.playTone({ time: now + 0.14 + index * 0.07, frequency, endFrequency: frequency * 1.01, duration: 0.22, gain: 0.07, wave: 'triangle' }));
    }).catch(() => {});
  }

  playEmpty() {
    if (!this.enabled) return;
    this.unlock().then((ready) => {
      if (!ready) return;
      const now = this.context.currentTime;
      this.playClick({ time: now, frequency: 980, duration: 0.025, gain: 0.16 });
      this.playClick({ time: now + 0.035, frequency: 530, duration: 0.035, gain: 0.12 });
    }).catch(() => {});
  }

  playReloadStart(type = '') {
    if (!this.enabled) return;
    this.unlock().then((ready) => {
      if (!ready) return;
      const now = this.context.currentTime;
      const heavy = ['shotgun', 'sniper', 'ak47', 'revolver'].includes(type);
      this.playClick({ time: now, frequency: heavy ? 360 : 520, duration: 0.045, gain: heavy ? 0.18 : 0.13 });
      this.playNoise({ time: now + 0.055, duration: 0.055, gain: 0.08, frequency: 2400, q: 1.1, type: 'highpass' });
    }).catch(() => {});
  }

  playReloadComplete(type = '') {
    if (!this.enabled) return;
    this.unlock().then((ready) => {
      if (!ready) return;
      const now = this.context.currentTime;
      const pump = type === 'shotgun';
      this.playClick({ time: now, frequency: pump ? 250 : 740, duration: pump ? 0.08 : 0.035, gain: pump ? 0.22 : 0.15 });
      this.playClick({ time: now + (pump ? 0.09 : 0.045), frequency: pump ? 430 : 1080, duration: 0.035, gain: 0.13 });
    }).catch(() => {});
  }

  playImpact(kind = 'block', material = '') {
    if (!this.enabled) return;
    this.unlock().then((ready) => {
      if (!ready) return;
      const now = this.context.currentTime;
      if (kind === 'monster' || kind === 'remote') {
        this.playNoise({ time: now, duration: 0.055, gain: 0.12, frequency: 520, q: 0.9, type: 'lowpass' });
        this.playTone({ time: now, frequency: 140, endFrequency: 90, duration: 0.07, gain: 0.09, wave: 'triangle' });
      } else {
        const glass = material === 'glass' || material === 'window';
        this.playClick({ time: now, frequency: glass ? 2100 : 680, duration: glass ? 0.065 : 0.025, gain: glass ? 0.12 : 0.075 });
      }
    }).catch(() => {});
  }

  playExplosion({ strength = 1, duration = 0.42 } = {}) {
    if (!this.context) return;
    const now = this.context.currentTime;
    this.playNoise({ time: now, duration, gain: 0.62 * strength, frequency: 680, q: 0.45, type: 'lowpass' });
    this.playTone({ time: now, frequency: 92, endFrequency: 36, duration: duration * 0.92, gain: 0.45 * strength, wave: 'sine' });
  }

  playFireball() {
    const now = this.context.currentTime;
    this.playNoise({ time: now, duration: 0.28, gain: 0.28, frequency: 1150, q: 0.8, type: 'bandpass' });
    this.playTone({ time: now, frequency: 190, endFrequency: 58, duration: 0.36, gain: 0.28, wave: 'sawtooth' });
  }

  playIceBolt() {
    const now = this.context.currentTime;
    [0, 0.025, 0.05].forEach((offset, index) => this.playTone({
      time: now + offset,
      frequency: 880 + index * 310,
      endFrequency: 1350 + index * 390,
      duration: 0.16,
      gain: 0.08,
      wave: 'sine'
    }));
    this.playNoise({ time: now, duration: 0.13, gain: 0.08, frequency: 3800, q: 1.8, type: 'highpass' });
  }

  playSword() {
    const now = this.context.currentTime;
    this.playNoise({ time: now, duration: 0.13, gain: 0.12, frequency: 2200, q: 0.7, type: 'highpass' });
    this.playTone({ time: now, frequency: 690, endFrequency: 240, duration: 0.12, gain: 0.07, wave: 'triangle' });
  }

  getNoiseBuffer() {
    if (this.noiseBuffer) return this.noiseBuffer;
    const length = Math.max(1, Math.floor(this.context.sampleRate * 0.7));
    const buffer = this.context.createBuffer(1, length, this.context.sampleRate);
    const data = buffer.getChannelData(0);
    let previous = 0;
    for (let index = 0; index < length; index += 1) {
      const white = Math.random() * 2 - 1;
      previous = previous * 0.34 + white * 0.66;
      data[index] = previous;
    }
    this.noiseBuffer = buffer;
    return buffer;
  }

  // Beta 4.27 : pose (« toc »), coup (plus sec) et casse (plus long et grave) selon le matériau.
  playBlock(blockType, action = 'place') {
    if (!this.enabled) return;
    const profile = MATERIAL_SOUNDS[materialOf(blockType)];
    this.unlock().then((ready) => {
      if (!ready) return;
      const now = this.context.currentTime;
      const scale = action === 'break' ? 1.6 : action === 'hit' ? 0.75 : 1;
      const pitch = action === 'break' ? 0.75 : action === 'hit' ? 1.15 : 1;
      this.playNoise({ time: now, duration: profile.duration * scale, gain: profile.gain * (action === 'break' ? 1.25 : 1), frequency: profile.noise * pitch, q: profile.q });
      if (profile.tone) this.playTone({ time: now, frequency: profile.tone * pitch, endFrequency: profile.tone * pitch * 0.7, duration: profile.duration * scale, gain: profile.gain * 0.6, wave: 'triangle' });
      if (action === 'break') this.playNoise({ time: now + 0.05, duration: 0.12, gain: profile.gain * 0.6, frequency: profile.noise * 0.5, q: 0.6, type: 'lowpass' });
    }).catch(() => {});
  }

  // Beta 4.27 : un pas discret, plus étouffé que la casse du même matériau.
  playStep(blockType) {
    if (!this.enabled || !this.context || this.context.state !== 'running') return;
    const profile = MATERIAL_SOUNDS[materialOf(blockType)];
    const now = this.context.currentTime;
    this.playNoise({ time: now, duration: Math.min(0.08, profile.duration), gain: profile.gain * 0.38, frequency: profile.noise * 0.8, q: profile.q * 0.7, type: 'bandpass' });
  }

  // Beta 4.27 : pêche, cuisine et photo.
  playSplash() { this.playSimple((now) => { this.playNoise({ time: now, duration: 0.22, gain: 0.10, frequency: 900, q: 0.5, type: 'lowpass' }); }); }
  playBite() { this.playSimple((now) => { this.playTone({ time: now, frequency: 420, endFrequency: 160, duration: 0.12, gain: 0.12, wave: 'sine' }); this.playNoise({ time: now, duration: 0.1, gain: 0.07, frequency: 700, q: 0.8 }); }); }
  playCatch() { this.playSimple((now) => { this.playTone({ time: now, frequency: 660, duration: 0.09, gain: 0.08, wave: 'triangle' }); this.playTone({ time: now + 0.1, frequency: 990, duration: 0.14, gain: 0.08, wave: 'triangle' }); }); }
  playSizzle() { this.playSimple((now) => { this.playNoise({ time: now, duration: 0.45, gain: 0.05, frequency: 5200, q: 0.7, type: 'highpass' }); }); }
  playCrackle() { if (!this.enabled || !this.context || this.context.state !== 'running') return; const now = this.context.currentTime; this.playNoise({ time: now, duration: 0.03, gain: 0.035, frequency: 2600 + Math.random() * 1800, q: 4 }); }
  playShutter() { this.playSimple((now) => { this.playClick({ time: now, frequency: 1600, duration: 0.02, gain: 0.08 }); this.playNoise({ time: now + 0.03, duration: 0.05, gain: 0.06, frequency: 3000, q: 1.2 }); }); }

  // Beta 4.29 : souffle du vent en parapente, plus fort quand on accélère.
  playWind(speed = 7) {
    if (!this.enabled || !this.context || this.context.state !== 'running') return;
    const now = this.context.currentTime;
    this.playNoise({ time: now, duration: 1.0, gain: 0.018 + Math.max(0, speed - 5) * 0.006, frequency: 380 + speed * 40, q: 0.4, type: 'lowpass' });
  }

  // Beta 4.28 : compagnon.
  playBark() { this.playSimple((now) => { this.playTone({ time: now, frequency: 420, endFrequency: 260, duration: 0.09, gain: 0.11, wave: 'sawtooth' }); this.playNoise({ time: now, duration: 0.08, gain: 0.06, frequency: 800, q: 1.5 }); this.playTone({ time: now + 0.14, frequency: 440, endFrequency: 280, duration: 0.08, gain: 0.09, wave: 'sawtooth' }); }); }
  playHappyDog() { this.playSimple((now) => { this.playTone({ time: now, frequency: 700, endFrequency: 1100, duration: 0.12, gain: 0.06, wave: 'sine' }); this.playTone({ time: now + 0.13, frequency: 900, endFrequency: 1300, duration: 0.1, gain: 0.05, wave: 'sine' }); }); }

  playSimple(callback) {
    if (!this.enabled) return;
    this.unlock().then((ready) => { if (ready) callback(this.context.currentTime); }).catch(() => {});
  }

  playNoise({ time, duration, gain, frequency, q = 0.8, type = 'bandpass' }) {
    if (!this.context || !this.masterGain) return;
    const source = this.context.createBufferSource();
    const filter = this.context.createBiquadFilter();
    const envelope = this.context.createGain();
    source.buffer = this.getNoiseBuffer();
    filter.type = type;
    filter.frequency.setValueAtTime(Math.max(80, frequency), time);
    filter.Q.setValueAtTime(q, time);
    envelope.gain.setValueAtTime(Math.max(0.0001, gain), time);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + Math.max(0.025, duration));
    source.connect(filter);
    filter.connect(envelope);
    envelope.connect(this.masterGain);
    source.start(time);
    source.stop(time + Math.max(0.035, duration) + 0.02);
  }

  playTone({ time, frequency, endFrequency = frequency, duration, gain, wave = 'sine' }) {
    if (!this.context || !this.masterGain) return;
    const oscillator = this.context.createOscillator();
    const envelope = this.context.createGain();
    oscillator.type = wave;
    oscillator.frequency.setValueAtTime(Math.max(25, frequency), time);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(25, endFrequency), time + Math.max(0.025, duration));
    envelope.gain.setValueAtTime(Math.max(0.0001, gain), time);
    envelope.gain.exponentialRampToValueAtTime(0.0001, time + Math.max(0.025, duration));
    oscillator.connect(envelope);
    envelope.connect(this.masterGain);
    oscillator.start(time);
    oscillator.stop(time + Math.max(0.035, duration) + 0.02);
  }

  playClick({ time = this.context?.currentTime ?? 0, frequency = 720, duration = 0.03, gain = 0.12 }) {
    this.playTone({ time, frequency, endFrequency: Math.max(90, frequency * 0.58), duration, gain, wave: 'square' });
  }
}
