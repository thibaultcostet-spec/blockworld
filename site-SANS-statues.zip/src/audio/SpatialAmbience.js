import { SPATIAL, ambienceGains, cryProfile, dripParams, dueCries } from './SpatialAudioRules.js';

// BlockWorld V3.0 Beta 4.32 — ambiance sonore spatialisée : écho et bourdonnement de grotte, gouttes d'eau stéréo,
// cris de monstres placés en 3D (PannerNode HRTF) avec écho dans la grotte. N'agit que si le son est déjà actif
// (contexte audio démarré par un geste du joueur) : jamais de démarrage forcé.

export class SpatialAmbience {
  constructor(game) {
    this.game = game;
    this.ready = false;
    this.timers = new WeakMap();
    this.dripTimer = 2;
  }

  get sfx() { return this.game.sfx; }

  setup() {
    const sfx = this.sfx;
    const ctx = sfx?.context;
    if (this.ready || !ctx || !sfx.masterGain || ctx.state !== 'running') return this.ready;
    this.ctx = ctx;
    this.echoIn = ctx.createGain();
    const delay = ctx.createDelay(1); delay.delayTime.value = SPATIAL.echo.delay;
    const feedback = ctx.createGain(); feedback.gain.value = SPATIAL.echo.feedback;
    const lowpass = ctx.createBiquadFilter(); lowpass.type = 'lowpass'; lowpass.frequency.value = SPATIAL.echo.lowpass;
    this.wet = ctx.createGain(); this.wet.gain.value = 0;
    this.echoIn.connect(delay); delay.connect(lowpass); lowpass.connect(this.wet); lowpass.connect(feedback); feedback.connect(delay);
    this.wet.connect(sfx.masterGain);
    const drone = ctx.createBufferSource(); drone.buffer = sfx.getNoiseBuffer(); drone.loop = true;
    const droneFilter = ctx.createBiquadFilter(); droneFilter.type = 'lowpass'; droneFilter.frequency.value = 140;
    this.droneGain = ctx.createGain(); this.droneGain.gain.value = 0;
    drone.connect(droneFilter); droneFilter.connect(this.droneGain); this.droneGain.connect(sfx.masterGain); drone.start();
    this.ready = true;
    return true;
  }

  /** `eye` : position de l'écouteur ; `forward` / `up` : vecteurs unitaires de la caméra. */
  update(delta, factor, eye, forward, up, monsters) {
    if (!this.sfx?.enabled || !eye || !this.setup()) return;
    const { ctx } = this;
    const gains = ambienceGains(factor);
    this.droneGain.gain.setTargetAtTime(gains.drone, ctx.currentTime, 0.4);
    this.wet.gain.setTargetAtTime(gains.wet, ctx.currentTime, 0.3);
    this.placeListener(eye, forward, up);
    if (gains.drips) {
      this.dripTimer -= delta;
      if (this.dripTimer <= 0) { const drip = dripParams(); this.dripTimer = drip.delay; this.drip(drip); }
    }
    for (const { monster, distance } of dueCries(monsters, eye, this.timers, delta)) this.cry(monster, distance, factor);
  }

  placeListener(eye, forward, up) {
    const l = this.ctx.listener, t = this.ctx.currentTime;
    if (l.positionX) {
      l.positionX.setValueAtTime(eye.x, t); l.positionY.setValueAtTime(eye.y, t); l.positionZ.setValueAtTime(eye.z, t);
      l.forwardX.setValueAtTime(forward.x, t); l.forwardY.setValueAtTime(forward.y, t); l.forwardZ.setValueAtTime(forward.z, t);
      l.upX.setValueAtTime(up.x, t); l.upY.setValueAtTime(up.y, t); l.upZ.setValueAtTime(up.z, t);
    } else { l.setPosition?.(eye.x, eye.y, eye.z); l.setOrientation?.(forward.x, forward.y, forward.z, up.x, up.y, up.z); }
  }

  drip({ frequency, pan, gain }) {
    const { ctx } = this, t = ctx.currentTime;
    const osc = ctx.createOscillator(), env = ctx.createGain(), panner = ctx.createStereoPanner?.();
    osc.type = 'sine'; osc.frequency.setValueAtTime(frequency, t); osc.frequency.exponentialRampToValueAtTime(frequency * 0.55, t + 0.09);
    env.gain.setValueAtTime(gain, t); env.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
    osc.connect(env);
    const out = panner ?? env;
    if (panner) { panner.pan.value = pan; env.connect(panner); }
    out.connect(this.sfx.masterGain);
    const send = ctx.createGain(); send.gain.value = 0.9; out.connect(send); send.connect(this.echoIn);
    osc.start(t); osc.stop(t + 0.16);
  }

  cry(monster, distance, factor) {
    const profile = cryProfile(monster.type);
    if (!profile) return;
    const { ctx } = this, t = ctx.currentTime, sfx = this.sfx;
    const panner = ctx.createPanner();
    panner.panningModel = 'HRTF'; panner.distanceModel = 'inverse'; panner.refDistance = 3; panner.rolloffFactor = 1.4; panner.maxDistance = SPATIAL.cryRange + 8;
    const p = monster.group.position;
    if (panner.positionX) { panner.positionX.setValueAtTime(p.x, t); panner.positionY.setValueAtTime(p.y + 1, t); panner.positionZ.setValueAtTime(p.z, t); } else panner.setPosition(p.x, p.y + 1, p.z);
    const out = ctx.createGain(); out.gain.value = profile.gain;
    out.connect(panner); panner.connect(sfx.masterGain);
    const send = ctx.createGain(); send.gain.value = 0.15 + 0.6 * factor; panner.connect(send); send.connect(this.echoIn);
    const stop = t + profile.duration + 0.1;
    const tone = (type, from, to, gain = 1, lfo = null) => {
      const osc = ctx.createOscillator(), env = ctx.createGain();
      osc.type = type; osc.frequency.setValueAtTime(from, t); osc.frequency.exponentialRampToValueAtTime(Math.max(25, to), t + profile.duration);
      env.gain.setValueAtTime(gain, t); env.gain.exponentialRampToValueAtTime(0.0001, t + profile.duration);
      if (lfo) { const l = ctx.createOscillator(), depth = ctx.createGain(); l.frequency.value = lfo.rate; depth.gain.value = lfo.depth; l.connect(depth); depth.connect(osc.frequency); l.start(t); l.stop(stop); }
      osc.connect(env); env.connect(out); osc.start(t); osc.stop(stop);
    };
    const noise = (frequency, filter = 'bandpass', gain = 1, q = 1.5) => {
      const src = ctx.createBufferSource(), flt = ctx.createBiquadFilter(), env = ctx.createGain();
      src.buffer = sfx.getNoiseBuffer(); flt.type = filter; flt.frequency.value = frequency; flt.Q.value = q;
      env.gain.setValueAtTime(gain, t); env.gain.exponentialRampToValueAtTime(0.0001, t + profile.duration);
      src.connect(flt); flt.connect(env); env.connect(out); src.start(t); src.stop(stop);
    };
    switch (profile.kind) {
      case 'squelch': tone('sine', 190, 80, 1, { rate: 17, depth: 28 }); noise(500, 'lowpass', 0.4); break;
      case 'hiss': noise(5200, 'bandpass', 1, 2.2); tone('sine', 2400, 3300, 0.25); break;
      case 'cackle': tone('triangle', 330, 190, 1, { rate: 14, depth: 22 }); tone('triangle', 660, 380, 0.3, { rate: 14, depth: 40 }); break;
      case 'rumble': tone('sawtooth', 72, 44, 1); noise(160, 'lowpass', 0.8, 0.7); break;
      default: tone('sine', 560, 380, 1, { rate: 7, depth: 30 }); tone('sine', 840, 570, 0.35, { rate: 7, depth: 45 }); break; // wail
    }
  }
}
