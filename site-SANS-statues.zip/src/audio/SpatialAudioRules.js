// BlockWorld V3.0 Beta 4.32 — règles pures de l'ambiance sonore spatialisée (testable sous Node).
// Cris de monstres positionnés en 3D, gouttes et écho dans les grottes. Synthèse locale : aucun fichier audio.

export const SPATIAL = {
  cryRange: 32, cryDelay: { min: 4.5, max: 11 },
  dripDelay: { min: 1.2, max: 4.5 },
  echo: { delay: 0.23, feedback: 0.42, lowpass: 1800 },
  droneGain: 0.06, wetGain: 0.5, activeFactor: 0.2
};

/** Profil sonore de chaque espèce (`null` : pas de cri). */
export const CRY_PROFILES = {
  slime: { kind: 'squelch', gain: 0.22, duration: 0.42 },
  spider: { kind: 'hiss', gain: 0.2, duration: 0.36 },
  goblin: { kind: 'cackle', gain: 0.2, duration: 0.5 },
  golem: { kind: 'rumble', gain: 0.3, duration: 0.95 },
  wraith: { kind: 'wail', gain: 0.14, duration: 1.2 },
  training_dummy: null
};

export const cryProfile = (type) => CRY_PROFILES[type] ?? null;

export function nextCryDelay(distance, rng = Math.random) {
  const { min, max } = SPATIAL.cryDelay;
  return min + rng() * (max - min) + (Math.min(distance, SPATIAL.cryRange) / SPATIAL.cryRange) * 3; // plus rare au loin
}

export function dripParams(rng = Math.random) {
  return { frequency: 900 + rng() * 900, pan: rng() * 2 - 1, gain: 0.05 + rng() * 0.05, delay: SPATIAL.dripDelay.min + rng() * (SPATIAL.dripDelay.max - SPATIAL.dripDelay.min) };
}

/** Gains de l'ambiance de grotte selon le facteur « dans la grotte » (0 dehors, 1 au fond). */
export function ambienceGains(factor) {
  const f = Math.max(0, Math.min(1, factor));
  return { drone: SPATIAL.droneGain * f, wet: SPATIAL.wetGain * f, drips: f >= SPATIAL.activeFactor };
}

/** Quels monstres crient maintenant : vivants, à portée, avec un profil et une échéance dépassée. */
export function dueCries(monsters, eye, timers, delta, rng = Math.random) {
  const due = [];
  for (const monster of monsters) {
    if (!monster.alive || !cryProfile(monster.type)) continue;
    const p = monster.group.position;
    const distance = Math.hypot(p.x - eye.x, p.y - eye.y, p.z - eye.z);
    if (distance > SPATIAL.cryRange) continue;
    const left = (timers.get(monster) ?? rng() * SPATIAL.cryDelay.max) - delta; // première échéance étalée : pas de chœur simultané
    if (left > 0) { timers.set(monster, left); continue; }
    timers.set(monster, nextCryDelay(distance, rng));
    due.push({ monster, distance });
  }
  return due;
}
