// BlockWorld V3.0 Beta 4.35 — bootstrap externe (autorisé par la CSP 'self').
// Un script inline serait bloqué en silence par la Content-Security-Policy du serveur.
  (() => {
    const box=document.getElementById('boot-diagnostic');
    const lines=[];
    const note=(msg,kind='')=>{
      lines.push(msg);
      while(lines.length>8)lines.shift();
      box.textContent=lines.join('\n');
      if(kind)box.className=kind;
      box.hidden=false; // Beta 4.26 : un incident ultérieur redevient visible
      console.log('[BlockWorld boot]',msg);
    };
    let runtimeErrors=0;
    window.addEventListener('error',()=>{runtimeErrors+=1;});
    window.addEventListener('unhandledrejection',()=>{runtimeErrors+=1;});
    window.addEventListener('error',(event)=>note(`ERREUR JS : ${event.message || 'inconnue'}${event.filename ? ` — ${event.filename}:${event.lineno||0}` : ''}`,'error'));
    window.addEventListener('unhandledrejection',(event)=>note(`ERREUR PROMESSE : ${event.reason?.message || event.reason || 'inconnue'}`,'error'));
    const probe=async(url)=>{
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),6500);
      try{const response=await fetch(url,{cache:'no-store',mode:'cors',signal:controller.signal});return response.ok;}catch(_e){return false;}finally{clearTimeout(timer);}
    };
    const load=async()=>{
      note('1/4 HTML chargé');
      // Beta 4.21 : moteur 3D intégré au jeu (hors ligne, application Android installée) ; CDN en secours.
      const candidates=[
        {name:'moteur intégré',three:'./vendor/three/build/three.module.min.js',addons:'./vendor/three/examples/jsm/'},
        {name:'jsDelivr',three:'https://cdn.jsdelivr.net/npm/three@0.185.1/build/three.module.js',addons:'https://cdn.jsdelivr.net/npm/three@0.185.1/examples/jsm/'},
        {name:'unpkg',three:'https://unpkg.com/three@0.185.1/build/three.module.js',addons:'https://unpkg.com/three@0.185.1/examples/jsm/'}
      ];
      let source=null;
      for(const candidate of candidates){
        note(`2/4 Test moteur 3D : ${candidate.name}…`);
        if(await probe(candidate.three)){source=candidate;break;}
      }
      if(!source){
        note('BLOCAGE : Three.js inaccessible. Vérifier connexion/filtrage Internet. Le jeu ne peut pas créer la scène 3D.','error');
        return;
      }
      note(`2/4 Moteur 3D accessible via ${source.name}`);
      const map=document.createElement('script');
      map.type='importmap';
      map.textContent=JSON.stringify({imports:{three:source.three,'three/addons/':source.addons}});
      document.head.appendChild(map);
      await new Promise(resolve=>requestAnimationFrame(()=>resolve()));
      note('3/4 Chargement du jeu…');
      try{
        await import(new URL('./src/main.js?v=3.0.0-beta.4.35',document.baseURI).href);
        note('3/4 Module principal chargé');
      }catch(error){
        note(`BLOCAGE MODULE : ${error?.message || error}`,'error');
        return;
      }
      setTimeout(()=>{
        const canvas=document.querySelector('#game canvas, canvas');
        // Beta 4.10 : ne plus annoncer « OK » si une erreur JS est survenue pendant le démarrage.
        if(canvas&&runtimeErrors){note(`4/4 Canvas créé mais ${runtimeErrors} erreur(s) JS : affichage probablement incomplet`,'error');}
        else if(canvas){note('4/4 Canvas WebGL créé — démarrage OK','ok');setTimeout(()=>{if(box.className==='ok')box.hidden=true;},4500);} // Beta 4.26 : bandeau retiré après un démarrage réussi (il restait à 25 % par-dessus le jeu)
        else note('BLOCAGE : module chargé mais aucun canvas WebGL créé.','error');
      },2200);
    };
    load();
  })();
