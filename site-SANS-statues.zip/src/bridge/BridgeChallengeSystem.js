// BlockWorld V3.0 Beta 4.30 — défis d'ingénieur : chantier, budget, efforts colorés en direct, flèche,
// essai au convoi avec rupture progressive, étoiles et badges.
//
// Le chantier (culées, rochers, rivière, escaliers) est posé devant le joueur, orienté selon +x. Les blocs du
// chantier sont protégés et mémorisés pour être retirés à la fin ; ce qui occupait la place est restauré.
import * as THREE from 'three';
import { BLOCK_TYPES } from '../world/BlockTypes.js';
import { makeCrackTexture } from '../graphics/BuildFeedback.js';
import {
  CHALLENGES, chiefEngineer, getChallenge, getConvoy, inClearance, insideZone, readBadges, recordResult,
  requiredDeck, scoreRun, siteLayout, starText
} from './BridgeChallenges.js';
import { BRIDGE_MATERIALS, addConvoyLoads, formatDeflection, formatPercent, materialOf, selfWeightLoads, simulateCrossing, solve, utilizationColor } from './BridgeSolver.js';
import { buildSign, buildVehicle } from './ConvoyModels.js';

export const SITE_KEY = 'blockworld-v4.30-bridge-site';
const CONVOY_SPEED = 3;           // m/s
const OVERLAY_CAPACITY = 900;
const PARTITIVE = { Planches: 'des planches', Bois: 'du bois', Pierre: 'de la pierre', Briques: 'des briques', 'Béton': 'du béton', Acier: 'de l’acier' };
const MODE_TEXT = { traction: 'traction', compression: 'écrasement', flexion: 'flexion', cisaillement: 'cisaillement', 'poussée hors du bloc': 'poussée mal centrée' };

const k3 = (x, y, z) => `${x}|${y}|${z}`;
const TERRAIN = new Set(['grass', 'dirt', 'sand', 'stone', 'snow', 'road']);

/** Sommet du terrain naturel (on ignore arbres, feuillages et décor). */
function terrainTop(world, x, z) {
  const column = world.columns.get(world.columnKey(x, z));
  let top = 0;
  if (column) for (const block of column.values()) if (TERRAIN.has(block.type) && block.y > top) top = block.y;
  return top;
}

/** Schéma de la légende (SVG en ligne) : couleurs, traction / compression, flèche. */
export const LEGEND_SVG = `<svg viewBox="0 0 360 118" role="img" aria-label="Lecture des couleurs : vert peu sollicité, rouge proche de la rupture ; flèche = affaissement du tablier">
<defs><linearGradient id="bw-util" x1="0" x2="1"><stop offset="0" stop-color="#2ecc5c"/><stop offset=".5" stop-color="#8cdb3d"/><stop offset=".75" stop-color="#fad633"/><stop offset=".9" stop-color="#ff8c1f"/><stop offset="1" stop-color="#ff2b3a"/></linearGradient></defs>
<rect x="8" y="8" width="314" height="14" rx="7" fill="url(#bw-util)"/>
<text x="8" y="36" fill="#c9d6e2" font-size="11">0 % : tranquille</text><text x="165" y="36" fill="#c9d6e2" font-size="11" text-anchor="middle">75 % : ça travaille</text><text x="322" y="36" fill="#ffb3b8" font-size="11" text-anchor="end">100 % : ça casse</text>
<rect x="8" y="58" width="22" height="34" fill="#7d8791"/><rect x="300" y="58" width="22" height="34" fill="#7d8791"/>
<path d="M30 60 H300" stroke="#e8c27a" stroke-width="6"/><path d="M30 60 Q165 84 300 60" stroke="#6fd3ff" stroke-width="2" stroke-dasharray="5 4" fill="none"/>
<path d="M165 62 V71" stroke="#6fd3ff" stroke-width="1.5"/><text x="165" y="92" fill="#6fd3ff" font-size="11" text-anchor="middle">flèche (déformée exagérée)</text>
<text x="8" y="110" fill="#ffb3b8" font-size="11">← → traction : on tire</text><text x="178" y="110" fill="#9fd0ff" font-size="11">→ ← compression : on écrase</text>
</svg>`;

export class BridgeChallengeSystem {
  constructor(game, { panel, bar } = {}) {
    this.game = game;
    this.panel = panel;
    this.bar = bar;
    this.active = null;
    this.test = null;
    this.result = null;
    this.showEfforts = true;
    this.previewTimer = -1;
    this.preview = null;
    this.debris = [];
    this.group = new THREE.Group();
    this.group.name = 'BridgeChallenge';
    game.scene.add(this.group);

    const unit = new THREE.BoxGeometry(1.035, 1.035, 1.035);
    this.overlay = new THREE.InstancedMesh(unit, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false }), OVERLAY_CAPACITY);
    this.overlay.name = 'BridgeEfforts';
    this.overlay.count = 0;
    this.overlay.renderOrder = 6;
    this.overlay.frustumCulled = false;
    this.ghosts = new THREE.InstancedMesh(new THREE.BoxGeometry(0.97, 0.97, 0.97), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3, depthWrite: false }), 128);
    this.ghosts.name = 'BridgeDeckGhosts';
    this.ghosts.count = 0;
    this.ghosts.frustumCulled = false;
    this.cracks = new THREE.InstancedMesh(new THREE.BoxGeometry(1.012, 1.012, 1.012), new THREE.MeshBasicMaterial({ map: makeCrackTexture(4), transparent: true, alphaTest: 0.25, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }), OVERLAY_CAPACITY);
    this.cracks.name = 'BridgeCracks';
    this.cracks.count = 0;
    this.cracks.frustumCulled = false;
    this.deflectionLine = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0x6fd3ff, transparent: true, opacity: 0.95, depthTest: false }));
    this.deflectionLine.renderOrder = 7;
    this.deflectionLine.visible = false;
    this.debrisGeometry = new THREE.BoxGeometry(0.96, 0.96, 0.96);
    this.group.add(this.overlay, this.ghosts, this.cracks, this.deflectionLine);
    this.matrix = new THREE.Matrix4();
    this.color = new THREE.Color();

    this.panel?.addEventListener('click', (event) => {
      const start = event.target.closest('[data-bridge-start]');
      if (start) { this.start(start.dataset.bridgeStart); return; }
      const action = event.target.closest('[data-bridge-action]')?.dataset.bridgeAction;
      if (action) this.handleAction(action);
    });
    this.bar?.addEventListener('click', (event) => {
      const action = event.target.closest('[data-bridge-action]')?.dataset.bridgeAction;
      if (action) this.handleAction(action);
    });
  }

  // --- Panneau -------------------------------------------------------------------------------------------

  handleAction(action) {
    if (action === 'close') this.game.toggleBridgePanel(false);
    else if (action === 'panel') this.game.toggleBridgePanel(true);
    else if (action === 'test') { this.game.toggleBridgePanel(false); this.runTest(); }
    else if (action === 'efforts') this.toggleEfforts();
    else if (action === 'quit') { this.quit(); this.game.toggleBridgePanel(false); }
    else if (action === 'retry') { this.result = null; this.game.toggleBridgePanel(false); }
    else if (action === 'next') {
      const index = CHALLENGES.findIndex((c) => c.id === this.active?.challenge.id);
      const next = CHALLENGES[index + 1];
      this.result = null;
      if (next) this.start(next.id); else this.game.toggleBridgePanel(false);
    }
  }

  isOpen() { return Boolean(this.panel && !this.panel.classList.contains('hidden')); }

  setOpen(open) {
    if (!this.panel) return;
    if (open) this.render();
    this.panel.classList.toggle('hidden', !open);
    this.panel.setAttribute('aria-hidden', String(!open));
  }

  render() {
    if (!this.panel) return;
    const badges = readBadges();
    const available = this.availability();
    const cards = CHALLENGES.map((c, i) => {
      const stars = badges[c.id]?.stars ?? 0;
      const convoy = getConvoy(c.convoy);
      const mats = c.materials.map((m) => `<span class="bridge-mat" title="${BRIDGE_MATERIALS[m].label} : ${BRIDGE_MATERIALS[m].cost} point${BRIDGE_MATERIALS[m].cost > 1 ? 's' : ''}">${BRIDGE_MATERIALS[m].label}${BRIDGE_MATERIALS[m].cost > 1 ? ` ×${BRIDGE_MATERIALS[m].cost}` : ''}</span>`).join('');
      const current = this.active?.challenge.id === c.id;
      return `<article class="bridge-challenge${stars ? ' done' : ''}${current ? ' current' : ''}">
        <header><span class="bridge-icon">${c.icon}</span><div><strong>${i + 1}. ${c.name}</strong><small>Brèche ${c.gap} m · ${convoy.icon} ${convoy.label} (${convoy.total} kN) · budget ${c.budget} pts</small></div><span class="bridge-stars" aria-label="${stars} étoile(s) sur 3">${starText(stars)}</span></header>
        <p>${c.story}</p>
        <div class="bridge-mats">${mats}</div>
        <footer><span class="bridge-badge${stars ? '' : ' locked'}" title="Badge">${c.badge.icon} ${c.badge.label}</span>
        <button type="button" data-bridge-start="${c.id}" ${available.ok ? '' : 'disabled'}>${current ? '↺ Recommencer' : stars ? 'Rejouer' : 'Commencer'}</button></footer>
      </article>`;
    }).join('');
    const chief = chiefEngineer(badges);
    const current = this.active ? `<section class="bridge-current">
        <strong>${this.active.challenge.icon} Chantier en cours : ${this.active.challenge.name}</strong>
        <span>${this.forecastText()}</span>
        <div><button type="button" class="primary-button" data-bridge-action="test">▶ Lancer le convoi</button><button type="button" data-bridge-action="efforts">${this.showEfforts ? '🎨 Masquer les efforts' : '🎨 Montrer les efforts'}</button><button type="button" class="danger-button" data-bridge-action="quit">✖ Quitter le chantier</button></div>
      </section>` : '';
    const result = this.result ? this.renderResult() : '';
    this.panel.innerHTML = `<div class="bridge-card">
      <header class="bridge-head"><strong>🌉 Défis d’ingénieur</strong><small>Construis un pont, le calcul colore chaque bloc selon l’effort qu’il subit, puis le convoi passe… ou pas !</small><button type="button" data-bridge-action="close" aria-label="Fermer">✕</button></header>
      ${result}${current}
      ${available.ok ? '' : `<p class="bridge-warning">${available.reason}</p>`}
      <details class="bridge-help"${this.active || this.result ? '' : ' open'}><summary>Comment lire le calcul ?</summary>${LEGEND_SVG}
        <p>Chaque bloc est coloré selon son <b>taux de travail</b> : l’effort qu’il subit comparé à ce qu’il peut supporter. Le bois résiste bien en traction et en flexion, la pierre et la brique surtout en compression : une <b>voûte</b> les fait travailler écrasées. Des blocs qui se touchent par une arête forment une <b>diagonale</b> (jambe de force). La <b>flèche</b> est l’affaissement du tablier sous le convoi.</p></details>
      <div class="bridge-list">${cards}</div>
      <footer class="bridge-foot">${chief ? '🏅 Ingénieur en chef : les cinq défis ont trois étoiles !' : '★ le convoi passe · ★ budget ≤ 75 % · ★ marge : aucun bloc au-delà de 80 %'}</footer>
    </div>`;
  }

  renderResult() {
    const r = this.result;
    if (r.success) {
      return `<section class="bridge-result success"><strong>🎉 ${r.convoy} ${r.convoy.includes(' et ') ? 'ont' : 'a'} traversé !</strong>
        <span class="bridge-stars big">${starText(r.stars)}</span>
        <ul><li>${r.crossed ? '★' : '☆'} le convoi passe</li><li>${r.thrifty ? '★' : '☆'} budget : ${r.used} / ${r.budget} points (≤ ${Math.floor(r.budget * 0.75)} pour l’étoile)</li><li>${r.margin ? '★' : '☆'} marge : taux maximal ${formatPercent(r.maxU)}${r.breaks ? `, ${r.breaks} liaison${r.breaks > 1 ? 's' : ''} rompue${r.breaks > 1 ? 's' : ''}` : ''} (≤ 80 % pour l’étoile)</li></ul>
        <small>Flèche maximale : ${formatDeflection(r.deflection)}${r.newBadge ? ` · nouveau badge ${r.newBadge}` : ''}</small>
        <div><button type="button" class="primary-button" data-bridge-action="next">Défi suivant ▶</button><button type="button" data-bridge-action="retry">Améliorer mon pont</button></div></section>`;
    }
    return `<section class="bridge-result failure"><strong>💥 Le pont a cédé !</strong><span>${r.reason}</span>
      <small>Le pont a été remis comme avant l’essai : renforce les blocs orange et rouges, puis relance le convoi.</small>
      <div><button type="button" class="primary-button" data-bridge-action="retry">Réessayer</button><button type="button" class="danger-button" data-bridge-action="quit">Quitter le chantier</button></div></section>`;
  }

  availability() {
    const g = this.game;
    if (g.multiplayerActive) return { ok: false, reason: 'Les défis d’ingénieur se jouent en solo.' };
    if (g.selectedModeId === 'battle') return { ok: false, reason: 'Pas de chantier pendant une Bataille : choisis Créatif, Survie ou Missions.' };
    if (this.test) return { ok: false, reason: 'Essai en cours…' };
    return { ok: true };
  }

  // --- Chantier ------------------------------------------------------------------------------------------

  start(id) {
    const g = this.game;
    const available = this.availability();
    if (!available.ok) { g.hud.setStatus(available.reason); return; }
    const challenge = getChallenge(id);
    if (!challenge) return;
    if (this.active) this.quit({ silent: true });
    const spot = this.findSpot(challenge);
    const layout = siteLayout(challenge, spot);
    this.active = { challenge, layout, support: new Set(), decor: new Set(), removed: [], worldId: g.selectedWorldId };
    this.buildSite();
    this.saveState();
    this.result = null;
    this.equipMaterials();
    this.placePlayer('build');
    this.schedulePreview(0);
    this.updateBar();
    g.toggleBridgePanel(false);
    g.hud.setStatus(`${challenge.icon} ${challenge.name} : ${challenge.hint} · Astuce : pour avancer au-dessus du vide, vise le bord du dessus du dernier bloc (face au vide) et clique droit`);
  }

  /** Cherche devant le joueur un terrain assez plat, sans monument, dans la carte. */
  findSpot(challenge) {
    const g = this.game;
    const eye = g.player.getEyePosition();
    const yaw = g.player.yaw ?? 0;
    const forward = { x: -Math.sin(yaw), z: -Math.cos(yaw) };
    const right = { x: -forward.z, z: forward.x };
    const total = challenge.gap + 14;
    const half = (g.world.currentDefinition?.size ?? 224) / 2 - 4;
    const pois = g.world.currentDefinition?.pointsOfInterest ?? [];
    let best = null;
    for (const distance of [total / 2 + 6, total / 2 + 16, total / 2 + 28, total / 2 + 42]) {
      for (const lateral of [0, 14, -14, 28, -28]) {
        const cx = eye.x + forward.x * distance + right.x * lateral;
        const cz = eye.z + forward.z * distance + right.z * lateral;
        const x0 = Math.round(cx - total / 2), zc = Math.round(cz);
        const x1 = x0 + total - 1;
        if (x0 - 14 < -half || x1 + 14 > half || zc - 7 < -half || zc + 8 > half) continue;
        let min = Infinity, max = -Infinity, clutter = 0;
        for (let x = x0; x <= x1; x += 1) for (let z = zc - 4; z <= zc + 5; z += 1) {
          const y = terrainTop(g.world, x, z);
          const top = g.world.getTopBlock(x, z, { solidOnly: true });
          min = Math.min(min, y); max = Math.max(max, y);
          if (top && top.y > y) clutter += 1;
        }
        const poi = pois.some((p) => Math.hypot(p.x - (x0 + total / 2), p.z - zc) < (p.discoveryRadius ?? 16) + total / 2 + 6);
        const score = (max - min) * 3 + clutter * 2 + (poi ? 400 : 0) + Math.abs(lateral) * 0.3 + distance * 0.2;
        if (!best || score < best.score) best = { x0, zc, groundTop: max, score };
      }
    }
    if (!best) {
      best = { x0: Math.round(eye.x) + 4, zc: Math.round(eye.z), groundTop: terrainTop(g.world, Math.round(eye.x), Math.round(eye.z)) };
    }
    return best;
  }

  /** Pose les blocs du chantier en une passe (un seul recalcul des tronçons de terrain). */
  buildSite() {
    const { world } = this.game;
    const { layout: L, support, decor, removed } = this.active;
    const touched = new Set();
    const edit = (fn) => { world.isBatching = true; try { fn(); } finally { world.isBatching = false; } };
    const groundAt = (x, z) => terrainTop(world, x, z);
    const clear = (x, y, z) => {
      const block = world.getBlock(x, y, z);
      if (!block) return;
      removed.push({ x, y, z, type: block.type, protectedBlock: Boolean(block.protectedBlock) });
      world.removeBlock(x, y, z, { persist: false, force: true });
      touched.add(k3(x, y, z));
    };
    const put = (x, y, z, type, set) => {
      if (world.getBlock(x, y, z)) clear(x, y, z);
      if (world.addBlock(x, y, z, type, { persist: false, protectedBlock: true })) { set.add(k3(x, y, z)); touched.add(k3(x, y, z)); }
    };
    edit(() => {
      // 1. Place nette : tout ce qui dépasse dans le volume du chantier (arbres, décor) est mis de côté.
      for (let x = L.x0 - 12; x <= L.x1 + 12; x += 1) for (let z = L.zMin - 2; z <= L.zMax + 2; z += 1) {
        const inner = x >= L.x0 && x <= L.x1 && z >= L.zMin && z <= L.zMax;
        for (let y = L.waterY; y <= L.yMax; y += 1) {
          const block = world.getBlock(x, y, z);
          if (!block) continue;
          if (!inner && y <= groundAt(x, z) && TERRAIN.has(block.type)) continue;
          if (!inner && y < L.deckY - 12) continue;
          clear(x, y, z);
        }
      }
      // 2. Culées (pierre, chaussée en route) et rochers : ce sont les appuis.
      for (let x = L.x0; x <= L.x1; x += 1) {
        const inGap = x >= L.gapX1 && x <= L.gapX2;
        const pier = L.piers.find((p) => x >= p.x1 && x <= p.x2);
        if (inGap && !pier) continue;
        for (let z = L.zMin; z <= L.zMax; z += 1) {
          const top = inGap ? pier.top : L.deckY;
          for (let y = groundAt(x, z) + 1; y <= top; y += 1) {
            const lane = L.lane.includes(z);
            const type = inGap ? 'stone' : y === L.deckY ? (lane ? 'road' : 'concrete') : (x === L.gapX1 - 1 || x === L.gapX2 + 1) ? 'bricks' : 'stone';
            put(x, y, z, type, support);
          }
        }
      }
      // 3. Rivière sous la brèche (sable puis une couche d'eau), un peu plus large que le chantier.
      for (let x = L.gapX1; x <= L.gapX2; x += 1) for (let z = L.zMin - 2; z <= L.zMax + 2; z += 1) {
        if (L.piers.some((p) => x >= p.x1 && x <= p.x2) && z >= L.zMin && z <= L.zMax) continue;
        for (let y = groundAt(x, z) + 1; y <= L.waterY; y += 1) put(x, y, z, y === L.waterY ? 'water' : 'sand', decor);
      }
      // 4. Escaliers d'accès aux deux bouts, garde-corps sur les culées.
      for (const [sx, dir] of [[L.x0 - 1, -1], [L.x1 + 1, 1]]) {
        for (let i = 0; i < 14; i += 1) {
          const x = sx + dir * i;
          const stepTop = L.deckY - 1 - i;
          let any = false;
          for (const z of L.lane) {
            const g0 = groundAt(x, z);
            if (stepTop <= g0) continue;
            any = true;
            for (let y = g0 + 1; y <= stepTop; y += 1) put(x, y, z, 'stone', decor);
          }
          if (!any) break;
        }
      }
      for (const [xa, xb] of [[L.x0, L.gapX1 - 1], [L.gapX2 + 1, L.x1]]) {
        for (let x = xa; x <= xb; x += 2) for (const z of [L.zMin, L.zMax]) put(x, L.deckY + 1, z, 'fence', decor);
      }
    });
    this.rebuildTouched(touched);
    // Panneau du chantier.
    this.sign?.removeFromParent();
    const c = this.active.challenge;
    this.sign = buildSign([`${c.icon} ${c.name}`, `Brèche ${c.gap} m · budget ${c.budget} pts`, `${getConvoy(c.convoy).icon} ${getConvoy(c.convoy).label}`]);
    this.sign.position.set(L.x0 + 1.5, L.deckY + 0.5, L.zMin - 0.2);
    this.group.add(this.sign);
  }

  rebuildTouched(keys) {
    const { world } = this.game;
    const chunks = new Set();
    for (const key of keys) {
      const [x, , z] = key.split('|').map(Number);
      chunks.add(world.chunkKey(x, z));
      world.syncDeltaForKey(key);
    }
    for (const chunk of chunks) if (world.chunks.has(chunk)) world.rebuildChunk(chunk);
    world.refreshBlockMeshes?.();
    world.save();
    this.game.stability?.scan();
    this.game.nightLights?.scanLanterns?.();
  }

  /** Retire le chantier et le pont du joueur, restaure ce qui occupait la place. */
  quit({ silent = false } = {}) {
    if (!this.active) return;
    const { world } = this.game;
    const { support, decor, removed } = this.active;
    this.stopTest(false);
    const touched = new Set();
    world.isBatching = true;
    try {
      for (const block of this.playerBlocks()) { world.removeBlock(block.x, block.y, block.z, { persist: false, force: true }); touched.add(k3(block.x, block.y, block.z)); }
      for (const key of [...support, ...decor]) { const [x, y, z] = key.split('|').map(Number); world.removeBlock(x, y, z, { persist: false, force: true }); touched.add(key); }
      for (const b of removed) { if (!world.getBlock(b.x, b.y, b.z)) world.addBlock(b.x, b.y, b.z, b.type, { persist: false, protectedBlock: b.protectedBlock }); touched.add(k3(b.x, b.y, b.z)); }
    } finally { world.isBatching = false; }
    this.rebuildTouched(touched);
    this.active = null;
    this.result = null;
    this.preview = null;
    this.sign?.removeFromParent();
    this.sign = null;
    this.clearVisuals();
    try { localStorage.removeItem(SITE_KEY); } catch { /* stockage indisponible */ }
    this.updateBar();
    if (!silent) this.game.hud.setStatus('Chantier rangé : le terrain est revenu comme avant');
  }

  /** Oublie le chantier sans toucher au monde (monde régénéré). */
  discard() {
    this.stopTest(false);
    this.active = null; this.result = null; this.preview = null;
    this.sign?.removeFromParent(); this.sign = null;
    this.clearVisuals();
    try { localStorage.removeItem(SITE_KEY); } catch { /* stockage indisponible */ }
    this.updateBar();
  }

  saveState() {
    if (!this.active) return;
    const { challenge, layout, support, decor, removed, worldId } = this.active;
    const state = { worldId, id: challenge.id, x0: layout.x0, zc: layout.zc, groundTop: layout.deckY - challenge.clearance - 1, support: [...support], decor: [...decor], removed };
    try { localStorage.setItem(SITE_KEY, JSON.stringify(state)); } catch { /* quota */ }
  }

  /** Au chargement d'un continent : reprend un chantier laissé en cours (si ses culées sont toujours là). */
  setWorld(definition) {
    this.stopTest(false);
    this.active = null; this.preview = null; this.result = null;
    this.sign?.removeFromParent(); this.sign = null;
    this.clearVisuals();
    if (this.game.multiplayerActive) { this.updateBar(); return; } // le chantier solo attend le retour en solo
    let state = null;
    try { state = JSON.parse(localStorage.getItem(SITE_KEY) ?? 'null'); } catch { state = null; }
    if (state && state.worldId === definition.id) {
      const challenge = getChallenge(state.id);
      const probe = state.support?.[0]?.split('|').map(Number);
      const intact = probe && this.game.world.getBlock(probe[0], probe[1], probe[2])?.protectedBlock;
      if (challenge && intact) {
        const layout = siteLayout(challenge, { x0: state.x0, zc: state.zc, groundTop: state.groundTop });
        this.active = { challenge, layout, support: new Set(state.support), decor: new Set(state.decor ?? []), removed: state.removed ?? [], worldId: definition.id };
        this.sign = buildSign([`${challenge.icon} ${challenge.name}`, `Brèche ${challenge.gap} m · budget ${challenge.budget} pts`, `${getConvoy(challenge.convoy).icon} ${getConvoy(challenge.convoy).label}`]);
        this.sign.position.set(layout.x0 + 1.5, layout.deckY + 0.5, layout.zMin - 0.2);
        this.group.add(this.sign);
        this.schedulePreview(0.3);
      } else if (!intact) {
        try { localStorage.removeItem(SITE_KEY); } catch { /* stockage indisponible */ }
      }
    }
    this.updateBar();
  }

  equipMaterials() {
    const hud = this.game.hud;
    if (!hud?.quickbarIds) return;
    const ids = this.active.challenge.materials.map((m) => `block-${m}`).filter((id) => !hud.allowedItemIds || hud.allowedItemIds.has(id));
    ids.slice(0, 6).forEach((id, i) => { hud.quickbarIds[i] = id; });
    hud.saveQuickbar?.();
    hud.renderHotbar?.();
    hud.select?.(0);
  }

  placePlayer(where) {
    const g = this.game;
    const L = this.active.layout;
    const p = g.player;
    const V = p.eyePosition.constructor;
    const eye = p.eyeHeight ?? 1.6;
    if (where === 'side') {
      // Pendant l'essai, le joueur s'écarte de la voie (sur la culée ouest, côté garde-corps).
      p.teleportTo(new V(L.x0 + 1, L.deckY + 0.5 + eye + 0.05, L.zMin + 0.2));
      p.yaw = -Math.PI / 2;
      p.pitch = -0.2;
    } else {
      p.teleportTo(new V(L.x0 + 3, L.deckY + 0.5 + eye + 0.05, L.zc + 0.5));
      p.yaw = -Math.PI / 2; // regarde vers +x, la brèche
      p.pitch = -0.32;
    }
    p.camera?.rotation.set(p.pitch, p.yaw, 0, 'YXZ');
  }

  // --- Règles de pose ------------------------------------------------------------------------------------

  isSiteBlock(x, y, z) {
    if (!this.active) return false;
    const key = k3(Math.round(x), Math.round(y), Math.round(z));
    return this.active.support.has(key) || this.active.decor.has(key);
  }

  /** Blocs du joueur dans le volume du chantier. */
  playerBlocks() {
    if (!this.active) return [];
    const { world } = this.game;
    const { layout: L, support, decor } = this.active;
    const out = [];
    for (let x = L.x0; x <= L.x1; x += 1) for (let z = L.zMin; z <= L.zMax; z += 1) {
      const column = world.columns.get(world.columnKey(x, z));
      if (!column) continue;
      for (const block of column.values()) {
        if (block.y < L.yMin || block.y > L.yMax) continue;
        const key = k3(x, block.y, z);
        if (support.has(key) || decor.has(key) || !BLOCK_TYPES[block.type]?.solid) continue;
        out.push({ x, y: block.y, z, type: block.type });
      }
    }
    return out;
  }

  budgetUsed(blocks = this.playerBlocks()) { return blocks.reduce((sum, b) => sum + materialOf(b.type).cost, 0); }

  canPlace(position, type) {
    if (!this.active) return { ok: true };
    const x = Math.round(position.x), y = Math.round(position.y), z = Math.round(position.z);
    const L = this.active.layout;
    const c = this.active.challenge;
    const inGapColumns = x >= L.gapX1 && x <= L.gapX2 && z >= L.zMin - 2 && z <= L.zMax + 2;
    if (inGapColumns && y <= L.waterY) return { ok: false, reason: '🌊 Pas de fondation dans la rivière : appuie-toi sur les culées (ou les rochers)' };
    if (!insideZone(L, x, y, z)) return { ok: true };
    if (this.test) return { ok: false, reason: 'Essai en cours : attends la fin du passage du convoi' };
    if (inClearance(L, x, y, z)) return { ok: false, reason: '🚚 Garde la voie libre : le convoi passe ici (construis sur les côtés ou dessous)' };
    if (!c.materials.includes(type)) return { ok: false, reason: `Ce défi se construit en ${c.materials.map((m) => BRIDGE_MATERIALS[m].label.toLowerCase()).join(', ')}` };
    const used = this.budgetUsed();
    const cost = materialOf(type).cost;
    if (used + cost > c.budget) return { ok: false, reason: `💰 Budget épuisé (${used} / ${c.budget} points) : retire des blocs ou choisis moins cher` };
    return { ok: true };
  }

  onBlockChanged(position) {
    if (!this.active) return;
    if (position && !insideZone(this.active.layout, Math.round(position.x), Math.round(position.y), Math.round(position.z))) return;
    this.schedulePreview(0.18);
  }

  schedulePreview(delay = 0.18) { this.previewTimer = delay; }

  isSupportCell = (x, y, z) => this.active?.support.has(k3(x, y, z)) ?? false;

  // --- Calcul en direct ----------------------------------------------------------------------------------

  computePreview() {
    if (!this.active) return;
    const blocks = this.playerBlocks();
    const { layout: L, challenge } = this.active;
    const convoy = getConvoy(challenge.convoy);
    const missing = requiredDeck(L).filter((cell) => !blocks.some((b) => b.x === cell.x && b.y === cell.y && b.z === cell.z));
    let sim = null;
    if (blocks.length) {
      try { sim = simulateCrossing(blocks, this.isSupportCell, convoy, L); } catch (error) { console.warn('Calcul du pont :', error); }
    }
    this.preview = { blocks, missing, sim, used: this.budgetUsed(blocks) };
    this.renderOverlay();
    this.updateBar();
  }

  renderOverlay() {
    const p = this.preview;
    if (!p || !this.active) { this.clearVisuals(); return; }
    const L = this.active.layout;
    // Contours de la chaussée à remplir.
    this.ghosts.count = Math.min(p.missing.length, this.ghosts.instanceMatrix.count);
    p.missing.slice(0, this.ghosts.count).forEach((cell, i) => { this.matrix.makeTranslation(cell.x, cell.y, cell.z); this.ghosts.setMatrixAt(i, this.matrix); });
    this.ghosts.instanceMatrix.needsUpdate = true;
    this.ghosts.visible = !this.test;
    // Couleurs d'effort.
    const sim = p.sim;
    let n = 0, c = 0;
    if (sim && this.showEfforts && !this.test) {
      for (const b of p.blocks) {
        if (n >= OVERLAY_CAPACITY) break;
        const node = `${b.x}|${b.y}`;
        const u = sim.fallen.has(node) ? Infinity : (sim.nodeMax.get(node) ?? 0);
        this.matrix.makeTranslation(b.x, b.y, b.z);
        this.overlay.setMatrixAt(n, this.matrix);
        this.overlay.setColorAt(n, this.color.setHex(utilizationColor(u)));
        n += 1;
        if (sim.damaged.has(node) && c < OVERLAY_CAPACITY) { this.cracks.setMatrixAt(c, this.matrix); c += 1; }
      }
    }
    this.overlay.count = n;
    this.overlay.instanceMatrix.needsUpdate = true;
    if (this.overlay.instanceColor) this.overlay.instanceColor.needsUpdate = true;
    this.cracks.count = this.test ? this.cracks.count : c;
    this.cracks.instanceMatrix.needsUpdate = true;
    // Déformée exagérée sous la position la plus défavorable du convoi.
    this.deflectionLine.visible = false;
    if (sim?.success && this.showEfforts && !this.test && sim.deflection.value > 0) {
      const convoy = getConvoy(this.active.challenge.convoy);
      const loads = selfWeightLoads(sim.model);
      if (addConvoyLoads(sim.model, loads, convoy, sim.deflection.front, L.deckY, L.gapX1, L.gapX2)) {
        const disp = solve(sim.model, loads);
        const amp = Math.min(80, 1.4 / sim.deflection.value);
        const points = [new THREE.Vector3(L.gapX1 - 0.5, L.deckY - 0.62, L.zMin - 0.55)];
        for (let x = L.gapX1; x <= L.gapX2; x += 1) {
          const node = sim.model.nodes.get(`${x}|${L.deckY}`);
          const uy = node && node.index >= 0 ? disp[node.index * 3 + 1] : 0;
          points.push(new THREE.Vector3(x, L.deckY - 0.62 + uy * amp, L.zMin - 0.55));
        }
        points.push(new THREE.Vector3(L.gapX2 + 0.5, L.deckY - 0.62, L.zMin - 0.55));
        this.deflectionLine.geometry.dispose();
        this.deflectionLine.geometry = new THREE.BufferGeometry().setFromPoints(points);
        this.deflectionLine.visible = true;
        this.deflectionAmp = Math.round(amp);
      }
    }
  }

  clearVisuals() {
    this.overlay.count = 0; this.ghosts.count = 0; this.cracks.count = 0;
    this.deflectionLine.visible = false;
    for (const part of this.test?.parts ?? []) part.group.removeFromParent();
  }

  toggleEfforts(force = null) {
    this.showEfforts = force ?? !this.showEfforts;
    this.renderOverlay();
    this.updateBar();
    if (this.isOpen()) this.render();
    this.game.hud.setStatus(this.showEfforts ? '🎨 Efforts affichés : vert tranquille → rouge, ça casse · ligne bleue = flèche exagérée' : 'Efforts masqués');
  }

  describeWeakPoint(sim) {
    const w = sim?.worst;
    if (!w || !this.active) return '';
    const L = this.active.layout;
    const x = (w.element.a.x + w.element.b.x) / 2;
    const fromWest = x - (L.gapX1 - 0.5), fromEast = (L.gapX2 + 0.5) - x;
    const where = Math.min(fromWest, fromEast) < 1.2 ? `contre la culée ${fromWest < fromEast ? 'ouest' : 'est'}` : Math.abs(fromWest - fromEast) < 2 ? 'au milieu' : `à ${Math.round(Math.min(fromWest, fromEast))} m de la culée ${fromWest < fromEast ? 'ouest' : 'est'}`;
    return `${MODE_TEXT[w.mode] ?? w.mode} ${PARTITIVE[w.element.material] ?? ''} ${where}`.replace(/\s+/g, ' ').trim();
  }

  describeFailure(sim) {
    const first = sim.events.find((e) => e.type === 'break') ?? sim.events.find((e) => e.type === 'fall');
    if (!first) return 'le tablier ne porte pas le convoi';
    if (first.type === 'fall') return first.reason === 'mécanisme' ? 'des blocs ne sont pas assez liés : l’assemblage se replie' : 'des blocs ne sont reliés à aucune culée';
    const L = this.active.layout;
    const x = (first.a.x + first.b.x) / 2;
    const d = Math.min(x - (L.gapX1 - 0.5), (L.gapX2 + 0.5) - x);
    return `${MODE_TEXT[first.mode] ?? first.mode} ${PARTITIVE[first.material] ?? ''} à ${Math.max(0, Math.round(d))} m d’une culée`.replace(/\s+/g, ' ');
  }

  forecastText() {
    const p = this.preview;
    if (!this.active) return '';
    if (!p) return 'Calcul en cours…';
    if (p.missing.length) return `🧩 Chaussée incomplète : ${p.missing.length} case${p.missing.length > 1 ? 's' : ''} blanche${p.missing.length > 1 ? 's' : ''} à remplir`;
    const sim = p.sim;
    if (!sim) return '';
    if (!sim.success) return `🔴 Prévision : le pont cède (${this.describeFailure(sim)})`;
    const tag = sim.breaks ? `🟠 Prévision : ça passe de justesse (${sim.breaks} liaison${sim.breaks > 1 ? 's' : ''} cède${sim.breaks > 1 ? 'nt' : ''})` : sim.maxU > 0.8 ? '🟡 Prévision : ça passe, sans marge' : '🟢 Prévision : ça passe';
    return `${tag} · taux max ${formatPercent(sim.maxU)} · flèche ${formatDeflection(sim.deflection.value)}`;
  }

  updateBar() {
    if (!this.bar) return;
    const visible = Boolean(this.active);
    this.bar.classList.toggle('hidden', !visible);
    document.body.classList.toggle('bridge-active', visible);
    if (!visible) return;
    const c = this.active.challenge;
    const used = this.preview?.used ?? this.budgetUsed();
    const set = (sel, text) => { const el = this.bar.querySelector(sel); if (el) el.textContent = text; };
    set('[data-bridge-title]', `${c.icon} ${c.name}`);
    set('[data-bridge-budget]', `💰 ${used} / ${c.budget} pts`);
    set('[data-bridge-forecast]', this.test ? `${getConvoy(c.convoy).icon} Essai en cours…` : this.forecastText());
    const weak = this.preview?.sim?.success && !this.test ? this.describeWeakPoint(this.preview.sim) : '';
    set('[data-bridge-weak]', weak ? `Point le plus sollicité : ${weak}${this.deflectionLine.visible ? ` · déformée ×${this.deflectionAmp}` : ''}` : '');
    const effortsButton = this.bar.querySelector('[data-bridge-action="efforts"]');
    effortsButton?.setAttribute('aria-pressed', String(this.showEfforts));
    const testButton = this.bar.querySelector('[data-bridge-action="test"]');
    if (testButton) testButton.disabled = Boolean(this.test);
    const budget = this.bar.querySelector('[data-bridge-budget]');
    budget?.classList.toggle('full', used >= c.budget);
  }

  // --- Essai au convoi -----------------------------------------------------------------------------------

  runTest() {
    const g = this.game;
    if (!this.active || this.test) return;
    this.computePreview();
    const p = this.preview;
    if (p.missing.length) { g.hud.setStatus(`🧩 Termine d’abord la chaussée : ${p.missing.length} case${p.missing.length > 1 ? 's' : ''} blanche${p.missing.length > 1 ? 's' : ''}`); return; }
    const { layout: L, challenge } = this.active;
    const convoy = getConvoy(challenge.convoy);
    const sim = p.sim ?? simulateCrossing(p.blocks, this.isSupportCell, convoy, L);
    const parts = convoy.parts.map((part) => ({ ...part, ...buildVehicle(part.kind) }));
    for (const part of parts) { part.group.position.set(-9999, 0, 0); this.group.add(part.group); }
    const length = Math.max(...convoy.axles.map((a) => -a.dx));
    this.test = {
      sim, convoy, parts, snapshot: p.blocks.map((b) => ({ ...b })),
      front: L.gapX1 - 3, end: L.gapX2 + 3 + length, eventIndex: 0, fell: null, fallTime: 0, done: false, wait: 0.8, lastCreak: 0
    };
    this.cracks.count = 0;
    this.overlay.count = 0; this.ghosts.visible = false; this.deflectionLine.visible = false;
    this.placePlayer('side');
    this.setupCinematic();
    g.sfx?.playClick?.({ frequency: 520, duration: 0.08, gain: 0.08 });
    g.hud.setStatus(`${convoy.icon} ${convoy.label} : en route ! (${convoy.total} kN)`);
    this.updateBar();
  }

  applyEvent(event) {
    const g = this.game;
    if (event.type === 'fall') {
      for (const node of event.nodes) for (const b of node.blocks) {
        const block = g.world.getBlock(b.x, b.y, b.z);
        if (!block) continue;
        g.world.removeBlock(b.x, b.y, b.z, { persist: false, force: true });
        const mesh = new THREE.Mesh(this.debrisGeometry, g.world.materials[b.type] ?? g.world.materials.stone);
        mesh.position.set(b.x, b.y, b.z);
        mesh.castShadow = true;
        this.group.add(mesh);
        this.debris.push({ mesh, vy: 0.5 + Math.random(), vx: (Math.random() - 0.5) * 1.2, vz: (Math.random() - 0.5) * 1.2, spin: new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(4), splashed: false });
      }
      g.sfx?.playBlock?.(event.nodes[0]?.blocks[0]?.type ?? 'stone', 'break');
      g.sfx?.playExplosion?.({ strength: 0.35, duration: 0.3 });
      return;
    }
    // Fissure (maçonnerie) ou rupture : marques de fissures, poussière, craquement.
    const L = this.active.layout;
    for (const n of [event.a, event.b]) {
      for (let z = L.zMin; z <= L.zMax; z += 1) {
        const block = g.world.getBlock(n.x, n.y, z);
        if (!block || this.isSiteBlock(n.x, n.y, z)) continue;
        if (this.cracks.count < OVERLAY_CAPACITY) { this.matrix.makeTranslation(n.x, n.y, z); this.cracks.setMatrixAt(this.cracks.count, this.matrix); this.cracks.count += 1; }
        if (event.type === 'break') g.buildFeedback?.burst?.(new THREE.Vector3(n.x, n.y, z), block.type, { count: 8, spread: 0.5, lift: 0.8 });
      }
    }
    this.cracks.instanceMatrix.needsUpdate = true;
    g.sfx?.playBlock?.(event.material === 'Pierre' ? 'stone' : event.material === 'Acier' ? 'steel' : 'wood', event.type === 'break' ? 'break' : 'hit');
  }

  updateTest(delta) {
    const t = this.test;
    const g = this.game;
    const L = this.active.layout;
    if (t.wait > 0) { t.wait -= delta; if (t.wait > 0) return; }
    if (!t.fell && !t.done) {
      t.front = Math.min(t.end, t.front + CONVOY_SPEED * delta);
      if (t.sim.convoyFell !== null && t.front >= t.sim.convoyFell) { t.fell = t.sim.convoyFell; t.fallTime = 0; }
      if (t.front >= t.end) t.done = true;
    }
    while (t.eventIndex < t.sim.events.length && t.sim.events[t.eventIndex].front <= t.front + 1e-6) { this.applyEvent(t.sim.events[t.eventIndex]); t.eventIndex += 1; }
    if (t.fell) t.fallTime += delta;
    for (const part of t.parts) {
      const x = t.front + part.dx;
      const visible = x - part.length < L.x1 + 0.5 && x > L.x0 - 0.5;
      part.group.visible = visible;
      let y = L.deckY + 0.5, rotZ = 0;
      if (t.fell && x - part.length < L.gapX2 + 0.5 && x > L.gapX1 - 0.5) {
        const fall = t.fallTime;
        y -= 0.5 * 18 * fall * fall;
        rotZ = -Math.min(1.1, fall * 1.4);
        y = Math.max(L.waterY - 0.2, y);
      }
      part.group.position.set(x, y, L.zc + 0.5);
      part.group.rotation.z = rotZ;
      if (!t.fell) for (const wheel of part.wheels) wheel.rotation.z -= (CONVOY_SPEED * delta) / 0.48;
    }
    if (t.fell && t.fallTime > 2.4) this.finishTest();
    else if (t.done) { t.doneTime = (t.doneTime ?? 0) + delta; if (t.doneTime > 0.6) this.finishTest(); }
    if (!t.fell) {
      t.lastCreak -= delta;
      if (t.lastCreak <= 0 && t.sim.maxU > 0.75) { t.lastCreak = 0.7; g.sfx?.playBlock?.('wood', 'hit'); }
    }
  }

  finishTest() {
    const t = this.test;
    const g = this.game;
    const { challenge } = this.active;
    const success = t.sim.success;
    const used = this.budgetUsed(t.snapshot);
    if (success) {
      const score = scoreRun({ success, used, budget: challenge.budget, maxU: t.sim.breaks ? Infinity : t.sim.maxU });
      const record = recordResult(challenge.id, score.stars);
      this.result = { success, ...score, used, budget: challenge.budget, maxU: t.sim.maxU, breaks: t.sim.breaks, deflection: t.sim.deflection.value, convoy: getConvoy(challenge.convoy).name, newBadge: record.firstBadge ? `${challenge.badge.icon} ${challenge.badge.label}` : '' };
      g.sfx?.playCatch?.();
      const crossed = getConvoy(challenge.convoy).name;
      g.hud.setStatus(`🎉 ${crossed} ${crossed.includes(' et ') ? 'ont' : 'a'} traversé : ${starText(score.stars)}`);
    } else {
      this.result = { success, reason: this.describeFailure(t.sim) };
      g.hud.setStatus(`💥 Le pont a cédé : ${this.result.reason}`);
    }
    this.stopTest(true);
    this.placePlayer('build');
    g.toggleBridgePanel(true);
  }

  /** Fin d'essai : retire le convoi, remet en place les blocs tombés (le joueur peut corriger). */
  stopTest(restore = true) {
    const t = this.test;
    if (!t) return;
    for (const part of t.parts) part.group.removeFromParent();
    for (const d of this.debris) d.mesh.removeFromParent();
    this.debris = [];
    if (restore && this.active) {
      const { world } = this.game;
      const touched = new Set();
      world.isBatching = true;
      try {
        for (const b of t.snapshot) if (!world.getBlock(b.x, b.y, b.z)) { world.addBlock(b.x, b.y, b.z, b.type, { persist: false }); touched.add(k3(b.x, b.y, b.z)); }
      } finally { world.isBatching = false; }
      if (touched.size) this.rebuildTouched(touched);
    }
    this.test = null;
    this.cracks.count = 0;
    this.schedulePreview(0.05);
    this.updateBar();
  }

  /** Caméra de l'essai : de côté, du côté le plus dégagé, elle suit le convoi. */
  setupCinematic() {
    const { world } = this.game;
    const L = this.active.layout;
    const mid = (L.gapX1 + L.gapX2) / 2;
    const distance = Math.max(13, Math.min(30, (L.gapX2 - L.gapX1 + 1) * 0.85 + 9));
    const sides = [-1, 1].map((side) => {
      const z = side < 0 ? L.zMin - distance : L.zMax + distance;
      let top = 0;
      for (let dx = -3; dx <= 3; dx += 1) for (let dz = -2; dz <= 2; dz += 1) top = Math.max(top, terrainTop(world, Math.round(mid + dx * 3), Math.round(z + dz)));
      return { z, top };
    }).sort((a, b) => a.top - b.top);
    this.test.camera = { mid, z: sides[0].z, y: Math.max(L.deckY + 3.5, sides[0].top + 3) };
  }

  updateCinematic() {
    const cam = this.test?.camera;
    if (!cam) return;
    const L = this.active.layout;
    const camera = this.game.camera;
    const follow = Math.max(L.x0, Math.min(L.x1, this.test.front - 2));
    camera.position.set(cam.mid + (follow - cam.mid) * 0.3, cam.y, cam.z);
    camera.lookAt(cam.mid + (follow - cam.mid) * 0.65, L.deckY - 1, L.zc + 0.5);
  }

  update(delta) {
    if (this.test && this.game.player.isActive()) this.updateTest(delta);
    if (this.test) this.updateCinematic();
    if (this.previewTimer >= 0 && !this.test) {
      this.previewTimer -= delta;
      if (this.previewTimer < 0) this.computePreview();
    }
    if (this.ghosts.count) this.ghosts.material.opacity = 0.22 + 0.14 * Math.sin(performance.now() * 0.005);
    for (const d of [...this.debris]) {
      d.vy -= 18 * delta;
      d.mesh.position.x += d.vx * delta; d.mesh.position.z += d.vz * delta; d.mesh.position.y += d.vy * delta;
      d.mesh.rotation.x += d.spin.x * delta; d.mesh.rotation.y += d.spin.y * delta; d.mesh.rotation.z += d.spin.z * delta;
      const floor = this.active ? this.active.layout.waterY : 0;
      if (d.mesh.position.y < floor + 0.2) {
        if (!d.splashed) { d.splashed = true; this.game.sfx?.playSplash?.(); }
        d.mesh.position.y = floor + 0.2; d.vy = 0; d.vx *= 0.9; d.vz *= 0.9;
      }
    }
  }
}
