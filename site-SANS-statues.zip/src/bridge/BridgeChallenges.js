// BlockWorld V3.0 Beta 4.30 — défis d'ingénieur : catalogue, géométrie des chantiers, étoiles et badges.
// Module pur (testable sous Node). Les chantiers sont orientés selon +x : culée ouest, brèche, culée est.

export const CONVOYS = Object.freeze({
  cart:   { id: 'cart', label: 'Charrette', name: 'La charrette', icon: '🛒', total: 16, axles: [{ dx: 0, P: 8 }, { dx: -2, P: 8 }], parts: [{ dx: 0, kind: 'cart' }] },
  truck:  { id: 'truck', label: 'Camion', name: 'Le camion', icon: '🚚', total: 50, axles: [{ dx: 0, P: 20 }, { dx: -3, P: 30 }], parts: [{ dx: 0, kind: 'truck' }] },
  heavy:  { id: 'heavy', label: 'Camion-benne chargé', name: 'Le camion-benne', icon: '🚛', total: 110, axles: [{ dx: 0, P: 30 }, { dx: -2.5, P: 40 }, { dx: -3.5, P: 40 }], parts: [{ dx: 0, kind: 'dumper' }] },
  convoy: { id: 'convoy', label: 'Convoi de 3 camions', name: 'Le convoi', icon: '🚚🚚🚚', total: 150, axles: [0, -7, -14].flatMap((o) => [{ dx: o, P: 20 }, { dx: o - 3, P: 30 }]), parts: [0, -7, -14].map((dx) => ({ dx, kind: 'truck' })) },
  maputo: { id: 'maputo', label: 'Bus et camion-benne', name: 'Le bus et le camion-benne', icon: '🚌🚛', total: 170, axles: [{ dx: 0, P: 25 }, { dx: -5, P: 35 }, { dx: -9, P: 30 }, { dx: -11.5, P: 40 }, { dx: -12.5, P: 40 }], parts: [{ dx: 0, kind: 'bus' }, { dx: -9, kind: 'dumper' }] }
});

export const CHALLENGES = Object.freeze([
  {
    id: 'ruisseau', name: 'Le petit ruisseau', icon: '🌱', gap: 4, clearance: 3, budget: 12,
    materials: ['planks', 'wood'], convoy: 'cart',
    story: 'La charrette du village doit traverser le ruisseau. Pose la chaussée entre les deux berges.',
    hint: 'Remplis les contours blancs : c’est la route du convoi.',
    badge: { icon: '🪵', label: 'Pontonnier' }
  },
  {
    id: 'ravin', name: 'Le ravin', icon: '⛰️', gap: 8, clearance: 6, budget: 40,
    materials: ['planks', 'wood', 'stone'], convoy: 'truck',
    story: 'Un camion de matériaux doit franchir le ravin. Une seule épaisseur de planches ne suffira pas…',
    hint: 'Plus une poutre est haute, plus elle est solide. Des blocs en diagonale (qui se touchent par une arête) font des jambes de force.',
    badge: { icon: '🪚', label: 'Charpentier' }
  },
  {
    id: 'riviere', name: 'La rivière', icon: '🌊', gap: 12, clearance: 7, budget: 70,
    materials: ['stone', 'bricks', 'planks', 'wood'], convoy: 'heavy',
    story: 'Le camion-benne est lourd et la rivière large. Les Romains auraient une idée…',
    hint: 'La pierre résiste très bien à la compression mais casse en traction : une voûte la fait travailler comprimée.',
    badge: { icon: '🏛️', label: 'Maître des voûtes' }
  },
  {
    id: 'canyon', name: 'Le canyon', icon: '🏜️', gap: 16, clearance: 9, budget: 110,
    materials: ['planks', 'wood', 'stone', 'steel'], convoy: 'convoy',
    story: 'Trois camions à la file au-dessus d’un canyon profond. Une simple poutre, même épaisse, ne suffira pas.',
    hint: 'Des jambes de force (diagonales parties du pied des culées) ou une voûte raccourcissent la portée. L’acier coûte cher mais résiste à tout.',
    badge: { icon: '🔺', label: 'Ingénieur des grandes portées' }
  },
  {
    id: 'maputo', name: 'La baie de Maputo', icon: '🌉', gap: 24, clearance: 9, budget: 130,
    materials: ['planks', 'wood', 'stone', 'bricks', 'concrete', 'steel'], convoy: 'maputo', piers: [7, 15],
    story: 'Comme à Maputo, un grand pont franchit la baie. Deux rochers peuvent servir de piles.',
    hint: 'Appuie-toi sur les rochers : trois travées courtes valent mieux qu’une grande.',
    badge: { icon: '🌉', label: 'Bâtisseur de Maputo' }
  }
]);

export const BADGE_KEY = 'blockworld-v4.30-bridge-badges';
export const STAR_RULES = Object.freeze({ budgetRatio: 0.75, margin: 0.8 });

export function getChallenge(id) { return CHALLENGES.find((c) => c.id === id) ?? null; }
export function getConvoy(id) { return CONVOYS[id] ?? CONVOYS.truck; }

/** Coût d'un bloc en points de budget (acier 3, béton 2, le reste 1). */
export function blockCost(type, costs) { return costs?.[type]?.cost ?? 1; }

/**
 * Géométrie d'un chantier posé à partir de x0 (bout ouest), axe central zc, sol le plus haut groundTop.
 * Chaussée : y = deckY, voie du convoi z ∈ {zc, zc + 1}. Largeur constructible : zc − 2 … zc + 3.
 */
export function siteLayout(challenge, { x0, zc, groundTop }) {
  const abutment = 7;
  const deckY = groundTop + challenge.clearance + 1;
  const waterY = deckY - challenge.clearance;
  const gapX1 = x0 + abutment, gapX2 = gapX1 + challenge.gap - 1;
  return {
    x0, x1: gapX2 + abutment, zc, deckY, waterY, gapX1, gapX2, abutment,
    lane: [zc, zc + 1], zMin: zc - 2, zMax: zc + 3,
    yMin: waterY + 1, yMax: deckY + 14,
    piers: (challenge.piers ?? []).map((offset) => ({ x1: gapX1 + offset, x2: gapX1 + offset + 1, top: deckY - 4 }))
  };
}

/** Cases de chaussée à remplir (contours blancs). */
export function requiredDeck(layout) {
  const cells = [];
  for (let x = layout.gapX1; x <= layout.gapX2; x += 1) for (const z of layout.lane) cells.push({ x, y: layout.deckY, z });
  return cells;
}

export function insideZone(layout, x, y, z) {
  return x >= layout.x0 && x <= layout.x1 && z >= layout.zMin && z <= layout.zMax && y >= layout.yMin && y <= layout.yMax;
}

/** Gabarit du convoi : rien au-dessus de la chaussée sur la voie, sur 3 m de haut. */
export function inClearance(layout, x, y, z) {
  return layout.lane.includes(z) && y > layout.deckY && y <= layout.deckY + 3 && x >= layout.x0 && x <= layout.x1;
}

/** Étoiles : ★ le convoi passe · ★ budget ≤ 75 % · ★ marge : taux maximal ≤ 80 %. */
export function scoreRun({ success, used, budget, maxU }) {
  if (!success) return { stars: 0, crossed: false, thrifty: false, margin: false };
  const thrifty = used <= Math.floor(budget * STAR_RULES.budgetRatio);
  const margin = maxU <= STAR_RULES.margin;
  return { stars: 1 + (thrifty ? 1 : 0) + (margin ? 1 : 0), crossed: true, thrifty, margin };
}

export function readBadges(storage = globalThis.localStorage) {
  try { const parsed = JSON.parse(storage?.getItem(BADGE_KEY) ?? '{}'); return parsed && typeof parsed === 'object' ? parsed : {}; } catch { return {}; }
}

/** Mémorise le meilleur résultat d'un défi ; renvoie { stars, improved, firstBadge }. */
export function recordResult(id, stars, storage = globalThis.localStorage) {
  const badges = readBadges(storage);
  const before = badges[id]?.stars ?? 0;
  const improved = stars > before;
  if (improved) badges[id] = { stars, date: new Date().toISOString().slice(0, 10) };
  try { storage?.setItem(BADGE_KEY, JSON.stringify(badges)); } catch { /* stockage indisponible */ }
  return { stars: Math.max(stars, before), improved, firstBadge: before === 0 && stars > 0 };
}

/** Badge spécial quand les cinq défis ont trois étoiles. */
export function chiefEngineer(badges) { return CHALLENGES.every((c) => (badges[c.id]?.stars ?? 0) >= 3); }

export function starText(stars) { return '★'.repeat(stars) + '☆'.repeat(Math.max(0, 3 - stars)); }
