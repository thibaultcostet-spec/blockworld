// BlockWorld V3.0 Beta 4.30 — calcul des ponts des défis d'ingénieur (module pur, testable sous Node).
//
// Modèle : portique plan dans le plan vertical de l'axe du pont (x, y). Les blocs d'une même tranche (x, y)
// répartis sur la largeur (z) forment un nœud ; deux nœuds voisins sont reliés par une barre de 1 m dont la
// section vaut le nombre de faces collées entre les deux tranches (« liaisons »). Nœuds à 3 degrés de liberté
// (ux, uy, rotation), barres d'Euler-Bernoulli, appui articulé des blocs collés à une culée ou à un rocher.
// Résolution par Cholesky en bande (numérotation par x croissant), donc quelques millisecondes pour un pont
// de plusieurs centaines de blocs : on peut recalculer à chaque bloc posé et à chaque pas du convoi.
//
// Unités du jeu : kN, kN·m, m. Les résistances sont réduites par rapport au réel (un bloc fait 1 m³) pour que
// les ordres de grandeur se ressentent en jouant : une planche seule ne porte pas un camion sur 8 m, une voûte
// en pierre si, un treillis en bois aussi.

// w : poids propre (kN par bloc) · EA : raideur axiale (kN par liaison) · Nt / Nc : traction / compression
// admissibles · M0 : moment admissible sans compression · mu : gain de moment et de cisaillement apporté par la
// compression (maçonnerie : la poussée doit rester dans le bloc) · V0 : cisaillement admissible sans compression.
// cost : points de budget. Maçonnerie : la traction est faible (mortier) ; au-delà, le joint s'ouvre (fissure)
// et les efforts se réorganisent en compression, comme dans une voûte.
export const BRIDGE_MATERIALS = Object.freeze({
  planks:   { label: 'Planches', w: 1.5, EA: 2e4,   Nt: 70,  Nc: 70,  M0: 14, mu: 0,    V0: 35,  cost: 1, family: 'bois' },
  wood:     { label: 'Bois',     w: 2,   EA: 3e4,   Nt: 110, Nc: 110, M0: 22, mu: 0,    V0: 55,  cost: 1, family: 'bois' },
  stone:    { label: 'Pierre',   w: 8,  EA: 4e5,   Nt: 30,  Nc: 500, M0: 14, mu: 0.8 , V0: 30,  cost: 1, family: 'maçonnerie' },
  bricks:   { label: 'Briques',  w: 6,  EA: 3e5,   Nt: 24,  Nc: 350, M0: 10, mu: 0.8 , V0: 24,  cost: 1, family: 'maçonnerie' },
  concrete: { label: 'Béton',    w: 8,  EA: 5e5,   Nt: 40,  Nc: 700, M0: 18, mu: 0.8 , V0: 40,  cost: 2, family: 'maçonnerie' },
  steel:    { label: 'Acier',    w: 4,  EA: 2e5,   Nt: 400, Nc: 400, M0: 80, mu: 0,    V0: 200, cost: 3, family: 'acier' }
});
const FALLBACK = { label: 'Bloc', w: 10, EA: 1e4, Nt: 5, Nc: 30, M0: 1, mu: 0.2, V0: 3, cost: 1, family: 'autre' };

export function materialOf(type) { return BRIDGE_MATERIALS[type] ?? FALLBACK; }

const nodeKey = (x, y) => `${x}|${y}`;
const elementKey = (a, b) => `${a.x}|${a.y}>${b.x}|${b.y}`;
const DIAGONAL = 0.6;
const MECHANISM_LIMIT = 0.3; // m : au-delà, l'assemblage se replie

/**
 * Construit le modèle à partir des blocs du joueur.
 * `isSupport(x, y, z)` : vrai si la case est une culée ou un rocher du chantier (appui fixe).
 * `broken` : clés des barres déjà rompues (rupture progressive).
 */
export function createBridgeModel(blocks, isSupport, { broken = new Set(), fallen = new Set() } = {}) {
  const cells = new Map(blocks.filter((b) => !fallen.has(nodeKey(b.x, b.y))).map((b) => [`${b.x}|${b.y}|${b.z}`, b]));
  const nodes = new Map();
  for (const block of cells.values()) {
    const key = nodeKey(block.x, block.y);
    let node = nodes.get(key);
    if (!node) { node = { key, x: block.x, y: block.y, blocks: [], weight: 0, supported: false }; nodes.set(key, node); }
    node.blocks.push(block);
    node.weight += materialOf(block.type).w;
    if (!node.supported) {
      for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]]) {
        if (isSupport(block.x + dx, block.y + dy, block.z + dz)) { node.supported = true; break; }
      }
    }
  }
  const elements = new Map();
  // Liaisons : faces collées (x, y) et arêtes en diagonale dans le plan du pont (contreventements, voûtes en
  // escalier). Une diagonale ne touche que par une arête : elle porte 60 % d'une face et peu de flexion.
  for (const block of cells.values()) {
    for (const [dx, dy, factor] of [[1, 0, 1], [0, 1, 1], [1, 1, DIAGONAL], [1, -1, DIAGONAL]]) {
      const other = cells.get(`${block.x + dx}|${block.y + dy}|${block.z}`);
      if (!other) continue;
      const a = nodes.get(nodeKey(block.x, block.y));
      const b = nodes.get(nodeKey(other.x, other.y));
      const key = elementKey(a, b);
      if (broken.has(key)) continue;
      let element = elements.get(key);
      if (!element) {
        const L = Math.hypot(dx, dy);
        element = { key, a, b, c: dx / L, s: dy / L, L, diagonal: factor !== 1, bonds: 0, EA: 0, EI: 0, Nt: 0, Nc: 0, M0: 0, mu: 0, V0: 0, family: '' };
        elements.set(key, element);
      }
      const ma = materialOf(block.type), mb = materialOf(other.type);
      // Liaison mixte : on retient le plus faible des deux matériaux.
      const weak = (ma.Nt + ma.Nc) <= (mb.Nt + mb.Nc) ? ma : mb;
      const bend = factor === 1 ? 1 : 0.4;
      element.bonds += 1;
      element.EA += Math.min(ma.EA, mb.EA) * factor;
      element.EI += Math.min(ma.EA, mb.EA) * factor / 12 * (factor === 1 ? 1 : 0.4) * Math.min(ma.flex ?? 1, mb.flex ?? 1);
      element.Nt += weak.Nt * factor; element.Nc += weak.Nc * factor; element.M0 += weak.M0 * factor * bend; element.V0 += weak.V0 * factor;
      element.mu = Math.max(element.mu, weak.mu);
      element.family = weak.family; element.material = weak.label;
    }
  }
  // Connexion aux appuis : ce qui n'est relié à rien tombe.
  const adjacency = new Map([...nodes.values()].map((n) => [n, []]));
  for (const e of elements.values()) { adjacency.get(e.a).push(e.b); adjacency.get(e.b).push(e.a); }
  const reached = new Set();
  const queue = [...nodes.values()].filter((n) => n.supported);
  for (const n of queue) reached.add(n);
  while (queue.length) {
    const n = queue.shift();
    for (const m of adjacency.get(n)) if (!reached.has(m)) { reached.add(m); queue.push(m); }
  }
  const active = [...reached].sort((p, q) => p.x - q.x || p.y - q.y);
  active.forEach((n, i) => { n.index = i; });
  const floating = [...nodes.values()].filter((n) => !reached.has(n));
  for (const n of floating) n.index = -1;
  // Une barre entre deux blocs tenus par la culée ne travaille pas : la culée les porte tous les deux.
  const activeElements = [...elements.values()].filter((e) => reached.has(e.a) && reached.has(e.b) && !(e.a.supported && e.b.supported));
  return { nodes, active, floating, elements: activeElements, cells, factor: null };
}

// --- Cholesky en bande -------------------------------------------------------------------------------------

function assemble(model) {
  const { active, elements } = model;
  const eq = new Int32Array(active.length * 3).fill(-1);
  let n = 0;
  // Appui : un bloc collé à une culée est tenu en déplacement mais peut tourner (articulation). Un encastrement
  // vient naturellement de plusieurs blocs appuyés les uns au-dessus des autres.
  for (const node of active) for (let d = 0; d < 3; d += 1) if (!node.supported || d === 2) eq[node.index * 3 + d] = n++;
  let bw = 0;
  for (const e of elements) {
    const ids = [0, 1, 2].map((d) => eq[e.a.index * 3 + d]).concat([0, 1, 2].map((d) => eq[e.b.index * 3 + d])).filter((v) => v >= 0);
    if (ids.length) bw = Math.max(bw, Math.max(...ids) - Math.min(...ids));
  }
  const w = bw + 1;
  const K = new Float64Array(Math.max(1, n * w));
  for (const e of elements) {
    const k = globalStiffness(e);
    const ids = [0, 1, 2].map((d) => eq[e.a.index * 3 + d]).concat([0, 1, 2].map((d) => eq[e.b.index * 3 + d]));
    for (let r = 0; r < 6; r += 1) {
      const i = ids[r]; if (i < 0) continue;
      for (let c = 0; c < 6; c += 1) {
        const j = ids[c]; if (j < i) continue;
        K[i * w + (j - i)] += k[r * 6 + c];
      }
    }
  }
  // Ressorts très faibles sur chaque degré de liberté : un nœud articulé de partout (maçonnerie) ne rend pas la
  // matrice singulière, et un mécanisme se traduit par des déplacements énormes, détectés ensuite.
  for (let i = 0; i < n; i += 1) K[i * w] += 1e-2;
  // Factorisation K = Uᵀ U (U triangulaire supérieure, stockée en bande).
  for (let i = 0; i < n; i += 1) {
    for (let j = i; j < Math.min(n, i + w); j += 1) {
      let sum = K[i * w + (j - i)];
      for (let k = Math.max(0, j - bw); k < i; k += 1) {
        if (i - k > bw) continue;
        sum -= K[k * w + (i - k)] * K[k * w + (j - k)];
      }
      if (i === j) {
        if (!(sum > 1e-9)) throw new Error('matrice singulière');
        K[i * w] = Math.sqrt(sum);
      } else K[i * w + (j - i)] = sum / K[i * w];
    }
  }
  model.factor = { eq, n, bw, w, U: K };
}

// Raideur d'une barre (horizontale, verticale ou diagonale) en axes globaux : Rᵀ · k_local · R.
function localStiffness(e) {
  const L = e.L, EA = e.EA, EI = e.EI; // section carrée : I = A / 12 (réduit pour les diagonales et la maçonnerie)
  const a = EA / L, b = 12 * EI / L ** 3, c = 6 * EI / L ** 2, d = 4 * EI / L, f = 2 * EI / L;
  return { EI, k: [
    a, 0, 0, -a, 0, 0,
    0, b, c, 0, -b, c,
    0, c, d, 0, -c, f,
    -a, 0, 0, a, 0, 0,
    0, -b, -c, 0, b, -c,
    0, c, f, 0, -c, d
  ] };
}

function toLocal(e, d) {
  const { c, s } = e;
  return [c * d[0] + s * d[1], -s * d[0] + c * d[1], d[2], c * d[3] + s * d[4], -s * d[3] + c * d[4], d[5]];
}

function globalStiffness(e) {
  const { k } = localStiffness(e);
  const { c, s } = e;
  const R = new Array(36).fill(0);
  for (let blk = 0; blk < 2; blk += 1) {
    const o = blk * 3;
    R[o * 6 + o] = c; R[o * 6 + o + 1] = s; R[(o + 1) * 6 + o] = -s; R[(o + 1) * 6 + o + 1] = c; R[(o + 2) * 6 + o + 2] = 1;
  }
  const out = new Array(36).fill(0);
  for (let i = 0; i < 6; i += 1) for (let j = 0; j < 6; j += 1) {
    let sum = 0;
    for (let p = 0; p < 6; p += 1) { const rpi = R[p * 6 + i]; if (!rpi) continue; for (let q = 0; q < 6; q += 1) { const rqj = R[q * 6 + j]; if (rqj) sum += rpi * k[p * 6 + q] * rqj; } }
    out[i * 6 + j] = sum;
  }
  return out;
}

/** Déplacements des nœuds actifs sous des charges nodales (Map nœud → {fx, fy}). */
export function solve(model, loads) {
  if (!model.factor) assemble(model);
  const { eq, n, bw, w, U } = model.factor;
  const rhs = new Float64Array(n);
  for (const [node, load] of loads) {
    if (node.index < 0) continue;
    const ix = eq[node.index * 3], iy = eq[node.index * 3 + 1];
    if (ix >= 0) rhs[ix] += load.fx ?? 0;
    if (iy >= 0) rhs[iy] += load.fy ?? 0;
  }
  // Uᵀ y = b
  for (let i = 0; i < n; i += 1) {
    let s = rhs[i];
    for (let k = Math.max(0, i - bw); k < i; k += 1) s -= U[k * w + (i - k)] * rhs[k];
    rhs[i] = s / U[i * w];
  }
  // U x = y
  for (let i = n - 1; i >= 0; i -= 1) {
    let s = rhs[i];
    for (let j = i + 1; j < Math.min(n, i + w); j += 1) s -= U[i * w + (j - i)] * rhs[j];
    rhs[i] = s / U[i * w];
  }
  const disp = new Float64Array(model.active.length * 3);
  for (let i = 0; i < disp.length; i += 1) if (eq[i] >= 0) disp[i] = rhs[eq[i]];
  return disp;
}

/** Efforts dans chaque barre : N (> 0 traction), V, M max aux extrémités, taux de travail u. */
export function elementForces(model, disp) {
  return model.elements.map((e) => {
    const ia = e.a.index * 3, ib = e.b.index * 3;
    const d = toLocal(e, [disp[ia], disp[ia + 1], disp[ia + 2], disp[ib], disp[ib + 1], disp[ib + 2]]);
    const { k } = localStiffness(e);
    const f = [0, 1, 2, 3, 4, 5].map((r) => k[r * 6] * d[0] + k[r * 6 + 1] * d[1] + k[r * 6 + 2] * d[2] + k[r * 6 + 3] * d[3] + k[r * 6 + 4] * d[4] + k[r * 6 + 5] * d[5]);
    const N = f[3];
    const V = f[1];
    const M = Math.max(Math.abs(f[2]), Math.abs(f[5]));
    return { element: e, N, V, M, ...utilization(e, N, V, M) };
  });
}

/** Taux de travail : interaction effort normal + flexion, et cisaillement (frottement en maçonnerie). */
export function utilization(e, N, V, M) {
  const C = Math.max(0, -N);
  const axial = N >= 0 ? N / e.Nt : C / e.Nc;
  const Mrd = e.M0 + e.mu * C;
  const Vrd = e.V0 + (e.mu ? 0.6 * C : 0);
  const bending = M / Mrd;
  const shear = Math.abs(V) / Vrd;
  const u = Math.max(axial + bending, shear);
  const mode = shear > axial + bending ? 'cisaillement'
    : bending > axial ? (e.mu && C > 0 ? 'poussée hors du bloc' : 'flexion')
      : N >= 0 ? 'traction' : 'compression';
  return { u, mode };
}

/** Charges du poids propre. */
export function selfWeightLoads(model) {
  const loads = new Map();
  for (const node of model.active) loads.set(node, { fx: 0, fy: -node.weight });
  return loads;
}

/**
 * Ajoute les essieux du convoi (position de l'avant `frontX`) sur la chaussée y = deckY, entre gapX1 et gapX2.
 * Renvoie false si un essieu se trouve au-dessus d'un trou (chaussée absente ou effondrée).
 */
export function addConvoyLoads(model, loads, convoy, frontX, deckY, gapX1, gapX2) {
  for (const axle of convoy.axles) {
    const xa = frontX + axle.dx;
    if (xa < gapX1 - 0.5 || xa > gapX2 + 0.5) continue; // essieu sur une culée
    const x0 = Math.floor(xa), t = xa - x0;
    for (const [x, share] of [[x0, 1 - t], [x0 + 1, t]]) {
      if (share <= 1e-6) continue;
      if (x < gapX1 || x > gapX2) continue; // part reprise par la culée
      const node = model.nodes.get(nodeKey(x, deckY));
      if (!node || node.index < 0) return false;
      const entry = loads.get(node) ?? { fx: 0, fy: 0 };
      entry.fy -= axle.P * share;
      loads.set(node, entry);
    }
  }
  return true;
}

function cloneLoads(loads) { return new Map([...loads].map(([k, v]) => [k, { ...v }])); }

/** Flèche : plus grand déplacement vertical vers le bas des nœuds de chaussée (m). */
export function deckDeflection(model, disp, deckY, gapX1, gapX2) {
  let max = 0, at = null;
  for (let x = gapX1; x <= gapX2; x += 1) {
    const node = model.nodes.get(nodeKey(x, deckY));
    if (!node || node.index < 0) continue;
    const uy = -disp[node.index * 3 + 1];
    if (uy > max) { max = uy; at = x; }
  }
  return { value: max, x: at };
}

/**
 * Enveloppe sous le passage du convoi (pas de 0,5 m) : taux de travail maximal par barre et par nœud,
 * flèche maximale, barre la plus sollicitée.
 */
export function convoyEnvelope(model, convoy, site, step = 0.5) {
  const { deckY, gapX1, gapX2 } = site;
  const base = selfWeightLoads(model);
  const elementMax = new Map();
  let maxU = 0, worst = null, deflection = { value: 0, x: null }, blocked = false;
  const length = Math.max(...convoy.axles.map((a) => -a.dx));
  for (let front = gapX1 - 1; front <= gapX2 + 1 + length; front += step) {
    const loads = cloneLoads(base);
    if (!addConvoyLoads(model, loads, convoy, front, deckY, gapX1, gapX2)) { blocked = true; continue; }
    const disp = solve(model, loads);
    for (const r of elementForces(model, disp)) {
      const prev = elementMax.get(r.element);
      if (!prev || r.u > prev.u) elementMax.set(r.element, r);
      if (r.u > maxU) { maxU = r.u; worst = { ...r, front }; }
    }
    const d = deckDeflection(model, disp, deckY, gapX1, gapX2);
    if (d.value > deflection.value) deflection = { ...d, front };
  }
  return { elementMax, nodeMax: nodeUtilization(model, elementMax), maxU, worst, deflection, blocked };
}

/** Taux de chaque nœud = taux maximal des barres qui y arrivent. */
export function nodeUtilization(model, elementResults) {
  const out = new Map();
  for (const r of elementResults.values ? elementResults.values() : elementResults) {
    for (const n of [r.element.a, r.element.b]) out.set(n, Math.max(out.get(n) ?? 0, r.u));
  }
  return out;
}

/**
 * Essai de passage du convoi, pas à pas (0,5 m). À chaque position, tant qu'une liaison dépasse 100 %, elle cède
 * (fissure en maçonnerie, rupture en bois ou en acier) et on recalcule : les efforts se reportent ailleurs. Une
 * voûte en pierre peut ainsi se fissurer aux reins et tenir, une poutre trop faible se casse en deux. Ce qui n'est
 * plus relié à un appui tombe ; si un essieu se retrouve au-dessus du vide, le convoi tombe.
 * Le même calcul sert à l'aperçu en direct et à l'essai animé : ce que l'on voit est ce qui arrivera.
 */
export function simulateCrossing(blocks, isSupport, convoy, site, { step = 0.5, maxBreaks = 120 } = {}) {
  const { deckY, gapX1, gapX2 } = site;
  const broken = new Set();   // ruptures définitives (bois, acier, maçonnerie écrasée ou cisaillée)
  const open = new Map();     // joints de maçonnerie ouverts (fissure de traction, peut se refermer)
  const fallen = new Set();
  const cracked = new Set();
  const events = [];
  const rebuild = () => createBridgeModel(blocks, isSupport, { broken: new Set([...broken, ...open.keys()]), fallen });
  let model = rebuild();
  const markFallen = (front, nodes, reason) => {
    const newly = nodes.filter((n) => !fallen.has(n.key));
    if (!newly.length) return false;
    for (const n of newly) fallen.add(n.key);
    events.push({ front, type: 'fall', reason, nodes: newly.map((n) => ({ x: n.x, y: n.y, blocks: n.blocks })) });
    return true;
  };
  if (markFallen(-Infinity, model.floating, 'sans appui')) model = rebuild();
  const elementMax = new Map();
  let maxU = 0, worst = null, deflection = { value: 0, x: null, front: null };
  const length = Math.max(...convoy.axles.map((a) => -a.dx));
  let convoyFell = null, breaks = 0;
  const start = gapX1 - 1, end = gapX2 + 1 + length;
  // Position « avant l'arrivée du convoi » : le pont doit d'abord tenir sous son propre poids.
  const fronts = [start - 50];
  for (let f = start; f <= end + 1e-9; f += step) fronts.push(f);
  for (const front of fronts) {
    let results = null;
    let settle = 0;
    for (let guard = 0; guard < 600; guard += 1) {
      const loads = selfWeightLoads(model);
      if (!addConvoyLoads(model, loads, convoy, front, deckY, gapX1, gapX2)) { convoyFell = front; break; }
      if (!model.active.length) { results = []; break; }
      const disp = solve(model, loads);
      // Mécanisme (assemblage articulé qui se replie, linteau de pierre) : déplacements démesurés.
      const loose = model.active.filter((n) => !n.supported && Math.hypot(disp[n.index * 3], disp[n.index * 3 + 1]) > MECHANISM_LIMIT);
      if (loose.length) { markFallen(front, loose, 'mécanisme'); model = rebuild(); if (markFallen(front, model.floating, 'sans appui')) model = rebuild(); continue; }
      results = elementForces(model, disp);
      // Maçonnerie sans traction : un joint tendu s'ouvre (fissure), un joint ouvert qui se recomprime se referme.
      if (settle < 160) {
        let changed = false;
        // On ouvre un seul joint à la fois (le plus tendu) : les efforts se réorganisent avant le suivant.
        let tense = null;
        for (const r of results) {
          if (r.element.family !== 'maçonnerie' || r.N <= r.element.Nt) continue;
          if (!tense || r.N / r.element.Nt > tense.N / tense.element.Nt) tense = r;
        }
        if (tense) {
          const e = tense.element;
          open.set(e.key, { ax: e.a.x, ay: e.a.y, bx: e.b.x, by: e.b.y, c: e.c, s: e.s });
          changed = true;
          if (!cracked.has(e.key)) { cracked.add(e.key); events.push({ front, type: 'crack', key: e.key, mode: 'traction', u: tense.u, material: e.material, a: { x: e.a.x, y: e.a.y }, b: { x: e.b.x, y: e.b.y } }); }
        }
        for (const [key, j] of open) {
          const na = model.nodes.get(nodeKey(j.ax, j.ay)), nb = model.nodes.get(nodeKey(j.bx, j.by));
          if (!na || !nb || na.index < 0 || nb.index < 0) continue;
          const elongation = (disp[nb.index * 3] - disp[na.index * 3]) * j.c + (disp[nb.index * 3 + 1] - disp[na.index * 3 + 1]) * j.s;
          if (elongation < -1e-6) { open.delete(key); changed = true; }
        }
        if (changed) { settle += 1; model = rebuild(); if (markFallen(front, model.floating, 'sans appui')) model = rebuild(); continue; }
      }
      const top = results.reduce((m, r) => (r.u > (m?.u ?? 0) ? r : m), null);
      if (top && top.u > 1 && breaks < maxBreaks) {
        breaks += 1;
        broken.add(top.element.key);
        events.push({ front, type: 'break', key: top.element.key, mode: top.mode, u: top.u, material: top.element.material, a: { x: top.element.a.x, y: top.element.a.y }, b: { x: top.element.b.x, y: top.element.b.y } });
        model = rebuild();
        if (markFallen(front, model.floating, 'sans appui')) model = rebuild();
        continue;
      }
      const d = deckDeflection(model, disp, deckY, gapX1, gapX2);
      if (d.value > deflection.value) deflection = { ...d, front };
      break;
    }
    if (convoyFell !== null) break;
    for (const r of results ?? []) {
      const prev = elementMax.get(r.element.key);
      if (!prev || r.u > prev.u) elementMax.set(r.element.key, r);
      if (r.u > maxU) { maxU = r.u; worst = { ...r, front }; }
    }
  }
  const nodeMax = new Map();
  for (const r of elementMax.values()) for (const n of [r.element.a, r.element.b]) nodeMax.set(n.key, Math.max(nodeMax.get(n.key) ?? 0, r.u));
  const damaged = new Set();
  for (const e of events) if (e.type !== 'fall') { damaged.add(`${e.a.x}|${e.a.y}`); damaged.add(`${e.b.x}|${e.b.y}`); }
  return {
    success: convoyFell === null, convoyFell, events, broken, fallen, model,
    elementMax, nodeMax, damaged, maxU, worst, deflection,
    breaks: events.filter((e) => e.type === 'break').length,
    cracks: events.filter((e) => e.type === 'crack').length
  };
}

/** Couleur d'un taux de travail : vert → jaune → orange → rouge. */
export function utilizationColor(u) {
  if (!Number.isFinite(u)) return 0xff2b3a;
  const stops = [[0, [0.18, 0.80, 0.36]], [0.5, [0.55, 0.86, 0.24]], [0.75, [0.98, 0.84, 0.20]], [0.9, [1.0, 0.55, 0.12]], [1.0, [1.0, 0.17, 0.23]]];
  const v = Math.max(0, Math.min(1, u));
  for (let i = 1; i < stops.length; i += 1) {
    if (v <= stops[i][0]) {
      const [p0, c0] = stops[i - 1], [p1, c1] = stops[i];
      const t = (v - p0) / (p1 - p0);
      const c = c0.map((x, k) => x + (c1[k] - x) * t);
      return (Math.round(c[0] * 255) << 16) | (Math.round(c[1] * 255) << 8) | Math.round(c[2] * 255);
    }
  }
  return 0xff2b3a;
}

export function formatPercent(u) { return `${Math.round(u * 100)} %`; }
export function formatDeflection(m) { return m < 0.01 ? `${(m * 1000).toFixed(1).replace('.', ',')} mm` : `${(m * 100).toFixed(1).replace('.', ',')} cm`; }
