// BlockWorld V3.0 Beta 4.30 — véhicules des défis d'ingénieur (charrette, camion, camion-benne, bus).
// Chaque modèle a son essieu avant en x = 0 et s'étend vers −x ; la largeur est centrée sur z = 0.
import * as THREE from 'three';

const mat = (color, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.62, metalness: 0.08, ...extra });

function box(w, h, d, material, x, y, z = 0) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  return mesh;
}

function wheels(group, xs, radius, wheelList) {
  const tyre = mat(0x1d1f22, { roughness: 0.9 });
  const hub = mat(0xc9ccd1, { metalness: 0.5, roughness: 0.4 });
  for (const x of xs) for (const z of [-0.78, 0.78]) {
    const wheel = new THREE.Group();
    const t = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, 0.26, 14), tyre);
    t.rotation.x = Math.PI / 2;
    const h = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.45, radius * 0.45, 0.28, 8), hub);
    h.rotation.x = Math.PI / 2;
    wheel.add(t, h);
    wheel.position.set(x, radius, z);
    group.add(wheel);
    wheelList.push(wheel);
  }
}

function cab(group, color, x0) {
  const paint = mat(color);
  const glass = mat(0x9fd3ee, { roughness: 0.15, metalness: 0.2, emissive: 0x16303c, emissiveIntensity: 0.4 });
  group.add(box(1.5, 1.25, 1.85, paint, x0, 1.1));
  group.add(box(0.06, 0.55, 1.6, glass, x0 + 0.77, 1.35));
  for (const z of [-0.93, 0.93]) group.add(box(0.9, 0.45, 0.04, glass, x0 + 0.1, 1.38, z));
  const light = mat(0xfff3c4, { emissive: 0xffd36b, emissiveIntensity: 1.2 });
  for (const z of [-0.65, 0.65]) group.add(box(0.05, 0.16, 0.26, light, x0 + 0.77, 0.75, z));
}

/** Construit la pièce du convoi ; renvoie { group, wheels, length }. */
export function buildVehicle(kind) {
  const group = new THREE.Group();
  group.name = `Convoy_${kind}`;
  const list = [];
  if (kind === 'cart') {
    const wood = mat(0x8a5a2b, { roughness: 0.85 });
    group.add(box(2.8, 0.55, 1.6, wood, -1.0, 0.95));
    group.add(box(2.4, 0.5, 1.3, mat(0xd8b85a, { roughness: 1 }), -1.1, 1.45)); // foin
    group.add(box(1.4, 0.08, 0.08, wood, 1.0, 0.85, -0.35));
    group.add(box(1.4, 0.08, 0.08, wood, 1.0, 0.85, 0.35));
    wheels(group, [0, -2], 0.5, list);
    return { group, wheels: list, length: 3.2 };
  }
  if (kind === 'truck') {
    cab(group, 0x2f6fd6, 0.25);
    group.add(box(4.6, 0.25, 1.9, mat(0x30343a), -1.6, 0.62));
    const bed = mat(0x6f7780);
    group.add(box(3.1, 0.75, 1.9, bed, -2.4, 1.12));
    const crate = mat(0xb07a3d, { roughness: 0.9 });
    group.add(box(0.9, 0.7, 0.8, crate, -1.6, 1.8, -0.45), box(0.9, 0.7, 0.8, crate, -2.6, 1.8, 0.4), box(0.9, 0.6, 0.8, crate, -3.4, 1.75, -0.3));
    wheels(group, [0, -3], 0.46, list);
    return { group, wheels: list, length: 4.6 };
  }
  if (kind === 'dumper') {
    cab(group, 0xf2b134, 0.25);
    group.add(box(4.8, 0.28, 1.95, mat(0x2b2e33), -1.7, 0.64));
    const tipper = mat(0xe08a1e);
    group.add(box(3.2, 1.05, 2.0, tipper, -2.6, 1.32));
    const rock = mat(0x8b7d6b, { roughness: 1 });
    for (let i = 0; i < 6; i += 1) {
      const r = new THREE.Mesh(new THREE.DodecahedronGeometry(0.34 + (i % 3) * 0.08, 0), rock);
      r.position.set(-1.4 - (i % 3) * 1.0, 1.95 + (i % 2) * 0.12, i < 3 ? -0.45 : 0.45);
      group.add(r);
    }
    wheels(group, [0, -2.5, -3.5], 0.5, list);
    return { group, wheels: list, length: 4.8 };
  }
  // Bus
  const paint = mat(0xd9483b);
  group.add(box(7.6, 2.0, 2.0, paint, -2.6, 1.55));
  const glass = mat(0xbfe4f5, { roughness: 0.15, emissive: 0x1d3846, emissiveIntensity: 0.35 });
  for (const z of [-1.01, 1.01]) group.add(box(6.6, 0.6, 0.03, glass, -2.9, 1.95, z));
  group.add(box(0.04, 0.8, 1.7, glass, 1.21, 1.85));
  group.add(box(7.6, 0.12, 2.02, mat(0xffffff), -2.6, 1.22));
  wheels(group, [0, -5], 0.5, list);
  return { group, wheels: list, length: 7.6 };
}

/** Panneau du chantier (texte sur canvas, pas de blob:). */
export function buildSign(lines, accent = '#f2b134') {
  const canvas = document.createElement('canvas');
  canvas.width = 512; canvas.height = 256;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#1b2633'; ctx.fillRect(0, 0, 512, 256);
  ctx.strokeStyle = accent; ctx.lineWidth = 12; ctx.strokeRect(8, 8, 496, 240);
  ctx.fillStyle = '#ffffff'; ctx.textAlign = 'center';
  ctx.font = 'bold 46px sans-serif'; ctx.fillText(lines[0] ?? '', 256, 92);
  ctx.fillStyle = '#c9d6e2'; ctx.font = '30px sans-serif';
  (lines.slice(1)).forEach((line, i) => ctx.fillText(line, 256, 150 + i * 44));
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const group = new THREE.Group();
  const board = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.6), new THREE.MeshStandardMaterial({ map: texture, roughness: 0.7, side: THREE.DoubleSide }));
  board.position.y = 2.2;
  const post = mat(0x5b3d24, { roughness: 0.9 });
  group.add(board, box(0.12, 1.6, 0.12, post, -1.2, 0.8), box(0.12, 1.6, 0.12, post, 1.2, 0.8));
  return group;
}
