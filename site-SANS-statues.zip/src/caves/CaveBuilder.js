import { planCave } from './CavePlanner.js';
import { CAVE, evaluate, planBounds, nearestSegment } from './CaveGeometry.js';
import { BLOCK_TYPES } from '../world/BlockTypes.js';

// BlockWorld V3.0 Beta 4.32 — construction des grottes dans le monde (appelée à la fin de `generate` de chaque continent).
// Le terrain est creux : on pose donc la coque de roche du tunnel à l'intérieur de la montagne (jamais au-dessus de la
// surface, sauf le porche d'entrée), on retire les blocs de la zone d'air, on remplit le lac, on sème des cristaux
// lumineux sur les parois et on bâtit un portail de briques flanqué de deux lanternes. Le plan est gardé dans world.cavePlan.

const NATURAL = new Set(['grass', 'stone', 'snow', 'sand', 'dirt']);

const hash = (x, y, z, seed) => {
  const v = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719 + seed * 4.1) * 43758.5453;
  return v - Math.floor(v);
};

export function buildCaves(world, definition) {
  world.cavePlan = null;
  if (typeof world?.addBlock !== 'function' || typeof world?.getTopBlock !== 'function' || !world.blocks?.get || typeof world.key !== 'function') return null;
  const blockAt = (x, y, z) => world.blocks.get(world.key(x, y, z));
  const heightAt = (x, z) => {
    const top = world.getTopBlock(x, z, { solidOnly: true });
    if (!top || !NATURAL.has(top.type)) return null;
    if (blockAt(top.x, top.y + 1, top.z)?.type === 'water') return null;
    return top.y;
  };
  const plan = planCave({ definition, half: Math.floor(definition.size / 2), heightAt });
  if (!plan) return null;
  plan.bounds = planBounds(plan);
  carve(world, plan, definition, blockAt);
  settleChests(plan, blockAt);
  buildPortal(world, plan, blockAt);
  clearOrphanTrees(world, plan, blockAt);
  world.cavePlan = plan;
  return plan;
}

function carve(world, plan, definition, blockAt) {
  const b = plan.bounds;
  const seed = definition.seed ?? 1;
  const topCache = new Map();
  const topY = (x, z) => {
    const key = x * 4096 + z;
    if (!topCache.has(key)) topCache.set(key, world.getTopBlock(x, z, { solidOnly: true })?.y ?? 0);
    return topCache.get(key);
  };
  const place = (x, y, z, type) => {
    const existing = blockAt(x, y, z);
    if (existing) { if (existing.protectedBlock) return; world.removeBlock(x, y, z, { persist: false }); }
    world.addBlock(x, y, z, type, { persist: false });
  };
  const lights = [];
  for (let x = b.minX; x <= b.maxX; x += 1) {
    for (let z = b.minZ; z <= b.maxZ; z += 1) {
      const segment = nearestSegment(plan.points, x, z);
      const inPorch = segment && segment.t < CAVE.porch;
      const surface = topY(x, z);
      for (let y = b.minY; y <= b.maxY; y += 1) {
        const kind = evaluate(plan, x, y, z);
        if (!kind) continue;
        let existing = blockAt(x, y, z);
        // Un décor non solide (buisson, herbe haute, fleur) ne doit pas laisser de trou dans la paroi : on le remplace.
        if (existing && kind === 'rock' && existing.type !== 'water' && !BLOCK_TYPES[existing.type]?.solid && !existing.protectedBlock) { world.removeBlock(x, y, z, { persist: false }); existing = null; }
        if (kind === 'air') {
          if (existing && !existing.protectedBlock) world.removeBlock(x, y, z, { persist: false });
        } else if (kind === 'water') {
          place(x, y, z, 'water');
        } else {
          const exposed = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]].some(([dx, dy, dz]) => evaluate(plan, x + dx, y + dy, z + dz) === 'air');
          // Pas de roche flottante au-dessus de la montagne, sauf la paroi qui touche l'air : elle ferme la grotte (affleurement rocheux).
          if (!inPorch && y > surface && !exposed) continue;
          const room = plan.chambers.some((c) => Math.hypot(x - c.cx, z - c.cz) <= c.radius + CAVE.wall);
          const crystal = exposed && hash(x, y, z, seed) < (room ? 0.05 : 0.014);
          if (existing) {
            if (crystal && existing.type === 'stone') { place(x, y, z, 'crystal'); }
          } else {
            place(x, y, z, crystal ? 'crystal' : 'stone');
          }
          if (crystal && hash(x, z, y, seed + 3) < 0.16 && lights.every((l) => Math.hypot(l.x - x, l.y - y, l.z - z) > 4.5) && lights.length < 28) lights.push({ x, y, z });
        }
      }
    }
  }
  plan.crystalLights = lights;
}

function buildPortal(world, plan, blockAt) {
  // Porte de briques posée devant l'ouverture (t < 0, hors de la coque) : deux piliers, un linteau de deux rangs et deux lanternes.
  const first = plan.points[0], next = plan.points[1];
  const length = Math.hypot(next.x - first.x, next.z - first.z) || 1;
  const dx = (next.x - first.x) / length, dz = (next.z - first.z) / length;
  const nx = -dz, nz = dx;
  const side = CAVE.halfWidth + 0.7;
  const floor = first.floor;
  const set = (x, y, z, type) => {
    const rx = Math.round(x), rz = Math.round(z);
    const existing = blockAt(rx, y, rz);
    if (existing) { if (existing.protectedBlock) return; world.removeBlock(rx, y, rz, { persist: false }); }
    world.addBlock(rx, y, rz, type, { persist: false });
  };
  const groundTop = (x, z) => world.getTopBlock(Math.round(x), Math.round(z), { solidOnly: true })?.y ?? floor;
  for (const depth of [1.2, 2.2]) {
    const cx = first.x - dx * depth, cz = first.z - dz * depth;
    for (const sign of [-1, 1]) {
      const px = cx + nx * side * sign, pz = cz + nz * side * sign;
      for (let y = Math.min(groundTop(px, pz), floor) + 1; y <= floor + 4; y += 1) set(px, y, pz, 'bricks');
      if (depth === 1.2) set(px, floor + 7, pz, 'lantern');
    }
    for (let k = -side; k <= side; k += 0.5) { set(cx + nx * k, floor + 5, cz + nz * k, 'bricks'); set(cx + nx * k, floor + 6, cz + nz * k, 'bricks'); }
  }
  plan.portal = { x: Math.round(first.x - dx * 1.7), y: floor, z: Math.round(first.z - dz * 1.7) };
}

/** Cale chaque coffre sur le vrai sol : première case d'air au-dessus d'un bloc plein, au plus près du point prévu. */
function settleChests(plan, blockAt) {
  for (const chest of plan.chests) {
    let found = null;
    for (let radius = 0; radius <= 3 && !found; radius += 1) {
      for (let dx = -radius; dx <= radius && !found; dx += 1) {
        for (let dz = -radius; dz <= radius && !found; dz += 1) {
          if (Math.max(Math.abs(dx), Math.abs(dz)) !== radius) continue;
          for (let y = chest.y - 3; y <= chest.y + 3; y += 1) {
            if (evaluate(plan, chest.x + dx, y, chest.z + dz) === 'air' && evaluate(plan, chest.x + dx, y - 1, chest.z + dz) !== 'air' && blockAt(chest.x + dx, y - 1, chest.z + dz) && !blockAt(chest.x + dx, y, chest.z + dz)) { found = { x: chest.x + dx, y, z: chest.z + dz }; break; }
          }
        }
      }
    }
    if (found) Object.assign(chest, found);
  }
}

const GROUND = new Set(['grass', 'dirt', 'sand', 'snow', 'stone', 'road']);

/**
 * Le creusement (air, coque de roche, portail) peut enterrer un arbre, lui couper le tronc ou lui retirer son sol : on retire
 * alors cet arbre, décoratif ou en blocs, au lieu de le laisser flotter ou dépasser de la roche.
 */
function clearOrphanTrees(world, plan, blockAt) {
  const b = plan.bounds, pad = 4;
  const groundTop = (x, z) => { let top = -1; for (const block of world.columns?.get(world.columnKey(x, z))?.values() ?? []) if (GROUND.has(block.type) && block.y > top) top = block.y; return top; };
  if (Array.isArray(world.decorTrees)) {
    world.decorTrees = world.decorTrees.filter((tree) => {
      if (tree.x < b.minX - pad || tree.x > b.maxX + pad || tree.z < b.minZ - pad || tree.z > b.maxZ + pad) return true;
      return Math.abs(tree.y - groundTop(Math.round(tree.x), Math.round(tree.z))) <= 0.51; // le tronc repose toujours sur le sol
    });
  }
  const remove = (x, y, z) => { if (blockAt(x, y, z)) world.removeBlock(x, y, z, { persist: false }); };
  for (let x = b.minX - pad; x <= b.maxX + pad; x += 1) {
    for (let z = b.minZ - pad; z <= b.maxZ + pad; z += 1) {
      const column = world.columns?.get(world.columnKey(x, z));
      if (!column) continue;
      const trunks = [...column.values()].filter((block) => block.type === 'tree_trunk').map((block) => block.y);
      if (!trunks.length) continue;
      const base = Math.min(...trunks);
      const below = blockAt(x, base - 1, z);
      if (below && (GROUND.has(below.type) || below.type === 'tree_trunk')) continue; // le tronc a toujours son sol
      for (const y of trunks) remove(x, y, z);
      for (let dx = -3; dx <= 3; dx += 1) for (let dz = -3; dz <= 3; dz += 1) for (let y = base; y <= base + 14; y += 1) if (blockAt(x + dx, y, z + dz)?.type === 'leaves') remove(x + dx, y, z + dz);
    }
  }
}
