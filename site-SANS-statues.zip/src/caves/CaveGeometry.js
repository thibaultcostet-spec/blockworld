// BlockWorld V3.0 Beta 4.32 — géométrie des grottes (module pur, testable sous Node).
// Une grotte est un tunnel voûté (polyligne de points au sol) qui traverse une montagne et relie des salles circulaires ;
// la salle du lac contient un lac peu profond avec un îlot. Le terrain étant creux, on construit aussi la coque de roche.
// Repères verticaux : `floor` est le y du bloc de sol (dy = 0) ; l'air commence à dy = 1.

export const CAVE = {
  halfWidth: 2.4, // demi-largeur de l'air du tunnel
  headroom: 4, // hauteur d'air au centre (voûte plus basse sur les bords)
  wall: 2.3, // épaisseur de la coque de roche
  segment: 5, // longueur d'un tronçon
  porch: 10, // longueur d'entrée bâtie en pierre même hors de la montagne
  cover: 3, // roche minimale au-dessus du plafond
  isletMinLake: 3.2 // lac assez grand pour un îlot (palier + bassin + palier + îlot)
};

/** Hauteur du sol du tunnel à la distance `t` : sol de départ + une marche d'un bloc à chaque position de `plan.rises`. */
export function floorAt(plan, t) {
  let floor = plan.baseFloor ?? plan.points[0].floor;
  for (const position of plan.rises ?? []) if (position <= t) floor += 1;
  return floor;
}

export const smoothstep = (x, min, max) => {
  if (x <= min) return 0;
  if (x >= max) return 1;
  const t = (x - min) / (max - min);
  return t * t * (3 - 2 * t);
};

/** Tronçon le plus proche de (x, z) : { d, floor, t, index, raw }. `t` = distance parcourue depuis l'entrée ; `raw` < 0 sur le premier tronçon = avant l'entrée. */
export function nearestSegment(points, x, z) {
  let best = null;
  for (let i = 0; i < points.length - 1; i += 1) {
    const a = points[i], b = points[i + 1];
    const vx = b.x - a.x, vz = b.z - a.z;
    const lengthSq = vx * vx + vz * vz || 1;
    const raw = ((x - a.x) * vx + (z - a.z) * vz) / lengthSq;
    const u = Math.max(0, Math.min(1, raw));
    const d = Math.hypot(x - (a.x + vx * u), z - (a.z + vz * u));
    if (!best || d < best.d) best = { d, floor: a.floor + (b.floor - a.floor) * u, t: a.t + (b.t - a.t) * u, index: i, raw };
  }
  return best;
}

const archTop = (d) => CAVE.headroom - Math.max(0, d - 1.4) * 1.1;

/**
 * Nature du voxel entier (x, y, z) : 'air', 'water', 'rock' ou null (hors grotte).
 * Priorité : lac > air > roche.
 */
export function evaluate(plan, x, y, z) {
  let air = false, rock = false;
  const s = nearestSegment(plan.points, x, z);
  if (s && !(s.index === 0 && s.raw < 0)) { // le tunnel commence net à son entrée (pas de bosse de roche devant)
    // Sol entier, une marche d'un bloc à la fois (plan.rises, jamais dans le plateau d'une salle) : le joueur ne monte qu'un bloc.
    const dy = y - floorAt(plan, s.t);
    if (s.d <= CAVE.halfWidth + CAVE.wall && dy >= -2 && dy <= CAVE.headroom + CAVE.wall) rock = true;
    if (s.d <= CAVE.halfWidth && dy >= 1 && dy <= archTop(s.d)) air = true;
  }
  for (const room of plan.chambers) {
    const dx = x - room.cx, dz = z - room.cz, dy = y - room.floor;
    const up = Math.max(0, dy - 1);
    const inner = (dx / room.radius) ** 2 + (dz / room.radius) ** 2 + (up / room.height) ** 2;
    const outer = (dx / (room.radius + CAVE.wall)) ** 2 + (dz / (room.radius + CAVE.wall)) ** 2 + (up / (room.height + CAVE.wall)) ** 2;
    if (dy >= 1 && inner <= 1) air = true;
    if (dy >= -2 && outer <= 1) rock = true;
    if (room.lake) {
      // Lac en gradins d'un bloc (le joueur ne monte qu'un bloc à la fois : un bassin plus profond serait un piège) :
      // rive (dy 0) → palier (dy −1, à sec) → bassin (1 bloc d'eau sur un fond à dy −2) → palier → îlot (dy 0), si le lac est assez grand.
      const lake = room.lake;
      const dist = Math.hypot(x - lake.cx, z - lake.cz);
      const islet = lake.islet ?? 0;
      if (dist > islet && dist <= lake.radius) {
        const step = dist > lake.radius - 1 || (islet > 0 && dist <= islet + 1);
        if (dy === 0) return 'air';
        if (dy === -1) return step ? 'rock' : 'water';
        if (dy === -2 || dy === -3) return 'rock';
      } else if (dist > islet && dist <= lake.radius + CAVE.wall && (dy === -2 || dy === -3)) rock = true;
    }
  }
  if (air) return 'air';
  return rock ? 'rock' : null;
}

/** Boîte englobante entière de la grotte : { minX, maxX, minY, maxY, minZ, maxZ }. */
export function planBounds(plan) {
  const pad = CAVE.halfWidth + CAVE.wall + 1;
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const p of plan.points) {
    minX = Math.min(minX, p.x - pad); maxX = Math.max(maxX, p.x + pad);
    minZ = Math.min(minZ, p.z - pad); maxZ = Math.max(maxZ, p.z + pad);
    minY = Math.min(minY, p.floor - 3); maxY = Math.max(maxY, p.floor + CAVE.headroom + CAVE.wall + 1);
  }
  for (const room of plan.chambers) {
    const r = room.radius + CAVE.wall + 1;
    minX = Math.min(minX, room.cx - r); maxX = Math.max(maxX, room.cx + r);
    minZ = Math.min(minZ, room.cz - r); maxZ = Math.max(maxZ, room.cz + r);
    minY = Math.min(minY, room.floor - 5); maxY = Math.max(maxY, room.floor + room.height + CAVE.wall + 2);
  }
  return { minX: Math.floor(minX), maxX: Math.ceil(maxX), minY: Math.floor(minY), maxY: Math.ceil(maxY), minZ: Math.floor(minZ), maxZ: Math.ceil(maxZ) };
}

/**
 * Facteur « dans la grotte » 0..1 pour une position (pieds ou yeux) : 1 sous la voûte, 0 dehors.
 * Progressif à l'entrée (0 → 1 entre 1 et 9 m dans le tunnel) ; `coverY` = hauteur du sol au-dessus (toit) pour
 * ne pas assombrir une grotte éventrée par le haut.
 */
export function caveFactorAt(plan, x, y, z, coverY = Infinity) {
  if (!plan) return 0;
  const b = plan.bounds;
  if (x < b.minX || x > b.maxX || z < b.minZ || z > b.maxZ || y < b.minY - 1 || y > b.maxY + 1) return 0;
  let best = 0;
  const s = nearestSegment(plan.points, x, z);
  if (s && !(s.index === 0 && s.raw < 0)) {
    const dy = y - floorAt(plan, s.t);
    if (dy >= -1 && dy <= CAVE.headroom + 2 && s.d <= CAVE.halfWidth + 0.8) best = Math.max(best, smoothstep(s.t, 1, 9));
  }
  for (const room of plan.chambers) {
    const dist = Math.hypot(x - room.cx, z - room.cz);
    const dy = y - room.floor;
    if (dy >= -4 && dy <= room.height + 1 && dist <= room.radius + 0.5) best = Math.max(best, smoothstep(plan.points.at(-1).t * 0.5, 1, 9));
  }
  if (coverY < y + 2) return 0; // pas de toit : on est dehors
  return best;
}
