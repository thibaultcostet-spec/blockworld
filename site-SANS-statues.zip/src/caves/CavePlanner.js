import { CAVE, floorAt } from './CaveGeometry.js';

// BlockWorld V3.0 Beta 4.32 — planificateur de grotte (module pur, testable sous Node).
// Une grotte par continent : on cherche le pied d'un massif (pente qui monte d'au moins 10 blocs en 20 m), on trace un
// tunnel qui s'enfonce dans la montagne en suivant les plus hauts reliefs, puis on place trois salles : cristaux, lac, fond.
// Le plan ne dépend que de la hauteur du terrain naturel : `heightAt(x, z)` renvoie le y du sol, ou null (eau, monument…).

const noise = (x, z, seed) => {
  const v = Math.sin((x + seed * 13) * 127.1 + (z - seed * 7) * 311.7) * 43758.5453;
  return v - Math.floor(v);
};

const DIRECTIONS = 16;

export function findCandidates({ definition, half, heightAt, minRise }) {
  const spawn = definition.spawn ?? { x: 0, z: 0 };
  const pois = definition.pointsOfInterest ?? [];
  const list = [];
  for (let x = -half + 14; x <= half - 14; x += 3) {
    for (let z = -half + 14; z <= half - 14; z += 3) {
      const h = heightAt(x, z);
      if (h == null || h < 1 || h > 8) continue;
      const fromSpawn = Math.hypot(x - spawn.x, z - spawn.z);
      if (fromSpawn < 26 || fromSpawn > 95) continue;
      if (pois.some((poi) => Math.hypot(x - poi.x, z - poi.z) < (poi.discoveryRadius || 16) + 18)) continue;
      let best = null;
      for (let k = 0; k < DIRECTIONS; k += 1) {
        const theta = (k / DIRECTIONS) * Math.PI * 2;
        const ahead = [8, 12, 16, 20].map((d) => heightAt(x + Math.cos(theta) * d, z + Math.sin(theta) * d));
        if (ahead.some((v) => v == null)) continue;
        if (!(ahead[1] >= ahead[0] - 1 && ahead[2] >= ahead[1] - 1 && ahead[3] >= ahead[2] - 1)) continue;
        const rise = Math.min(ahead[2], ahead[3]) - h;
        if (rise >= minRise && (!best || rise > best.rise)) best = { theta, rise };
      }
      if (!best) continue;
      const score = best.rise - Math.abs(fromSpawn - 45) * 0.12 + noise(x, z, definition.seed ?? 1) * 2;
      list.push({ x, z, h, theta: best.theta, rise: best.rise, score });
    }
  }
  return list.sort((a, b) => b.score - a.score);
}

export function tracePath(candidate, { definition, heightAt }) {
  const points = [{ x: candidate.x, z: candidate.z, floor: candidate.h, t: 0 }];
  const pois = definition.pointsOfInterest ?? [];
  const seed = definition.seed ?? 1;
  let angle = candidate.theta;
  let floor = candidate.h;
  // Marge latérale : à ±3,6 m de l'axe la surface doit être au moins à 3 blocs au-dessus du sol du tunnel (le constructeur ferme
  // le reste par un affleurement rocheux).
  const sidesCovered = (x, z, a, f) => [-1, 1].every((side) => {
    const h = heightAt(x - Math.sin(a) * 3.6 * side, z + Math.cos(a) * 3.6 * side);
    return h != null && h >= f + 3;
  });
  for (let i = 1; i <= 11; i += 1) {
    const prev = points[i - 1];
    const options = [];
    for (const turn of [-0.5, -0.25, 0, 0.25, 0.5]) {
      const a = angle + turn;
      const nx = prev.x + Math.cos(a) * CAVE.segment, nz = prev.z + Math.sin(a) * CAVE.segment;
      const height = heightAt(nx, nz);
      if (height == null) continue;
      if (pois.some((poi) => Math.hypot(nx - poi.x, nz - poi.z) < (poi.discoveryRadius || 16) + 8)) continue;
      options.push({ a, nx, nz, height, score: height - Math.abs(turn) * 4 + (noise(nx, nz, seed) - 0.5) * 3 });
    }
    options.sort((p, q) => q.score - p.score);
    let chosen = null;
    for (const option of options) {
      const rise = i >= 2 && i <= 6 ? 1 : 0; // pente douce : 1 bloc tous les 5 m
      for (const nextFloor of rise ? [floor + 1, floor] : [floor]) {
        const covered = i === 1 ? option.height >= nextFloor + CAVE.headroom : option.height >= nextFloor + CAVE.headroom + 2 && sidesCovered(option.nx, option.nz, option.a, nextFloor);
        if (covered) { chosen = { ...option, floor: nextFloor }; break; }
      }
      if (chosen) break;
    }
    if (!chosen) break;
    floor = chosen.floor;
    angle = chosen.a;
    points.push({ x: chosen.nx, z: chosen.nz, floor, t: prev.t + CAVE.segment, angle });
  }
  return points;
}

export function fitRoom(kind, base, point, heightAt) {
  let radius = base.radius;
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const ring = (factor) => [[1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7]].map(([dx, dz]) => heightAt(point.x + dx * factor, point.z + dz * factor));
    const inner = [heightAt(point.x, point.z), ...ring(radius * 0.85)];
    const outer = ring(radius + CAVE.wall + 0.8); // la coque de roche doit rester sous la surface sur tout son pourtour
    if (inner.every((v) => v != null) && outer.every((v) => v != null)) {
      const height = Math.min(base.height, Math.min(...inner) - point.floor - 2);
      if (height >= 3.5 && Math.min(...outer) >= point.floor + 2) return { kind, cx: point.x, cz: point.z, floor: point.floor, radius, height };
    }
    radius *= 0.88;
  }
  return null;
}

/** Plan de grotte pour un continent, ou null si le relief n'offre aucun massif assez haut. */
export function planCave({ definition, half = Math.floor(definition.size / 2), heightAt }) {
  let best = null;
  for (const minRise of [10, 8, 6]) {
    const candidates = findCandidates({ definition, half, heightAt, minRise }).slice(0, 40);
    for (const candidate of candidates) {
      const plan = buildPlan(candidate, { definition, heightAt });
      if (!plan) continue;
      const lakeRoom = plan.chambers.find((room) => room.kind === 'lake');
      plan.quality = plan.chambers.length * 100 + (plan.points.length - 1) * 3 + candidate.rise * 0.1 + lakeRoom.radius * 8; // un grand lac vaut le détour
      if (!best || plan.quality > best.quality) best = plan;
      if (plan.chambers.length === 3 && plan.points.length - 1 >= 8 && lakeRoom.radius >= 7) return plan;
    }
    if (best) return best;
  }
  return best;
}

function buildPlan(candidate, { definition, heightAt }) {
  const points = tracePath(candidate, { definition, heightAt });
  const n = points.length - 1;
  if (n < 6) return null;
  const crystalAt = Math.max(2, Math.round(n * 0.34));
  const lakeAt = Math.max(crystalAt + 2, Math.round(n * 0.67));
  const crystal = fitRoom('crystal', { radius: 6.5, height: 5 }, points[crystalAt], heightAt);
  const lake = fitRoom('lake', { radius: 8.5, height: 6 }, points[lakeAt], heightAt);
  const end = fitRoom('end', { radius: 6, height: 5 }, points[n], heightAt);
  if (!lake || lake.radius < 5.4) return null; // sans vrai lac, ce n'est pas la grotte promise
  if (crystal) crystal.index = crystalAt;
  lake.index = lakeAt;
  if (end) end.index = n;
  const chambers = [crystal, lake, end].filter(Boolean);
  const lakeAngle = points[lakeAt].angle ?? candidate.theta;
  const nx = -Math.sin(lakeAngle), nz = Math.cos(lakeAngle);
  // Le lac est décalé de l'axe du tunnel : une bande sèche reste libre le long du chemin (écart ≥ 0,1 R, soit ≥ 0,5 m) ; il reste dans la salle (0,9 R au plus).
  const lakeRadius = Math.min(4.4, lake.radius * 0.42);
  lake.lake = { cx: lake.cx + nx * lake.radius * 0.5, cz: lake.cz + nz * lake.radius * 0.5, radius: lakeRadius, islet: lakeRadius >= CAVE.isletMinLake ? 1.2 : 0 };
  const chests = [];
  const at = (room, dx, dz, id) => chests.push({ id, x: Math.round(room.cx + dx), y: room.floor + 1, z: Math.round(room.cz + dz) });
  const pointAngle = (i) => points[i].angle ?? candidate.theta;
  if (crystal) at(crystal, -Math.sin(pointAngle(crystalAt)) * (crystal.radius - 1.8), Math.cos(pointAngle(crystalAt)) * (crystal.radius - 1.8), 'cristaux');
  else at({ cx: points[crystalAt].x, cz: points[crystalAt].z, floor: points[crystalAt].floor }, 0, 0, 'cristaux'); // salle trop étroite : coffre dans le tunnel
  if (lake.lake.islet > 0) at({ cx: lake.lake.cx, cz: lake.lake.cz, floor: lake.floor }, 0, 0, 'lac'); // îlot du lac
  else at(lake, -nx * (lake.radius - 1.8), -nz * (lake.radius - 1.8), 'lac'); // petit lac : coffre sur la rive d'en face
  if (end) at(end, Math.cos(pointAngle(n)) * (end.radius - 1.8), Math.sin(pointAngle(n)) * (end.radius - 1.8), 'fond');
  else at({ cx: points[n].x, cz: points[n].z, floor: points[n].floor }, 0, 0, 'fond'); // fond du tunnel
  const guardians = [];
  if (crystal) guardians.push({ type: 'spider', x: crystal.cx + nx * 2, y: crystal.floor + 1, z: crystal.cz + nz * 2 });
  if (end) guardians.push({ type: 'slime', x: end.cx, y: end.floor + 1, z: end.cz }, { type: 'spider', x: end.cx - nx * 2, y: end.floor + 1, z: end.cz - nz * 2 });
  if (!guardians.length) guardians.push({ type: 'spider', x: lake.cx - nx * 2, y: lake.floor + 1, z: lake.cz - nz * 2 }); // grotte réduite à la salle du lac : un gardien tout de même
  // Marches : le tunnel monte d'un bloc à la fois et jamais à l'intérieur du plateau plat d'une salle (sinon, à la sortie d'une salle,
  // le sol du tunnel pourrait dépasser celui de la salle de 2 blocs, que le joueur ne sait pas monter). Une marche tombant dans un plateau
  // est repoussée à sa sortie ; deux marches sont toujours espacées d'au moins 4 m. Retarder une marche ne fait que baisser le sol (plus de roche au-dessus).
  const plateaus = chambers.map((room) => ({ from: points[room.index].t - room.radius - 1, to: points[room.index].t + room.radius + 1 }));
  const rises = [];
  let lastRise = -Infinity;
  for (let i = 1; i <= n; i += 1) {
    for (let k = 0; k < points[i].floor - points[i - 1].floor; k += 1) {
      let position = (points[i - 1].t + points[i].t) / 2;
      for (let pass = 0; pass < 8; pass += 1) { // l'espacement minimal peut repousser une marche dans un autre plateau : on reboucle jusqu'à stabilité
        const before = position;
        for (const plateau of plateaus) if (position > plateau.from && position < plateau.to) position = plateau.to;
        position = Math.max(position, lastRise + 4);
        if (position === before) break;
      }
      rises.push(position);
      lastRise = position;
    }
  }
  const baseFloor = points[0].floor;
  const plan = { baseFloor, rises };
  for (const point of points) point.floor = floorAt(plan, point.t);
  for (const room of chambers) room.floor = floorAt(plan, points[room.index].t);
  lake.lake.floor = lake.floor;
  const settle = (chest, room) => { chest.y = room.floor + 1; };
  for (const chest of chests) { const near = chambers.find((room) => Math.hypot(room.cx - chest.x, room.cz - chest.z) <= room.radius + 1) ?? null; if (near) settle(chest, near); else chest.y = floorAt(plan, nearestT(points, chest.x, chest.z)) + 1; }
  for (const guardian of guardians) { const near = chambers.find((room) => Math.hypot(room.cx - guardian.x, room.cz - guardian.z) <= room.radius + 1); guardian.y = (near ? near.floor : baseFloor) + 1; }
  return {
    id: `cave-${definition.id}`,
    entrance: { x: candidate.x, z: candidate.z, y: candidate.h, dirX: Math.cos(candidate.theta), dirZ: Math.sin(candidate.theta) },
    points, chambers, chests, guardians, crystalLights: [], rise: candidate.rise, baseFloor, rises
  };
}

/** Distance parcourue du point de l'axe le plus proche de (x, z). */
function nearestT(points, x, z) {
  let best = { d: Infinity, t: 0 };
  for (let i = 0; i < points.length - 1; i += 1) {
    const a = points[i], b = points[i + 1], vx = b.x - a.x, vz = b.z - a.z;
    const u = Math.max(0, Math.min(1, ((x - a.x) * vx + (z - a.z) * vz) / (vx * vx + vz * vz || 1)));
    const d = Math.hypot(x - (a.x + vx * u), z - (a.z + vz * u));
    if (d < best.d) best = { d, t: a.t + (b.t - a.t) * u };
  }
  return best.t;
}
