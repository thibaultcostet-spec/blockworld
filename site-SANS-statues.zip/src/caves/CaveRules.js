// BlockWorld V3.0 Beta 4.32 — règles pures de la grotte : coffres, progression, obscurité, gardiens (testable sous Node).

export const CAVE_RULES = {
  chestReach: 3.6, chestMinDot: 0.86, hintDistance: 45,
  guardianModes: ['survival', 'missions'], // Défense : les vagues décident des monstres ; Créatif et Battle : aucun
  darkness: { lite: 0.6, mobile: 0.8, standard: 0.92, high: 0.93, ultra: 0.94 }, // lite : pas de lumière dynamique, on garde de la visibilité
  chestReward: { min: 20, max: 45 }, completeBonus: 100,
  storageKey: 'blockworld-v4.32-caves'
};

/**
 * Dessus de sol praticable dans une colonne : le plus haut bloc plein ≤ maxY dont les deux cases au-dessus sont libres
 * (un monstre ne se tient ni sur une paroi pleine ni sur un plafond). `ys` : hauteurs des blocs pleins de la colonne ;
 * `isSolid(y)` : la case y est-elle pleine ? Renvoie le y du bloc, ou null.
 */
export function standableTop(ys, isSolid, maxY) {
  const sorted = ys.filter((y) => y <= maxY).sort((a, b) => b - a);
  for (const y of sorted) if (!isSolid(y + 1) && !isSolid(y + 2)) return y;
  return null;
}

export const darknessFor = (qualityId) => CAVE_RULES.darkness[qualityId] ?? 0.9;
export const guardiansEnabled = (modeId) => CAVE_RULES.guardianModes.includes(modeId);

/** Coffre visé : le plus proche dans un cône devant `dir` (vecteur unitaire), à portée. Renvoie le coffre ou null. */
export function findChestInView(chests, eye, dir, { reach = CAVE_RULES.chestReach, minDot = CAVE_RULES.chestMinDot } = {}) {
  let best = null;
  for (const chest of chests) {
    const dx = chest.x - eye.x, dy = chest.y - 0.1 - eye.y, dz = chest.z - eye.z;
    const distance = Math.hypot(dx, dy, dz);
    if (distance > reach || distance < 0.05) continue;
    const dot = (dx * dir.x + dy * dir.y + dz * dir.z) / distance;
    if (dot < minDot) continue;
    if (!best || distance < best.distance) best = { chest, distance };
  }
  return best?.chest ?? null;
}

export function chestReward(rng = Math.random) {
  const { min, max } = CAVE_RULES.chestReward;
  return min + Math.floor(rng() * (max - min + 1));
}

/** Point cardinal (même convention que le radar des monstres : N = −z, E = +x). */
export function compassWord(dx, dz) {
  if (Math.abs(dx) > Math.abs(dz)) return dx > 0 ? 'à l’est' : 'à l’ouest';
  return dz > 0 ? 'au sud' : 'au nord';
}

export function readProgress(storage, worldId) {
  try {
    const all = JSON.parse(storage.getItem(CAVE_RULES.storageKey) ?? '{}');
    const entry = all[worldId] ?? {};
    return { chests: Array.isArray(entry.chests) ? entry.chests : [], entered: Boolean(entry.entered) };
  } catch { return { chests: [], entered: false }; }
}

export function writeProgress(storage, worldId, progress) {
  try {
    const all = JSON.parse(storage.getItem(CAVE_RULES.storageKey) ?? '{}');
    all[worldId] = { chests: [...progress.chests], entered: Boolean(progress.entered) };
    storage.setItem(CAVE_RULES.storageKey, JSON.stringify(all));
  } catch { /* stockage refusé : la progression reste en mémoire */ }
}

/** Ouvre un coffre : renvoie { crystals, bonus, found, total, complete }. `progress` est modifié. */
export function openChest(progress, chestId, total, rng = Math.random) {
  if (progress.chests.includes(chestId)) return null;
  progress.chests.push(chestId);
  const complete = progress.chests.length >= total;
  return { crystals: chestReward(rng), bonus: complete ? CAVE_RULES.completeBonus : 0, found: progress.chests.length, total, complete };
}
