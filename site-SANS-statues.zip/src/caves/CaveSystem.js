import * as THREE from 'three';
import { caveFactorAt } from './CaveGeometry.js';
import { CAVE_RULES, darknessFor, guardiansEnabled, findChestInView, compassWord, readProgress, writeProgress, openChest, standableTop } from './CaveRules.js';

// BlockWorld V3.0 Beta 4.32 — grotte du continent : obscurité progressive à l'intérieur, lampe frontale (via NightLights),
// cristaux lumineux, trois coffres à trouver (progression mémorisée par continent), quelques gardiens (Survie et Missions).
// Le plan vient de world.cavePlan (calculé à la génération par CaveBuilder).

const WOOD = new THREE.MeshStandardMaterial({ color: 0x8a5a2b, roughness: 0.85 });
const GOLD = new THREE.MeshStandardMaterial({ color: 0xe0b030, roughness: 0.35, metalness: 0.5, emissive: 0x6b4a00, emissiveIntensity: 0.7 });
const SPARK = new THREE.MeshBasicMaterial({ color: 0xffe27a });
const baseGeometry = new THREE.BoxGeometry(0.95, 0.5, 0.62);
const lidGeometry = new THREE.BoxGeometry(0.95, 0.2, 0.62);
const bandGeometry = new THREE.BoxGeometry(0.12, 0.54, 0.66);
const sparkGeometry = new THREE.BoxGeometry(0.07, 0.07, 0.07);

function buildChest(chest, opened) {
  const root = new THREE.Group();
  root.name = `CaveChest-${chest.id}`;
  root.position.set(chest.x, chest.y - 0.5, chest.z); // la case d'air repose sur le dessus du bloc de sol
  root.rotation.y = (chest.x * 7 + chest.z * 3) % (Math.PI * 2);
  const base = new THREE.Mesh(baseGeometry, WOOD); base.position.y = 0.25;
  const band = new THREE.Mesh(bandGeometry, GOLD); band.position.y = 0.25;
  const hinge = new THREE.Group(); hinge.position.set(0, 0.5, -0.31);
  const lid = new THREE.Mesh(lidGeometry, WOOD); lid.position.set(0, 0.1, 0.31);
  const clasp = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.14, 0.05), GOLD); clasp.position.set(0, 0.0, 0.64);
  hinge.add(lid, clasp);
  hinge.rotation.x = opened ? -1.2 : 0;
  root.add(base, band, hinge);
  const sparks = [];
  if (!opened) for (let k = 0; k < 4; k += 1) { const s = new THREE.Mesh(sparkGeometry, SPARK); root.add(s); sparks.push(s); }
  return { root, hinge, sparks, chest, opened };
}

export class CaveSystem {
  constructor(game) {
    this.game = game;
    this.group = new THREE.Group();
    this.group.name = 'CaveV432';
    game.scene.add(this.group);
    this.plan = null;
    this.factor = 0;
    this.darkness = darknessFor(game.graphicsQuality?.id ?? 'standard');
    this.entries = [];
    this.sources = [];
    this.guardians = [];
    this.progress = { chests: [], entered: false };
    this.worldId = '';
    this.hinted = false;
    this.guardiansSpawned = false;
  }

  say(text) { this.game.hud?.setStatus?.(text); }

  setQuality(id) { this.darkness = darknessFor(id); }

  /** Appelé à chaque changement / régénération de continent. */
  setWorld(definition) {
    for (const entry of this.entries) this.group.remove(entry.root);
    this.entries = []; this.guardians = [];
    this.plan = this.game.world?.cavePlan ?? null;
    this.worldId = definition?.id ?? '';
    this.factor = 0;
    this.hinted = false; this.guardiansSpawned = false;
    this.progress = readProgress(localStorage, this.worldId);
    this.game.navigationMap?.setCave?.(this.plan?.entrance ?? null); // repère sur la mini-carte (la grande carte lit caves.plan)
    if (!this.plan) { this.sources = []; return; }
    for (const chest of this.plan.chests) {
      const entry = buildChest(chest, this.progress.chests.includes(chest.id));
      this.group.add(entry.root);
      this.entries.push(entry);
    }
    this.sources = this.plan.crystalLights.map((p) => ({ position: new THREE.Vector3(p.x, p.y, p.z), color: 0x62d9ff, intensity: 1.1, distance: 8, lantern: true }));
  }

  /** Sources de lumière des cristaux (réutilisées par NightLights quand on est dans la grotte). */
  lightSources() { return this.factor > 0.05 ? this.sources : []; }

  update(delta, eye, time = performance.now() * 0.001) {
    const plan = this.plan;
    if (!plan || !eye) { this.factor = 0; return; }
    const world = this.game.world;
    const roof = world.getTopBlock(eye.x, eye.z, { solidOnly: true })?.y ?? -Infinity;
    const target = caveFactorAt(plan, eye.x, eye.y - 0.9, eye.z, roof);
    this.factor += (target - this.factor) * Math.min(1, delta * 2.5);
    if (this.factor < 0.002) this.factor = 0;
    if (!this.hinted && this.factor === 0) {
      const dx = plan.entrance.x - eye.x, dz = plan.entrance.z - eye.z;
      if (Math.hypot(dx, dz) < CAVE_RULES.hintDistance) { this.hinted = true; this.say(`🕳️ Une grotte s’ouvre dans la montagne ${compassWord(dx, dz)}`); }
    }
    if (!this.progress.entered && this.factor > 0.6) {
      this.progress.entered = true;
      writeProgress(localStorage, this.worldId, this.progress);
      this.say(`🕳️ Tu entres dans la grotte · ${plan.chests.length - this.progress.chests.length} trésor${plan.chests.length - this.progress.chests.length > 1 ? 's' : ''} à trouver · clic droit sur un coffre`);
    }
    if (this.factor > 0.6 && !this.guardiansSpawned) this.spawnGuardians();
    for (const entry of this.entries) {
      entry.sparks.forEach((spark, i) => { const a = time * 1.6 + i * 1.57; spark.position.set(Math.cos(a) * 0.42, 0.85 + Math.sin(time * 2.3 + i) * 0.12, Math.sin(a) * 0.3); });
    }
    for (const monster of this.guardians) if (monster.alive) monster.floorRef = monster.group.position.y;
  }

  /** Hauteur du sol (dessus du bloc) sous `maxY` : les gardiens suivent le sol de la grotte et non la surface de la montagne. */
  surfaceBelow(x, z, maxY) {
    const world = this.game.world;
    const rx = Math.round(x), rz = Math.round(z); // les monstres se déplacent en coordonnées décimales : la clé de colonne est entière
    const column = world.columns.get(world.columnKey(rx, rz));
    if (!column) return 0;
    const FREE = new Set(['water', 'rail', 'ladder', 'tall_grass', 'shrub', 'flower_red', 'flower_yellow']);
    const isSolid = (yy) => { const b = world.blocks.get(world.key(rx, yy, rz)); return Boolean(b) && !FREE.has(b.type); };
    const ys = [...column.values()].filter((b) => !FREE.has(b.type)).map((b) => b.y);
    const top = standableTop(ys, isSolid, maxY); // jamais sur un plafond ni sur une paroi pleine
    return top === null ? 0 : top + 0.5;
  }

  spawnGuardians() {
    this.guardiansSpawned = true;
    if (!guardiansEnabled(this.game.selectedModeId) || !this.plan) return;
    const { monsters } = this.game;
    for (const spot of this.plan.guardians) {
      monsters.spawnOne(spot.type, { x: spot.x, y: spot.y, z: spot.z });
      const monster = monsters.monsters.at(-1);
      if (!monster || monster.type !== spot.type) continue;
      monster.floorRef = spot.y - 0.5;
      monster.surface = (x, z) => this.surfaceBelow(x, z, monster.floorRef + 1.2); // une marche d'un bloc au plus
      this.guardians.push(monster);
    }
  }

  /** Clic droit : ouvre le coffre visé (renvoie true si un coffre a été ouvert). */
  tryOpenChest(eye, dir) {
    if (!this.plan) return false;
    const closed = this.entries.filter((entry) => !entry.opened).map((entry) => entry.chest);
    const chest = findChestInView(closed, eye, dir);
    if (!chest) return false;
    const result = openChest(this.progress, chest.id, this.plan.chests.length);
    if (!result) return false;
    writeProgress(localStorage, this.worldId, this.progress);
    const entry = this.entries.find((e) => e.chest === chest);
    entry.opened = true; entry.hinge.rotation.x = -1.2; for (const spark of entry.sparks) entry.root.remove(spark); entry.sparks = [];
    this.game.monsters?.addCrystals(result.crystals + result.bonus);
    this.game.sfx?.playChest?.();
    this.say(result.complete
      ? `🏆 Dernier trésor ! +${result.crystals} cristaux et +${result.bonus} de bonus : la grotte n’a plus de secret`
      : `💎 Trésor ${result.found}/${result.total} · +${result.crystals} cristaux`);
    return true;
  }
}
