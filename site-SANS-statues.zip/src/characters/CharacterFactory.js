import * as THREE from 'three';

// BlockWorld V3.0 Beta 4.19 — personnages « stylisé-réaliste ».
// Huit personnages originaux (4 femmes, 4 hommes) inspirés des codes actuels du character design :
// proportions adultes (~7 têtes), silhouettes différenciées, visage peint sobre et lisible,
// coiffures en volumes, vêtements en couches, mains et chaussures.
// Le squelette reprend celui des versions précédentes (pivots leg/knee/arm/elbow, repère de semelle),
// afin que démarche, ancrage au sol et sursaut d'impact fonctionnent sans modification.

export const CHARACTER_ROSTER = [
  { id: 'malo', name: 'Malo', sex: 'm', age: 34, profession: 'Guide de montagne', height: 1.86, build: 0.96, skin: 0xe2b48f, eyes: 0x4f6b3a,
    hair: { style: 'short', color: 0x5a3a22 }, beard: 'short', hat: 'beanie', hatColor: 0xb8442f,
    top: { kind: 'jacket', color: 0x2f5d73, inner: 0xd9d4c7, open: true }, pants: 0x3b3f45, shoes: { kind: 'boots', color: 0x5b3c25 }, backpack: 0x7a5a2c },
  { id: 'idris', name: 'Idris', sex: 'm', age: 41, profession: 'Ingénieur structures', height: 1.80, build: 1.0, skin: 0x8d5a3b, eyes: 0x3a2618,
    hair: { style: 'fade', color: 0x151313 }, beard: 'stubble', glasses: 0x1d1f24,
    top: { kind: 'vest', color: 0x3c4a5e, inner: 0xe9edf2 }, pants: 0x2b3240, shoes: { kind: 'shoes', color: 0x3b2a20 } },
  { id: 'teo', name: 'Teo', sex: 'm', age: 47, profession: 'Charpentier', height: 1.83, build: 1.18, skin: 0xd59f78, eyes: 0x5b4632,
    hair: { style: 'swept', color: 0x7a5a3e }, beard: 'full',
    top: { kind: 'shirt', color: 0x9b3b32, pattern: 'check', inner: 0x9b3b32, apron: 0x6e4a2c }, pants: 0x46505a, shoes: { kind: 'boots', color: 0x3a2a1e } },
  { id: 'kenji', name: 'Kenji', sex: 'm', age: 26, profession: 'Coursier urbain', height: 1.76, build: 0.9, skin: 0xe8c39e, eyes: 0x2b1d14,
    hair: { style: 'undercut', color: 0x101014 },
    top: { kind: 'bomber', color: 0x2c3a2f, inner: 0x9aa3ab, hood: true }, pants: 0x1f2328, shoes: { kind: 'sneakers', color: 0xeeeeee, accent: 0xd8462c } },
  { id: 'nora', name: 'Nora', sex: 'f', age: 38, profession: 'Architecte', height: 1.74, build: 0.92, skin: 0xf0cdb2, eyes: 0x4b6f8a,
    hair: { style: 'bob', color: 0x231a16 },
    top: { kind: 'coat', color: 0xb9a68a, inner: 0x2b2b30 }, pants: 0x2b2b30, shoes: { kind: 'boots', color: 0x1f1b18 } },
  { id: 'amara', name: 'Amara', sex: 'f', age: 31, profession: 'Géomètre', height: 1.72, build: 1.02, skin: 0x7a4a30, eyes: 0x2e1d12,
    hair: { style: 'braidbun', color: 0x141110 },
    top: { kind: 'hiviz', color: 0xe8792a, inner: 0x2e3540, stripes: 0xd9dde2 }, pants: 0x55593f, shoes: { kind: 'boots', color: 0x3c2c20 } },
  { id: 'lucie', name: 'Lucie', sex: 'f', age: 27, profession: 'Botaniste', height: 1.64, build: 0.88, skin: 0xf3d4bd, eyes: 0x5d7d3e, freckles: true,
    hair: { style: 'ponytail', color: 0xa24d26 },
    top: { kind: 'shirt', color: 0xe4ddc8, inner: 0xe4ddc8, rolled: true, overalls: 0x55708a }, pants: 0x55708a, shoes: { kind: 'sneakers', color: 0x6b7b52, accent: 0xf2efe6 } },
  { id: 'sofia', name: 'Sofia', sex: 'f', age: 35, profession: 'Pilote de drone', height: 1.70, build: 0.95, skin: 0xd8a882, eyes: 0x5a3d26,
    hair: { style: 'pixie', color: 0x3d2a21, streak: 0xb07a4a },
    top: { kind: 'aviator', color: 0x6b4a33, inner: 0x2f3a33, collar: 0xe9dcc4 }, pants: 0x30363c, shoes: { kind: 'boots', color: 0x24211f }, gloves: 0x2a2523 }
];

export function rosterCharacter(index) {
  const list = CHARACTER_ROSTER;
  return list[((index % list.length) + list.length) % list.length];
}

export function rosterIndexFromId(id = '') {
  let hash = 0;
  for (const character of String(id)) hash = (hash * 31 + character.charCodeAt(0)) >>> 0;
  return hash % CHARACTER_ROSTER.length;
}

// ─── Matériaux et utilitaires ─────────────────────────────────────────────────────────────────

const materialCache = new Map();
function mat(color, roughness = 0.8, extra = {}) {
  const key = `${color}|${roughness}|${JSON.stringify(extra)}`;
  if (!materialCache.has(key)) materialCache.set(key, new THREE.MeshStandardMaterial({ color, roughness, metalness: 0, ...extra }));
  // Matériau propre à chaque personnage (l'éclair d'impact et les couleurs réseau le modifient).
  return materialCache.get(key).clone();
}

// Assombrit/éclaircit une couleur hexadécimale sRGB (sans passer par l'espace linéaire).
function shade(color, factor) {
  const f = (v) => Math.max(0, Math.min(255, Math.round(v * factor)));
  return (f((color >> 16) & 255) << 16) | (f((color >> 8) & 255) << 8) | f(color & 255);
}

function add(parent, geometry, material, x = 0, y = 0, z = 0, name = '') {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  if (name) mesh.name = name;
  parent.add(mesh);
  return mesh;
}

// Profil de buste par tour (avant = -z). Points (rayon, hauteur) du bas (taille basse) vers le haut (épaules).
function torsoGeometry(spec, scaleX, scaleZ) {
  const female = spec.sex === 'f';
  const b = spec.build;
  const points = female
    ? [[0.165, 0], [0.150, 0.08], [0.135, 0.16], [0.155, 0.26], [0.170, 0.33], [0.175, 0.40], [0.175, 0.45], [0.120, 0.50]]
    : [[0.160, 0], [0.165, 0.08], [0.170, 0.16], [0.185, 0.27], [0.195, 0.36], [0.200, 0.43], [0.190, 0.47], [0.125, 0.52]];
  const geometry = new THREE.LatheGeometry(points.map(([r, y]) => new THREE.Vector2(r * b, y)), 18);
  geometry.scale(scaleX, 1, scaleZ);
  return geometry;
}

// ─── Visage peint (yeux, sourcils, nez, lèvres) ───────────────────────────────────────────────

function faceTexture(spec) {
  const size = 256, canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  // Couleurs écrites dans le canvas en sRGB (THREE.Color stocke en linéaire : visage trop sombre et orangé).
  const css = (color, alpha = 1) => `rgba(${(color >> 16) & 255},${(color >> 8) & 255},${color & 255},${alpha})`;
  ctx.fillStyle = css(spec.skin);
  ctx.fillRect(0, 0, size, size);
  // Volumes doux : ombre sous les pommettes, sous le nez, autour des yeux.
  const blob = (x, y, rx, ry, color, alpha) => {
    const g = ctx.createRadialGradient(x, y, 0, x, y, Math.max(rx, ry));
    g.addColorStop(0, css(color, alpha)); g.addColorStop(1, css(color, 0));
    ctx.save(); ctx.translate(x, y); ctx.scale(rx / Math.max(rx, ry), ry / Math.max(rx, ry)); ctx.translate(-x, -y);
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, Math.max(rx, ry), 0, Math.PI * 2); ctx.fill(); ctx.restore();
  };
  const dark = shade(spec.skin, 0.72), warm = spec.sex === 'f' ? 0xd9776b : 0xc8806a;
  // Les traits sont dessinés dans un repère « visage » puis agrandis pour occuper la calotte frontale
  // (yeux à ±25° environ du centre, comme sur une tête réelle).
  ctx.save(); ctx.translate(128, 136); ctx.scale(1.46, 1.21); ctx.translate(-128, -136);
  blob(78, 150, 30, 18, dark, 0.22); blob(178, 150, 30, 18, dark, 0.22);
  blob(82, 160, 22, 14, warm, spec.sex === 'f' ? 0.22 : 0.12); blob(174, 160, 22, 14, warm, spec.sex === 'f' ? 0.22 : 0.12);
  blob(128, 168, 16, 10, dark, 0.28);
  // Yeux : blanc, iris, pupille, reflet, paupière supérieure marquée.
  for (const x of [92, 164]) {
    blob(x, 118, 26, 14, dark, 0.25);
    ctx.fillStyle = '#f4f1ec'; ctx.beginPath(); ctx.ellipse(x, 120, 15, 7.5, 0, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = css(spec.eyes); ctx.beginPath(); ctx.arc(x, 120, 6.4, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#0d0f12'; ctx.beginPath(); ctx.arc(x, 120, 3, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,.85)'; ctx.beginPath(); ctx.arc(x + 2.2, 117.6, 1.6, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = css(shade(spec.hair.color, 0.6), 0.95); ctx.lineWidth = spec.sex === 'f' ? 2.6 : 2;
    ctx.beginPath(); ctx.ellipse(x, 121, 15.5, 8.2, 0, Math.PI * 1.05, Math.PI * 1.95); ctx.stroke();
  }
  // Sourcils : plus épais et droits pour les hommes, arqués et fins pour les femmes.
  ctx.strokeStyle = css(shade(spec.hair.color, 0.85), 0.92); ctx.lineCap = 'round';
  ctx.lineWidth = spec.sex === 'f' ? 3.4 : 5.2;
  for (const [x, dir] of [[92, -1], [164, 1]]) {
    ctx.beginPath(); ctx.moveTo(x - 17 * -dir, 103); ctx.quadraticCurveTo(x, spec.sex === 'f' ? 95 : 99, x + 17 * -dir, 101 + (spec.sex === 'f' ? 2 : 0)); ctx.stroke();
  }
  // Nez : arête claire et ombre de narines.
  blob(128, 140, 7, 22, 0xffffff, 0.10);
  ctx.fillStyle = css(shade(spec.skin, 0.62), 0.55);
  ctx.beginPath(); ctx.ellipse(121, 165, 3.2, 2, 0, 0, Math.PI * 2); ctx.ellipse(135, 165, 3.2, 2, 0, 0, Math.PI * 2); ctx.fill();
  // Lèvres.
  const lip = spec.sex === 'f' ? shade(0xb85a55, 0.95) : shade(spec.skin, 0.74);
  ctx.fillStyle = css(lip, 0.9);
  ctx.beginPath(); ctx.moveTo(110, 190); ctx.quadraticCurveTo(128, 182, 146, 190); ctx.quadraticCurveTo(128, 194, 110, 190); ctx.fill();
  ctx.fillStyle = css(shade(lip, 1.08), 0.85);
  ctx.beginPath(); ctx.moveTo(112, 191); ctx.quadraticCurveTo(128, 202, 144, 191); ctx.quadraticCurveTo(128, 195, 112, 191); ctx.fill();
  if (spec.freckles) {
    ctx.fillStyle = css(shade(spec.skin, 0.66), 0.55);
    for (let k = 0; k < 34; k += 1) { const x = 70 + Math.random() * 116, y = 132 + Math.random() * 30; if (Math.abs(x - 128) > 10) { ctx.beginPath(); ctx.arc(x, y, 1.1 + Math.random(), 0, Math.PI * 2); ctx.fill(); } }
  }
  if (spec.beard === 'stubble' || spec.beard === 'short' || spec.beard === 'full') {
    const alpha = spec.beard === 'stubble' ? 0.32 : 0.55;
    ctx.fillStyle = css(shade(spec.hair.color, 0.9), alpha);
    for (let k = 0; k < 900; k += 1) {
      const a = Math.random() * Math.PI, r = 60 + Math.random() * 40;
      const x = 128 + Math.cos(a) * r * 0.95, y = 150 + Math.sin(a) * r * 0.85;
      if (y > 172 && !(y < 200 && Math.abs(x - 128) < 22 && y > 182)) ctx.fillRect(x, y, 1.6, 1.6);
    }
  }
  ctx.restore();
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

// ─── Tête et coiffure ─────────────────────────────────────────────────────────────────────────

function buildHead(spec, skinMat) {
  const head = new THREE.Group();
  head.name = 'Head';
  const female = spec.sex === 'f';
  const skull = add(head, new THREE.SphereGeometry(0.118, 24, 18), skinMat, 0, 0.02, 0, 'Skull');
  skull.scale.set(female ? 0.9 : 0.94, 1.08, 0.98);
  // Mâchoire : plus carrée chez les hommes, plus fine chez les femmes.
  const jaw = add(head, new THREE.SphereGeometry(0.095, 20, 14), skinMat, 0, -0.045, -0.012, 'Jaw');
  jaw.scale.set(female ? 0.86 : 1.0, female ? 0.78 : 0.86, 0.92);
  // Visage peint sur une calotte frontale.
  const faceMat = new THREE.MeshStandardMaterial({ map: faceTexture(spec), roughness: 0.68 });
  const face = add(head, new THREE.SphereGeometry(0.1184, 32, 22, Math.PI * 0.2, Math.PI * 0.6, Math.PI * 0.2, Math.PI * 0.62), faceMat, 0, 0.004, 0, 'Face'); // raccord rejeté sur les côtés
  face.scale.set(female ? 0.9 : 0.94, 1.08, 0.985);
  face.rotation.y = Math.PI;
  // Nez en volume (petit coin arrondi) et oreilles.
  const nose = add(head, new THREE.SphereGeometry(0.019, 12, 10), skinMat, 0, -0.004, -0.112, 'Nose');
  nose.scale.set(0.75, 1.25, 0.85);
  for (const side of [-1, 1]) {
    const ear = add(head, new THREE.SphereGeometry(0.026, 10, 8), skinMat, side * (female ? 0.103 : 0.108), 0.005, 0.006, 'Ear');
    ear.scale.set(0.45, 1, 0.8);
  }
  if (spec.glasses) {
    const frame = mat(spec.glasses, 0.4);
    for (const side of [-1, 1]) {
      const rim = add(head, new THREE.TorusGeometry(0.023, 0.0035, 6, 18), frame, side * 0.04, 0.024, -0.118, 'Glasses');
      rim.scale.set(1.25, 0.85, 1);
    }
    add(head, new THREE.BoxGeometry(0.03, 0.004, 0.004), frame, 0, 0.026, -0.12);
  }
  buildHair(head, spec);
  return head;
}

function buildHair(head, spec) {
  const color = spec.hair.color;
  const hairMat = mat(color, 0.62);
  const darker = mat(shade(color, 0.78), 0.7);
  const female = spec.sex === 'f';
  const cap = (scaleY = 0.62, y = 0.07, z = 0.012) => {
    const mesh = add(head, new THREE.SphereGeometry(0.124, 22, 14, 0, Math.PI * 2, 0, Math.PI * 0.55), hairMat, 0, y - 0.035, z, 'HairCap');
    mesh.scale.set(female ? 0.93 : 0.97, scaleY + 0.5, 1.02);
    return mesh;
  };
  const strand = (x, y, z, w, h, d, rx = 0, rz = 0, material = hairMat) => {
    const mesh = add(head, new THREE.CapsuleGeometry(Math.min(w, d) / 2, Math.max(0.001, h - Math.min(w, d)), 3, 8), material, x, y, z, 'HairStrand');
    mesh.scale.set(w / Math.min(w, d), 1, d / Math.min(w, d));
    mesh.rotation.set(rx, 0, rz);
    return mesh;
  };
  switch (spec.hair.style) {
    case 'fade': {
      const top = cap(0.42, 0.075); top.scale.multiplyScalar(0.99);
      add(head, new THREE.SphereGeometry(0.121, 22, 14, 0, Math.PI * 2, Math.PI * 0.35, Math.PI * 0.28), darker, 0, 0.02, 0.008).scale.set(0.96, 1.08, 1.0);
      break;
    }
    case 'undercut': {
      add(head, new THREE.SphereGeometry(0.12, 22, 14, 0, Math.PI * 2, Math.PI * 0.32, Math.PI * 0.3), darker, 0, 0.02, 0.008).scale.set(0.95, 1.08, 0.99);
      const top = strand(0, 0.115, -0.02, 0.17, 0.07, 0.2, -0.25); top.scale.y = 1.1;
      strand(0.02, 0.105, -0.1, 0.12, 0.05, 0.06, -0.9, -0.3);
      break;
    }
    case 'swept': {
      cap(0.6, 0.075);
      strand(0.03, 0.115, -0.07, 0.17, 0.06, 0.09, -0.6, -0.35);
      break;
    }
    case 'short': {
      cap(0.55, 0.07);
      strand(-0.02, 0.1, -0.095, 0.15, 0.045, 0.05, -1.1, 0.2);
      break;
    }
    case 'bob': {
      cap(0.66, 0.075);
      for (const side of [-1, 1]) strand(side * 0.098, -0.005, -0.005, 0.05, 0.15, 0.2, 0, side * 0.08);
      strand(0, -0.005, 0.07, 0.2, 0.15, 0.08, 0.12);
      strand(-0.03, 0.095, -0.095, 0.17, 0.05, 0.05, -1.25, 0.15);
      break;
    }
    case 'braidbun': {
      cap(0.62, 0.075);
      for (let k = 0; k < 7; k += 1) {
        const a = (k / 7) * Math.PI * 2;
        strand(Math.cos(a) * 0.11, 0.06, Math.sin(a) * 0.11, 0.02, 0.06, 0.02, Math.sin(a) * 0.6, -Math.cos(a) * 0.6, darker);
      }
      const bun = add(head, new THREE.TorusGeometry(0.045, 0.024, 8, 18), hairMat, 0, 0.15, 0.03, 'Bun');
      bun.rotation.x = Math.PI / 2;
      add(head, new THREE.SphereGeometry(0.04, 12, 10), darker, 0, 0.155, 0.03);
      break;
    }
    case 'ponytail': {
      cap(0.64, 0.075);
      strand(-0.02, 0.095, -0.098, 0.16, 0.05, 0.05, -1.2, 0.25);
      add(head, new THREE.TorusGeometry(0.02, 0.008, 6, 12), mat(0x2f3a4a, 0.5), 0, 0.07, 0.115);
      const tail = strand(0, -0.03, 0.15, 0.06, 0.24, 0.05, 0.35); tail.name = 'Ponytail';
      break;
    }
    case 'pixie': {
      cap(0.58, 0.072);
      strand(-0.045, 0.09, -0.095, 0.13, 0.05, 0.05, -1.05, 0.45);
      if (spec.hair.streak) strand(-0.06, 0.095, -0.09, 0.04, 0.05, 0.03, -1.05, 0.45, mat(spec.hair.streak, 0.6));
      strand(0.09, 0.02, -0.03, 0.03, 0.08, 0.06, 0, 0.1);
      break;
    }
    default: cap();
  }
  if (spec.beard === 'short' || spec.beard === 'full') {
    // Barbe : mâchoire et menton seulement (la bouche reste visible, peinte sur le visage).
    const beard = add(head, new THREE.SphereGeometry(0.097, 18, 10, 0, Math.PI * 2, Math.PI * 0.66, Math.PI * 0.26), hairMat, 0, -0.03, -0.006, 'Beard');
    beard.scale.set(spec.beard === 'full' ? 1.04 : 1.0, spec.beard === 'full' ? 1.12 : 0.96, 1.0);
  }
  if (spec.hat === 'beanie') {
    const beanie = add(head, new THREE.SphereGeometry(0.128, 22, 14, 0, Math.PI * 2, 0, Math.PI * 0.5), mat(spec.hatColor, 0.9), 0, 0.045, 0.01, 'Beanie');
    beanie.scale.set(0.98, 1.12, 1.03);
    add(head, new THREE.TorusGeometry(0.121, 0.016, 8, 26), mat(shade(spec.hatColor, 0.85), 0.9), 0, 0.05, 0.01).rotation.x = Math.PI / 2;
  }
}

// ─── Corps, vêtements, membres ────────────────────────────────────────────────────────────────

export function buildCharacter(spec, { labelHeight = false } = {}) {
  const group = new THREE.Group();
  group.name = `Character_${spec.id}`;
  const female = spec.sex === 'f';
  const k = spec.height / 1.8;           // échelle verticale
  const b = spec.build;                  // carrure
  const skinMat = mat(spec.skin, 0.62);
  const topMat = mat(spec.top.color, 0.82);
  const innerMat = mat(spec.top.inner ?? spec.top.color, 0.8);
  const pantsMat = mat(spec.pants, 0.86);
  const shoeMat = mat(spec.shoes.color, 0.7);
  const handMat = spec.gloves ? mat(spec.gloves, 0.6) : skinMat;

  const hipY = 0.93 * k, waistY = 1.02 * k, shoulderY = 1.47 * k;
  // Bassin et ceinture.
  const pelvis = add(group, new THREE.SphereGeometry(0.17, 18, 12), pantsMat, 0, hipY + 0.02, 0, 'Pelvis');
  pelvis.scale.set((female ? 1.08 : 0.98) * b, 0.55, 0.78 * b);
  add(group, new THREE.CylinderGeometry(0.162 * b, 0.165 * b, 0.04, 18), mat(0x2a2420, 0.55), 0, waistY - 0.015, 0, 'Belt');
  add(group, new THREE.BoxGeometry(0.05, 0.035, 0.012), mat(0xb9a36a, 0.35, { metalness: 0.6 }), 0, waistY - 0.015, -0.135 * b, 'Buckle');

  // Buste (sous-vêtement / chemise) en profil tourné.
  const torso = add(group, torsoGeometry(spec, 1.0, 0.72), innerMat, 0, waistY, 0, 'Torso');
  torso.scale.y = (shoulderY - waistY) / 0.5;
  // Couche extérieure selon le vêtement.
  const kind = spec.top.kind;
  const layered = ['jacket', 'coat', 'bomber', 'aviator', 'vest', 'hiviz'].includes(kind);
  if (female) {
    // Volume de poitrine dans la matière de la couche la plus extérieure (sinon il traverse le gilet).
    const bustMat = layered ? topMat : innerMat;
    for (const side of [-1, 1]) {
      const bust = add(group, new THREE.SphereGeometry(0.05 * b, 14, 10), bustMat, side * 0.055 * b, waistY + 0.31 * k, -(layered ? 0.098 : 0.092) * b, 'Bust');
      bust.scale.set(1.15, 0.85, 0.55); // volume discret, fondu dans le buste
    }
  }
  if (layered) {
    const open = spec.top.open || kind === 'coat' || kind === 'vest' || kind === 'hiviz';
    const outer = add(group, torsoGeometry(spec, 1.06, 0.78), topMat, 0, waistY - (kind === 'coat' ? 0.0 : 0.02), 0, 'Outer');
    outer.scale.y = (shoulderY - waistY + 0.03) / 0.5;
    if (open) {
      // Ouverture frontale : bande de la couche intérieure visible + revers.
      // Ouverture en V : large en haut, refermée vers la taille.
      const opening = add(group, new THREE.ConeGeometry(0.05 * b, (shoulderY - waistY) * 0.7, 3, 1), innerMat, 0, shoulderY - (shoulderY - waistY) * 0.36, -0.15 * b, 'Opening');
      opening.rotation.set(Math.PI, Math.PI / 6, 0); opening.scale.z = 0.12;
      for (const side of (['jacket', 'coat'].includes(kind) ? [-1, 1] : [])) {
        const lapel = add(group, new THREE.BoxGeometry(0.045, 0.14 * k, 0.012), mat(shade(spec.top.color, 0.85), 0.8), side * 0.05 * b, shoulderY - 0.1 * k, -0.15 * b, 'Lapel');
        lapel.rotation.z = side * 0.35;
      }
    } else {
      add(group, new THREE.BoxGeometry(0.008, (shoulderY - waistY) * 0.9, 0.006), mat(0x9a9a9a, 0.3, { metalness: 0.7 }), 0, (waistY + shoulderY) / 2, -0.152 * b, 'Zip');
    }
    if (kind === 'coat') {
      const skirt = add(group, new THREE.CylinderGeometry(0.175 * b, 0.215 * b, 0.42 * k, 18, 1, true), topMat, 0, waistY - 0.2 * k, 0, 'CoatSkirt');
      skirt.scale.z = 0.8;
      skirt.material.side = THREE.DoubleSide;
    }
    if (kind === 'hiviz') {
      for (const y of [0.18, 0.3]) add(group, new THREE.CylinderGeometry(0.167 * b * 1.06, 0.167 * b * 1.06, 0.025, 18, 1, true), mat(spec.top.stripes, 0.3, { emissive: 0x333333 }), 0, waistY + y * k, 0, 'Reflective').scale.z = 0.78;
    }
    if (kind === 'aviator' || kind === 'bomber') {
      const collar = add(group, new THREE.TorusGeometry(0.085, 0.03, 8, 18, Math.PI * 1.4), mat(spec.top.collar ?? shade(spec.top.color, 0.8), 0.95), 0, shoulderY + 0.005, 0.01, 'Collar');
      collar.rotation.set(Math.PI / 2, 0, Math.PI * 0.8);
      add(group, new THREE.CylinderGeometry(0.168 * b, 0.165 * b, 0.05, 18), mat(shade(spec.top.color, 0.75), 0.9), 0, waistY + 0.01, 0, 'Waistband').scale.z = 0.74;
    }
    if (spec.top.hood) {
      const hood = add(group, new THREE.TorusGeometry(0.1, 0.035, 8, 18, Math.PI * 1.2), mat(spec.top.inner, 0.9), 0, shoulderY - 0.01, 0.06, 'Hood');
      hood.rotation.set(Math.PI / 2.4, 0, Math.PI * 0.9);
    }
  } else if (kind === 'shirt') {
    add(group, new THREE.BoxGeometry(0.008, (shoulderY - waistY) * 0.9, 0.006), mat(shade(spec.top.color, 0.7), 0.7), 0, (waistY + shoulderY) / 2, -0.146 * b, 'Placket');
    const collar = add(group, new THREE.TorusGeometry(0.075, 0.016, 6, 16, Math.PI * 1.3), mat(shade(spec.top.color, 0.9), 0.8), 0, shoulderY - 0.005, -0.005, 'Collar');
    collar.rotation.set(Math.PI / 2, 0, Math.PI * 0.85);
    if (spec.top.pattern === 'check') applyCheckPattern(torso, spec.top.color);
    if (spec.top.apron) {
      const apron = add(group, new THREE.BoxGeometry(0.3 * b, 0.58 * k, 0.012), mat(spec.top.apron, 0.6), 0, waistY + 0.02, -0.158 * b, 'Apron');
      apron.rotation.x = 0.04;
    }
    if (spec.top.overalls) {
      add(group, new THREE.BoxGeometry(0.2 * b, 0.22 * k, 0.012), mat(spec.top.overalls, 0.85), 0, waistY + 0.12 * k, -0.15 * b, 'Bib');
      for (const side of [-1, 1]) {
        const strap = add(group, new THREE.BoxGeometry(0.03, 0.3 * k, 0.012), mat(spec.top.overalls, 0.85), side * 0.075 * b, waistY + 0.32 * k, -0.135 * b, 'Strap');
        strap.rotation.z = side * -0.12;
      }
    }
  }
  if (spec.backpack) {
    const pack = add(group, new THREE.BoxGeometry(0.26 * b, 0.36 * k, 0.14), mat(spec.backpack, 0.85), 0, waistY + 0.27 * k, 0.17 * b, 'Backpack');
    pack.geometry.translate(0, 0, 0);
    add(group, new THREE.BoxGeometry(0.22 * b, 0.06, 0.03), mat(shade(spec.backpack, 0.8), 0.85), 0, waistY + 0.43 * k, 0.24 * b);
  }

  // Cou et tête.
  add(group, new THREE.CylinderGeometry(female ? 0.043 : 0.052, female ? 0.048 : 0.058, 0.09 * k, 14), skinMat, 0, shoulderY + 0.035 * k, 0, 'Neck');
  const head = buildHead(spec, skinMat);
  head.position.set(0, shoulderY + 0.17 * k, 0);
  head.scale.setScalar(Math.min(1.06, Math.max(0.94, k)));
  group.add(head);
  group.userData.headObject = head;

  // Jambes : pivot de hanche, genou, chaussure avec repère de semelle (ancrage au sol).
  const legLength = hipY - 0.04;
  for (const side of [-1, 1]) {
    const legPivot = new THREE.Group();
    legPivot.name = 'LegPivot';
    legPivot.position.set(side * (female ? 0.088 : 0.095) * b, hipY, 0);
    legPivot.userData.leg = side;
    const thigh = add(legPivot, new THREE.CapsuleGeometry(0.075 * b, legLength * 0.42, 4, 12), pantsMat, 0, -legLength * 0.25, 0, 'Thigh');
    thigh.scale.z = 0.95;
    const knee = new THREE.Group();
    knee.position.y = -legLength * 0.5;
    add(knee, new THREE.CapsuleGeometry(0.06 * b, legLength * 0.4, 4, 12), pantsMat, 0, -legLength * 0.24, 0.005, 'Shin');
    const shoe = buildShoe(spec, shoeMat);
    shoe.position.set(0, -legLength * 0.5 + 0.02, -0.03);
    const sole = new THREE.Object3D();
    sole.position.set(0, -0.02, 0);
    sole.userData.footMarker = true;
    shoe.add(sole);
    knee.add(shoe);
    legPivot.add(knee);
    legPivot.userData.knee = knee;
    group.add(legPivot);
  }

  // Bras : pivot d'épaule, coude, main avec pouce.
  const armLength = 0.62 * k;
  const sleeveMat = ['vest', 'hiviz'].includes(kind) ? innerMat : (kind === 'shirt' ? innerMat : topMat);
  for (const side of [-1, 1]) {
    const armPivot = new THREE.Group();
    armPivot.name = 'ArmPivot';
    armPivot.position.set(side * (female ? 0.175 : 0.2) * b, shoulderY - 0.035, 0);
    armPivot.userData.arm = side;
    add(armPivot, new THREE.SphereGeometry(0.058 * b, 14, 10), sleeveMat, 0, 0, 0, 'Shoulder');
    add(armPivot, new THREE.CapsuleGeometry(0.048 * b, armLength * 0.36, 4, 10), sleeveMat, 0, -armLength * 0.22, 0, 'UpperArm');
    const elbow = new THREE.Group();
    elbow.position.y = -armLength * 0.46;
    const rolled = spec.top.rolled;
    add(elbow, new THREE.CapsuleGeometry(0.041 * b, armLength * 0.32, 4, 10), rolled ? skinMat : sleeveMat, 0, -armLength * 0.19, 0, 'Forearm');
    if (rolled) add(elbow, new THREE.CylinderGeometry(0.05 * b, 0.05 * b, 0.05, 12), sleeveMat, 0, -0.01, 0, 'Cuff');
    else add(elbow, new THREE.CylinderGeometry(0.046 * b, 0.044 * b, 0.03, 12), mat(shade(spec.top.color, 0.8), 0.8), 0, -armLength * 0.38, 0, 'Cuff');
    const hand = add(elbow, new THREE.SphereGeometry(0.04, 12, 10), handMat, 0, -armLength * 0.45, -0.004, 'Hand');
    hand.scale.set(0.75, 1.15, 0.5);
    const thumb = add(elbow, new THREE.CapsuleGeometry(0.012, 0.03, 3, 6), handMat, side * -0.022, -armLength * 0.43, -0.02, 'Thumb');
    thumb.rotation.z = side * 0.5;
    armPivot.add(elbow);
    armPivot.userData.elbow = elbow;
    group.add(armPivot);
  }

  group.userData.character = { id: spec.id, name: spec.name, sex: spec.sex, profession: spec.profession, age: spec.age };
  group.userData.modelBottom = 0;
  group.userData.materials = { top: topMat, pants: pantsMat, skin: skinMat };
  if (labelHeight) group.userData.labelHeight = shoulderY + 0.5 * k;
  return group;
}

function buildShoe(spec, shoeMat) {
  const shoe = new THREE.Group();
  shoe.name = 'Shoe';
  const boots = spec.shoes.kind === 'boots';
  const upper = add(shoe, new THREE.CapsuleGeometry(0.048, 0.12, 4, 10), shoeMat, 0, 0.03, -0.035, 'ShoeUpper');
  upper.rotation.x = Math.PI / 2;
  upper.scale.set(1.0, 1.0, boots ? 1.25 : 0.95);
  if (boots) add(shoe, new THREE.CylinderGeometry(0.055, 0.058, 0.11, 12), shoeMat, 0, 0.08, 0, 'BootShaft');
  const soleColor = spec.shoes.kind === 'sneakers' ? 0xf4f2ee : 0x1c1a18;
  add(shoe, new THREE.BoxGeometry(0.1, 0.022, 0.24), mat(soleColor, 0.9), 0, -0.011, -0.035, 'Sole');
  if (spec.shoes.accent) add(shoe, new THREE.BoxGeometry(0.102, 0.018, 0.08), mat(spec.shoes.accent, 0.6), 0, 0.03, -0.01, 'Accent');
  return shoe;
}

function applyCheckPattern(mesh, base) {
  const size = 64, canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  const rgb = (f, a = 1) => `rgba(${Math.round(((base >> 16) & 255) * f)},${Math.round(((base >> 8) & 255) * f)},${Math.round((base & 255) * f)},${a})`;
  ctx.fillStyle = rgb(1); ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = rgb(0.45, 0.55); for (let i = 0; i < size; i += 16) { ctx.fillRect(i, 0, 6, size); ctx.fillRect(0, i, size, 6); }
  ctx.fillStyle = 'rgba(240,230,210,.25)'; for (let i = 8; i < size; i += 16) { ctx.fillRect(i, 0, 1, size); ctx.fillRect(0, i, size, 1); }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(4, 2);
  texture.colorSpace = THREE.SRGBColorSpace;
  mesh.material = mesh.material.clone();
  mesh.material.map = texture;
  mesh.material.color.set(0xffffff);
}
