import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { clone as cloneSkinned } from 'three/addons/utils/SkeletonUtils.js';

// BlockWorld V3.0 Beta 4.24 — personnages HD réalistes (profils Élevée et Ultra).
// Modèles Microsoft Rocketbox (licence MIT) : visages sculptés, textures de peau et de vêtements,
// squelette complet et animations capturées en studio (repos, marche, course).
// Chargés à la demande (≈ 10 Mo, puis gardés en cache) ; les autres profils gardent les personnages générés.

export const HD_ROSTER = [
  // Personnages féminins choisis lors du casting (Rocketbox Female_Adult_03, _11, _17, Female_Party_01).
  { id: 'f03', sex: 'f', name: 'Maya', profession: 'Danseuse', age: 27 },
  { id: 'f11', sex: 'f', name: 'Élise', profession: 'Avocate', age: 35 },
  { id: 'f17', sex: 'f', name: 'Sarah', profession: 'Coach sportive', age: 29 },
  { id: 'p01', sex: 'f', name: 'Jade', profession: 'Musicienne', age: 25 },
  { id: 'm01', sex: 'm', name: 'Tom', profession: 'Étudiant', age: 22 },
  { id: 'm05', sex: 'm', name: 'Bernard', profession: 'Reporter', age: 56 },
  { id: 'm10', sex: 'm', name: 'Jun', profession: 'Coureur', age: 27 },
  { id: 'm16', sex: 'm', name: 'Marc', profession: 'Ingénieur', age: 41 }
];
export const HD_QUALITIES = ['high', 'ultra'];
const BASE = './assets/characters-hd';

// Neutralise l'avancée horizontale de la racine (le jeu déplace lui-même les personnages) et
// renvoie la vitesse naturelle de l'animation (m/s), pour caler la lecture sur le déplacement réel.
export function stripRootMotion(clip) {
  const track = clip.tracks.find((t) => t.name === 'Bip01.position');
  if (!track) return 0;
  const values = track.values;
  const ranges = [0, 1, 2].map((axis) => {
    let min = Infinity, max = -Infinity;
    for (let i = axis; i < values.length; i += 3) { min = Math.min(min, values[i]); max = Math.max(max, values[i]); }
    return max - min;
  });
  const forward = ranges.indexOf(Math.max(...ranges));
  const distance = ranges[forward];
  for (let i = forward; i < values.length; i += 3) values[i] = values[forward];
  return clip.duration > 0 ? distance / clip.duration : 0;
}

class HDController {
  constructor(model, clips) {
    this.mixer = new THREE.AnimationMixer(model);
    this.actions = {};
    this.speeds = {};
    for (const [name, clip] of Object.entries(clips)) {
      const action = this.mixer.clipAction(clip.clip);
      action.play();
      action.setEffectiveWeight(name === 'idle' ? 1 : 0);
      action.time = Math.random() * clip.clip.duration; // personnages désynchronisés
      this.actions[name] = action;
      this.speeds[name] = clip.speed;
    }
    this.weights = { idle: 1, walk: 0, run: 0 };
  }

  /** Mélange repos / marche / course selon la vitesse réelle (m/s), lecture calée sur le déplacement. */
  update(delta, speed = 0) {
    const target = speed < 0.15 ? { idle: 1, walk: 0, run: 0 }
      : speed < 3.2 ? { idle: 0, walk: 1, run: 0 }
      : { idle: 0, walk: Math.max(0, 1 - (speed - 3.2) / 1.2), run: Math.min(1, (speed - 3.2) / 1.2) };
    for (const name of Object.keys(this.actions)) {
      this.weights[name] = THREE.MathUtils.damp(this.weights[name], target[name] ?? 0, 9, delta);
      this.actions[name].setEffectiveWeight(this.weights[name]);
    }
    // Cadence calée sur le déplacement réel (flânerie lente des habitants jusqu'à la course du joueur à 6 m/s).
    if (this.speeds.walk) this.actions.walk.timeScale = THREE.MathUtils.clamp(speed / this.speeds.walk, 0.25, 2.2);
    if (this.speeds.run) this.actions.run.timeScale = THREE.MathUtils.clamp(speed / this.speeds.run, 0.6, 2.2);
    this.mixer.update(delta);
  }
}

export class HDCharacterLibrary {
  constructor() {
    this.loader = new GLTFLoader();
    this.models = new Map();
    this.clips = null;
    this.loading = null;
    this.ready = false;
  }

  load() {
    if (this.loading) return this.loading;
    const get = (url) => new Promise((resolve, reject) => this.loader.load(url, resolve, undefined, reject));
    this.loading = (async () => {
      const animNames = ['f_idle', 'f_walk', 'f_run', 'm_idle', 'm_walk', 'm_run'];
      const [anims, models] = await Promise.all([
        Promise.all(animNames.map((name) => get(`${BASE}/anims/${name}.glb`))),
        Promise.all(HD_ROSTER.map((spec) => get(`${BASE}/${spec.id}/model.gltf`)))
      ]);
      this.clips = { f: {}, m: {} };
      animNames.forEach((name, index) => {
        const [sex, kind] = name.split('_');
        const clip = anims[index].animations[0];
        clip.name = name;
        this.clips[sex][kind] = { clip, speed: kind === 'idle' ? 0 : stripRootMotion(clip) };
      });
      HD_ROSTER.forEach((spec, index) => this.models.set(spec.id, models[index].scene));
      this.ready = true;
      return this;
    })();
    return this.loading;
  }

  /** Personnage HD prêt à poser : regard vers −z (convention du jeu), repère de semelle, contrôleur d'animation. */
  instantiate(index) {
    const spec = HD_ROSTER[((index % HD_ROSTER.length) + HD_ROSTER.length) % HD_ROSTER.length];
    const source = this.models.get(spec.id);
    if (!source) return null;
    const model = cloneSkinned(source);
    model.rotation.y = Math.PI;
    model.traverse((object) => {
      if (!object.isMesh) return;
      object.castShadow = true;
      object.receiveShadow = true;
      object.frustumCulled = false; // boîte englobante du maillage animé non fiable
      object.material = Array.isArray(object.material) ? object.material.map((m) => m.clone()) : object.material.clone();
      for (const material of [].concat(object.material)) {
        material.color?.setRGB?.(0.94, 0.92, 0.9); // peau légèrement désaturée sous la lumière dorée
        if (material.map) material.map.colorSpace = THREE.SRGBColorSpace;
      }
    });
    const wrapper = new THREE.Group();
    wrapper.name = `HDCharacter_${spec.id}`;
    wrapper.add(model);
    const sole = new THREE.Object3D();
    sole.userData.footMarker = true;
    wrapper.add(sole);
    const controller = new HDController(model, this.clips[spec.sex]);
    wrapper.userData.hdController = controller;
    wrapper.userData.spec = spec;
    return wrapper;
  }
}

/**
 * Pose (ou retire) l'apparence HD sur un groupe existant (habitant, joueur distant, avatar).
 * L'apparence générée est masquée, pas supprimée : retour immédiat si la qualité baisse.
 */
export function applyHD(group, library, index, enabled) {
  const current = group.userData.hdWrapper;
  if (!enabled || !library?.ready) {
    if (current) { group.remove(current); group.userData.hdWrapper = null; group.userData.hd = null; }
    for (const child of group.children) if (child.userData.hiddenForHD) { child.visible = true; child.userData.hiddenForHD = false; }
    if (group.userData.proceduralIdentity) Object.assign(group.userData, group.userData.proceduralIdentity);
    return false;
  }
  if (current && current.parent === group && current.userData.index === index) return true; // déjà en place
  if (current) group.remove(current);
  const wrapper = library.instantiate(index);
  if (!wrapper) return false;
  wrapper.userData.index = index;
  for (const child of group.children) {
    if (child === wrapper || child.userData.keepWithHD) continue;
    if (child.visible && (child.isMesh || child.isGroup || child.children?.length)) { child.visible = false; child.userData.hiddenForHD = true; }
  }
  group.add(wrapper);
  group.userData.hdWrapper = wrapper;
  group.userData.hd = wrapper.userData.hdController;
  return true;
}
