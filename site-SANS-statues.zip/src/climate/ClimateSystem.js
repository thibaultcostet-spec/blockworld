import * as THREE from 'three';
const CLIMATES={
 europe:[['clair',36],['pluie',24],['brouillard',18],['orage',16]],
 africa:[['clair',45],['vent de sable',18],['pluie',14],['orage',12]],
 asia:[['clair',30],['pluie',28],['brouillard',16],['neige',18]],
 americas:[['clair',30],['pluie',22],['orage',20],['neige',14]],
 oceania:[['clair',34],['pluie',28],['orage',18],['brouillard',12]]
};
function hash(s){let h=0;for(const c of s)h=(Math.imul(h,31)+c.charCodeAt(0))|0;return h>>>0;}
export class ClimateSystem{
 constructor(game){ this.game=game; this.scene=game.scene; this.camera=game.camera; this.state='clair'; this.elapsed=0; this.duration=35; this.worldId='europe'; this.particles=null; this.baseFogFar=150; this.seed=1; this.badge=this.makeBadge(); }
 makeBadge(){ const e=document.createElement('div'); e.id='climate-indicator'; e.setAttribute('aria-live','polite'); document.body.append(e); return e; }
 setWorld(definition){ this.worldId=definition.id; this.seed=hash(definition.id); this.elapsed=0; this.apply('clair'); }
 next(){ const list=CLIMATES[this.worldId]||CLIMATES.europe; const index=(this.seed++ + Math.floor(performance.now()/30000))%list.length; const [state,duration]=list[index]; this.duration=duration; this.elapsed=0; this.apply(state); }
 apply(state){ this.state=state; this.disposeParticles(); const icons={'clair':'☀️','pluie':'🌧️','brouillard':'🌫️','orage':'⛈️','neige':'🌨️','vent de sable':'🌪️'}; this.badge.textContent=`${icons[state]||'🌤️'} ${state}`;
   const fog=this.scene.fog; if(fog){ fog.near=state==='brouillard'?12:state==='vent de sable'?18:48; const base=this.game.graphicsQuality?.profile?.fogFar||150; fog.far=state==='brouillard'?Math.min(62,base):state==='vent de sable'?Math.min(78,base):state==='pluie'||state==='neige'?Math.min(120,base):base; }
   if(['pluie','orage','neige','vent de sable'].includes(state)) this.createParticles(state);
 }
 createParticles(state){ const count=this.game.touchMode?320:650; const positions=new Float32Array(count*3); for(let i=0;i<count;i++){positions[i*3]=(Math.random()-.5)*38;positions[i*3+1]=Math.random()*22;positions[i*3+2]=(Math.random()-.5)*38;}
   const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(positions,3)); const color=state==='neige'?0xffffff:state==='vent de sable'?0xd6a65b:0x9bc9f5; const size=state==='neige'?.12:state==='vent de sable'?.08:.055;
   this.particles=new THREE.Points(g,new THREE.PointsMaterial({color,size,transparent:true,opacity:.72,depthWrite:false})); this.particles.name='ClimateParticles'; this.scene.add(this.particles);
 }
 disposeParticles(){ if(!this.particles)return;this.scene.remove(this.particles);this.particles.geometry.dispose();this.particles.material.dispose();this.particles=null; }
 update(delta, playerPosition){ this.elapsed+=delta; if(this.elapsed>=this.duration)this.next(); if(this.particles){this.particles.position.set(playerPosition.x,playerPosition.y,playerPosition.z); const p=this.particles.geometry.attributes.position.array; const snow=this.state==='neige'; for(let i=0;i<p.length;i+=3){p[i+1]-=delta*(snow?2.2:this.state==='vent de sable'?.4:11);p[i]+=delta*(this.state==='vent de sable'?5.5:this.state==='orage'?1.6:.5);if(p[i+1]<-2){p[i+1]=20;p[i]=(Math.random()-.5)*38;p[i+2]=(Math.random()-.5)*38;}}this.particles.geometry.attributes.position.needsUpdate=true;}
   if(this.state==='orage' && Math.random()<delta*.12){this.game.sun.intensity=5.5;setTimeout(()=>{if(this.state==='orage')this.game.sun.intensity=.95},70);} }
}
