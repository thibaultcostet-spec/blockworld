import * as THREE from 'three';

// BlockWorld V3.0 Beta 4.22 — combat contre les créatures (animaux et habitants).
// Toutes les armes les touchent, avec le même retour d'impact que les joueurs (HitFeedback).
// Touchée, une créature fuit à l'opposé du tireur ; à 0 PV elle s'effondre puis disparaît.
// Un animal abattu donne des portions de viande ; animaux et habitants réapparaissent ensuite.

export const ANIMAL_STATS = {
  rabbit: { health: 12, meat: 1 }, bird: { health: 6, meat: 1 }, deer: { health: 45, meat: 3 }, gazelle: { health: 35, meat: 2 },
  llama: { health: 50, meat: 3 }, zebra: { health: 55, meat: 3 }, bison: { health: 90, meat: 5 }, yak: { health: 90, meat: 5 },
  panda: { health: 70, meat: 3 }
};
export const CITIZEN_HEALTH = 60;
const RESPAWN = { animal: 75, citizen: 45 };

export function creatureOf(object) {
  let node = object;
  while (node && !node.userData?.creatureKind) node = node.parent;
  return node ?? null;
}

export class CreatureCombat {
  constructor(game) {
    this.game = game;
    this.dying = [];
  }

  /** Prépare une créature (appelé à la création des animaux et des habitants). */
  static tag(group, kind, type = '') {
    const stats = kind === 'animal' ? (ANIMAL_STATS[type] ?? { health: 30, meat: 2 }) : { health: CITIZEN_HEALTH, meat: 0 };
    Object.assign(group.userData, { creatureKind: kind, maxHealth: stats.health, health: stats.health, meat: stats.meat, dead: false });
    return group;
  }

  targets() {
    const list = [];
    for (const animal of this.game.fauna?.animals ?? []) if (animal.visible && !animal.userData.dead) list.push(animal);
    for (const agent of this.game.life?.ai?.agents ?? []) if (agent.visible && !agent.userData.dead) list.push(agent);
    return list;
  }

  /** Inflige des dégâts ; renvoie { label, health, maxHealth, killed, meat }. */
  hit(creature, damage, { weapon = '', source = null } = {}) {
    const data = creature?.userData;
    if (!data?.creatureKind || data.dead) return null;
    data.health = Math.max(0, data.health - damage);
    const killed = data.health <= 0;
    this.game.hitFeedback?.onRemoteHit({ group: creature }, { amount: damage, weapon, source, kill: killed });
    const label = data.creatureKind === 'animal' ? animalLabel(data.type) : (data.name ?? 'Habitant');
    if (killed) this.kill(creature);
    else this.flee(creature, source);
    let meat = 0;
    if (killed && data.creatureKind === 'animal') meat = this.game.hunger?.addFood ? (this.game.hunger.addFood(data.meat), data.meat) : 0;
    return { label, health: Math.round(data.health), maxHealth: data.maxHealth, killed, meat, kind: data.creatureKind };
  }

  damageInRadius(center, radius, damage, weapon = '') {
    let touched = 0, meat = 0;
    for (const creature of this.targets()) {
      const distance = creature.position.distanceTo(center);
      if (distance > radius + 0.6) continue;
      const result = this.hit(creature, damage * Math.max(0.35, 1 - distance / (radius + 0.6)), { weapon, source: center });
      if (result) { touched += 1; meat += result.meat; }
    }
    return { touched, meat };
  }

  flee(creature, source) {
    const data = creature.userData;
    const from = source ?? this.game.player?.getEyePosition?.() ?? creature.position;
    const away = new THREE.Vector3(creature.position.x - from.x, 0, creature.position.z - from.z);
    if (away.lengthSq() < 0.01) away.set(Math.random() - 0.5, 0, Math.random() - 0.5);
    away.normalize();
    data.fleeUntil = performance.now() + 6000;
    data.fleeDirection = away;
    if (data.creatureKind === 'citizen') {
      data.baseSpeed ??= data.speed;
      data.speed = data.baseSpeed * 2.6;
      data.path = [{ x: creature.position.x + away.x * 14, z: creature.position.z + away.z * 14 }];
      data.pathIndex = 0;
      data.activityLabel = 'Fuit !';
    }
  }

  kill(creature) {
    const data = creature.userData;
    data.dead = true;
    data.deathAge = 0;
    data.respawnIn = RESPAWN[data.creatureKind] ?? 60;
    data.fallSide = Math.random() < 0.5 ? -1 : 1;
    this.dying.push(creature);
  }

  update(delta) {
    const now = performance.now();
    for (const agent of this.game.life?.ai?.agents ?? []) {
      const data = agent.userData;
      if (data.baseSpeed && !data.dead && (data.fleeUntil ?? 0) < now) { data.speed = data.baseSpeed; data.baseSpeed = undefined; }
    }
    this.dying = this.dying.filter((creature) => {
      const data = creature.userData;
      data.deathAge += delta;
      // Effondrement sur le côté (0,5 s), puis disparition au bout de 5 s ; réapparition plus tard.
      const t = Math.min(1, data.deathAge / 0.5);
      creature.rotation.z = data.fallSide * (Math.PI / 2) * t * t;
      if (data.deathAge > 5) creature.visible = false;
      if (data.deathAge < data.respawnIn) return true;
      this.respawn(creature);
      return false;
    });
  }

  respawn(creature) {
    const data = creature.userData;
    Object.assign(data, { dead: false, health: data.maxHealth, fleeUntil: 0 });
    creature.rotation.set(0, creature.rotation.y, 0);
    const home = data.creatureKind === 'animal' ? data.origin : data.home;
    if (home) {
      const ground = this.game.world?.getSurfaceHeight?.(home.x, home.z);
      creature.position.set(home.x, Number.isFinite(ground) ? ground + 0.5 : creature.position.y, home.z);
      this.game.fauna?.grounding?.settle?.(creature, home.x, home.z, 0);
    }
    if (data.creatureKind === 'citizen') { data.path = []; data.pathIndex = 0; }
    creature.visible = true;
  }
}

function animalLabel(type) {
  return { rabbit: 'Lapin', bird: 'Oiseau', deer: 'Cerf', gazelle: 'Gazelle', llama: 'Lama', zebra: 'Zèbre', bison: 'Bison', yak: 'Yack', panda: 'Panda' }[type] ?? 'Animal';
}
