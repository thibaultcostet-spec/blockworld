import * as THREE from 'three';
import { computeHitReaction, screenAngleToSource, normalizeImpactStyle, IMPACT_STYLE_STORAGE_KEY } from './HitReactionProfiles.js';

// BlockWorld V3.0 Beta 4.17 — retour visuel des coups, identique dans son principe pour toutes les armes.
// Victime : visée déviée, secousse, poussée, ralentissement, indicateur de direction, voile d'écran.
// Avatar touché : sursaut, éclair bref, particules selon l'arme (étincelles, poussière, braises…),
// au plus 2–3 minuscules éclats sombres pour les balles et la mêlée. Tireur : marqueur de touche.

const PARTICLE_COLORS = {
  sparks: [0xfff2c2, 0xffd36b, 0xffffff],
  dust: [0xb8aa92, 0x9c8f7a, 0xd6cbb7],
  smoke: [0x77736c, 0x9a958c, 0x5f5b55],
  embers: [0xff8a1f, 0xffc04a, 0xff5a12],
  frost: [0xbfe9ff, 0x8fd3ff, 0xffffff]
};

export class HitFeedback {
  constructor(game) {
    this.game = game;
    this.overlay = document.getElementById('hit-overlay');
    this.vignette = this.overlay?.querySelector('.hit-vignette') ?? null;
    this.indicatorLayer = this.overlay?.querySelector('.hit-indicators') ?? null;
    this.marker = document.getElementById('hit-marker');
    this.particles = [];
    this.flinches = [];
    this.geometry = new THREE.BoxGeometry(1, 1, 1);
    this.overlayLevel = 0;
    this.overlayTint = [110, 24, 20];
    this.decals = [];
    this.splatTexture = null;
    this.style = 'soft';
    try { this.style = normalizeImpactStyle(globalThis.localStorage?.getItem(IMPACT_STYLE_STORAGE_KEY)); } catch (_error) { this.style = 'soft'; }
    this.bindStyleSelect(document.getElementById('impact-style'));
  }

  // Réglage « Impacts » : le style Intense demande une confirmation d'âge et n'affecte que ce joueur.
  bindStyleSelect(select) {
    if (!select) return;
    select.value = this.style;
    select.addEventListener('change', () => {
      let next = normalizeImpactStyle(select.value);
      if (next === 'intense' && !window.confirm('Le style Intense affiche du sang plus présent (gouttes, éclaboussures au sol et sur les murs). Il est réservé aux adultes.\n\nConfirmes-tu avoir 18 ans ou plus ?')) next = 'soft';
      this.setStyle(next);
      select.value = next;
    });
  }

  setStyle(style) {
    this.style = normalizeImpactStyle(style);
    try { globalThis.localStorage?.setItem(IMPACT_STYLE_STORAGE_KEY, this.style); } catch (_error) { /* stockage indisponible */ }
    if (this.style === 'soft') this.clearDecals();
  }

  /** Coup reçu par le joueur local. `source` : position du tireur (ou du monstre), facultative. */
  onLocalHit({ amount = 10, weapon = '', source = null } = {}) {
    const player = this.game.player;
    if (!player) return null;
    const position = player.getEyePosition();
    let direction = null;
    if (source) {
      direction = { x: position.x - source.x, z: position.z - source.z };
      const length = Math.hypot(direction.x, direction.z);
      direction = length > 0.01 ? { x: direction.x / length, z: direction.z / length } : null;
    }
    const reaction = computeHitReaction({ weapon, damage: amount, direction, style: this.style });
    player.applyHitReaction?.(reaction);
    this.flashScreen(reaction);
    if (source) this.showIndicator(screenAngleToSource(player.yaw ?? 0, source, position), reaction);
    this.game.sfx?.playImpact?.('monster');
    return reaction;
  }

  /** Coup reçu par un autre joueur (vu par tous, y compris le tireur). */
  onRemoteHit(remote, { weapon = '', amount = 10, source = null, kill = false } = {}) {
    const group = remote?.group;
    if (!group) return;
    const center = group.position.clone();
    center.y += 1.15;
    let direction = null;
    if (source) {
      const d = new THREE.Vector3(center.x - source.x, 0, center.z - source.z);
      if (d.lengthSq() > 0.0001) direction = d.normalize();
    }
    const reaction = computeHitReaction({ weapon, damage: amount, direction, style: this.style, kill });
    this.flinch(group, direction, reaction);
    this.burst(center, direction, reaction);
    if (reaction.splats) this.splatter(center, direction, reaction, group.position.y);
  }

  /** Marqueur sur le réticule du tireur : blanc = touché, rouge = éliminé. */
  showHitMarker(kill = false) {
    if (!this.marker) return;
    this.marker.classList.remove('show', 'kill');
    void this.marker.offsetWidth; // relance l'animation CSS
    this.marker.classList.add('show');
    if (kill) this.marker.classList.add('kill');
    this.game.sfx?.playClick?.({ frequency: kill ? 520 : 1250, duration: 0.05 });
  }

  flashScreen(reaction) {
    this.overlayLevel = Math.max(this.overlayLevel, reaction.flash);
    this.overlayTint = reaction.tint;
  }

  showIndicator(angle, reaction) {
    if (!this.indicatorLayer) return;
    const arc = document.createElement('div');
    arc.className = 'hit-indicator';
    arc.style.transform = `rotate(${angle}rad)`;
    arc.style.setProperty('--hit-color', `rgb(${reaction.tint.join(',')})`);
    this.indicatorLayer.appendChild(arc);
    setTimeout(() => arc.remove(), 1100);
  }

  flinch(group, direction, reaction) {
    // Sursaut : bascule brève à l'opposé du tir, puis retour amorti.
    const axis = direction ? new THREE.Vector3(direction.z, 0, -direction.x) : new THREE.Vector3(1, 0, 0);
    this.flinches = this.flinches.filter((entry) => entry.group !== group); // la couleur d'origine reste mémorisée sur les matériaux
    this.flinches.push({ group, axis, amplitude: 0.22 + reaction.intensity * 0.22, age: 0, duration: 0.42, flash: 0.14 });
    // Couleur d'origine mémorisée sur le matériau (souvent partagé entre plusieurs pièces de l'avatar),
    // une seule fois : sinon une pièce mémorisait le blanc posé par la précédente et l'avatar restait blanc.
    group.traverse((object) => {
      const material = object.isMesh ? object.material : null;
      if (!material?.emissive) return;
      if (material.userData.hitBaseEmissive === undefined) {
        material.userData.hitBaseEmissive = material.emissive.getHex();
        material.userData.hitBaseIntensity = material.emissiveIntensity ?? 1;
      }
      material.emissive.setHex(0xffffff);
      material.emissiveIntensity = 0.55;
    });
  }

  burst(center, direction, reaction) {
    const palette = PARTICLE_COLORS[reaction.particles] ?? PARTICLE_COLORS.sparks;
    const count = Math.round(8 + reaction.intensity * 8);
    const spawn = (color, size, speed, gravity, life) => {
      const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 1, depthWrite: false });
      const mesh = new THREE.Mesh(this.geometry, material);
      mesh.scale.setScalar(size);
      mesh.position.copy(center).add(new THREE.Vector3((Math.random() - 0.5) * 0.3, (Math.random() - 0.3) * 0.5, (Math.random() - 0.5) * 0.3));
      const velocity = new THREE.Vector3((Math.random() - 0.5) * speed, Math.random() * speed * 0.8, (Math.random() - 0.5) * speed);
      if (direction) velocity.addScaledVector(direction, speed * 0.7);
      this.game.scene.add(mesh);
      this.particles.push({ mesh, velocity, gravity, age: 0, life });
    };
    for (let index = 0; index < count; index += 1) {
      const color = palette[index % palette.length];
      if (reaction.particles === 'smoke') spawn(color, 0.18 + Math.random() * 0.2, 2.2, -0.6, 0.9);
      else if (reaction.particles === 'dust') spawn(color, 0.06 + Math.random() * 0.07, 3.2, 6, 0.55);
      else spawn(color, 0.035 + Math.random() * 0.05, 5.5, 9, 0.38);
    }
    if (reaction.style === 'intense') {
      const blood = [0x8a0c0c, 0x6a0808, 0xa51414];
      for (let index = 0; index < (reaction.gore ?? 0); index += 1) spawn(blood[index % 3], 0.04 + Math.random() * 0.07, 4.2, 9.5, 0.55 + Math.random() * 0.3);
    } else {
      // Style Doux : au plus quelques minuscules éclats sombres, qui disparaissent vite.
      for (let index = 0; index < (reaction.gore ?? 0); index += 1) spawn(0x5a1414, 0.035, 2.4, 9, 0.32);
    }
  }

  // Style Intense : éclaboussures persistantes au sol et sur le mur derrière la cible (≈ 25 s).
  splatter(center, direction, reaction, groundY) {
    if (!this.splatTexture) this.splatTexture = makeSplatTexture();
    const place = (position, normal, size) => {
      const material = new THREE.MeshBasicMaterial({ map: this.splatTexture, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, opacity: 0.92 });
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(size, size), material);
      mesh.position.copy(position).addScaledVector(normal, 0.02);
      mesh.lookAt(position.clone().add(normal));
      mesh.rotateZ(Math.random() * Math.PI * 2);
      this.game.scene.add(mesh);
      this.decals.push({ mesh, age: 0, life: 25 });
      while (this.decals.length > 40) this.removeDecal(this.decals.shift());
    };
    const ground = this.game.world?.getSurfaceHeight?.(center.x, center.z);
    const floorY = Number.isFinite(ground) ? ground + 0.5 : groundY;
    const along = direction ?? new THREE.Vector3(0, 0, 0);
    place(new THREE.Vector3(center.x + along.x * 0.5, floorY, center.z + along.z * 0.5), new THREE.Vector3(0, 1, 0), 0.7 + reaction.intensity * 0.6);
    if (direction && this.game.world?.getRaycastMeshes) {
      const raycaster = new THREE.Raycaster(center, direction.clone().normalize(), 0, 3);
      const [hit] = raycaster.intersectObjects(this.game.world.getRaycastMeshes(), false);
      if (hit?.face) {
        const normal = hit.face.normal.clone();
        if (hit.object.isInstancedMesh && hit.instanceId !== undefined) {
          const matrix = new THREE.Matrix4(); hit.object.getMatrixAt(hit.instanceId, matrix);
          normal.transformDirection(matrix);
        }
        place(hit.point, normal.normalize(), 0.6 + reaction.intensity * 0.5);
      }
    }
  }

  removeDecal(decal) {
    if (!decal) return;
    this.game.scene.remove(decal.mesh);
    decal.mesh.geometry.dispose();
    decal.mesh.material.dispose();
  }

  clearDecals() { for (const decal of this.decals) this.removeDecal(decal); this.decals = []; }

  update(delta) {
    // Voile d'écran : bords assombris et teintés, légère désaturation, retour en ~0,6 s.
    if (this.vignette) {
      this.overlayLevel = Math.max(0, this.overlayLevel - delta * 1.6);
      const [r, g, b] = this.overlayTint;
      this.vignette.style.opacity = this.overlayLevel.toFixed(3);
      this.vignette.style.background = `radial-gradient(ellipse at center, transparent 42%, rgba(${r},${g},${b},.55) 82%, rgba(${Math.round(r * 0.5)},${Math.round(g * 0.5)},${Math.round(b * 0.5)},.85) 100%)`;
      this.vignette.style.backdropFilter = this.overlayLevel > 0.02 ? `saturate(${(1 - this.overlayLevel * 0.55).toFixed(2)})` : 'none';
    }
    for (const entry of this.flinches) {
      entry.age += delta;
      const t = Math.min(1, entry.age / entry.duration);
      const angle = Math.sin(t * Math.PI) * entry.amplitude * (1 - t * 0.6);
      entry.group.quaternion.setFromAxisAngle(entry.axis, angle).premultiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), entry.group.rotation.y));
      if (entry.age >= entry.flash && !entry.restored) {
        entry.restored = true;
        entry.group.traverse((object) => {
          const material = object.isMesh ? object.material : null;
          if (!material || material.userData.hitBaseEmissive === undefined) return;
          material.emissive.setHex(material.userData.hitBaseEmissive);
          material.emissiveIntensity = material.userData.hitBaseIntensity;
        });
      }
    }
    this.flinches = this.flinches.filter((entry) => {
      if (entry.age < entry.duration) return true;
      entry.group.rotation.x = 0; entry.group.rotation.z = 0;
      return false;
    });
    this.decals = this.decals.filter((decal) => {
      decal.age += delta;
      if (decal.age > decal.life - 5) decal.mesh.material.opacity = Math.max(0, 0.92 * (decal.life - decal.age) / 5);
      if (decal.age < decal.life) return true;
      this.removeDecal(decal);
      return false;
    });
    this.particles = this.particles.filter((particle) => {
      particle.age += delta;
      particle.velocity.y -= particle.gravity * delta;
      particle.velocity.multiplyScalar(Math.exp(-2.2 * delta));
      particle.mesh.position.addScaledVector(particle.velocity, delta);
      particle.mesh.rotation.x += delta * 6; particle.mesh.rotation.y += delta * 5;
      const t = particle.age / particle.life;
      particle.mesh.material.opacity = Math.max(0, 1 - t * t);
      if (t < 1) return true;
      this.game.scene.remove(particle.mesh);
      particle.mesh.material.dispose();
      return false;
    });
  }
}

// Tache procédurale : disque irrégulier + gouttelettes, rouge sombre (générée une seule fois).
function makeSplatTexture() {
  const size = 128, canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(110,8,8,0.9)';
  ctx.beginPath();
  for (let k = 0; k <= 24; k += 1) {
    const a = (k / 24) * Math.PI * 2, r = 26 + Math.random() * 16;
    const x = 64 + Math.cos(a) * r, y = 64 + Math.sin(a) * r;
    if (k === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  }
  ctx.fill();
  for (let k = 0; k < 18; k += 1) {
    const a = Math.random() * Math.PI * 2, d = 36 + Math.random() * 24, r = 2 + Math.random() * 6;
    ctx.fillStyle = `rgba(${90 + Math.round(Math.random() * 40)},6,6,${0.6 + Math.random() * 0.35})`;
    ctx.beginPath(); ctx.arc(64 + Math.cos(a) * d, 64 + Math.sin(a) * d, r, 0, Math.PI * 2); ctx.fill();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}
