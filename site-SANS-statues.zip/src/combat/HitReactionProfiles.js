// BlockWorld V3.0 Beta 4.17 — réactions aux coups : familles d'armes et calcul de l'intensité.
// Module pur (sans Three.js ni DOM), testable sous Node. Même principe pour toutes les armes :
// l'intensité suit les dégâts, la « signature » (poussée, secousse, couleur) dépend de la famille.

export const HIT_FAMILIES = {
  ballistic: { kick: 0.030, yaw: 0.020, shake: 0.55, push: 3.2, hop: 0, slow: 0.62, stagger: 0.32, tint: [110, 24, 20], particles: 'sparks', gore: 2 },
  heavy: { kick: 0.075, yaw: 0.040, shake: 0.95, push: 6.0, hop: 0.8, slow: 0.48, stagger: 0.55, tint: [120, 22, 18], particles: 'sparks', gore: 3 },
  melee: { kick: 0.040, yaw: 0.070, shake: 0.80, push: 5.2, hop: 0.6, slow: 0.55, stagger: 0.45, tint: [105, 30, 22], particles: 'dust', gore: 2 },
  explosive: { kick: 0.060, yaw: 0.060, shake: 1.40, push: 8.5, hop: 4.2, slow: 0.50, stagger: 0.70, tint: [70, 60, 52], particles: 'smoke', gore: 0 },
  fire: { kick: 0.035, yaw: 0.030, shake: 0.65, push: 3.6, hop: 0.4, slow: 0.60, stagger: 0.40, tint: [190, 92, 20], particles: 'embers', gore: 0 },
  ice: { kick: 0.025, yaw: 0.020, shake: 0.45, push: 2.4, hop: 0, slow: 0.35, stagger: 1.10, tint: [70, 150, 210], particles: 'frost', gore: 0 }
};

const WEAPON_FAMILY = {
  pistol: 'ballistic', revolver: 'ballistic', smg: 'ballistic', carbine: 'ballistic', ak47: 'ballistic', dmr: 'ballistic',
  sniper: 'heavy', shotgun: 'heavy',
  sword: 'melee', axe: 'melee', hammer: 'melee', pickaxe: 'melee', shovel: 'melee', monster: 'melee',
  grenade: 'explosive', explosion: 'explosive',
  fireball: 'fire', 'ice-bolt': 'ice', icebolt: 'ice', ice: 'ice',
  bow: 'ballistic', slingshot: 'melee', net: 'ice', companion: 'melee' // Beta 4.28 : outils doux et compagnon
};

// Beta 4.18 : deux styles d'impact, choisis par chaque joueur pour son propre affichage.
// « soft » (défaut) : retenue (au plus 3 éclats sombres). « intense » (adultes) : gouttes de sang
// nombreuses, éclaboussures au sol et sur les murs, voile rouge plus franc. La physique est identique.
export const IMPACT_STYLES = ['soft', 'intense'];
export const IMPACT_STYLE_STORAGE_KEY = 'blockworld-impact-style';
const INTENSE_GORE = { ballistic: 12, heavy: 22, melee: 16, explosive: 14, fire: 3, ice: 2 };
const INTENSE_TINT = { ballistic: [165, 8, 8], heavy: [175, 6, 6], melee: [160, 10, 10], explosive: [140, 20, 12] };

export function normalizeImpactStyle(value) { return value === 'intense' ? 'intense' : 'soft'; }

export function hitFamily(weapon = '') {
  return WEAPON_FAMILY[String(weapon).toLowerCase()] ?? 'ballistic';
}

/**
 * Réaction d'un coup reçu.
 * @param {object} hit  { weapon, damage, direction: {x,z} vecteur unitaire du tireur vers la victime }
 * @returns paramètres directement applicables par le joueur et l'affichage.
 */
export function computeHitReaction({ weapon = '', damage = 10, direction = null, style = 'soft', kill = false } = {}) {
  const familyName = hitFamily(weapon);
  const family = HIT_FAMILIES[familyName];
  const intensity = Math.max(0.25, Math.min(1.4, (Number(damage) || 0) / 60));
  const side = direction ? Math.sign(direction.x * 0.6 + direction.z * 0.4) || 1 : (Math.random() < 0.5 ? -1 : 1);
  const length = direction ? Math.hypot(direction.x, direction.z) || 1 : 1;
  return {
    family: familyName,
    intensity,
    kickPitch: family.kick * intensity,
    kickYaw: family.yaw * intensity * side,
    shake: family.shake * intensity,
    pushX: direction ? (direction.x / length) * family.push * intensity : 0,
    pushZ: direction ? (direction.z / length) * family.push * intensity : 0,
    hop: family.hop * Math.min(1, intensity),
    slow: family.slow,
    stagger: family.stagger * Math.min(1.2, 0.6 + intensity * 0.5),
    tint: style === 'intense' ? (INTENSE_TINT[familyName] ?? family.tint) : family.tint,
    particles: family.particles,
    gore: style === 'intense' ? Math.round(INTENSE_GORE[familyName] * Math.min(1.3, 0.7 + intensity * 0.4) * (kill ? 1.6 : 1)) : family.gore,
    splats: style === 'intense' && INTENSE_GORE[familyName] >= 10,
    style: normalizeImpactStyle(style),
    flash: Math.min(style === 'intense' ? 0.95 : 0.85, (style === 'intense' ? 0.5 : 0.35) + intensity * 0.35)
  };
}

/** Angle (radians, sens horaire à l'écran) de la source par rapport au regard, pour l'indicateur. */
export function screenAngleToSource(viewYaw, from, to) {
  const dx = from.x - to.x, dz = from.z - to.z;
  const sourceYaw = Math.atan2(-dx, -dz);
  let angle = viewYaw - sourceYaw;
  while (angle > Math.PI) angle -= Math.PI * 2;
  while (angle < -Math.PI) angle += Math.PI * 2;
  return angle;
}
