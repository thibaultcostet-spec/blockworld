// BlockWorld V3.0 Beta 4.28 — outils doux : flèche et caillou visibles en vol (trajectoire courbe), filet lancé
// qui recouvre la cible. Le calcul du coup reste celui des autres armes (rayon instantané, même retour d'impact) :
// ces objets ne sont qu'un rendu, ils ne touchent rien eux-mêmes.
import * as THREE from 'three';

export const PROJECTILE_SPEED = { arrow: 42, stone: 30, net: 18 };
export const NET_RULES = { monsterSeconds: 6, animalSeconds: 8, radius: 1.8 };

/** Hauteur de la flèche en vol (parabole, flèche d'environ 4 % de la portée) — pure, testable. */
export function arcHeight(progress, distance) {
  const p = Math.min(1, Math.max(0, progress));
  return 4 * p * (1 - p) * Math.min(1.6, distance * 0.04);
}

function buildArrow() {
  const group = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.7, 5), new THREE.MeshStandardMaterial({ color: 0x8a6034, roughness: 0.8 }));
  shaft.rotation.x = Math.PI / 2;
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.09, 6), new THREE.MeshStandardMaterial({ color: 0x9aa3ad, metalness: 0.6, roughness: 0.4 }));
  tip.rotation.x = -Math.PI / 2; tip.position.z = -0.39;
  const fletch = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.004, 0.14), new THREE.MeshStandardMaterial({ color: 0xd8432f, roughness: 0.9 }));
  fletch.position.z = 0.3;
  const fletch2 = fletch.clone(); fletch2.rotation.z = Math.PI / 2;
  group.add(shaft, tip, fletch, fletch2);
  return group;
}

function buildStone() {
  return new THREE.Mesh(new THREE.DodecahedronGeometry(0.06, 0), new THREE.MeshStandardMaterial({ color: 0x8c8780, roughness: 0.95 }));
}

function buildNet() {
  const geometry = new THREE.SphereGeometry(1, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2);
  const material = new THREE.MeshBasicMaterial({ color: 0xe8dcc0, wireframe: true, transparent: true, opacity: 0.85 });
  return new THREE.Mesh(geometry, material);
}

export class SoftTools {
  constructor(game) {
    this.game = game;
    this.group = new THREE.Group();
    this.group.name = 'SoftTools';
    game.scene.add(this.group);
    this.flights = [];
    this.nets = [];
  }

  /** Lance un projectile visible de `from` à `to`. `onLand` est appelé à l'arrivée (filet). */
  launch(kind, from, to, onLand = null) {
    const object = kind === 'arrow' ? buildArrow() : kind === 'net' ? buildNet() : buildStone();
    if (kind === 'net') object.scale.setScalar(0.25);
    object.position.copy(from);
    this.group.add(object);
    const distance = from.distanceTo(to);
    this.flights.push({ kind, object, from: from.clone(), to: to.clone(), distance, age: 0, duration: Math.max(0.08, distance / (PROJECTILE_SPEED[kind] ?? 30)), onLand, stuck: 0 });
  }

  /** Filet posé au sol, qui suit éventuellement une cible, puis s'efface. */
  dropNet(position, seconds, follow = null) {
    const net = buildNet();
    net.position.copy(position);
    net.scale.set(NET_RULES.radius * 0.8, 1.1, NET_RULES.radius * 0.8);
    this.group.add(net);
    this.nets.push({ net, remaining: seconds, total: seconds, follow });
  }

  update(delta) {
    for (let i = this.flights.length - 1; i >= 0; i -= 1) {
      const f = this.flights[i];
      if (f.stuck > 0) {
        f.stuck -= delta;
        if (f.stuck <= 0) { this.group.remove(f.object); this.flights.splice(i, 1); }
        continue;
      }
      f.age += delta;
      const p = Math.min(1, f.age / f.duration);
      const previous = f.object.position.clone();
      f.object.position.lerpVectors(f.from, f.to, p);
      f.object.position.y += arcHeight(p, f.distance);
      if (f.kind === 'arrow') { const ahead = f.object.position.clone().add(f.object.position.clone().sub(previous)); f.object.lookAt(ahead); f.object.rotateY(Math.PI); }
      else if (f.kind === 'net') { f.object.scale.setScalar(0.25 + p * 1.2); f.object.rotation.y += delta * 9; }
      else f.object.rotation.x += delta * 14;
      if (p >= 1) {
        f.onLand?.(f.to);
        if (f.kind === 'arrow') { f.stuck = 2.5; continue; }   // la flèche reste plantée un instant
        this.group.remove(f.object);
        this.flights.splice(i, 1);
      }
    }
    for (let i = this.nets.length - 1; i >= 0; i -= 1) {
      const n = this.nets[i];
      n.remaining -= delta;
      if (n.follow?.position) n.net.position.set(n.follow.position.x, n.net.position.y, n.follow.position.z);
      n.net.material.opacity = 0.85 * Math.min(1, n.remaining / 0.8);
      if (n.remaining <= 0) { this.group.remove(n.net); this.nets.splice(i, 1); }
    }
  }
}
