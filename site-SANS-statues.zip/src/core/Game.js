import * as THREE from 'three';
import { Input } from './Input.js';
import { World } from '../world/World.js';
import { Player } from '../player/Player.js';
import { Hud } from '../ui/Hud.js';
import { TouchControls } from '../ui/TouchControls.js';
import { MonsterManager } from '../entities/MonsterManager.js';
import { BLOCK_TYPES } from '../world/BlockTypes.js';
import { getAttackProfile, getHitsToBreak } from '../items/ItemCatalog.js';
import { ModeController } from '../modes/ModeController.js';
import { MODE_BY_ID, MODE_DEFINITIONS } from '../modes/ModeRegistry.js';
import { CaveSystem } from '../caves/CaveSystem.js';
import { resolvePlacement } from '../world/PlacementRules.js';
import { SpatialAmbience } from '../audio/SpatialAmbience.js';
import { SpawnProtection } from '../systems/SpawnProtection.js';
import { MultiplayerClient } from '../network/MultiplayerClient.js';
import { RemotePlayerManager } from '../network/RemotePlayerManager.js';
import { DEFAULT_WORLD_ID, WORLD_BY_ID, WORLD_DEFINITIONS, getWorldDefinition } from '../worlds/WorldRegistry.js';
import { WeaponSystem } from '../weapons/WeaponSystem.js';
import { WeaponViewModel } from '../weapons/WeaponViewModel.js';
import { AudioManager } from '../audio/AudioManager.js';
import { SoundEffectsManager } from '../audio/SoundEffectsManager.js';
import { LandmarkPassport } from '../exploration/LandmarkPassport.js';
import { NavigationMap } from '../exploration/NavigationMap.js';
import { PassportView } from '../exploration/PassportView.js';
import { StabilitySystem } from '../engineering/StabilitySystem.js';
import { DisasterManager } from '../disasters/DisasterManager.js';
import { FaunaManager } from '../fauna/FaunaManager.js';
import { ClimateSystem } from '../climate/ClimateSystem.js';
import { LivingWaterSystem } from '../water/LivingWaterSystem.js';
import { LifeEngine } from '../life/LifeEngine.js';
import { GraphicsQualityManager } from '../graphics/GraphicsQualityManager.js';
import { AtmosphereSystem } from '../graphics/AtmosphereSystem.js';
import { RenderPipeline } from '../graphics/RenderPipeline.js';
import { MonumentVisualEnhancer } from '../graphics/MonumentVisualEnhancer.js';
import { ScenicVegetationSystem } from '../graphics/ScenicVegetationSystem.js';
import { MicroVoxelDecor, buildVoxelClouds, updateVoxelClouds } from '../graphics/MicroVoxelDecor.js';
import { HitFeedback } from '../combat/HitFeedback.js';
import { StatueDecor } from '../graphics/StatueDecor.js';
import { CharacterSelector } from '../ui/CharacterSelector.js';
import { CreatureCombat, creatureOf } from '../combat/CreatureCombat.js';
import { HungerSystem } from '../systems/HungerSystem.js';
import { GamepadInput } from '../core/GamepadInput.js';
import { ControlsLegend } from '../ui/ControlsLegend.js';
import { HDCharacterLibrary, HD_ROSTER, HD_QUALITIES, applyHD } from '../characters/HDCharacters.js';
import { AmbientDetailSystem } from '../graphics/AmbientDetailSystem.js';
import { HudContext } from '../ui/HudContext.js';
import { PauseMenu } from '../ui/PauseMenu.js';
import { BuildFeedback } from '../graphics/BuildFeedback.js';
import { CampfireSystem, CAMPFIRE_COOK_RADIUS } from '../world/Campfires.js';
import { NightLights } from '../graphics/NightLights.js';
import { FishingSystem } from '../systems/Fishing.js';
import { PhotoMode } from '../ui/PhotoMode.js';
import { SoftTools, NET_RULES } from '../combat/SoftTools.js';
import { CompanionSystem } from '../fauna/Companion.js';
import { ParaglidingSystem } from '../systems/Paragliding.js';
import { BigMap } from '../exploration/BigMap.js';
import { StartWizard } from '../ui/StartWizard.js';
import { renderBlockIcons } from '../ui/BlockIcons.js';
import { BridgeChallengeSystem } from '../bridge/BridgeChallengeSystem.js';

const MODE_SAVE_KEY = 'blockworld-v0.7-selected-mode';
const WORLD_SAVE_KEY = 'blockworld-v1.1-selected-world';

export class Game {
  constructor(elements) {
    Object.assign(this, elements);
    this.clock = new THREE.Clock();
    this.raycaster = new THREE.Raycaster();
    this.selectedItem = null;
    this.selectedBlockType = 'grass';
    this.blockDamage = new Map();
    this.touchMode = window.matchMedia('(pointer: coarse), (hover: none)').matches;
    this.inventoryOpen = false;
    this.passportOpen = false;
    this.navigationUpdateTimer = 0;
    this.nextAttackAt = 0;
    this.effects = [];
    this.primaryHeld = false;
    this.mouseLookActive = false;
    this.mouseLookButton = -1;
    this.mouseLookDistance = 0;
    this.mouseLastX = 0;
    this.mouseLastY = 0;
    this.zoomActive = false;
    this.defaultFov = 70;
    this.targetFov = this.defaultFov;
    this.scopeUpdateAt = 0;
    this.hasBegun = false;
    this.multiplayerActive = false;
    this.roomPlayers = new Map();
    this.soloModeId = localStorage.getItem(MODE_SAVE_KEY) || 'creative';
    this.selectedModeId = localStorage.getItem(MODE_SAVE_KEY) || 'creative';
    if (!MODE_BY_ID.has(this.selectedModeId)) this.selectedModeId = 'creative';
    this.soloWorldId = localStorage.getItem(WORLD_SAVE_KEY) || DEFAULT_WORLD_ID;
    this.selectedWorldId = WORLD_BY_ID.has(this.soloWorldId) ? this.soloWorldId : DEFAULT_WORLD_ID;

    this.animate = this.animate.bind(this);
    this.handleResize = this.handleResize.bind(this);
    this.handleMouseDown = this.handleMouseDown.bind(this);
    this.handleMouseUp = this.handleMouseUp.bind(this);
    this.handleMouseMove = this.handleMouseMove.bind(this);
  }

  async start() {
    this.setupScene();
    this.setupSystems();
    this.graphicsQuality?.apply(this.graphicsQuality.id);
    this.setupEvents();

    const loaded = this.world.load(this.selectedWorldId);
    if (!loaded) this.world.generatePreset(this.selectedWorldId);
    this.applyWorldSpawn();

    this.renderWorldSelector();
    this.renderModeSelector();
    this.selectMode(this.selectedModeId);
    this.selectWorld(this.selectedWorldId, { force: true, persist: false, regenerate: false });
    this.stability.scan();
    this.fauna?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.campfires?.setWorld(this.selectedWorldId);
    this.nightLights?.scanLanterns();
    this.companions?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.bigMap?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.paragliding?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.startWizard?.refresh({ begun: this.hasBegun, multiplayer: this.multiplayerActive });
    window.setTimeout(() => this.hud.setBlockIcons(renderBlockIcons(this.world.materials)), 250);
    this.climate?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.livingWater?.setWorld();
    this.life?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.monumentEnhancer?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.scenicVegetation?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.microDecor?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.ambientDetails?.setWorld(getWorldDefinition(this.selectedWorldId));
    this.hud.setStatus(loaded ? `Monde ${getWorldDefinition(this.selectedWorldId).label} sauvegardé chargé` : `Nouveau monde ${getWorldDefinition(this.selectedWorldId).label} généré`);
    this.deviceMessage.textContent = this.touchMode
      ? 'Android : choisis un continent et un mode, puis utilise le joystick, le sac 🎒, le passeport 📘 et la caméra 👁.'
      : 'Ordinateur : ZQSD/WASD pour marcher · clic droit maintenu et glissé pour regarder · clic droit bref pour poser/utiliser · Échap pause.';
    this.renderer.setAnimationLoop(this.animate);
  }

  setupScene() {
    this.scene = new THREE.Scene();
    this.dayColor = new THREE.Color(0x8fc8ff);
    this.nightColor = new THREE.Color(0x17213f);
    this.scene.background = this.dayColor.clone();
    this.scene.fog = new THREE.Fog(this.dayColor, 48, 150);

    this.camera = new THREE.PerspectiveCamera(this.defaultFov, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.scene.add(this.camera);
    this.renderer = new THREE.WebGLRenderer({ antialias: !this.touchMode, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, this.touchMode ? 1.35 : 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.container.append(this.renderer.domElement);

    this.hemisphere = new THREE.HemisphereLight(0xe4f4ff, 0x4d5b3b, 2.15);
    this.scene.add(this.hemisphere);

    this.sun = new THREE.DirectionalLight(0xfff4d6, 2.75);
    this.sun.position.set(20, 32, 14);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(this.touchMode ? 1024 : 2048, this.touchMode ? 1024 : 2048);
    this.sun.shadow.camera.left = -62;
    this.sun.shadow.camera.right = 62;
    this.sun.shadow.camera.top = 62;
    this.sun.shadow.camera.bottom = -62;
    this.scene.add(this.sun);

    this.addClouds(9);
  }

  addClouds(count = 9, qualityId = null) {
    // Beta 4.14 : nuages en mini-blocs au-dessus des sommets (60–82 m), répartis sur toute la carte.
    this.clouds = buildVoxelClouds({ size: this.world?.size ?? 224, quality: qualityId ?? this.graphicsQuality?.id ?? (this.touchMode ? 'mobile' : 'high'), count: Math.max(8, count + 4), seed: 17 });
    this.scene.add(this.clouds);
  }

  rebuildClouds(count, qualityId = null) {
    if (this.clouds) { this.scene.remove(this.clouds); this.clouds.traverse(o=>{o.geometry?.dispose?.();}); this.clouds.userData.material?.dispose?.(); }
    this.addClouds(count, qualityId);
  }

  setupSystems() {
    this.input = new Input();
    this.input.connect();
    this.world = new World(this.scene);
    this.hud = new Hud({
      statusElement: this.statusElement,
      hotbarElement: this.hotbarElement,
      healthElement: this.healthElement,
      lootElement: this.lootElement,
      modeElement: this.modeElement,
      modeTimerElement: this.modeTimerElement,
      objectiveElement: this.objectiveElement,
      protectionElement: this.protectionElement,
      radarElement: this.radarElement,
      inventoryScreen: this.inventoryScreen,
      inventoryCategories: this.inventoryCategories,
      inventoryGrid: this.inventoryGrid,
      inventorySearch: this.inventorySearch,
      inventorySelection: this.inventorySelection,
      touchMode: this.touchMode
    });
    this.player = new Player(this.scene, this.camera, this.renderer.domElement, this.input, this.world, {
      touchMode: this.touchMode,
      onHealthChange: (current, maximum) => this.hud.updateHealth(current, maximum),
      onDeath: () => {
        this.hud.setStatus('Vous avez été vaincu — une nouvelle bulle apparaîtra à la reprise');
        this.pauseMenu?.setSummary('Tu as été vaincu · une bulle de protection t’attend à la reprise.');
        this.spawnProtection?.start(5);
        this.modeController?.onEvent({ type: 'player_death' }); // Beta 4.31 : la vague de Défense est rejouée
      }
    });
    this.monsters = new MonsterManager(this.scene, this.world, this.player, this.hud, {
      targetCount: 0,
      onMonsterDeath: (monster) => this.modeController?.onEvent({ type: 'kill', targetType: monster.type, amount: 1 })
    });
    // Beta 4.31 : jauges de vie, attaques annoncées (son) et siège des barricades (mode Défense seulement : réglé par le mode).
    this.monsters.setCamera(this.camera);
    this.monsters.onMonsterTelegraph = () => this.sfx?.playTelegraph?.();
    this.monsters.onSiege = (monster, block, delta) => this.modeController?.onSiege(monster, block, delta) ?? false;
    this.modeController = new ModeController(this);
    this.spawnProtection = new SpawnProtection(this.scene, this.player, this.monsters, this.hud);
    this.multiplayer = new MultiplayerClient();
    this.remotePlayers = new RemotePlayerManager(this.scene);
    this.weaponSystem = new WeaponSystem({ onChange: () => this.updateWeaponHud() });
    this.weaponView = new WeaponViewModel(this.camera);
    this.audio = new AudioManager();
    this.sfx = new SoundEffectsManager();
    this.passport = new LandmarkPassport(WORLD_DEFINITIONS);
    this.navigationMap = new NavigationMap({
      canvas: this.minimapCanvas,
      headingElement: this.compassHeading,
      nearestElement: this.nearestLandmark,
      progressElement: this.mapProgress,
      titleElement: this.mapWorldTitle,
      panel: this.navigationPanel,
      toggleButton: this.mapToggleButton
    });
    this.passportView = new PassportView({
      overlay: this.passportScreen,
      closeButton: this.passportCloseButton,
      resetButton: this.passportResetButton,
      content: this.passportContent,
      summary: this.passportSummary
    }, this.passport, WORLD_DEFINITIONS);
    this.stability = new StabilitySystem(this.scene, this.world, {
      panel: this.stabilityPanel,
      summary: this.stabilitySummary,
      counts: this.stabilityCounts,
      details: this.stabilityDetails,
      toggleButton: this.stabilityToggleButton,
      startButton: this.stabilityButton,
      gameButton: this.gameStabilityButton,
      mobileButton: this.mobileStabilityButton
    });
    this.fauna = new FaunaManager(this.scene, this.world, { touchMode: this.touchMode });
    this.climate = new ClimateSystem(this);
    this.livingWater = new LivingWaterSystem(this.scene, this.world, { touchMode: this.touchMode, renderer: this.renderer });
    this.atmosphere = new AtmosphereSystem(this);
    this.renderPipeline = new RenderPipeline(this);
    this.monumentEnhancer = new MonumentVisualEnhancer(this.scene, this.world);
    this.scenicVegetation = new ScenicVegetationSystem(this.scene, this.world, { touchMode: this.touchMode });
    this.microDecor = new MicroVoxelDecor(this.scene, this.world, { touchMode: this.touchMode });
    this.hitFeedback = new HitFeedback(this);
    // Beta 4.22 : créatures (animaux, habitants) comme cibles, faim, manette, légende des commandes.
    this.creatures = new CreatureCombat(this);
    this.hunger = new HungerSystem();
    this.controlsLegend = new ControlsLegend();
    this.gamepad = new GamepadInput({
      onAction: (action) => this.handleGamepadAction(action, true),
      onRelease: (action) => this.handleGamepadAction(action, false),
      onConnect: (name) => this.hud?.setStatus?.(`🎮 Manette connectée : ${name.slice(0, 40)} · Select = commandes`)
    });
    this.hud.updateHunger?.(this.hunger);
    document.getElementById('hunger')?.addEventListener('click', () => this.eatFood());
    this.statues = new StatueDecor(this.scene, this.world);
    this.statues.setWorld(getWorldDefinition(this.selectedWorldId));
    // Beta 4.20 : choix du personnage sur l'écran de démarrage (verrouillé une fois la partie lancée).
    this.characterSelector = new CharacterSelector(document.getElementById('character-selector'), {
      onSelect: (index, spec) => { this.player.setCharacter(index); this.syncHDCharacters(true); this.hud?.setStatus?.(`Personnage : ${spec.name} · ${spec.profession}`); }
    });
    this.player.setCharacter(this.characterSelector.index);
    if (this.monsters) this.monsters.onPlayerHit = (hit) => this.hitFeedback.onLocalHit(hit);
    this.ambientDetails = new AmbientDetailSystem(this.scene, this.world, { touchMode: this.touchMode });
    // Beta 4.26 : HUD contextuel, menu Pause dédié, retours visuels de construction.
    this.hudContext = new HudContext({ stabilityPanel: this.stabilityPanel });
    this.buildFeedback = new BuildFeedback(this);
    this.pauseMenu = new PauseMenu(document.getElementById('pause-menu'), {
      resume: () => this.beginOrResume(),
      settings: () => this.showStartScreenFromPause({ focusSettings: true }),
      controls: () => this.controlsLegend?.toggle(true),
      home: () => this.showStartScreenFromPause(),
      bridges: () => this.toggleBridgePanel(true)
    });
    this.graphicsQuality = new GraphicsQualityManager(this, this.graphicsQualitySelect);
    // Beta 4.27 : feux de camp, lumières de nuit, pêche, mode photo et carnet de voyage.
    this.campfires = new CampfireSystem(this);
    this.nightLights = new NightLights(this);
    // Beta 4.32 : grotte du continent (obscurité, coffres, gardiens) et ambiance sonore spatialisée (gouttes, écho, cris).
    this.caves = new CaveSystem(this);
    this.ambience = new SpatialAmbience(this);
    this.cameraDirection = new THREE.Vector3();
    this.fishing = new FishingSystem(this);
    // Beta 4.28 : outils doux (flèche, caillou, filet visibles) et compagnon animal.
    this.softTools = new SoftTools(this);
    this.companions = new CompanionSystem(this);
    // Beta 4.29 : parapente, grande carte en relief, accueil en assistant.
    this.paragliding = new ParaglidingSystem(this);
    this.bigMap = new BigMap(this, document.getElementById('big-map'));
    this.startWizard = new StartWizard(this.startScreen, { onContinue: () => this.beginOrResume() });
    // Beta 4.30 : défis d'ingénieur (ponts, convoi, efforts colorés, badges).
    this.bridges = new BridgeChallengeSystem(this, { panel: document.getElementById('bridge-panel'), bar: document.getElementById('bridge-bar') });
    for (const id of ['game-bridge-button', 'mobile-bridge-button']) document.getElementById(id)?.addEventListener('click', () => this.toggleBridgePanel());
    this.minimapCanvas?.addEventListener('click', () => this.toggleBigMap(true));
    this.photoMode = new PhotoMode(this, { overlay: document.getElementById('photo-overlay'), albumElement: document.getElementById('photo-album') });
    document.getElementById('game-photo-button')?.addEventListener('click', () => this.photoMode.toggle());
    document.getElementById('mobile-photo-button')?.addEventListener('click', () => this.photoMode.toggle());
    this.life = new LifeEngine(this.scene, this.world, { touchMode: this.touchMode });
    this.disasters = new DisasterManager(this, {
      panel: this.disasterPanel,
      title: this.disasterTitle,
      timer: this.disasterTimer,
      risk: this.disasterRisk,
      button: this.disasterButton,
      gameButton: this.gameDisasterButton,
      mobileButton: this.mobileDisasterButton
    });
    this.passportView.addEventListener('opened', () => { this.handlePassportOpened(); this.photoMode?.renderAlbum(); });
    this.passportView.addEventListener('closed', () => this.handlePassportClosed());
    this.passportView.addEventListener('track', (event) => {
      const { worldId, point } = event.detail;
      if (worldId !== this.selectedWorldId) {
        this.hud.setStatus(`Le repère ${point.name} se trouve sur la carte ${getWorldDefinition(worldId).label}`);
        return;
      }
      this.navigationMap.track(point.id);
      this.hud.setStatus(`Repère ${point.name} surligné sur la mini-carte`);
    });
    this.passport.addEventListener('discover', (event) => {
      const { point } = event.detail;
      this.sfx?.playClick?.({ frequency: 1180, duration: 0.08, gain: 0.09 });
      this.hud.setStatus(`📘 Nouveau tampon : ${point.name}`);
      this.modeController?.onEvent({ type: 'discover', targetType: point.id, amount: 1 });
    });
    this.setupAudio();
    this.setupSoundEffects();
    this.setupMultiplayer();

    this.hud.init((item) => {
      this.selectedItem = item;
      this.paragliding?.setEquipped(item.type === 'paraglider');
      this.weaponSystem.select(item);
      if (!item.zoomFov) this.toggleZoom(false);
      this.weaponView.setItem(item, { firstPerson: this.player.viewMode === 'first' });
      this.updateWeaponControls();
      if (item.kind === 'block') {
        this.selectedBlockType = item.type;
        this.hud.setStatus(`Bloc sélectionné : ${item.label}`);
      } else if (['clothing', 'vehicle', 'consumable'].includes(item.kind) || ['heal-spell', 'teleport'].includes(item.type)) {
        this.hud.setStatus(`${item.label} sélectionné · clic droit ou ▣ pour utiliser`);
      } else if (item.zoomFov) {
        this.hud.setStatus(`${item.label} sélectionné · F, clic droit ou 🔭 pour viser`);
      } else {
        this.hud.setStatus(`${item.label} sélectionné · ${item.description}`);
      }
    });

    if (this.touchMode) {
      this.touchControls = new TouchControls({
        input: this.input,
        joystick: this.joystick,
        joystickKnob: this.joystickKnob,
        lookZone: this.lookZone,
        attackButton: this.attackButton,
        placeButton: this.placeButton,
        jumpButton: this.jumpButton,
        pauseButton: this.pauseButton,
        inventoryButton: this.mobileInventoryButton,
        cameraButton: this.mobileCameraButton,
        zoomButton: this.mobileZoomButton,
        reloadButton: this.mobileReloadButton,
        onPrimary: () => this.handleInteraction(0),
        onPrimaryStart: () => { this.primaryHeld = true; },
        onPrimaryEnd: () => { this.primaryHeld = false; },
        onSecondary: () => this.handleInteraction(2),
        onPause: () => this.player.pause(),
        onInventory: () => this.openInventory(),
        onCamera: () => this.toggleCamera(),
        onZoom: () => this.toggleZoom(),
        onReload: () => this.reloadSelectedWeapon()
      });
      this.touchControls.connect();
    }
  }

  setupAudio() {
    this.audio.addEventListener('change', () => this.updateAudioUi());
    if (this.musicVolume) {
      this.musicVolume.value = String(Math.round(this.audio.volume * 100));
      this.musicVolume.addEventListener('input', () => {
        this.audio.setVolume(Number(this.musicVolume.value) / 100);
      });
    }
    this.updateAudioUi();
  }

  setupSoundEffects() {
    this.sfx.addEventListener('change', () => this.updateSoundEffectsUi());
    if (this.sfxVolume) {
      this.sfxVolume.value = String(Math.round(this.sfx.volume * 100));
      this.sfxVolume.addEventListener('input', () => {
        this.sfx.setVolume(Number(this.sfxVolume.value) / 100);
      });
    }
    this.updateSoundEffectsUi();
  }

  updateSoundEffectsUi() {
    const state = this.sfx?.state;
    if (!state) return;
    const label = state.supported
      ? (state.enabled ? '💥 Bruitages' : '🔕 Bruitages')
      : '🔕 Effets indisponibles';
    for (const button of [this.sfxButton, this.gameSfxButton]) {
      if (!button) continue;
      button.textContent = button === this.gameSfxButton ? (state.enabled ? '💥' : '🔕') : label;
      button.disabled = !state.supported;
      button.setAttribute('aria-pressed', String(state.enabled));
      button.dataset.enabled = String(state.enabled);
    }
    if (this.sfxVolume) {
      this.sfxVolume.disabled = !state.supported;
      const percentage = Math.round(state.volume * 100);
      if (Number(this.sfxVolume.value) !== percentage) this.sfxVolume.value = String(percentage);
      if (this.sfxVolumeValue) this.sfxVolumeValue.textContent = `${percentage} %`;
    }
  }

  async toggleSoundEffects() {
    if (!this.sfx?.supported) {
      this.hud?.setStatus('Le navigateur ne prend pas en charge les bruitages Web Audio');
      return;
    }
    const enabled = await this.sfx.toggle();
    this.hud?.setStatus(enabled ? 'Bruitages activés' : 'Bruitages coupés');
  }

  updateAudioUi() {
    const state = this.audio?.state;
    if (!state) return;
    const label = state.supported
      ? (state.enabled ? '🔊 Musique' : '🔇 Musique')
      : '🔇 Audio indisponible';
    for (const button of [this.musicButton, this.gameMusicButton]) {
      if (!button) continue;
      button.textContent = button === this.gameMusicButton ? (state.enabled ? '🔊' : '🔇') : label;
      button.disabled = !state.supported;
      button.setAttribute('aria-pressed', String(state.enabled));
      button.dataset.enabled = String(state.enabled);
    }
    if (this.musicVolume) {
      this.musicVolume.disabled = !state.supported;
      const percentage = Math.round(state.volume * 100);
      if (Number(this.musicVolume.value) !== percentage) this.musicVolume.value = String(percentage);
      if (this.musicVolumeValue) this.musicVolumeValue.textContent = `${percentage} %`;
    }
  }

  async toggleMusic() {
    if (!this.audio?.supported) {
      this.hud?.setStatus('Le navigateur ne prend pas en charge la musique Web Audio');
      return;
    }
    const enabled = await this.audio.toggle();
    this.audio.setPaused(!this.player?.isActive());
    this.hud?.setStatus(enabled ? 'Musique activée' : 'Musique coupée');
  }

  async toggleFullscreen() {
    try {
      if (!document.fullscreenElement) {
        try {
          await document.documentElement.requestFullscreen({ navigationUI: 'hide' });
        } catch (firstError) {
          await document.documentElement.requestFullscreen();
        }
        if (this.touchMode && screen.orientation?.lock) await screen.orientation.lock('landscape').catch(() => {});
      } else {
        await document.exitFullscreen();
        if (screen.orientation?.unlock) screen.orientation.unlock();
      }
    } catch (error) {
      this.hud?.setStatus('Le plein écran doit être autorisé par le navigateur');
    }
  }

  updateFullscreenUi() {
    const active = Boolean(document.fullscreenElement);
    if (this.fullscreenButton) this.fullscreenButton.textContent = active ? '⛶ Quitter le plein écran' : '⛶ Plein écran';
    if (this.gameFullscreenButton) {
      this.gameFullscreenButton.textContent = active ? '↙' : '⛶';
      this.gameFullscreenButton.title = active ? 'Quitter le plein écran' : 'Plein écran';
      this.gameFullscreenButton.setAttribute('aria-pressed', String(active));
    }
    this.handleResize();
  }

  setupMultiplayer() {
    const savedName = localStorage.getItem('blockworld-player-name');
    if (savedName && this.nicknameInput) this.nicknameInput.value = savedName;

    this.createRoomButton?.addEventListener('click', async () => {
      const nickname = this.getNickname();
      this.setNetworkStatus('connecting', 'Connexion…');
      this.networkMessage.textContent = 'Création de la salle privée…';
      try {
        await this.multiplayer.createRoom({
          nickname,
          mode: this.roomModeSelect?.value || this.selectedModeId,
          worldId: this.roomWorldSelect?.value || this.selectedWorldId
        });
      } catch (error) {
        this.setNetworkStatus('error', 'Erreur');
        this.networkMessage.textContent = error.message;
      }
    });

    this.joinRoomButton?.addEventListener('click', async () => {
      const nickname = this.getNickname();
      const code = String(this.roomCodeInput?.value || '').trim().toUpperCase();
      if (code.length !== 8) {
        this.networkMessage.textContent = 'Saisis le code privé de 8 caractères.';
        return;
      }
      this.setNetworkStatus('connecting', 'Connexion…');
      this.networkMessage.textContent = 'Connexion à la salle…';
      try {
        await this.multiplayer.joinRoom({ nickname, code });
      } catch (error) {
        this.setNetworkStatus('error', 'Erreur');
        this.networkMessage.textContent = error.message;
      }
    });

    this.leaveRoomButton?.addEventListener('click', () => this.leaveMultiplayerRoom('Salle quittée.'));
    this.copyRoomCodeButton?.addEventListener('click', async () => {
      const code = this.multiplayer.roomCode;
      if (!code) return;
      try {
        await navigator.clipboard.writeText(code);
        this.networkMessage.textContent = `Code ${code} copié.`;
      } catch {
        this.networkMessage.textContent = `Code à communiquer : ${code}`;
      }
    });
    this.roomCodeInput?.addEventListener('input', () => {
      this.roomCodeInput.value = this.roomCodeInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
    });

    this.multiplayer.addEventListener('message', (event) => this.handleNetworkMessage(event.detail));
    this.multiplayer.addEventListener('status', (event) => {
      const { state, wasJoined } = event.detail;
      if (state === 'connected') this.setNetworkStatus('connecting', 'Serveur trouvé');
      if (state === 'disconnected' && wasJoined) this.leaveMultiplayerRoom('Connexion perdue. Retour au monde solo.', { closeSocket: false });
      if (state === 'closed' && !this.multiplayerActive) this.setNetworkStatus('offline', 'Hors ligne');
    });
  }

  getNickname() {
    const nickname = String(this.nicknameInput?.value || 'Joueur')
      .replace(/[^\p{L}\p{N} _-]/gu, '')
      .trim()
      .slice(0, 18) || 'Joueur';
    if (this.nicknameInput) this.nicknameInput.value = nickname;
    localStorage.setItem('blockworld-player-name', nickname);
    return nickname;
  }

  setNetworkStatus(state, label) {
    if (!this.networkStatus) return;
    this.networkStatus.dataset.state = state;
    this.networkStatus.textContent = label;
  }

  handleNetworkMessage(message) {
    switch (message.type) {
      case 'hello':
        this.networkMessage.textContent = `Serveur V${message.version} prêt · ${message.maxPlayers} joueurs maximum.`;
        break;
      case 'joined':
        this.enterMultiplayerRoom(message);
        break;
      case 'player_joined':
        this.roomPlayers.set(message.player.id, message.player);
        if (message.player.id !== this.multiplayer.clientId) this.remotePlayers.upsert(message.player);
        this.refreshPlayerList();
        this.hud.setStatus(`${message.player.nickname} a rejoint la salle`);
        break;
      case 'player_left': {
        const player = this.roomPlayers.get(message.playerId);
        this.roomPlayers.delete(message.playerId);
        this.remotePlayers.remove(message.playerId);
        this.refreshPlayerList();
        if (player) this.hud.setStatus(`${player.nickname} a quitté la salle`);
        break;
      }
      case 'host_changed':
        this.multiplayer.hostId = message.hostId;
        this.refreshPlayerList();
        break;
      case 'player_state': {
        const player = this.roomPlayers.get(message.playerId);
        if (player) {
          player.state = message.state;
          player.health = message.health;
          if (this.remotePlayers.get(message.playerId)) this.remotePlayers.applyState(message.playerId, message.state, message.health);
          else this.remotePlayers.upsert({ id: message.playerId, nickname: player.nickname, state: message.state, health: message.health });
        }
        break;
      }
      case 'state_rejected':
        if (message.state?.x !== undefined) {
          this.player.teleportTo(new THREE.Vector3(message.state.x, message.state.y, message.state.z));
          this.hud.setStatus('Déplacement corrigé par le serveur');
        }
        break;
      case 'block_change':
        this.applyNetworkBlockChange(message.change, message.actorId);
        if (message.battleState && message.actorId === this.multiplayer.clientId) { this.multiplayer.battleState = message.battleState; this.modeController.applyBattleState(message.battleState); }
        break;
      case 'battle_state':
        this.multiplayer.battleState = message.state;
        this.modeController.applyBattleState(message.state);
        break;
      case 'player_health':
        this.applyNetworkHealth(message);
        break;
      case 'player_respawn':
        this.applyNetworkRespawn(message);
        break;
      case 'attack_rejected':
        this.hud.setStatus(message.reason === 'protected'
          ? 'Ce joueur est encore protégé'
          : message.reason === 'reloading' ? 'Le serveur confirme le rechargement en cours' : 'Attaque refusée');
        break;
      case 'weapon_ammo': {
        if (this.selectedItem?.type === message.weapon) {
          const state = this.weaponSystem.stateFor(this.selectedItem);
          if (state) state.ammo = Math.max(0, Math.min(state.ammo, state.magazineSize, Number(message.ammo) || 0));
          this.weaponSystem.emit();
        }
        break;
      }
      case 'reload_required':
        if (this.selectedItem?.type === message.weapon) {
          const state = this.weaponSystem.stateFor(this.selectedItem);
          if (state) state.ammo = 0;
          this.weaponSystem.emit();
        }
        this.hud.setStatus('Le serveur demande un rechargement');
        break;
      case 'weapon_reloaded':
        this.hud.setStatus(`Rechargement ${message.weapon} validé par le serveur`);
        break;
      case 'error':
        this.setNetworkStatus('error', 'Erreur');
        this.networkMessage.textContent = message.message || 'Erreur réseau.';
        break;
      case 'left':
        break;
      default:
        break;
    }
  }

  enterMultiplayerRoom(message) {
    this.multiplayerActive = true;
    this.roomPlayers.clear();
    this.remotePlayers.clear();
    const snapshot = message.snapshot || {};
    for (const playerData of snapshot.players || []) {
      this.roomPlayers.set(playerData.id, playerData);
      if (playerData.id !== this.multiplayer.clientId) this.remotePlayers.upsert(playerData);
    }

    this.soloModeId = localStorage.getItem(MODE_SAVE_KEY) || this.selectedModeId;
    this.soloWorldId = localStorage.getItem(WORLD_SAVE_KEY) || this.selectedWorldId;
    const localPlayerIndex = Math.max(0, (snapshot.players || []).findIndex((player) => player.id === this.multiplayer.clientId));
    this.loadRoomWorld(snapshot.blockChanges || [], snapshot.worldId || DEFAULT_WORLD_ID, localPlayerIndex + 1);
    this.selectWorld(snapshot.worldId || DEFAULT_WORLD_ID, { force: true, persist: false, regenerate: false });
    this.selectMode(snapshot.mode || 'creative', { force: true, persist: false });
    this.hasBegun = false;
    this.player.respawn();
    this.startScreen.classList.remove('hidden');
    this.startButton.textContent = 'Entrer dans la salle';
    this.networkSetup?.classList.add('hidden');
    this.networkRoom?.classList.remove('hidden');
    this.roomCodeDisplay.textContent = message.roomCode;
    this.multiplayerIndicator?.classList.remove('hidden');
    this.multiplayerIndicator.textContent = `🌐 ${message.roomCode}`;
    this.setNetworkStatus('online', 'Connecté');
    this.networkMessage.textContent = `Salle ${message.roomCode} active. Communique uniquement ce code aux joueurs invités.`;
    this.refreshPlayerList();
    this.renderWorldSelector();
    this.renderModeSelector();
  }

  leaveMultiplayerRoom(message = 'Retour au monde solo.', { closeSocket = true } = {}) {
    if (closeSocket && (this.multiplayer.connected || this.multiplayer.joined)) this.multiplayer.leave();
    this.multiplayerActive = false;
    this.remotePlayers.clear();
    this.roomPlayers.clear();
    this.networkRoom?.classList.add('hidden');
    this.networkSetup?.classList.remove('hidden');
    this.multiplayerIndicator?.classList.add('hidden');
    this.setNetworkStatus('offline', 'Hors ligne');
    this.networkMessage.textContent = message;
    this.hasBegun = false;
    this.player.pause();
    this.selectedWorldId = WORLD_BY_ID.has(this.soloWorldId) ? this.soloWorldId : DEFAULT_WORLD_ID;
    const loaded = this.world.load(this.selectedWorldId);
    if (!loaded) this.world.generatePreset(this.selectedWorldId);
    this.applyWorldSpawn();
    this.selectWorld(this.selectedWorldId, { force: true, persist: true, regenerate: false });
    this.selectMode(this.soloModeId || 'creative', { force: true, persist: true });
    this.startScreen.classList.remove('hidden');
    this.startButton.textContent = 'Entrer dans le monde';
    this.renderWorldSelector();
    this.renderModeSelector();
  }

  loadRoomWorld(blockChanges, worldId = DEFAULT_WORLD_ID, spawnIndex = 1) {
    this.world.generatePreset(worldId, { persist: false });
    this.applyWorldSpawn(spawnIndex);
    for (const change of blockChanges) this.applyNetworkBlockChange(change, null, { announce: false, scan: false });
    this.stability?.scan();
  }

  applyNetworkBlockChange(change, actorId, { announce = true, scan = true } = {}) {
    if (!change) return;
    const { x, y, z, blockType } = change;
    const removedType = blockType ? null : this.world.getBlock(x, y, z)?.type ?? null;
    if (blockType) {
      const existing = this.world.getBlock(x, y, z);
      if (existing) this.world.removeBlock(x, y, z, { persist: false });
      this.world.addBlock(x, y, z, blockType, { persist: false });
      if (actorId === this.multiplayer.clientId) this.modeController.onEvent({ type: 'place', targetType: blockType, amount: 1, x, y, z });
    } else {
      const existing = this.world.getBlock(x, y, z);
      const harvestedType = existing?.type;
      this.world.removeBlock(x, y, z, { persist: false });
      if (actorId === this.multiplayer.clientId && harvestedType) {
        this.modeController.onEvent({ type: 'harvest', targetType: harvestedType, amount: 1 });
      }
    }
    const report = scan ? this.stability?.scan() : this.stability?.report;
    if (scan) this.hudContext?.pulseStability();
    if (actorId === this.multiplayer.clientId) {
      const spot = new THREE.Vector3(x, y, z);
      if (blockType) this.buildFeedback?.onPlace(spot, blockType); else if (removedType) this.buildFeedback?.onBreak(spot, removedType);
    }
    if (blockType === 'lantern' || removedType === 'lantern') this.nightLights?.scanLanterns();
    if (announce && actorId === this.multiplayer.clientId) {
      const focus = blockType ? this.stability?.describeBlock(x, y, z) : null;
      const warning = report?.counts.red ? ` · ${report.counts.red} bloc${report.counts.red > 1 ? 's' : ''} rouge${report.counts.red > 1 ? 's' : ''}` : '';
      this.hud.setStatus(`Modification validée par le serveur${focus ? ` · ${focus}` : warning}`);
    }
  }

  applyNetworkHealth(message) {
    // Beta 4.17 : dégâts reçus = baisse de santé ; source = position du tireur (avatar distant ou soi).
    const previous = message.playerId === this.multiplayer.clientId ? this.player.health : (this.roomPlayers.get(message.playerId)?.health ?? 100);
    const amount = Math.max(0, previous - message.health);
    const attackerIsMe = message.attackerId === this.multiplayer.clientId;
    const source = attackerIsMe ? this.player.getEyePosition() : this.remotePlayers.get(message.attackerId)?.group?.position ?? null;
    if (message.playerId === this.multiplayer.clientId) {
      this.player.setNetworkHealth(message.health);
      this.hud.setStatus(`Touché par un autre joueur : ${message.health} PV`);
      if (amount > 0) this.hitFeedback?.onLocalHit({ amount, weapon: message.weapon, source });
    } else {
      const remote = this.remotePlayers.get(message.playerId);
      remote?.setHealth(message.health);
      if (amount > 0 && remote) this.hitFeedback?.onRemoteHit(remote, { amount, weapon: message.weapon, source, kill: message.health <= 0 });
      if (attackerIsMe && amount > 0) this.hitFeedback?.showHitMarker(message.health <= 0);
    }
    const player = this.roomPlayers.get(message.playerId);
    if (player) player.health = message.health;
  }

  applyNetworkRespawn(message) {
    if (message.playerId === this.multiplayer.clientId) {
      this.player.respawn();
      this.spawnProtection.start(5);
      this.hud.setStatus('Éliminé — réapparition protégée');
    } else {
      const defeated = this.roomPlayers.get(message.playerId);
      this.remotePlayers.remove(message.playerId);
      if (message.defeatedBy === this.multiplayer.clientId && defeated) {
        this.hud.setStatus(`${defeated.nickname} éliminé · il réapparaît protégé`);
      }
    }
  }

  refreshPlayerList() {
    if (!this.playerList) return;
    this.playerList.replaceChildren();
    for (const player of this.roomPlayers.values()) {
      const chip = document.createElement('span');
      chip.className = `player-chip${player.id === this.multiplayer.hostId ? ' host' : ''}`;
      chip.textContent = `${player.id === this.multiplayer.clientId ? 'Vous · ' : ''}${player.nickname}`;
      this.playerList.append(chip);
    }
    const host = this.roomPlayers.get(this.multiplayer.hostId);
    if (this.roomHostLabel) {
      const world = getWorldDefinition(this.multiplayer.roomWorldId || this.selectedWorldId);
      this.roomHostLabel.textContent = `Hôte : ${host?.nickname || '—'} · Mode : ${MODE_BY_ID.get(this.multiplayer.roomMode)?.label || this.multiplayer.roomMode} · Monde : ${world.label}`;
    }
  }

  // Beta 4.24 : personnages HD réalistes en Élevée / Ultra (chargés à la demande, ≈ 10 Mo, puis en cache).
  async updateHDCharacters(enabled) {
    this.hdEnabled = Boolean(enabled);
    if (this.hdEnabled && !this.hdLibrary?.ready) {
      this.hdLibrary ??= new HDCharacterLibrary();
      this.hud?.setStatus?.('Chargement des personnages HD (≈ 10 Mo, une seule fois)…');
      try { await this.hdLibrary.load(); this.hud?.setStatus?.('Personnages HD prêts'); }
      catch (error) { console.warn('[personnages HD]', error?.message); this.hdEnabled = false; this.hud?.setStatus?.('Personnages HD indisponibles : personnages standard conservés'); }
    }
    this.characterSelector?.setRoster?.(this.hdEnabled && this.hdLibrary?.ready ? { roster: HD_ROSTER, library: this.hdLibrary } : null);
    this.syncHDCharacters(true);
  }

  syncHDCharacters(force = false) {
    const on = Boolean(this.hdEnabled && this.hdLibrary?.ready);
    if (!force && !on && !this.hdApplied) return;
    this.hdApplied = on;
    if (this.player?.avatarBody) applyHD(this.player.avatarBody, this.hdLibrary, this.player.characterIndex ?? 0, on);
    (this.life?.ai?.agents ?? []).forEach((agent, index) => {
      const data = agent.userData;
      data.proceduralIdentity ??= { name: data.name, profession: data.profession, age: data.age };
      if (applyHD(agent, this.hdLibrary, index, on)) { const spec = HD_ROSTER[index % HD_ROSTER.length]; Object.assign(data, { name: spec.name, profession: spec.profession, age: spec.age }); }
    });
    for (const remote of this.remotePlayers?.players?.values?.() ?? []) applyHD(remote.group, this.hdLibrary, remote.characterIndex ?? 0, on);
  }

  eatFood() {
    if (!this.hunger) return;
    const result = this.hunger.eat();
    if (result.ok) {
      const healed = this.player.heal(result.heal);
      const gain = result.cooked ? this.hunger.rules.cookedHunger : this.hunger.rules.mealHunger;
      this.hud.setStatus(`${result.cooked ? 'Délicieux (cuit)' : 'Miam (cru)'} : +${gain} faim, +${healed} PV · ${this.hunger.cooked} 🍢 cuite(s), ${this.hunger.food} 🍖 crue(s)`);
    }
    else this.hud.setStatus(result.reason === 'empty' ? 'Rien à manger : chasse un animal ou pêche un poisson, puis cuis-le au feu de camp' : 'Tu n’as pas faim');
    this.hud.updateHunger?.(this.hunger, this.hunger.isActive(this.selectedModeId));
  }

  // Beta 4.22 : manette (mêmes actions que le clavier et la souris).
  pollGamepad(delta) {
    if (!this.gamepad?.poll()) { if (this.input) this.input.gamepadMove = { x: 0, y: 0 }; return; }
    this.input.gamepadMove = this.gamepad.move;
    const look = this.gamepad.look;
    if (look.x || look.y) this.input.addLookDelta(look.x * 900 * delta, look.y * 700 * delta);
  }

  handleGamepadAction(action, pressed) {
    const playing = this.player?.isActive();
    if (action === 'primary') { this.primaryHeld = pressed && playing; if (pressed && playing) this.handleInteraction(0); return; }
    if (!pressed) return;
    if (action === 'pause') { if (playing) this.player.pause(); else this.beginOrResume(); return; }
    if (action === 'legend') { this.controlsLegend?.toggle(); return; }
    if (!playing) return;
    const actions = {
      jump: () => this.input.pressVirtual('jump'),
      eat: () => this.eatFood(),
      reload: () => this.reloadSelectedWeapon(),
      inventory: () => (this.inventoryOpen ? this.closeInventory() : this.openInventory()),
      previous: () => this.hud.selectNext(-1),
      next: () => this.hud.selectNext(1),
      secondary: () => this.handleInteraction(2),
      camera: () => this.toggleCamera(),
      talk: () => this.hud.setStatus(this.life?.interact(this.player.eyePosition) || 'Aucun habitant à proximité.'),
      map: () => this.toggleBigMap(),
      passport: () => this.passportView.toggle()
    };
    actions[action]?.();
  }

  setupEvents() {
    window.addEventListener('keydown', (event) => {
      if (event.code === 'KeyQ' && !event.repeat && this.player?.isActive()) {
        this.hud.setStatus(this.life?.interact(this.player.eyePosition) || 'Aucun habitant à proximité.');
      }
    });
    this.disasterButton?.addEventListener('click', () => this.disasters.cycle());
    this.gameDisasterButton?.addEventListener('click', () => this.disasters.cycle());
    this.mobileDisasterButton?.addEventListener('click', () => this.disasters.cycle());
    this.mobileTalkButton?.addEventListener('click', () => this.hud.setStatus(this.life?.interact(this.player.eyePosition) || 'Aucun habitant à proximité.'));
    window.addEventListener('keydown', (event) => {
      if (event.code === 'KeyH' && !event.repeat && !this.inventoryOpen && !this.passportOpen) this.disasters.cycle();
    });
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('orientationchange', () => window.setTimeout(this.handleResize, 120));
    document.addEventListener('fullscreenchange', () => this.updateFullscreenUi());
    document.addEventListener('visibilitychange', () => {
      this.audio?.setPaused(document.hidden || !this.player?.isActive());
    });
    window.addEventListener('blur', () => {
      // Beta 4.9 : évite un mode « regarder » bloqué si le bouton est relâché hors de la fenêtre.
      this.mouseLookActive = false;
      this.mouseLookButton = -1;
      this.primaryHeld = false;
      document.body.classList.remove('mouse-looking');
    });
    window.addEventListener('mousedown', this.handleMouseDown);
    window.addEventListener('mousemove', this.handleMouseMove);
    window.addEventListener('mouseup', this.handleMouseUp);
    window.addEventListener('contextmenu', (event) => {
      if (event.target === this.renderer.domElement && this.player?.isActive()) event.preventDefault();
    });
    window.addEventListener('keydown', (event) => {
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(event.target?.tagName)) return;
      // Beta 4.27 : mode photo — C bascule, Entrée déclenche, Échap ressort (sans mettre en pause).
      if (event.code === 'KeyC' && !event.repeat && !this.inventoryOpen && !this.passportOpen) { this.photoMode?.toggle(); return; }
      if (event.code === 'KeyX' && !event.repeat && this.player?.isActive()) { this.companions?.toggleMode(); return; } // Beta 4.28 : assis / au pied
      if (this.photoMode?.active && (event.code === 'Enter' || event.code === 'NumpadEnter') && !event.repeat) { event.preventDefault(); this.photoMode.shoot(); return; }
      if (this.photoMode?.active && event.code === 'Escape' && !event.repeat) { event.preventDefault(); this.photoMode.toggle(false); return; }
      if (this.bigMapOpen && event.code === 'Escape' && !event.repeat) { event.preventDefault(); this.toggleBigMap(false); return; }
      if (this.bridgePanelOpen && (event.code === 'Escape' || event.code === 'KeyO') && !event.repeat) { event.preventDefault(); this.toggleBridgePanel(false); return; }
      if (event.code === 'KeyO' && !event.repeat && !this.inventoryOpen && !this.passportOpen && !this.bigMapOpen) { event.preventDefault(); this.toggleBridgePanel(true); return; } // Beta 4.30 : défis d'ouvrages
      // Beta 4.26 : Échap referme le menu Pause (la légende des commandes se ferme d'abord si elle est ouverte).
      if (event.code === 'Escape' && !event.repeat && this.pauseMenu?.isOpen() && !this.player?.isActive()) {
        event.preventDefault();
        if (this.controlsLegend?.panel && !this.controlsLegend.panel.classList.contains('hidden')) this.controlsLegend.toggle(false);
        else this.beginOrResume();
        return;
      }
      if (event.code === 'KeyI' || event.code === 'Tab') {
        event.preventDefault();
        if (this.inventoryOpen) this.closeInventory();
        else this.openInventory();
      }
      if (event.code === 'KeyJ' && !event.repeat) {
        event.preventDefault();
        this.passportView.toggle();
      }
      if (event.code === 'KeyK' && !event.repeat) this.toggleBigMap(); // Beta 4.29 : grande carte en relief
      if (event.code === 'KeyB' && !event.repeat) this.toggleStability();
      if (event.code === 'KeyV' && !this.inventoryOpen && !this.passportOpen) this.toggleCamera();
      if (event.code === 'KeyF' && !this.inventoryOpen) this.toggleZoom();
      if (event.code === 'KeyT' && !this.inventoryOpen) this.reloadSelectedWeapon();
      if (event.code === 'KeyG' && !event.repeat && this.player?.isActive()) this.eatFood();
      if (event.code === 'KeyL' && !event.repeat) this.controlsLegend?.toggle();
      if (event.code === 'KeyM' && !event.repeat) this.toggleMusic();
      if (event.code === 'KeyN' && !event.repeat) this.toggleSoundEffects();
      if (event.code === 'KeyP' && !event.repeat) this.toggleFullscreen();
      if (event.code === 'Escape' && !event.repeat && this.player?.isActive()) {
        event.preventDefault();
        this.mouseLookActive = false;
        this.primaryHeld = false;
        document.body.classList.remove('mouse-looking');
        this.player.pause();
      }
    });

    this.startButton.addEventListener('click', () => this.beginOrResume());
    this.inventoryButton?.addEventListener('click', () => this.openInventory());
    this.inventoryCloseButton?.addEventListener('click', () => this.closeInventory());
    this.passportButton?.addEventListener('click', () => this.passportView.open());
    this.gamePassportButton?.addEventListener('click', () => this.passportView.open());
    this.mobilePassportButton?.addEventListener('click', () => this.passportView.open());
    this.stabilityButton?.addEventListener('click', () => this.toggleStability());
    this.gameStabilityButton?.addEventListener('click', () => this.toggleStability());
    this.mobileStabilityButton?.addEventListener('click', () => this.toggleStability());
    this.stabilityToggleButton?.addEventListener('click', () => this.toggleStability());
    this.cameraViewButton?.addEventListener('click', () => this.toggleCamera());
    this.reloadButton?.addEventListener('click', () => this.reloadSelectedWeapon());
    this.fullscreenButton?.addEventListener('click', () => this.toggleFullscreen());
    this.gameFullscreenButton?.addEventListener('click', () => this.toggleFullscreen());
    this.musicButton?.addEventListener('click', () => this.toggleMusic());
    this.gameMusicButton?.addEventListener('click', () => this.toggleMusic());
    this.sfxButton?.addEventListener('click', () => this.toggleSoundEffects());
    this.gameSfxButton?.addEventListener('click', () => this.toggleSoundEffects());

    this.player.addEventListener('active', () => {
      this.startScreen.classList.add('hidden');
      this.pauseMenu?.hide();
      document.body.classList.add('playing');
      this.audio?.start().then(() => this.audio.setPaused(false)).catch(() => {});
      this.sfx?.unlock().catch(() => {});
      this.hud.setStatus(this.spawnProtection.active ? 'Observe les monstres depuis la bulle · clic droit glissé : regarder · Échap : pause' : 'Exploration · clic droit glissé : regarder · clic droit bref : poser/utiliser · Échap : pause');
    });

    this.player.addEventListener('pause', () => {
      this.photoMode?.toggle(false);
      this.fishing?.cancel();
      this.mouseLookActive = false;
      this.primaryHeld = false;
      document.body.classList.remove('mouse-looking');
      document.body.classList.remove('playing');
      if (this.inventoryOpen || this.passportOpen || this.bigMapOpen || this.bridgePanelOpen) {
        this.startScreen.classList.add('hidden');
      } else {
        // Beta 4.26 : partie lancée → menu Pause court ; sinon écran d'accueil comme avant.
        if (this.hasBegun) this.pauseMenu?.show(this.pauseSummary());
        else this.startScreen.classList.remove('hidden');
        this.startButton.textContent = this.hasBegun ? 'Reprendre la partie' : 'Entrer dans le monde';
        this.modeSelector?.classList.toggle('locked', this.hasBegun);
        this.worldSelector?.classList.toggle('locked', this.hasBegun || this.multiplayerActive);
        this.primaryHeld = false;
        this.toggleZoom(false);
        this.audio?.setPaused(true);
        if (this.player.health > 0) this.hud.setStatus('Jeu en pause');
      }
    });

    this.saveButton.addEventListener('click', () => {
      if (this.multiplayerActive) {
        this.hud.setStatus('La salle multijoueur synchronise automatiquement les constructions');
        return;
      }
      this.world.save();
      this.hud.setStatus('Monde, mode et barre rapide sauvegardés dans le navigateur');
    });

    this.resetButton.addEventListener('click', () => {
      if (this.multiplayerActive) {
        this.hud.setStatus('La réinitialisation d’une salle partagée est réservée à une future commande d’hôte');
        return;
      }
      const confirmed = window.confirm('Réinitialiser le monde et la progression du mode actuel ?');
      if (!confirmed) return;
      this.monsters.clear();
      this.monsters.resetProgress();
      this.modeController.reset();
      this.spawnProtection.stop();
      this.bridges?.discard();
      this.world.reset(this.selectedWorldId);
      this.stability.scan();
      this.applyWorldSpawn();
      this.player.respawn();
      this.hasBegun = false;
      this.startButton.textContent = 'Entrer dans le monde';
      this.modeSelector?.classList.remove('locked');
      this.worldSelector?.classList.remove('locked');
      this.selectMode(this.selectedModeId);
      this.pauseMenu?.hide();
      this.startScreen.classList.remove('hidden');
      this.hud.setStatus('Nouveau monde généré');
    });

  }

  applyWorldSpawn(spawnIndex = 0) {
    if (!this.player || !this.world) return;
    const spawn = this.world.getSpawnPoint(spawnIndex);
    this.player.spawnPoint.copy(spawn);
    this.player.teleportTo(spawn);
  }

  renderWorldSelector() {
    if (!this.worldSelector) return;
    this.worldSelector.replaceChildren();
    const roomWorldId = this.multiplayer.roomWorldId || this.selectedWorldId;
    for (const world of WORLD_DEFINITIONS) {
      const roomLocked = this.multiplayerActive && world.id !== roomWorldId;
      const card = document.createElement('button');
      card.type = 'button';
      card.dataset.worldId = world.id;
      card.disabled = roomLocked;
      card.className = `world-card${world.id === this.selectedWorldId ? ' selected' : ''}${roomLocked ? ' unavailable' : ''}`;
      card.style.setProperty('--world-accent', world.accent);
      const title = document.createElement('strong');
      title.textContent = `${world.icon} ${world.label}`;
      const description = document.createElement('span');
      description.textContent = world.description;
      const count = document.createElement('small');
      count.textContent = `${world.landmarks.length} monuments`;
      card.append(title, description, count);
      if (!roomLocked) card.addEventListener('click', () => {
        if (!this.hasBegun && !this.multiplayerActive) this.selectWorld(world.id);
      });
      this.worldSelector.append(card);
    }
    this.worldSelector.classList.toggle('locked', this.hasBegun || this.multiplayerActive);
  }

  selectWorld(id, { force = false, persist = true, regenerate = true } = {}) {
    if ((this.hasBegun || this.multiplayerActive) && !force) return;
    const definition = getWorldDefinition(id);
    this.selectedWorldId = definition.id;
    if (persist && !this.multiplayerActive) {
      localStorage.setItem(WORLD_SAVE_KEY, definition.id);
      this.soloWorldId = definition.id;
    }
    if (regenerate) {
      this.monsters?.clear();
      const loaded = this.world.load(definition.id);
      if (!loaded) this.world.generatePreset(definition.id);
      this.applyWorldSpawn();
      this.hasBegun = false;
    }
    if (this.roomWorldSelect && !this.multiplayerActive) this.roomWorldSelect.value = definition.id;
    if (this.worldDescription) this.worldDescription.textContent = definition.description;
    if (this.worldLandmarks) this.worldLandmarks.textContent = definition.landmarks.join(' · ');
    this.passport?.setWorld(definition);
    this.navigationMap?.setWorld(definition, this.passport);
    this.passportView?.render();
    this.modeController?.current?.setWorld?.(definition);
    this.stability?.scan();
    this.fauna?.setWorld(definition);
    this.campfires?.setWorld(definition.id);
    this.nightLights?.scanLanterns();
    this.companions?.setWorld(definition);
    this.bigMap?.setWorld(definition);
    this.paragliding?.setWorld(definition);
    this.bridges?.setWorld(definition);
    this.monumentEnhancer?.setWorld(definition);
    this.scenicVegetation?.setWorld(definition);
    this.microDecor?.setWorld(definition);
    this.statues?.setWorld(definition);
    this.caves?.setWorld(definition); // Beta 4.32 : la grotte vient d'être (re)générée avec le continent
    this.ambientDetails?.setWorld(definition);
    this.climate?.setWorld(definition);
    this.livingWater?.setWorld();
    this.life?.setWorld(definition);
    this.renderWorldSelector();
    this.hud?.setStatus(`Monde sélectionné : ${definition.label}`);
  }

  renderModeSelector() {
    if (!this.modeSelector) return;
    this.modeSelector.replaceChildren();
    for (const mode of MODE_DEFINITIONS) {
      const roomLocked = this.multiplayerActive && mode.id !== this.multiplayer.roomMode;
      const available = mode.available || (mode.id === 'battle' && this.multiplayerActive && this.multiplayer.roomMode === 'battle');
      const card = document.createElement('button');
      card.type = 'button';
      card.dataset.modeId = mode.id;
      card.disabled = !available || roomLocked;
      card.className = `mode-card${mode.id === this.selectedModeId ? ' selected' : ''}${available && !roomLocked ? '' : ' unavailable'}`;
      card.style.setProperty('--mode-accent', mode.accent);
      const title = document.createElement('strong');
      title.textContent = `${mode.icon} ${mode.label}`;
      const description = document.createElement('span');
      description.textContent = mode.description;
      const state = document.createElement('small');
      if (this.multiplayerActive) state.textContent = mode.id === this.multiplayer.roomMode ? 'Mode de la salle' : 'Verrouillé par la salle';
      else if (mode.id === 'battle') state.textContent = 'Entraînement solo disponible';
      else state.textContent = mode.available ? 'Disponible en solo' : 'Indisponible';
      card.append(title, description, state);
      if (available && !roomLocked) card.addEventListener('click', () => {
        if (!this.hasBegun && !this.multiplayerActive) this.selectMode(mode.id);
      });
      this.modeSelector.append(card);
    }
  }

  selectMode(id, { force = false, persist = true } = {}) {
    if (this.hasBegun && !force) return;
    const definition = this.modeController.select(id);
    this.selectedModeId = definition.id;
    this.audio?.setMode(definition.id);
    if (persist) localStorage.setItem(MODE_SAVE_KEY, this.selectedModeId);
    this.hud.setModeInventory(
      this.selectedModeId,
      this.modeController.current.allowedItemIds,
      this.modeController.current.quickbarTemplate
    );
    this.modeController.current.select();
    this.renderModeSelector();
    const available = definition.available || (definition.id === 'battle' && this.multiplayerActive);
    this.startButton.disabled = !available;
    this.startButton.textContent = available
      ? (this.multiplayerActive
        ? 'Entrer dans la salle'
        : definition.id === 'battle' ? 'Entrer dans l’entraînement Battle' : 'Entrer dans le monde')
      : 'Mode indisponible';
    this.modeDescription.textContent = this.multiplayerActive
      ? `${definition.description} Mode imposé par la salle privée.`
      : definition.description;
    this.setNightIntensity(this.selectedModeId === 'survival' ? 0.55 : 0);
  }

  beginOrResume() {
    if (!this.hasBegun) {
      const definition = MODE_BY_ID.get(this.selectedModeId);
      const available = definition?.available || (definition?.id === 'battle' && this.multiplayerActive);
      if (!available) return;
      this.hasBegun = true;
      if (this.characterSelector) this.characterSelector.locked = true;
      // Beta 4.29 : mémorise la partie pour le bouton « Continuer » de l'accueil.
      this.startWizard?.rememberSession({
        mode: MODE_BY_ID.get(this.selectedModeId)?.label ?? '',
        world: getWorldDefinition(this.selectedWorldId)?.label ?? '',
        character: document.querySelector('.character-card.selected strong')?.textContent ?? ''
      });
      this.modeController.startSession();
      const seconds = this.modeController.spawnProtectionSeconds;
      if (seconds > 0) this.spawnProtection.start(seconds);
      this.modeSelector?.classList.add('locked');
      this.worldSelector?.classList.add('locked');
    }
    this.audio?.start().then(() => this.audio.setPaused(false)).catch(() => {});
    this.player.start();
  }

  handlePassportOpened() {
    this.passportOpen = true;
    if (this.inventoryOpen) {
      this.inventoryOpen = false;
      document.body.classList.remove('inventory-open');
      this.hud.setInventoryVisible(false);
    }
    this.startScreen.classList.add('hidden');
    if (this.player.isActive()) this.player.pause();
  }

  handlePassportClosed() {
    const wasOpen = this.passportOpen;
    this.passportOpen = false;
    if (!wasOpen) return;
    if (this.hasBegun) this.player.start();
    else this.startScreen.classList.remove('hidden');
  }

  openInventory() {
    if (this.inventoryOpen || this.passportOpen) return;
    this.inventoryOpen = true;
    document.body.classList.add('inventory-open');
    this.hud.setInventoryVisible(true);
    this.startScreen.classList.add('hidden');
    if (this.player.isActive()) this.player.pause();
  }

  closeInventory() {
    if (!this.inventoryOpen) return;
    this.inventoryOpen = false;
    document.body.classList.remove('inventory-open');
    this.hud.setInventoryVisible(false);
    if (this.hasBegun) this.player.start();
    else this.startScreen.classList.remove('hidden');
  }

  toggleCamera() {
    this.toggleZoom(false);
    const mode = this.player.toggleView();
    const label = mode === 'third' ? 'Vue extérieure' : 'Vue subjective';
    if (this.cameraViewButton) this.cameraViewButton.textContent = mode === 'third' ? 'Vue subjective' : 'Vue extérieure';
    this.weaponView.setItem(this.selectedItem, { firstPerson: mode === 'first' });
    this.hud.setStatus(`${label} activée`);
  }

  updateWeaponControls() {
    const zoomable = Boolean(this.selectedItem?.zoomFov);
    const reloadable = Boolean(this.selectedItem?.magazineSize);
    this.mobileZoomButton?.classList.toggle('hidden', !zoomable);
    this.mobileReloadButton?.classList.toggle('hidden', !reloadable);
    this.reloadButton?.classList.toggle('hidden', !reloadable);
  }

  updateWeaponHud() {
    if (!this.weaponElement) return;
    const display = this.weaponSystem?.getDisplay(this.selectedItem);
    const isWeapon = this.selectedItem?.kind === 'weapon';
    this.weaponElement.classList.toggle('hidden', !isWeapon);
    this.weaponElement.textContent = display ? `🔸 ${this.selectedItem.label} · ${display}` : '';
  }

  combatDisabledMessage() {
    if (this.selectedModeId === 'battle') return this.modeController.combatMessage();
    return 'Tir désactivé en mode Créatif · choisis Survie, Missions ou Battle pour tirer';
  }

  toggleZoom(force = null) {
    const canZoom = Boolean(this.selectedItem?.zoomFov) && this.player?.isActive();
    const next = force === null ? !this.zoomActive : Boolean(force);
    this.zoomActive = canZoom && next;
    this.targetFov = this.zoomActive ? this.selectedItem.zoomFov : this.defaultFov;
    document.body.classList.toggle('scope-active', this.zoomActive);
    this.scopeOverlay?.classList.toggle('hidden', !this.zoomActive);
    this.mobileZoomButton?.classList.toggle('active', this.zoomActive);
    if (this.zoomActive && this.player.viewMode !== 'first') {
      this.player.setView('first');
      if (this.cameraViewButton) this.cameraViewButton.textContent = 'Vue extérieure';
    }
    this.player?.setAimZoom(this.zoomActive);
    this.weaponView?.setItem(this.selectedItem, { firstPerson: this.player?.viewMode === 'first' });
    // Beta 4.15 : en mode Créatif, prévenir dès la visée que le tir est désactivé (avant : clic sans effet ni explication).
    const noCombat = this.zoomActive && !this.modeController?.allowsCombat;
    if (force === null) this.hud.setStatus(!this.zoomActive ? 'Lunette désactivée' : noCombat ? this.combatDisabledMessage() : 'Lunette activée · vise avec le réticule');
  }

  updateZoom(delta) {
    const nextFov = THREE.MathUtils.damp(this.camera.fov, this.targetFov, 13, delta);
    if (Math.abs(nextFov - this.camera.fov) > 0.001) {
      this.camera.fov = nextFov;
      this.camera.updateProjectionMatrix();
    }
    if (this.zoomActive && this.scopeDistance && performance.now() >= this.scopeUpdateAt) {
      const { blockHit, monsterHit, remoteHit } = this.raycastScene(this.selectedItem?.range ?? 60);
      const distance = Math.min(blockHit?.distance ?? Infinity, monsterHit?.distance ?? Infinity, remoteHit?.distance ?? Infinity);
      this.scopeDistance.textContent = Number.isFinite(distance) ? `${distance.toFixed(1)} m` : '— m';
      this.scopeUpdateAt = performance.now() + 120;
    }
  }

  reloadSelectedWeapon() {
    const item = this.selectedItem;
    if (!item?.magazineSize) {
      this.hud.setStatus('Cet objet ne possède pas de chargeur');
      return;
    }
    const result = this.weaponSystem.reload(item);
    if (!result.ok) {
      const message = result.reason === 'full' ? 'Chargeur déjà plein' : result.reason === 'already-reloading' ? 'Rechargement déjà en cours' : 'Rechargement impossible';
      this.hud.setStatus(message);
      return;
    }
    if (this.multiplayerActive && this.selectedModeId === 'battle') this.multiplayer.reloadWeapon(item.type);
    this.sfx?.playReloadStart(item.type);
    this.toggleZoom(false);
    this.hud.setStatus(`${item.label} : rechargement en cours`);
  }

  handleMouseDown(event) {
    if (this.touchMode || this.inventoryOpen || this.passportOpen || !this.player.isActive()) return;
    if (event.target !== this.renderer.domElement) return;
    if (this.photoMode?.active && event.button === 0 && !event.altKey) { event.preventDefault(); this.photoMode.shoot(); return; }

    const startsLook = event.button === 2 || event.button === 1 || (event.button === 0 && event.altKey);
    if (startsLook) {
      event.preventDefault();
      this.mouseLookActive = true;
      this.mouseLookButton = event.button;
      this.mouseLookDistance = 0;
      this.mouseLastX = event.clientX;
      this.mouseLastY = event.clientY;
      document.body.classList.add('mouse-looking');
      return;
    }

    if (event.button === 0) {
      this.primaryHeld = true;
      this.handleInteraction(0);
    }
  }

  handleMouseMove(event) {
    if (!this.mouseLookActive || !this.player.isActive()) return;
    const dx = event.clientX - this.mouseLastX;
    const dy = event.clientY - this.mouseLastY;
    this.mouseLastX = event.clientX;
    this.mouseLastY = event.clientY;
    this.mouseLookDistance += Math.hypot(dx, dy);
    this.input.addLookDelta(dx, dy);
  }

  handleMouseUp(event) {
    if (event.button === 0 && !this.mouseLookActive) this.primaryHeld = false;
    if (!this.mouseLookActive || event.button !== this.mouseLookButton) return;

    const wasSecondaryClick = event.button === 2 && this.mouseLookDistance < 5;
    this.mouseLookActive = false;
    this.mouseLookButton = -1;
    document.body.classList.remove('mouse-looking');
    if (event.button === 0) this.primaryHeld = false;
    if (wasSecondaryClick && this.player.isActive() && !this.inventoryOpen && !this.passportOpen) {
      this.handleInteraction(2);
    }
  }

  raycastScene(range, aim = null) {
    this.raycaster.far = range;
    const point = aim instanceof THREE.Vector2 ? aim : new THREE.Vector2(aim?.x ?? 0, aim?.y ?? 0);
    this.raycaster.setFromCamera(point, this.camera);
    const [blockHit] = this.raycaster.intersectObjects(this.world.getRaycastMeshes(), false);
    const [monsterHit] = this.raycaster.intersectObjects(this.monsters.getRaycastTargets(), true);
    const [remoteHit] = this.multiplayerActive
      ? this.raycaster.intersectObjects(this.remotePlayers.getRaycastTargets(), true)
      : [];
    const [creatureHit] = this.creatures ? this.raycaster.intersectObjects(this.creatures.targets(), true) : [];
    return { blockHit, monsterHit, remoteHit, creatureHit };
  }

  canAttack(cooldown) {
    const now = performance.now() / 1000;
    if (now < this.nextAttackAt) return false;
    this.nextAttackAt = now + cooldown;
    return true;
  }

  randomAim(spread = 0) {
    if (!spread) return new THREE.Vector2(0, 0);
    const accuracy = this.zoomActive ? 0.22 : 1;
    return new THREE.Vector2(
      (Math.random() - 0.5) * spread * accuracy,
      (Math.random() - 0.5) * spread * accuracy
    );
  }

  closestImpact({ blockHit, monsterHit, remoteHit, creatureHit }) {
    const entries = [
      blockHit ? { kind: 'block', hit: blockHit } : null,
      creatureHit ? { kind: 'creature', hit: creatureHit } : null,
      monsterHit ? { kind: 'monster', hit: monsterHit } : null,
      remoteHit ? { kind: 'remote', hit: remoteHit } : null
    ].filter(Boolean);
    entries.sort((a, b) => a.hit.distance - b.hit.distance);
    return entries[0] ?? null;
  }

  createTracer(start, end, color = 0xffe5a6) {
    const geometry = new THREE.BufferGeometry().setFromPoints([start, end]);
    const material = new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.9, depthWrite: false });
    const line = new THREE.Line(geometry, material);
    this.scene.add(line);
    this.effects.push({ mesh: line, age: 0, duration: 0.09, tracer: true });
  }

  fireCombatItem(profile) {
    const item = this.selectedItem;
    if (item.kind === 'weapon') {
      const ammo = this.weaponSystem.consumeShot(item);
      if (!ammo.ok) {
        this.primaryHeld = false;
        if (ammo.reason === 'empty') this.sfx?.playEmpty();
        this.hud.setStatus(ammo.reason === 'empty' ? `Chargeur vide · appuie sur T${this.touchMode ? ' ou ↻' : ''}` : 'Rechargement en cours');
        return;
      }
    }

    if (item.type === 'net') { this.throwNet(item); return; } // Beta 4.28 : capture sans blesser

    this.sfx?.playWeapon(item.type);
    // Beta 4.22 : le recul relevait la caméra AVANT le calcul du tir : la balle partait au-dessus du point visé.
    // Il est désormais appliqué après les rayons de tir.
    const applyRecoil = () => this.player.applyRecoil(profile.recoil ?? 0);
    this.weaponView.kick(profile.recoil ?? 0.2);
    const eye = this.player.getEyePosition().clone();

    if (profile.radius > 0) {
      const hits = this.raycastScene(Math.max(7, profile.range), this.randomAim(profile.spread));
      const impact = this.closestImpact(hits);
      const center = impact?.hit.point ?? eye.clone().add(this.camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(profile.range));
      if (this.selectedModeId === 'battle' && this.multiplayerActive && impact?.kind === 'remote') {
        const remote = impact.hit.object.userData.remotePlayer;
        if (remote) this.multiplayer.attackPlayer(remote.id, item.type);
      }
      const result = this.monsters.damageInRadius(center, profile.radius, profile.damage, {
        slowDuration: profile.slowDuration,
        burnDuration: profile.burnDuration,
        burnDamage: profile.burnDamage
      });
      const creatureResult = this.creatures?.damageInRadius(center, profile.radius, profile.damage, item.type) ?? { touched: 0, meat: 0 };
      result.touched += creatureResult.touched;
      if (creatureResult.meat) this.hud.updateHunger?.(this.hunger);
      if (impact) this.sfx?.playImpact(impact.kind === 'creature' ? 'monster' : impact.kind);
      this.createPulse(center, profile.radius, item.type === 'fireball' ? 0xff6a27 : 0xeeeeee);
      this.createTracer(eye, center, item.type === 'fireball' ? 0xff7a2c : 0xffe5a6);
      const extra = item.type === 'fireball' && result.touched > 0 ? ' · brûlure active' : '';
      this.hud.setStatus(`${item.label} : ${result.touched} cible${result.touched > 1 ? 's' : ''} touchée${result.touched > 1 ? 's' : ''}${extra}`);
      applyRecoil();
      return;
    }

    const pellets = Math.max(1, profile.pellets ?? 1);
    const localHits = new Map();
    const creatureHits = new Map();
    let remoteTarget = null;
    let remoteDistance = Infinity;
    let lastImpact = eye.clone().add(this.camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(profile.range));

    for (let pellet = 0; pellet < pellets; pellet += 1) {
      const hits = this.raycastScene(Math.max(7, profile.range), this.randomAim(profile.spread));
      const impact = this.closestImpact(hits);
      if (!impact) continue;
      lastImpact = impact.hit.point ?? lastImpact;
      if (impact.kind === 'monster') {
        const monster = impact.hit.object.userData.monster;
        if (monster) localHits.set(monster, (localHits.get(monster) ?? 0) + 1);
      } else if (impact.kind === 'creature') {
        const creature = creatureOf(impact.hit.object);
        if (creature) creatureHits.set(creature, (creatureHits.get(creature) ?? 0) + 1);
      } else if (impact.kind === 'remote' && impact.hit.distance < remoteDistance) {
        remoteTarget = impact.hit.object.userData.remotePlayer ?? null;
        remoteDistance = impact.hit.distance;
      }
    }

    if (this.selectedModeId === 'battle' && this.multiplayerActive && remoteTarget) {
      this.sfx?.playImpact('remote');
      this.multiplayer.attackPlayer(remoteTarget.id, item.type);
      this.hud.setStatus(`Tir validé par le serveur vers ${remoteTarget.nickname}`);
    } else if (localHits.size > 0) {
      this.sfx?.playImpact('monster');
      let totalHits = 0;
      let lastResult = null;
      for (const [monster, count] of localHits) {
        totalHits += count;
        lastResult = this.monsters.hitMonster(monster, profile.damage * count, {
          slowDuration: profile.slowDuration,
          burnDuration: profile.burnDuration,
          burnDamage: profile.burnDamage
        });
      }
      if (lastResult) {
        this.hud.setStatus(lastResult.killed
          ? `${lastResult.label} vaincu avec ${item.label}`
          : `${item.label} : ${totalHits} impact${totalHits > 1 ? 's' : ''} · ${lastResult.health} / ${lastResult.maxHealth} PV`);
      }
    } else if (creatureHits.size > 0) {
      this.sfx?.playImpact('monster');
      let last = null;
      for (const [creature, count] of creatureHits) last = this.creatures.hit(creature, profile.damage * count, { weapon: item.type, source: eye }) ?? last;
      if (last) {
        if (last.meat) this.hud.updateHunger?.(this.hunger);
        this.hud.setStatus(last.killed
          ? (last.kind === 'animal' ? `${last.label} abattu · +${last.meat} 🍖 (G pour manger)` : `${last.label} est à terre`)
          : `${last.label} touché : ${last.health} / ${last.maxHealth} PV`);
      }
    } else {
      const resolvedBlock = this.world.resolveRaycastHit?.(this.raycastScene(Math.max(7, profile.range)).blockHit);
      if (resolvedBlock) this.sfx?.playImpact('block', resolvedBlock.block?.type ?? '');
      this.hud.setStatus(`${item.label} utilisé — aucune cible`);
    }
    // Beta 4.28 : l'arc et le lance-pierre montrent leur projectile en vol au lieu d'une traînée.
    if (item.projectile) this.softTools?.launch(item.projectile, this.handPosition(), lastImpact);
    else this.createTracer(eye, lastImpact, profile.tracerColor);
    applyRecoil();
  }

  // Beta 4.28 : point de départ des projectiles (main droite, devant la caméra).
  handPosition() {
    return new THREE.Vector3(0.28, -0.18, -0.6).applyQuaternion(this.camera.quaternion).add(this.camera.position);
  }

  // Beta 4.28 : filet — immobilise monstres (6 s), animaux et chiens errants (8 s) dans un rayon de 1,8 m, sans dégâts.
  throwNet(item) {
    const range = item.range ?? 12;
    const hits = this.raycastScene(range);
    const impact = this.closestImpact({ blockHit: hits.blockHit, monsterHit: hits.monsterHit, creatureHit: hits.creatureHit });
    const eye = this.player.getEyePosition().clone();
    const center = impact?.hit.point?.clone() ?? eye.clone().add(this.camera.getWorldDirection(new THREE.Vector3()).multiplyScalar(range));
    this.sfx?.playWeapon('net');
    this.weaponView.kick(0.1);
    this.softTools.launch('net', this.handPosition(), center, () => this.applyNet(center, item));
  }

  applyNet(center, item) {
    const radius = item.netRadius ?? NET_RULES.radius;
    const caught = [];
    for (const monster of this.monsters.monsters ?? []) {
      if (!monster.alive) continue;
      const p = monster.group.position;
      if (Math.hypot(p.x - center.x, p.z - center.z) <= radius + 0.4 && Math.abs(p.y - center.y) < 3) { monster.applyNet(item.netDuration ?? NET_RULES.monsterSeconds); caught.push({ label: monster.label, object: monster.group, seconds: item.netDuration ?? NET_RULES.monsterSeconds }); }
    }
    for (const animal of this.fauna?.animals ?? []) {
      if (animal.userData.dead || !animal.visible) continue;
      const p = animal.position;
      if (Math.hypot(p.x - center.x, p.z - center.z) <= radius + 0.5 && Math.abs(p.y - center.y) < 3) { animal.userData.netUntil = performance.now() + NET_RULES.animalSeconds * 1000; caught.push({ label: animal.userData.type === 'bird' ? 'Oiseau' : 'Animal', object: animal, seconds: NET_RULES.animalSeconds }); }
    }
    for (const dog of this.companions?.dogs ?? []) {
      const p = dog.group.position;
      if (!dog.tamed && Math.hypot(p.x - center.x, p.z - center.z) <= radius + 0.5) { this.companions.net(dog, NET_RULES.animalSeconds); caught.push({ label: 'Chien errant', object: dog.group, seconds: NET_RULES.animalSeconds, dog: true }); }
    }
    const ground = this.world.getSurfaceHeight(Math.round(center.x), Math.round(center.z)) + 0.5;
    const first = caught[0];
    this.softTools.dropNet(new THREE.Vector3(center.x, Number.isFinite(ground) ? ground : center.y, center.z), first?.seconds ?? 1.2, first?.object ?? null);
    if (!first) { this.hud.setStatus('Filet vide · vise un monstre ou un animal à moins de 12 m'); return; }
    this.sfx?.playImpact('monster');
    this.hud.setStatus(first.dog
      ? 'Chien errant pris au filet : nourris-le vite (clic droit / ▣), une seule portion suffit pour l’apprivoiser'
      : `Filet : ${first.label}${caught.length > 1 ? ` et ${caught.length - 1} autre(s)` : ''} immobilisé(s) ${first.seconds} s, sans blessure`);
  }

  handleInteraction(button) {
    if (!this.player.isActive() || this.inventoryOpen || !this.selectedItem) return;
    const profile = getAttackProfile(this.selectedItem);
    const { blockHit, monsterHit } = this.raycastScene(Math.max(7, profile.range ?? 7));

    // Beta 4.28 : clic droit / ▣ sur un chien — le nourrir (errant) ou « assis / au pied » (compagnon).
    if (button === 2 && this.companions?.dogs.length) {
      this.raycaster.far = 4.5;
      const [dogHit] = this.raycaster.intersectObjects(this.companions.getRaycastTargets(), true);
      const dog = dogHit && (!blockHit || dogHit.distance <= blockHit.distance + 0.3) ? this.companions.dogFromHit(dogHit) : null;
      if (dog) { this.companions.interact(dog); return; }
    }

    // Beta 4.32 : clic droit sur un coffre de la grotte (prioritaire sur la pose d'un bloc).
    if (button === 2 && this.caves?.plan) {
      this.camera.getWorldDirection(this.cameraDirection);
      if (this.caves.tryOpenChest(this.player.getEyePosition(), this.cameraDirection)) return;
    }

    if (button === 2 && this.selectedItem.zoomFov) {
      this.toggleZoom();
      return;
    }

    if (button === 2 && this.selectedItem.kind !== 'block') {
      this.useSelectedItem(blockHit);
      return;
    }

    if (button === 0 && ['weapon', 'magic'].includes(this.selectedItem.kind)) {
      if (!this.modeController.allowsCombat) {
        this.hud.setStatus(this.combatDisabledMessage());
        return;
      }
      if (!this.canAttack(profile.cooldown)) return;
      this.fireCombatItem(profile);
      return;
    }

    if (button === 0 && monsterHit && (!blockHit || monsterHit.distance < blockHit.distance)) {
      if (!this.modeController.allowsCombat) return;
      if (!this.canAttack(profile.cooldown)) return;
      const monster = monsterHit.object.userData.monster;
      this.sfx?.playWeapon(this.selectedItem.type);
      this.sfx?.playImpact('monster');
      const result = this.monsters.hitMonster(monster, profile.damage);
      if (!result) return;
      this.hud.setStatus(result.killed ? `${result.label} vaincu` : `${result.label} touché : ${result.health} / ${result.maxHealth} PV`);
      return;
    }

    if (button === 0 && this.campfires?.fires.length) {
      // Beta 4.27 : clic gauche sur un feu de camp proche = l'éteindre (et le ramasser).
      this.raycaster.far = 5;
      const [fireHit] = this.raycaster.intersectObjects(this.campfires.getRaycastTargets(), true);
      const fire = fireHit && (!blockHit || fireHit.distance <= blockHit.distance + 0.3) ? this.campfires.fireFromHit(fireHit) : null;
      if (fire) { this.campfires.remove(fire); this.sfx?.playSizzle?.(); this.hud.setStatus('Feu de camp éteint'); return; }
    }

    if (!blockHit) {
      this.hud.setStatus(button === 0 ? 'Aucune cible à portée' : 'Aucun emplacement à portée');
      return;
    }

    const resolvedBlockHit = this.world.resolveRaycastHit(blockHit);
    if (!resolvedBlockHit) return;
    const block = resolvedBlockHit.block;
    if (button === 0) {
      if (!this.modeController.canBreakBlock()) { this.hud.setStatus(this.modeController.constructionMessage()); return; }
      this.damageBlock(block);
      return;
    }

    if (!this.modeController.canPlaceBlock()) { this.hud.setStatus(this.modeController.constructionMessage()); return; }
    const normal = blockHit.face?.normal;
    if (!normal) return;
    // Beta 4.32 r4 : au bord du dessus d'un bloc, en regardant vers le vide, le bloc se pose sur le côté (prolonger une passerelle).
    this.camera.getWorldDirection(this.cameraDirection);
    const viewLength = Math.hypot(this.cameraDirection.x, this.cameraDirection.z) || 1;
    const placement = resolvePlacement({
      hit: blockHit.point ?? null, block: resolvedBlockHit.position, normal,
      view: { x: this.cameraDirection.x / viewLength, z: this.cameraDirection.z / viewLength },
      isSolid: (x, y, z) => this.world.isSolidAt(x, y, z)
    });
    const target = new THREE.Vector3(placement.target.x, placement.target.y, placement.target.z);
    if (target.distanceTo(this.player.getEyePosition()) < 1.4) {
      this.hud.setStatus('Impossible de poser un bloc sur le joueur');
      return;
    }
    const bridgeVerdict = this.bridges?.canPlace(target, this.selectedBlockType);
    if (bridgeVerdict && !bridgeVerdict.ok) { this.hud.setStatus(bridgeVerdict.reason); return; }
    const existing = this.world.getBlock(target.x, target.y, target.z);
    if (existing?.type === 'water') this.world.removeBlock(existing.x, existing.y, existing.z, { persist: false });
    if (this.multiplayerActive) {
      if (this.multiplayer.addBlock(Math.round(target.x), Math.round(target.y), Math.round(target.z), this.selectedBlockType)) {
        this.hud.setStatus(`Pose de ${BLOCK_TYPES[this.selectedBlockType].label} en attente du serveur`);
      }
    } else if (this.world.addBlock(target.x, target.y, target.z, this.selectedBlockType)) {
      this.stability.scan();
      this.hudContext?.pulseStability();
      this.buildFeedback?.onPlace(target, this.selectedBlockType);
      this.bridges?.onBlockChanged(target);
      if (this.selectedBlockType === 'lantern') this.nightLights?.scanLanterns();
      const stability = this.stability.describeBlock(target.x, target.y, target.z);
      this.hud.setStatus(`Bloc ${BLOCK_TYPES[this.selectedBlockType].label} posé${placement.extended ? ' · prolongement' : ''}${stability ? ` · ${stability}` : ''}`);
      this.modeController.onEvent({ type: 'place', targetType: this.selectedBlockType, amount: 1, x: Math.round(target.x), y: Math.round(target.y), z: Math.round(target.z) });
    }
  }

  useSelectedItem(blockHit) {
    const item = this.selectedItem;
    if (item.type === 'fishing-rod') { this.fishing?.use(); return; }
    if (item.type === 'paraglider') { this.hud.setStatus(this.player.gliding ? 'En vol : Espace (ou ↑) referme la voile' : 'Saute d’une hauteur, puis Espace (ou ↑) en l’air pour ouvrir la voile'); return; }
    if (item.kind === 'placeable' && item.type === 'campfire') {
      const resolved = blockHit ? this.world.resolveRaycastHit(blockHit) : null;
      if (!resolved || blockHit.face?.normal?.y < 0.5) { this.hud.setStatus('Vise le dessus d’un bloc pour poser le feu de camp'); return; }
      if (['water', 'leaves', 'glass', 'window'].includes(resolved.block.type)) { this.hud.setStatus('Impossible d’allumer un feu ici'); return; }
      const placed = this.campfires.placeOnBlock(resolved.position);
      if (!placed.ok) { this.hud.setStatus(placed.reason === 'full' ? 'Douze feux au maximum sur ce continent' : 'Il y a déjà un feu ici'); return; }
      this.buildFeedback?.burst(placed.position, 'wood', { count: 12, spread: 0.4, lift: 1.4 });
      this.sfx?.playBlock?.('wood', 'place');
      this.hud.setStatus('🔥 Feu de camp allumé · approche-toi avec de la viande ou du poisson cru pour cuisiner');
      return;
    }
    if (item.kind === 'clothing') {
      this.player.equipClothing(item);
      this.hud.setStatus(`${item.label} équipé · visible en vue extérieure`);
      return;
    }
    if (item.kind === 'vehicle') {
      const enabled = this.player.setVehicle(item);
      this.hud.setStatus(enabled ? `${item.label} activé · mode de transport prototype` : `${item.label} rangé · déplacement à pied`);
      return;
    }
    if (item.kind === 'consumable') {
      if (item.heal) {
        const restored = this.player.heal(item.heal);
        this.hud.setStatus(`${item.label} utilisé : +${restored} PV`);
      } else if (item.speedBoost) {
        this.player.applySpeedBoost(item.speedBoost, item.duration);
        this.hud.setStatus(`${item.label} : vitesse augmentée pendant ${item.duration} s`);
      } else if (item.protection) {
        this.player.applyShield(item.protection, item.duration);
        this.hud.setStatus(`${item.label} : protection active pendant ${item.duration} s`);
      }
      return;
    }
    if (item.kind === 'magic' && item.type === 'heal-spell') {
      if (!this.canAttack(item.cooldown ?? 4)) return;
      const restored = this.player.heal(item.heal);
      this.hud.setStatus(`Soin magique : +${restored} PV`);
      return;
    }
    if (item.kind === 'magic' && item.type === 'teleport') {
      if (!this.canAttack(item.cooldown ?? 2.5)) return;
      if (!blockHit) {
        this.hud.setStatus('Téléportation : vise un bloc à portée');
        return;
      }
      const resolvedBlockHit = this.world.resolveRaycastHit(blockHit);
      if (!resolvedBlockHit) return;
      const target = resolvedBlockHit.position.clone();
      target.y += this.player.eyeHeight + 1.05;
      this.player.teleportTo(target);
      this.createPulse(target, 1.6, 0x7b5cff);
      this.hud.setStatus('Téléportation réussie');
      return;
    }
    this.hud.setStatus(`${item.label} s’utilise avec le bouton d’attaque`);
  }

  toggleStability() {
    const visible = this.stability.toggle();
    this.hudContext?.setInspecting(visible);
    if (visible && this.stability.report.total === 0) {
      this.hud.setStatus('Analyse de stabilité : construis quelques blocs pour commencer');
      return;
    }
    this.hud.setStatus(visible
      ? `Inspection de stabilité activée · ${this.stability.describeReport()}`
      : 'Inspection de stabilité masquée');
  }

  createPulse(position, radius, color) {
    const geometry = new THREE.SphereGeometry(1, 18, 12);
    const material = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.42, wireframe: true, depthWrite: false });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.copy(position);
    mesh.scale.setScalar(0.15);
    this.scene.add(mesh);
    this.effects.push({ mesh, radius, age: 0, duration: 0.42 });
  }

  updateEffects(delta) {
    for (const effect of [...this.effects]) {
      effect.age += delta;
      const progress = Math.min(1, effect.age / effect.duration);
      if (effect.tracer) {
        effect.mesh.material.opacity = 0.9 * (1 - progress);
      } else {
        effect.mesh.scale.setScalar(Math.max(0.15, effect.radius * progress));
        effect.mesh.material.opacity = 0.42 * (1 - progress);
      }
      if (progress >= 1) {
        this.scene.remove(effect.mesh);
        effect.mesh.geometry.dispose();
        effect.mesh.material.dispose();
        this.effects = this.effects.filter((entry) => entry !== effect);
      }
    }
  }

  damageBlock(block) {
    const config = BLOCK_TYPES[block.type];
    if (!config || !config.solid) {
      this.hud.setStatus('Ce bloc ne peut pas être récolté');
      return;
    }
    if (block.y <= 0) {
      this.hud.setStatus('La couche de base est protégée');
      return;
    }
    if (this.bridges?.isSiteBlock(block.x, block.y, block.z)) { this.hud.setStatus('Les culées et la rivière du chantier sont protégées'); return; }
    if (this.bridges?.test) { this.hud.setStatus('Essai en cours : attends la fin du passage du convoi'); return; }
    const key = this.world.key(block.x, block.y, block.z);
    const requiredHits = getHitsToBreak(block.type, this.selectedItem);
    const nextHits = (this.blockDamage.get(key) ?? 0) + 1;
    if (nextHits >= requiredHits) {
      this.blockDamage.delete(key);
      if (this.multiplayerActive) {
        this.multiplayer.removeBlock(block.x, block.y, block.z);
        this.hud.setStatus(`${config.label} : récolte en attente du serveur`);
      } else {
        const wasPlayerBlock = Boolean(this.world.addedBlocks?.has(key)); // Beta 4.31 : le mode Défense rend les blocs de tes propres murs
        this.world.removeBlock(block.x, block.y, block.z);
        this.buildFeedback?.onBreak(new THREE.Vector3(block.x, block.y, block.z), block.type);
        this.bridges?.onBlockChanged(block);
        if (block.type === 'lantern') this.nightLights?.scanLanterns();
        const report = this.stability.scan();
        this.hudContext?.pulseStability();
        const warning = report.counts.red ? ` · attention : ${report.counts.red} bloc${report.counts.red > 1 ? 's' : ''} rouge${report.counts.red > 1 ? 's' : ''}` : '';
        this.hud.setStatus(`${config.label} récolté${warning}`);
        this.modeController.onEvent({ type: 'harvest', targetType: block.type, amount: 1, playerBuilt: wasPlayerBlock });
      }
      return;
    }
    this.blockDamage.set(key, nextHits);
    this.buildFeedback?.onHit(new THREE.Vector3(block.x, block.y, block.z), block.type);
    this.hud.setStatus(`${config.label} : ${nextHits} / ${requiredHits} coups`);
  }

  // Beta 4.27 : continent courant (photos, poissons).
  currentWorldLabel() { return getWorldDefinition(this.selectedWorldId)?.label ?? ''; }
  currentWorldTheme() { const d = getWorldDefinition(this.selectedWorldId); return d?.theme ?? d?.id ?? 'europe'; }

  // Beta 4.27 : cuisson près d'un feu, pas sonores selon le sol.
  updateOutdoorLife(delta, eye) {
    this.campfires?.update(delta, eye);
    this.softTools?.update(delta);
    this.paragliding?.update(delta, eye);
    this.companions?.update(delta, eye);
    this.nightLights?.update(delta, eye);
    this.fishing?.update(delta);
    if (this.hunger && this.campfires) {
      const near = this.campfires.nearestDistance(eye) < CAMPFIRE_COOK_RADIUS;
      const cooked = this.hunger.cook(delta, near);
      if (cooked > 0) {
        this.sfx?.playSizzle?.();
        this.hud.setStatus(`🍢 Une portion cuite au feu de camp · ${this.hunger.cooked} cuite(s), ${this.hunger.food} crue(s) · G pour manger`);
        this.hud.updateHunger?.(this.hunger, this.hunger.isActive(this.selectedModeId));
      }
    }
    if (!this.player?.grounded || this.player.vehicle) { this.stepPosition = null; return; }
    const feet = this.player.getEyePosition();
    if (!this.stepPosition) { this.stepPosition = feet.clone(); return; }
    const moved = Math.hypot(feet.x - this.stepPosition.x, feet.z - this.stepPosition.z);
    if (moved > 1.7) {
      this.stepPosition.copy(feet);
      const ground = this.world.getTopBlock?.(Math.round(feet.x), Math.round(feet.z), { solidOnly: false });
      this.sfx?.playStep?.(ground?.type ?? 'grass');
    }
  }

  // Beta 4.26 : coups nécessaires avec l'objet en main (fissures progressives du bloc visé).
  hitsToBreak(blockType) {
    return getHitsToBreak(blockType, this.selectedItem);
  }

  // Beta 4.26 : résumé affiché dans le menu Pause.
  pauseSummary() {
    const mode = MODE_BY_ID.get(this.selectedModeId)?.label ?? '';
    const world = getWorldDefinition(this.selectedWorldId)?.label ?? '';
    return [mode, world, this.multiplayerActive ? 'salle multijoueur' : null].filter(Boolean).join(' · ');
  }

  // Beta 4.26 : du menu Pause vers l'écran d'accueil complet (réglages, salle, personnage).
  showStartScreenFromPause({ focusSettings = false } = {}) {
    this.pauseMenu?.hide();
    this.startScreen.classList.remove('hidden');
    this.startWizard?.refresh({ begun: this.hasBegun, multiplayer: this.multiplayerActive });
    if (focusSettings) this.startWizard?.openSettings();
  }

  // Beta 4.30 : panneau des défis d'ingénieur (O, bouton 🌉, menu Pause) ; le jeu se met en pause.
  toggleBridgePanel(force = null) {
    const open = force ?? !this.bridgePanelOpen;
    if (open === Boolean(this.bridgePanelOpen)) { if (open) this.bridges?.render(); return; }
    if (open && (this.inventoryOpen || this.passportOpen || this.bigMapOpen)) return;
    this.bridgePanelOpen = open;
    if (open) {
      this.pauseMenu?.hide();
      if (this.player.isActive()) this.player.pause();
      this.startScreen.classList.add('hidden');
      this.bridges?.setOpen(true);
    } else {
      this.bridges?.setOpen(false);
      if (this.hasBegun) this.player.start();
      else this.startScreen.classList.remove('hidden');
    }
  }

  // Beta 4.29 : grande carte (K, toucher la mini-carte) ; le jeu se met en pause pendant la lecture.
  toggleBigMap(force = null) {
    const open = force ?? !this.bigMapOpen;
    if (open === this.bigMapOpen) return;
    if (open && (this.inventoryOpen || this.passportOpen)) return;
    this.bigMapOpen = open;
    if (open) {
      if (this.player.isActive()) this.player.pause();
      this.bigMap?.toggle(true);
    } else {
      this.bigMap?.toggle(false);
      if (this.hasBegun) this.player.start();
    }
  }

  setNightIntensity(intensity) {
    const value = THREE.MathUtils.clamp(intensity, 0, 1);
    const color = this.dayColor.clone().lerp(new THREE.Color(0x4f73ab), value * 0.82);
    this.scene.background.copy(color);
    this.scene.fog.color.copy(color);
    this.hemisphere.intensity = 2.05 + value * 0.34;
    this.sun.intensity = 2.75 - value * 1.05;
    this.renderer.toneMappingExposure = 1.08 + value * 0.16;
  }

  handleResize() {
    const width = window.innerWidth;
    const height = window.innerHeight;
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.renderPipeline?.resize(width,height);
    this.navigationMap?.resize();
  }

  animate() {
    const delta = Math.min(this.clock.getDelta(), 0.05);
    this.pollGamepad(delta);
    this.player.update(delta);
    this.creatures?.update(delta);
    this.hdSyncTimer = (this.hdSyncTimer ?? 0) + delta;
    if (this.hdSyncTimer > 1) { this.hdSyncTimer = 0; this.syncHDCharacters(); } // joueurs arrivés, avatars reconstruits
    if (this.hunger && this.hasBegun) {
      const starving = this.hunger.update(delta, this.selectedModeId);
      if (starving > 0) { this.player.damage?.(starving); this.hud.setStatus('Tu as faim : chasse un animal puis mange (G)'); }
      this.hungerHudTimer = (this.hungerHudTimer ?? 0) + delta;
      if (this.hungerHudTimer > 0.5) { this.hungerHudTimer = 0; this.hud.updateHunger?.(this.hunger, this.hunger.isActive(this.selectedModeId)); }
    }
    const completedReloads = this.weaponSystem.update(delta);
    for (const itemId of completedReloads) this.sfx?.playReloadComplete(itemId);
    this.updateZoom(delta);
    if (this.primaryHeld && this.selectedItem?.automatic && this.player.isActive() && !this.inventoryOpen) this.handleInteraction(0);
    this.weaponView.update(delta, {
      moving: this.player.moveVector?.lengthSq?.() > 0.02,
      zoomed: this.zoomActive,
      firstPerson: this.player.viewMode === 'first'
    });
    if (this.photoMode?.active && this.weaponView?.group) this.weaponView.group.visible = false; // Beta 4.27 : pas d'arme sur les photos
    const playerPosition = this.player.getEyePosition();
    this.world.updateVisibleChunks(playerPosition, this.viewDistance || (this.touchMode ? 48 : 72));
    if (this.player.isActive()) {
      this.monsters.update(delta);
      this.modeController.update(delta);
      this.spawnProtection.update(delta);
      this.disasters?.update(delta);
      this.fauna?.update(delta, playerPosition);
      this.climate?.update(delta, playerPosition);
      this.caves?.update(delta, playerPosition); // avant l'atmosphère : elle lit caves.factor
      this.atmosphere?.update(delta, playerPosition);
      if (this.ambience) { this.camera.getWorldDirection(this.cameraDirection); this.ambience.update(delta, this.caves?.factor ?? 0, playerPosition, this.cameraDirection, this.camera.up, this.monsters.monsters); }
      this.livingWater?.update(delta, playerPosition);
      this.life?.update(delta, playerPosition);
      this.monumentEnhancer?.update(playerPosition);
      this.scenicVegetation?.update(delta, playerPosition);
      this.microDecor?.update(delta, this.camera.position);
      this.hitFeedback?.update(delta);
      this.ambientDetails?.update(delta, playerPosition);
    }
    if (this.multiplayerActive) {
      this.remotePlayers.update(delta);
      if (this.player.isActive()) this.multiplayer.sendState(this.player.getNetworkState());
    }
    updateVoxelClouds(this.clouds, delta); // Beta 4.14 : dérive nuage par nuage sur toute la carte
    this.navigationUpdateTimer += delta;
    if (this.navigationUpdateTimer >= 0.1) {
      this.navigationUpdateTimer = 0;
      const nearest = this.passport?.update(playerPosition);
      this.lastNearestLandmark = nearest;
      const navigationYaw = this.touchMode ? this.player.yaw : this.camera.rotation.y;
      this.navigationMap?.render(playerPosition, navigationYaw, nearest);
    }
    this.updateEffects(delta);
    this.bridges?.update(delta);
    this.hudContext?.update(delta);
    this.buildFeedback?.update(delta);
    if (this.player.isActive()) this.updateOutdoorLife(delta, playerPosition);
    if (this.renderPipeline) this.renderPipeline.render(delta); else this.renderer.render(this.scene, this.camera);
  }
}
