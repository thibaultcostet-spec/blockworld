// BlockWorld V3.0 Beta 4.22 — manette de jeu (API Gamepad, disposition « standard » : Xbox, PlayStation…).
// Les actions reprennent exactement celles du clavier et de la souris (voir CONTROL_BINDINGS).

export const GAMEPAD_BINDINGS = [
  { button: 0, action: 'jump', label: 'A / ✕', description: 'Sauter' },
  { button: 1, action: 'eat', label: 'B / ◯', description: 'Manger' },
  { button: 2, action: 'reload', label: 'X / ▢', description: 'Recharger' },
  { button: 3, action: 'inventory', label: 'Y / △', description: 'Inventaire' },
  { button: 4, action: 'previous', label: 'LB / L1', description: 'Objet précédent' },
  { button: 5, action: 'next', label: 'RB / R1', description: 'Objet suivant' },
  { button: 6, action: 'secondary', label: 'LT / L2', description: 'Viser · poser · utiliser' },
  { button: 7, action: 'primary', label: 'RT / R2', description: 'Tirer · frapper · casser' },
  { button: 8, action: 'legend', label: 'Select', description: 'Légende des commandes' },
  { button: 9, action: 'pause', label: 'Start', description: 'Pause / reprendre' },
  { button: 10, action: 'camera', label: 'L3', description: 'Changer de vue' },
  { button: 11, action: 'talk', label: 'R3', description: 'Parler à un habitant' },
  { button: 12, action: 'map', label: 'Croix ↑', description: 'Carte' },
  { button: 13, action: 'passport', label: 'Croix ↓', description: 'Passeport' },
  { button: 14, action: 'previous', label: 'Croix ←', description: 'Objet précédent' },
  { button: 15, action: 'next', label: 'Croix →', description: 'Objet suivant' }
];

const DEAD_ZONE = 0.16;
const deadZone = (value) => (Math.abs(value) < DEAD_ZONE ? 0 : (value - Math.sign(value) * DEAD_ZONE) / (1 - DEAD_ZONE));

export class GamepadInput {
  constructor({ onAction = () => {}, onRelease = () => {}, onConnect = () => {} } = {}) {
    this.onAction = onAction;
    this.onRelease = onRelease;
    this.previous = [];
    this.connected = false;
    this.move = { x: 0, y: 0 };
    this.look = { x: 0, y: 0 };
    globalThis.addEventListener?.('gamepadconnected', (event) => { this.connected = true; onConnect(event.gamepad?.id ?? 'Manette'); });
    globalThis.addEventListener?.('gamepaddisconnected', () => { this.connected = false; this.move = { x: 0, y: 0 }; });
  }

  pad() {
    const pads = globalThis.navigator?.getGamepads?.() ?? [];
    for (const pad of pads) if (pad?.connected) return pad;
    return null;
  }

  /** Lit la manette : sticks (déplacement, regard) et fronts montants/descendants des boutons. */
  poll() {
    const pad = this.pad();
    if (!pad) { this.move = { x: 0, y: 0 }; this.look = { x: 0, y: 0 }; return false; }
    this.move = { x: deadZone(pad.axes[0] ?? 0), y: -deadZone(pad.axes[1] ?? 0) };
    this.look = { x: deadZone(pad.axes[2] ?? 0), y: deadZone(pad.axes[3] ?? 0) };
    pad.buttons.forEach((button, index) => {
      const pressed = button.pressed || button.value > 0.5;
      const was = this.previous[index] ?? false;
      const binding = GAMEPAD_BINDINGS.find((entry) => entry.button === index);
      if (binding && pressed && !was) this.onAction(binding.action);
      if (binding && !pressed && was) this.onRelease(binding.action);
      this.previous[index] = pressed;
    });
    return true;
  }
}
