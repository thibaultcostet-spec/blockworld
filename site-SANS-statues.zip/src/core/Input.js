export class Input {
  constructor() {
    this.keys = new Set();
    this.pressed = new Set();
    this.virtualPressed = new Set();
    this.virtualMove = { x: 0, y: 0 };
    this.lookDelta = { x: 0, y: 0 };
    this.onKeyDown = this.onKeyDown.bind(this);
    this.onKeyUp = this.onKeyUp.bind(this);
  }

  connect() {
    window.addEventListener('keydown', this.onKeyDown, { passive: false });
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', () => this.reset());
  }

  disconnect() {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.reset();
  }

  reset() {
    this.keys.clear();
    this.pressed.clear();
    this.virtualPressed.clear();
    this.virtualMove.x = 0;
    this.virtualMove.y = 0;
    this.lookDelta.x = 0;
    this.lookDelta.y = 0;
  }

  onKeyDown(event) {
    const controlledCodes = [
      'KeyW', 'KeyZ', 'KeyS', 'KeyA', 'KeyQ', 'KeyD',
      'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'
    ];
    if (controlledCodes.includes(event.code)) event.preventDefault();
    if (!event.repeat) this.pressed.add(event.code);
    this.keys.add(event.code);
  }

  onKeyUp(event) {
    this.keys.delete(event.code);
  }

  isPressed(...codes) {
    return codes.some((code) => this.keys.has(code));
  }

  consumePress(...codes) {
    for (const code of codes) {
      if (this.pressed.has(code)) {
        this.pressed.delete(code);
        return true;
      }
    }
    return false;
  }

  setVirtualMove(x, y) {
    const length = Math.hypot(x, y);
    const scale = length > 1 ? 1 / length : 1;
    this.virtualMove.x = x * scale;
    this.virtualMove.y = y * scale;
  }

  getMovement() {
    const keyboardForward = Number(this.isPressed('KeyW', 'KeyZ', 'ArrowUp'))
      - Number(this.isPressed('KeyS', 'ArrowDown'));
    const keyboardRight = Number(this.isPressed('KeyD', 'ArrowRight'))
      - Number(this.isPressed('KeyA', 'KeyQ', 'ArrowLeft'));

    let x = keyboardRight + this.virtualMove.x + (this.gamepadMove?.x ?? 0);
    let y = keyboardForward + this.virtualMove.y + (this.gamepadMove?.y ?? 0);
    const length = Math.hypot(x, y);
    if (length > 1) {
      x /= length;
      y /= length;
    }
    return { x, y };
  }

  pressVirtual(action) {
    this.virtualPressed.add(action);
  }

  consumeVirtual(action) {
    if (!this.virtualPressed.has(action)) return false;
    this.virtualPressed.delete(action);
    return true;
  }

  addLookDelta(x, y) {
    this.lookDelta.x += x;
    this.lookDelta.y += y;
  }

  consumeLookDelta() {
    const result = { ...this.lookDelta };
    this.lookDelta.x = 0;
    this.lookDelta.y = 0;
    return result;
  }
}
