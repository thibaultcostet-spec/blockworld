import * as THREE from 'three';

export const DISASTER_TYPES = Object.freeze({
  earthquake: { label: 'Séisme', icon: '🌍', duration: 18 },
  storm: { label: 'Tempête', icon: '🌪️', duration: 24 },
  flood: { label: 'Inondation', icon: '🌊', duration: 22 }
});

export class DisasterManager extends EventTarget {
  constructor(game, elements = {}) {
    super();
    this.game = game;
    this.elements = elements;
    this.active = null;
    this.elapsed = 0;
    this.cooldown = 0;
    this.water = null;
    this.windParticles = null;
    this.baseCameraOffset = new THREE.Vector3();
    this.render();
  }

  start(type) {
    if (!DISASTER_TYPES[type] || this.active) return false;
    this.active = type;
    this.elapsed = 0;
    this.cooldown = 0;
    if (type === 'flood') this.createWater();
    if (type === 'storm') this.createWind();
    this.game.stability?.scan();
    this.game.sfx?.playExplosion?.({ gain: 0.08 });
    this.game.hud?.setStatus(`${DISASTER_TYPES[type].icon} ${DISASTER_TYPES[type].label} : reste à l’abri et inspecte les constructions fragiles`);
    this.render();
    this.dispatchEvent(new CustomEvent('start', { detail: { type } }));
    return true;
  }

  stop(message = true) {
    if (!this.active) return;
    const type = this.active;
    this.active = null;
    this.elapsed = 0;
    this.cleanupVisuals();
    this.game.setNightIntensity?.(0);
    if (message) this.game.hud?.setStatus(`${DISASTER_TYPES[type].icon} Fin de l’événement · aucune construction n’a été détruite automatiquement`);
    this.render();
    this.dispatchEvent(new CustomEvent('stop', { detail: { type } }));
  }

  cycle() {
    if (this.active) return this.stop();
    const order = ['earthquake', 'storm', 'flood'];
    const previous = localStorage.getItem('blockworld-v1.9-last-disaster');
    const next = order[(order.indexOf(previous) + 1) % order.length];
    localStorage.setItem('blockworld-v1.9-last-disaster', next);
    this.start(next);
  }

  createWater() {
    const geometry = new THREE.PlaneGeometry(260, 260);
    const material = new THREE.MeshStandardMaterial({ color: 0x278dd8, transparent: true, opacity: 0.48, roughness: 0.2, metalness: 0.05, side: THREE.DoubleSide });
    this.water = new THREE.Mesh(geometry, material);
    this.water.rotation.x = -Math.PI / 2;
    this.water.position.y = -0.45;
    this.water.name = 'PlayableFloodWater';
    this.game.scene.add(this.water);
  }

  createWind() {
    const count = this.game.touchMode ? 70 : 140;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      positions[i * 3] = (Math.random() - 0.5) * 90;
      positions[i * 3 + 1] = Math.random() * 24 + 1;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({ color: 0xdaf3ff, size: 0.16, transparent: true, opacity: 0.75 });
    this.windParticles = new THREE.Points(geometry, material);
    this.windParticles.name = 'StormParticles';
    this.game.scene.add(this.windParticles);
  }

  cleanupVisuals() {
    for (const object of [this.water, this.windParticles]) {
      if (!object) continue;
      this.game.scene.remove(object);
      object.geometry?.dispose?.();
      object.material?.dispose?.();
    }
    this.water = null;
    this.windParticles = null;
  }

  update(delta) {
    if (!this.active) return;
    this.elapsed += delta;
    const meta = DISASTER_TYPES[this.active];
    const progress = Math.min(1, this.elapsed / meta.duration);
    if (this.active === 'earthquake') this.updateEarthquake();
    if (this.active === 'storm') this.updateStorm(delta);
    if (this.active === 'flood') this.updateFlood(progress);
    if (this.elapsed >= meta.duration) this.stop();
    else this.render();
  }

  updateEarthquake() {
    const strength = 0.045 + Math.sin(this.elapsed * 2.1) * 0.018;
    this.game.camera.position.x += (Math.random() - 0.5) * strength;
    this.game.camera.position.y += (Math.random() - 0.5) * strength * 0.6;
    this.game.scene.fog.near = 42;
    this.game.scene.fog.far = 130;
  }

  updateStorm(delta) {
    this.game.setNightIntensity?.(0.62);
    if (this.windParticles) {
      this.windParticles.position.x += delta * 12;
      if (this.windParticles.position.x > 35) this.windParticles.position.x = -35;
      this.windParticles.rotation.y += delta * 0.08;
    }
    if (this.game.clouds) this.game.clouds.position.x += delta * 10;
  }

  updateFlood(progress) {
    this.game.setNightIntensity?.(0.24);
    if (!this.water) return;
    const maximum = Math.min(3.1, Math.max(1.35, this.game.player?.position?.y ?? 1.35));
    this.water.position.y = -0.45 + maximum * Math.sin(progress * Math.PI * 0.5);
    this.water.material.opacity = 0.38 + Math.sin(this.elapsed * 2) * 0.06;
    if (this.game.player?.position?.y < this.water.position.y + 0.5) {
      this.cooldown -= 1 / 60;
      if (this.cooldown <= 0) {
        this.cooldown = 2.2;
        this.game.hud?.setStatus('🌊 Zone inondée : gagne un point haut ou construis une passerelle stable');
      }
    }
  }

  render() {
    const { panel, title, timer, risk, button, gameButton, mobileButton } = this.elements;
    const report = this.game.stability?.report;
    const activeMeta = this.active ? DISASTER_TYPES[this.active] : null;
    panel?.classList.toggle('active', Boolean(this.active));
    if (title) title.textContent = activeMeta ? `${activeMeta.icon} ${activeMeta.label} en cours` : '☀️ Conditions normales';
    if (timer) timer.textContent = activeMeta ? `${Math.max(0, Math.ceil(activeMeta.duration - this.elapsed))} s restantes` : 'H : lancer un événement';
    if (risk) risk.textContent = report?.total
      ? `Construction : ${report.counts.green} vert · ${report.counts.orange} orange · ${report.counts.red} rouge`
      : 'Construis un abri ou une passerelle pour tester sa résistance.';
    for (const control of [button, gameButton, mobileButton]) {
      if (!control) continue;
      control.classList.toggle('active', Boolean(this.active));
      control.setAttribute('aria-pressed', String(Boolean(this.active)));
      if (control === button) control.textContent = this.active ? 'Arrêter l’événement' : 'Lancer une catastrophe';
    }
  }
}
