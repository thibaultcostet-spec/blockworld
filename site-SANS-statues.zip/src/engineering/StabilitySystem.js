import * as THREE from 'three';
import { analyzeConstruction, STABILITY_STATES } from './StructuralAnalyzer.js';

const STATE_META = Object.freeze({
  [STABILITY_STATES.GREEN]: { label: 'Stable', color: 0x48d46a, icon: '🟢' },
  [STABILITY_STATES.ORANGE]: { label: 'À surveiller', color: 0xffa928, icon: '🟠' },
  [STABILITY_STATES.RED]: { label: 'Instable', color: 0xff4050, icon: '🔴' }
});

export class StabilitySystem extends EventTarget {
  constructor(scene, world, elements = {}) {
    super();
    this.scene = scene;
    this.world = world;
    this.elements = elements;
    this.visible = false;
    this.report = analyzeConstruction(world);
    this.group = new THREE.Group();
    this.group.name = 'StructuralStabilityOverlay';
    this.group.visible = false;
    this.scene.add(this.group);
    this.geometry = new THREE.BoxGeometry(1.06, 1.06, 1.06);
    this.materials = Object.fromEntries(Object.entries(STATE_META).map(([state, meta]) => [
      state,
      new THREE.MeshBasicMaterial({
        color: meta.color,
        transparent: true,
        opacity: state === STABILITY_STATES.GREEN ? 0.26 : 0.58,
        wireframe: true,
        depthTest: false,
        depthWrite: false
      })
    ]));
    this.tempMatrix = new THREE.Matrix4();
    this.renderSummary();
  }

  scan() {
    this.report = analyzeConstruction(this.world);
    this.rebuildOverlay();
    this.renderSummary();
    this.dispatchEvent(new CustomEvent('change', { detail: this.report }));
    return this.report;
  }

  clearOverlay() {
    while (this.group.children.length) this.group.remove(this.group.children[0]);
  }

  rebuildOverlay() {
    this.clearOverlay();
    const grouped = { green: [], orange: [], red: [] };
    for (const entry of this.report.states.values()) grouped[entry.state].push(entry.block);
    for (const [state, blocks] of Object.entries(grouped)) {
      if (!blocks.length) continue;
      const mesh = new THREE.InstancedMesh(this.geometry, this.materials[state], blocks.length);
      mesh.name = `Stability_${state}`;
      mesh.renderOrder = 900;
      mesh.frustumCulled = true;
      for (let index = 0; index < blocks.length; index += 1) {
        const block = blocks[index];
        this.tempMatrix.makeTranslation(block.x, block.y, block.z);
        mesh.setMatrixAt(index, this.tempMatrix);
      }
      mesh.instanceMatrix.needsUpdate = true;
      mesh.computeBoundingSphere();
      this.group.add(mesh);
    }
    this.group.visible = this.visible && this.report.total > 0;
  }

  toggle(force = null) {
    this.visible = typeof force === 'boolean' ? force : !this.visible;
    this.group.visible = this.visible && this.report.total > 0;
    this.renderSummary();
    return this.visible;
  }

  getStateAt(x, y, z) {
    return this.report.states.get(this.world.key(Math.round(x), Math.round(y), Math.round(z))) ?? null;
  }

  describeReport(report = this.report) {
    if (!report.total) return 'Aucune construction personnelle à analyser';
    if (report.overall === STABILITY_STATES.RED) return `${report.counts.red} bloc${report.counts.red > 1 ? 's' : ''} sans appui suffisant`;
    if (report.overall === STABILITY_STATES.ORANGE) return `${report.counts.orange} bloc${report.counts.orange > 1 ? 's' : ''} proche${report.counts.orange > 1 ? 's' : ''} de la portée limite`;
    return 'Tous les blocs construits disposent d’un chemin d’appui';
  }

  describeBlock(x, y, z) {
    const result = this.getStateAt(x, y, z);
    if (!result) return null;
    const meta = STATE_META[result.state];
    const distance = result.supportDistance === null ? '' : ` · portée ${result.supportDistance}/${result.capacity}`;
    return `${meta.icon} ${meta.label}${distance}`;
  }

  renderSummary() {
    const { panel, summary, counts, details, toggleButton, startButton, gameButton, mobileButton } = this.elements;
    const report = this.report;
    const meta = STATE_META[report.overall];
    panel?.setAttribute('data-state', report.overall);
    panel?.classList.toggle('empty', report.total === 0);
    if (summary) summary.textContent = report.total ? `${meta.icon} ${meta.label} · ${report.score} %` : '⚪ Aucune construction';
    if (counts) counts.textContent = report.total
      ? `🟢 ${report.counts.green} · 🟠 ${report.counts.orange} · 🔴 ${report.counts.red}`
      : 'Pose des blocs pour lancer l’analyse.';
    if (details) details.textContent = this.describeReport(report);
    const active = this.visible;
    for (const button of [toggleButton, startButton, gameButton, mobileButton]) {
      if (!button) continue;
      button.setAttribute('aria-pressed', String(active));
      button.classList.toggle('active', active);
      if (button === toggleButton) button.textContent = active ? 'Masquer' : 'Inspecter';
      if (button === gameButton) button.textContent = active ? '🏗️' : '🏗';
    }
  }
}
