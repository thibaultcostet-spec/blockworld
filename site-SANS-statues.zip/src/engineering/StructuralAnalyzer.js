import { BLOCK_TYPES } from '../world/BlockTypes.js';

export const STABILITY_STATES = Object.freeze({
  GREEN: 'green',
  ORANGE: 'orange',
  RED: 'red'
});

const DEFAULT_SPAN = 2;
const SPAN_BY_TYPE = Object.freeze({
  concrete: 6,
  stone: 5,
  bricks: 5,
  obsidian: 6,
  wood: 4,
  planks: 4,
  roof: 4,
  fence: 3,
  door: 3,
  glass: 2,
  window: 2,
  crate: 2,
  grass: 2,
  dirt: 2,
  sand: 1,
  snow: 1,
  leaves: 1,
  crystal: 2,
  lantern: 1
});

const FREE_HEIGHT_BY_TYPE = Object.freeze({
  concrete: 14,
  stone: 12,
  bricks: 10,
  obsidian: 16,
  wood: 8,
  planks: 8,
  roof: 6,
  glass: 5,
  window: 5,
  fence: 5,
  door: 5
});

const HORIZONTAL_NEIGHBORS = Object.freeze([
  [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]
]);

function keyOf(world, x, y, z) {
  return typeof world.key === 'function' ? world.key(x, y, z) : `${x}|${y}|${z}`;
}

function getConstructionBlocks(world) {
  if (typeof world.getConstructionBlocks === 'function') return world.getConstructionBlocks();
  if (world.addedBlocks instanceof Map) return [...world.addedBlocks.values()];
  return [];
}

function getSpanCapacity(type) {
  return SPAN_BY_TYPE[type] ?? DEFAULT_SPAN;
}

function getFreeHeight(type) {
  return FREE_HEIGHT_BY_TYPE[type] ?? 7;
}

function isSolid(world, x, y, z) {
  const block = world.getBlock?.(x, y, z);
  return Boolean(block && BLOCK_TYPES[block.type]?.solid);
}

function countComponents(blocksByKey, world) {
  const remaining = new Set(blocksByKey.keys());
  let count = 0;
  const directions = [
    ...HORIZONTAL_NEIGHBORS,
    [0, 1, 0], [0, -1, 0]
  ];
  while (remaining.size) {
    count += 1;
    const start = remaining.values().next().value;
    remaining.delete(start);
    const queue = [blocksByKey.get(start)];
    while (queue.length) {
      const block = queue.shift();
      for (const [dx, dy, dz] of directions) {
        const neighborKey = keyOf(world, block.x + dx, block.y + dy, block.z + dz);
        if (!remaining.has(neighborKey)) continue;
        remaining.delete(neighborKey);
        queue.push(blocksByKey.get(neighborKey));
      }
    }
  }
  return count;
}

function isSlender(block, blocksByKey, world) {
  const limit = getFreeHeight(block.type);
  let height = 1;
  let cursorY = block.y - 1;
  while (blocksByKey.has(keyOf(world, block.x, cursorY, block.z))) {
    height += 1;
    cursorY -= 1;
  }
  if (height <= limit) return false;
  const hasBrace = HORIZONTAL_NEIGHBORS.some(([dx, , dz]) =>
    blocksByKey.has(keyOf(world, block.x + dx, block.y, block.z + dz))
  );
  return !hasBrace;
}

export function analyzeConstruction(world) {
  const construction = getConstructionBlocks(world)
    .map((block) => ({ ...block }))
    .filter((block) => BLOCK_TYPES[block.type]?.solid);
  const blocksByKey = new Map(construction.map((block) => [keyOf(world, block.x, block.y, block.z), block]));
  const supportDistance = new Map();
  const supportReason = new Map();
  const queue = [];

  for (const [key, block] of blocksByKey) {
    const belowKey = keyOf(world, block.x, block.y - 1, block.z);
    const belowIsConstruction = blocksByKey.has(belowKey);
    const anchoredToExistingWorld = block.y <= 0 || (isSolid(world, block.x, block.y - 1, block.z) && !belowIsConstruction);
    if (anchoredToExistingWorld) {
      supportDistance.set(key, 0);
      supportReason.set(key, 'appui direct sur le terrain ou une construction existante');
      queue.push(block);
    }
  }

  while (queue.length) {
    const current = queue.shift();
    const currentKey = keyOf(world, current.x, current.y, current.z);
    const currentDistance = supportDistance.get(currentKey) ?? 0;

    const aboveKey = keyOf(world, current.x, current.y + 1, current.z);
    if (blocksByKey.has(aboveKey) && (!supportDistance.has(aboveKey) || currentDistance < supportDistance.get(aboveKey))) {
      supportDistance.set(aboveKey, currentDistance);
      supportReason.set(aboveKey, 'appui vertical continu');
      queue.push(blocksByKey.get(aboveKey));
    }

    for (const [dx, , dz] of HORIZONTAL_NEIGHBORS) {
      const neighborKey = keyOf(world, current.x + dx, current.y, current.z + dz);
      const neighbor = blocksByKey.get(neighborKey);
      if (!neighbor) continue;
      const candidateDistance = currentDistance + 1;
      if (candidateDistance > getSpanCapacity(neighbor.type)) continue;
      if (!supportDistance.has(neighborKey) || candidateDistance < supportDistance.get(neighborKey)) {
        supportDistance.set(neighborKey, candidateDistance);
        supportReason.set(neighborKey, 'portée horizontale vers un appui');
        queue.push(neighbor);
      }
    }
  }

  const states = new Map();
  const counts = { green: 0, orange: 0, red: 0 };
  const issues = [];

  for (const [key, block] of blocksByKey) {
    const capacity = getSpanCapacity(block.type);
    const distance = supportDistance.get(key);
    let state = STABILITY_STATES.RED;
    let reason = 'aucun chemin d’appui détecté';

    if (Number.isFinite(distance)) {
      const warningThreshold = Math.max(2, Math.ceil(capacity * 0.65));
      const slender = isSlender(block, blocksByKey, world);
      state = distance >= warningThreshold || slender ? STABILITY_STATES.ORANGE : STABILITY_STATES.GREEN;
      reason = slender
        ? 'élément vertical élancé sans liaison latérale'
        : supportReason.get(key) ?? 'appui détecté';
    }

    counts[state] += 1;
    const result = { key, block, state, supportDistance: Number.isFinite(distance) ? distance : null, capacity, reason };
    states.set(key, result);
    if (state !== STABILITY_STATES.GREEN) issues.push(result);
  }

  issues.sort((a, b) => {
    const priority = { red: 0, orange: 1, green: 2 };
    return priority[a.state] - priority[b.state]
      || (b.supportDistance ?? 999) - (a.supportDistance ?? 999)
      || b.block.y - a.block.y;
  });

  const total = construction.length;
  const score = total > 0 ? Math.round(((counts.green + counts.orange * 0.5) / total) * 100) : 100;
  const overall = counts.red > 0
    ? STABILITY_STATES.RED
    : counts.orange > 0 ? STABILITY_STATES.ORANGE : STABILITY_STATES.GREEN;

  return {
    total,
    counts,
    score,
    overall,
    components: countComponents(blocksByKey, world),
    states,
    issues,
    analyzedAt: Date.now()
  };
}
