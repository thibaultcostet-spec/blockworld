import * as THREE from 'three';

// BlockWorld V3.0 Beta 4.31 — anneau d'avertissement au sol sous un monstre qui prépare son attaque :
// contour fixe + disque qui se remplit pendant les 0,6 s. Rouge vif, sans écriture dans le tampon de profondeur.

const ringGeometry = new THREE.RingGeometry(0.9, 1, 40);
const discGeometry = new THREE.CircleGeometry(0.9, 40);

export class AttackWarning {
  constructor(scene, radius = 1.5) {
    this.scene = scene;
    this.radius = radius;
    this.group = new THREE.Group();
    this.group.name = 'AttackWarning';
    this.group.visible = false;
    const material = (opacity) => new THREE.MeshBasicMaterial({ color: 0xff3b2f, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    this.ring = new THREE.Mesh(ringGeometry, material(0.95));
    this.disc = new THREE.Mesh(discGeometry, material(0.38));
    for (const mesh of [this.ring, this.disc]) { mesh.rotation.x = -Math.PI / 2; mesh.renderOrder = 5; this.group.add(mesh); }
    this.group.scale.setScalar(radius);
    scene.add(this.group);
  }

  /** Affiche l'anneau en (x, y, z) ; progress ∈ [0, 1] remplit le disque. */
  show(x, y, z, progress) {
    this.group.visible = true;
    this.group.position.set(x, y, z);
    this.disc.scale.setScalar(0.12 + 0.88 * progress);
    this.disc.material.opacity = 0.28 + 0.4 * progress;
  }

  hide() { this.group.visible = false; }

  dispose() {
    this.scene.remove(this.group);
    this.ring.material.dispose();
    this.disc.material.dispose();
  }
}
