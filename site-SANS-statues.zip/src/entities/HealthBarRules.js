// BlockWorld V3.0 Beta 4.31 — jauges de vie au-dessus des monstres : visibles à moins de 25 m, qui s'estompent
// entre 20 et 25 m, vert → ambre → rouge selon la vie restante. Module sans dépendance (testable sous Node).

export const BAR = { range: 25, fadeStart: 20 };
export const BAR_COLORS = { good: 0x5fd35f, warn: 0xf0b43a, bad: 0xe5483b };
// Hauteur de la jauge au-dessus de l'origine du modèle (m), selon l'espèce (le spectre vole, le golem est grand).
export const BAR_HEIGHT = { slime: 1.35, spider: 1.15, goblin: 2.05, golem: 2.95, wraith: 2.3, training_dummy: 2.5 };

export function barHeight(type) { return BAR_HEIGHT[type] ?? 2; }

export function barColor(ratio) {
  if (ratio > 0.6) return BAR_COLORS.good;
  if (ratio > 0.3) return BAR_COLORS.warn;
  return BAR_COLORS.bad;
}

/** État d'une jauge : { visible, ratio, color, opacity }. */
export function barState({ health, maxHealth, distance, alive = true, enabled = true, range = BAR.range, fadeStart = BAR.fadeStart }) {
  const ratio = maxHealth > 0 ? Math.min(1, Math.max(0, health / maxHealth)) : 0;
  if (!enabled || !alive || !(distance < range)) return { visible: false, ratio, color: barColor(ratio), opacity: 0 };
  const opacity = distance <= fadeStart ? 1 : Math.max(0, (range - distance) / (range - fadeStart));
  return { visible: opacity > 0.02, ratio, color: barColor(ratio), opacity };
}
