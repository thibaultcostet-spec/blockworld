import * as THREE from 'three';
import { monsterConfig } from './MonsterTypes.js';
import { buildMonster, animateMonster } from './MonsterModels.js';
import { createTelegraph, stepTelegraph, telegraphProgress, cancelTelegraph, TELEGRAPH } from './TelegraphRules.js';
import { AttackWarning } from './AttackWarning.js';
import { BLOCK_TYPES } from '../world/BlockTypes.js';

// Beta 4.25 : monstres morts animés (effondrement ou dissipation) avant de quitter la scène.
const DYING = new Set();
export function updateDyingMonsters(delta) {
  for (const monster of DYING) {
    monster.deathTime += delta;
    const t = Math.min(1, monster.deathTime / 1.1);
    const group = monster.group;
    if (monster.type === 'wraith') { group.scale.setScalar(monster.config.scale * (1 + t * 0.6)); group.position.y += delta * 0.8; }
    else if (monster.type === 'slime') { group.scale.set(monster.config.scale * (1 + t * 0.7), monster.config.scale * (1 - t * 0.85), monster.config.scale * (1 + t * 0.7)); }
    else if (monster.type === 'golem') { group.position.y -= delta * 0.9 * t; group.rotation.x = -t * 0.35; }
    else { group.rotation.z = monster.fallSide * Math.min(1, t * 1.8) * (Math.PI / 2); }
    group.traverse((object) => { if (object.isMesh && object.material) { object.material.transparent = true; object.material.opacity = Math.min(object.material.opacity ?? 1, 1 - Math.max(0, t - 0.45) / 0.55); } });
    if (t >= 1) { monster.scene.remove(group); DYING.delete(monster); }
  }
}

function box(width, height, depth, material, x, y, z) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), material);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

export class Monster {
  constructor(scene, world, position, type = 'slime', { onAttack, onDeath, onTelegraph, onSiege } = {}) {
    this.scene = scene;
    this.world = world;
    this.type = type;
    this.config = monsterConfig(type);
    this.label = this.config.label;
    this.onAttack = onAttack;
    this.onDeath = onDeath;
    this.onTelegraph = onTelegraph; // Beta 4.31 : début d'une attaque annoncée
    this.onSiege = onSiege; // Beta 4.31 : bloqué par un mur construit → renvoie true si le bloc est ronge
    this.telegraph = createTelegraph();
    this.warning = null;
    // Beta 4.32 : hauteur du sol sous le monstre. Par défaut le dessus de la colonne (surface de la montagne) ;
    // les gardiens de grotte la remplacent par le sol de la grotte (CaveSystem.surfaceBelow).
    this.surface = (x, z) => this.world.getSurfaceHeight(x, z);

    this.health = this.config.health;
    this.maxHealth = this.config.health;
    this.speed = this.config.speed * (0.92 + Math.random() * 0.16);
    this.attackCooldown = Math.random() * 0.4;
    this.directionTimer = 0;
    this.wanderAngle = Math.random() * Math.PI * 2;
    this.alive = true;
    this.elapsed = Math.random() * 10;
    this.hitTimer = 0;
    this.slowTimer = 0;
    this.netTimer = 0; // Beta 4.28 : immobilisé par un filet
    this.burnTimer = 0;
    this.burnDamage = 0;
    this.burnAccumulator = 0;

    this.group = this.createModel();
    this.marker = this.createMarker();
    this.group.add(this.marker);
    this.group.position.copy(position);
    this.scene.add(this.group);
  }

  createModel() {
    // Beta 4.25 : modèles détaillés et articulés (MonsterModels.js), face à −z.
    const { group, rig } = buildMonster(this.type, this.config);
    group.name = `Monster-${this.type}`;
    this.rig = rig;
    group.scale.setScalar(this.config.scale);
    group.traverse((object) => {
      object.userData.monster = this;
    });
    return group;
  }


  createMarker() {
    const material = new THREE.MeshBasicMaterial({
      color: 0xffe95f, transparent: true, opacity: 0.92, depthWrite: false
    });
    const marker = new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.055, 8, 32), material);
    marker.position.y = 2.25;
    marker.rotation.x = Math.PI / 2;
    marker.visible = false;
    return marker;
  }

  setHighlighted(value) {
    if (this.marker) this.marker.visible = Boolean(value);
  }

  // Beta 4.28 : filet — immobile et sans attaque pendant la durée.
  applyNet(duration = 6) {
    this.netTimer = Math.max(this.netTimer, duration);
  }

  applySlow(duration = 3) {
    this.slowTimer = Math.max(this.slowTimer, duration);
  }

  applyBurn(duration = 3, damagePerSecond = 4) {
    this.burnTimer = Math.max(this.burnTimer, duration);
    this.burnDamage = Math.max(this.burnDamage, damagePerSecond);
    this.burnAccumulator = 0;
  }

  hit(damage) {
    if (!this.alive) return false;
    this.health = Math.max(0, this.health - damage);
    this.hitTimer = 0.11;

    if (this.health <= 0) {
      this.alive = false;
      this.deathTime = 0;
      this.fallSide = Math.random() < 0.5 ? -1 : 1;
      this.setHighlighted(false);
      this.warning?.hide();
      DYING.add(this);
      this.onDeath?.(this);
      return true;
    }
    return false;
  }

  /** Beta 4.31 : disparition à l'aube — même animation qu'une mort, sans butin ni compte d'éliminations. */
  banish() {
    if (!this.alive) return;
    this.alive = false;
    this.deathTime = 0;
    this.fallSide = Math.random() < 0.5 ? -1 : 1;
    this.setHighlighted(false);
    this.warning?.hide();
    DYING.add(this);
  }

  update(delta, playerPosition, { detectMultiplier = 1, attacksEnabled = true, telegraphSeconds = 0, siegeEnabled = false } = {}) {
    if (!this.alive) return;

    this.elapsed += delta;
    this.attackCooldown = Math.max(0, this.attackCooldown - delta);
    this.directionTimer -= delta;
    this.hitTimer = Math.max(0, this.hitTimer - delta);
    this.slowTimer = Math.max(0, this.slowTimer - delta);
    this.netTimer = Math.max(0, this.netTimer - delta);
    if (this.burnTimer > 0) {
      this.burnTimer = Math.max(0, this.burnTimer - delta);
      this.burnAccumulator += delta;
      while (this.burnAccumulator >= 1 && this.alive) {
        this.burnAccumulator -= 1;
        this.hit(Math.max(1, Math.round(this.burnDamage)));
      }
    } else {
      this.burnDamage = 0;
      this.burnAccumulator = 0;
    }
    if (!this.alive) return;

    const pulse = this.hitTimer > 0 ? 1.13 : 1;
    this.group.scale.setScalar(this.config.scale * pulse);
    this.group.traverse((object) => {
      if (!object.isMesh || !object.material?.emissive || object.material.userData.glow) return; // yeux, fissures, cœur restent lumineux
      if (this.telegraph.phase === 'windup') {
        object.material.emissive.setHex(0xff2a10); // Beta 4.31 : le corps rougit pendant la préparation du coup
        object.material.emissiveIntensity = 0.3 + 0.7 * telegraphProgress(this.telegraph, telegraphSeconds || TELEGRAPH.windup);
      } else if (this.burnTimer > 0) {
        object.material.emissive.setHex(0x7a2200);
        object.material.emissiveIntensity = 0.75;
      } else if (this.type !== 'wraith') {
        object.material.emissive.setHex(0x000000);
        object.material.emissiveIntensity = 0;
      }
    });

    if (this.config.model === 'training_dummy') {
      const ground = this.surface(this.group.position.x, this.group.position.z);
      this.group.position.y = ground + 0.5; // Beta 4.25 : posé sur la face supérieure du bloc
      this.group.rotation.y = 0;
      return;
    }

    const toPlayer = new THREE.Vector3(
      playerPosition.x - this.group.position.x,
      0,
      playerPosition.z - this.group.position.z
    );
    const distanceToPlayer = toPlayer.length();

    let direction;
    const effectiveDetectRange = this.config.detectRange * detectMultiplier;
    if (distanceToPlayer < effectiveDetectRange && distanceToPlayer > 0.001) {
      direction = toPlayer.normalize();
    } else {
      if (this.directionTimer <= 0) {
        this.wanderAngle += (Math.random() - 0.5) * Math.PI;
        this.directionTimer = 1.2 + Math.random() * 2.5;
      }
      direction = new THREE.Vector3(Math.cos(this.wanderAngle), 0, Math.sin(this.wanderAngle));
    }

    const startX = this.group.position.x, startZ = this.group.position.z;
    const attackDistance = this.type === 'golem' ? 1.65 : this.type === 'wraith' ? 1.5 : 1.3;
    const winding = this.telegraph.phase === 'windup'; // Beta 4.31 : il reste en place pendant qu'il se prépare
    if (distanceToPlayer > attackDistance && !winding) {
      const speedFactor = this.netTimer > 0 ? 0 : this.slowTimer > 0 ? 0.42 : 1;
      const nextX = this.group.position.x + direction.x * this.speed * speedFactor * delta;
      const nextZ = this.group.position.z + direction.z * this.speed * speedFactor * delta;
      const nextGround = this.surface(nextX, nextZ);
      const currentGround = this.surface(this.group.position.x, this.group.position.z);
      const canFly = Boolean(this.config.flying);
      const stepOk = Math.abs(nextGround - currentGround) <= 1.05 && nextGround > 0;
      // Beta 4.31 (mode Défense) : un mur construit par le joueur arrête le monstre qui chasse — il le ronge
      // (les spectres ne traversent plus les murs à leur altitude de vol). Le terrain naturel reste ignoré.
      let obstacle = null;
      if (siegeEnabled && speedFactor > 0 && distanceToPlayer < effectiveDetectRange) {
        if (canFly) {
          const inWay = this.world.getBlock(nextX, this.group.position.y, nextZ);
          if (inWay && BLOCK_TYPES[inWay.type]?.solid) obstacle = inWay;
        } else if (!stepOk) {
          obstacle = this.world.getTopBlock(nextX, nextZ, { solidOnly: true });
        }
      }
      const gnawing = obstacle ? Boolean(this.onSiege?.(this, obstacle, delta)) : false;

      if (gnawing) {
        this.attackAnim = Math.max(this.attackAnim ?? 0, 0.2); // coups répétés contre le mur
      } else if (canFly || stepOk) {
        this.group.position.x = nextX;
        this.group.position.z = nextZ;
      } else {
        this.wanderAngle += Math.PI * (0.45 + Math.random() * 0.65);
        this.directionTimer = 0.35;
      }
    }

    // Beta 4.25 : posé sur la face supérieure du bloc (+0,5 ; il était enfoncé d'un demi-bloc).
    const ground = this.surface(this.group.position.x, this.group.position.z) + 0.5;
    if (this.config.flying) {
      this.group.position.y = ground + 1.3 + Math.sin(this.elapsed * 2.8) * 0.3;
    } else if (this.type === 'slime') {
      this.group.position.y = ground + Math.max(0, Math.sin(this.elapsed * 3.5)) * 0.25;
    } else {
      this.group.position.y = ground;
    }

    // Beta 4.25 : modèles tournés vers −z ; le cap de marche (+z) les faisait avancer à reculons.
    if (direction.lengthSq() > 0) this.group.rotation.y = Math.atan2(direction.x, direction.z) + Math.PI;
    const moved = Math.hypot(this.group.position.x - startX, this.group.position.z - startZ);
    this.attackAnim = Math.max(0, (this.attackAnim ?? 0) - delta);
    animateMonster(this.rig, { t: this.elapsed, speed: delta > 0 ? moved / delta : 0, attack: this.attackAnim > 0 ? 1 - this.attackAnim / 0.55 : 0 });

    if (attacksEnabled && this.netTimer <= 0) {
      const outcome = stepTelegraph(this.telegraph, delta, { ready: this.attackCooldown <= 0, distance: distanceToPlayer, reach: attackDistance, windup: telegraphSeconds });
      if (outcome === 'start') {
        this.onTelegraph?.(this);
      } else if (outcome === 'hit' || outcome === 'miss') {
        this.attackCooldown = this.config.attackCooldown;
        this.attackAnim = 0.55; // animation du coup
        if (outcome === 'hit') this.onAttack?.(this.config.attackDamage, this);
      }
    } else {
      cancelTelegraph(this.telegraph);
    }
    this.updateWarning(attackDistance, telegraphSeconds);
  }

  /** Anneau rouge au sol pendant la préparation du coup (Défense uniquement : telegraphSeconds > 0). */
  updateWarning(attackDistance, telegraphSeconds) {
    if (this.telegraph.phase !== 'windup' || !(telegraphSeconds > 0)) { this.warning?.hide(); return; }
    this.warning ??= new AttackWarning(this.scene, attackDistance + 0.25);
    const { x, z } = this.group.position;
    this.warning.show(x, this.surface(x, z) + 0.04, z, telegraphProgress(this.telegraph, telegraphSeconds));
  }

  dispose() {
    this.alive = false;
    DYING.delete(this);
    this.warning?.dispose();
    this.warning = null;
    this.scene.remove(this.group);
  }
}
