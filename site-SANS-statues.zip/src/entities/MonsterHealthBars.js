import * as THREE from 'three';
import { barHeight, barState } from './HealthBarRules.js';

// BlockWorld V3.0 Beta 4.31 — jauges de vie flottantes (face à la caméra) pour les monstres à moins de 25 m.
// Une jauge par monstre vivant, créée à la demande et supprimée quand le monstre quitte la liste.

const WIDTH = 1.3;
const HEIGHT = 0.18;
const plane = new THREE.PlaneGeometry(1, 1);

export class MonsterHealthBars {
  constructor(scene) {
    this.scene = scene;
    this.group = new THREE.Group();
    this.group.name = 'MonsterHealthBars';
    this.group.visible = false;
    scene.add(this.group);
    this.bars = new Map();
  }

  create() {
    const root = new THREE.Group();
    const back = new THREE.Mesh(plane, new THREE.MeshBasicMaterial({ color: 0x14181f, transparent: true, opacity: 0.8, depthWrite: false }));
    back.scale.set(WIDTH + 0.08, HEIGHT + 0.07, 1);
    const fill = new THREE.Mesh(plane, new THREE.MeshBasicMaterial({ color: 0x5fd35f, transparent: true, opacity: 1, depthWrite: false }));
    fill.position.z = 0.002;
    back.renderOrder = 20;
    fill.renderOrder = 21;
    root.add(back, fill);
    this.group.add(root);
    return { root, back, fill };
  }

  /** Met les jauges à jour. `enabled` faux : tout est masqué (modes sans jauges). */
  update(monsters, eye, camera, enabled) {
    this.group.visible = Boolean(enabled);
    if (!enabled) return;
    const live = new Set();
    for (const monster of monsters) {
      if (!monster.alive) continue;
      const position = monster.group.position;
      const distance = Math.hypot(position.x - eye.x, position.y - eye.y, position.z - eye.z);
      const state = barState({ health: monster.health, maxHealth: monster.maxHealth, distance, alive: monster.alive });
      let bar = this.bars.get(monster);
      if (!state.visible) { if (bar) bar.root.visible = false; if (bar) live.add(monster); continue; }
      if (!bar) { bar = this.create(); this.bars.set(monster, bar); }
      live.add(monster);
      bar.root.visible = true;
      bar.root.position.set(position.x, position.y + barHeight(monster.type), position.z);
      bar.root.quaternion.copy(camera.quaternion);
      const ratio = Math.max(0.001, state.ratio);
      bar.fill.scale.set(WIDTH * ratio, HEIGHT, 1);
      bar.fill.position.x = (ratio - 1) * WIDTH * 0.5;
      bar.fill.material.color.setHex(state.color);
      bar.fill.material.opacity = state.opacity;
      bar.back.material.opacity = 0.8 * state.opacity;
    }
    for (const [monster, bar] of this.bars) {
      if (live.has(monster)) continue;
      this.group.remove(bar.root);
      bar.back.material.dispose();
      bar.fill.material.dispose();
      this.bars.delete(monster);
    }
  }

  clear() {
    for (const bar of this.bars.values()) { this.group.remove(bar.root); bar.back.material.dispose(); bar.fill.material.dispose(); }
    this.bars.clear();
    this.group.visible = false;
  }
}
