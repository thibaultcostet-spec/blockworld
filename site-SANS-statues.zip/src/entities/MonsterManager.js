import * as THREE from 'three';
import { Monster, updateDyingMonsters } from './Monster.js';
import { MONSTER_ORDER } from './MonsterTypes.js';
import { MonsterHealthBars } from './MonsterHealthBars.js';

const LOOT_KEY = 'blockworld-v0.7-crystals';
const LEGACY_LOOT_KEYS = ['blockworld-v0.6-crystals', 'blockworld-v0.5-crystals'];

export class MonsterManager {
  constructor(scene, world, player, hud, { targetCount = 9, onMonsterDeath } = {}) {
    this.scene = scene;
    this.world = world;
    this.player = player;
    this.hud = hud;
    this.targetCount = targetCount;
    this.onMonsterDeath = onMonsterDeath;
    this.monsters = [];
    this.respawnTimer = 0;
    this.spawnCursor = 0;
    this.spawnPositionCursor = 0;
    this.spawnTypes = null;
    this.spawnPositions = [];
    this.aggressionMultiplier = 1;
    this.attacksEnabled = true;
    // Beta 4.31 (mode Défense) : attaques annoncées, siège des barricades, jauges de vie, apparitions pilotées par le mode.
    // Tous à zéro / faux par défaut : Survie, Missions et Battle se comportent exactement comme en 4.30.
    this.telegraphSeconds = 0;
    this.siegeEnabled = false;
    this.healthBarsEnabled = false;
    this.autoRespawn = true;
    this.camera = null;
    this.healthBars = new MonsterHealthBars(scene);
    this.onMonsterTelegraph = null;
    this.onSiege = null;
    this.highlighted = false;
    this.crystals = this.loadCrystals();
    this.hud.updateLoot(this.crystals);
  }

  loadCrystals() {
    for (const key of [LOOT_KEY, ...LEGACY_LOOT_KEYS]) {
      const value = Number.parseInt(localStorage.getItem(key) ?? '', 10);
      if (Number.isFinite(value)) {
        if (key !== LOOT_KEY) localStorage.setItem(LOOT_KEY, String(value));
        return value;
      }
    }
    return 0;
  }

  configure({ targetCount = this.targetCount, aggressionMultiplier = 1, attacksEnabled = true, spawnTypes = null, telegraphSeconds = 0, siege = false, healthBars = false, autoRespawn = true } = {}) {
    this.targetCount = Math.max(0, Math.round(targetCount));
    this.aggressionMultiplier = Math.max(0, aggressionMultiplier);
    this.attacksEnabled = Boolean(attacksEnabled);
    this.telegraphSeconds = Math.max(0, telegraphSeconds);
    this.siegeEnabled = Boolean(siege);
    this.healthBarsEnabled = Boolean(healthBars);
    this.autoRespawn = Boolean(autoRespawn);
    this.spawnTypes = Array.isArray(spawnTypes) && spawnTypes.length ? [...spawnTypes] : null;
    this.spawnCursor = 0;
    this.spawnPositionCursor = 0;
    while (this.monsters.length > this.targetCount) {
      this.monsters.pop()?.dispose();
    }
  }

  spawnInitial({ positions = [] } = {}) {
    this.clear();
    this.spawnPositions = Array.isArray(positions)
      ? positions.filter(Boolean).map((position) => position.clone ? position.clone() : new THREE.Vector3(position.x, position.y, position.z))
      : [];
    this.spawnPositionCursor = 0;
    for (let index = 0; index < this.targetCount; index += 1) {
      this.spawnOne();
    }
  }

  spawnOne(forcedType = null, forcedPosition = null) {
    if (this.targetCount <= 0) return;
    const pooledPosition = this.spawnPositions.length
      ? this.spawnPositions[this.spawnPositionCursor++ % this.spawnPositions.length]
      : null;
    const positionSource = forcedPosition ?? pooledPosition;
    const position = positionSource
      ? (positionSource.clone ? positionSource.clone() : new THREE.Vector3(positionSource.x, positionSource.y, positionSource.z))
      : this.world.findSpawnPosition();
    const typePool = this.spawnTypes ?? MONSTER_ORDER;
    const type = forcedType ?? typePool[this.spawnCursor++ % typePool.length];
    const monster = new Monster(this.scene, this.world, position, type, {
      onAttack: (damage, attacker) => {
        const applied = this.player.damage(damage);
        // Beta 4.17 : même retour visuel et physique que les armes (famille « mêlée »).
        if (applied > 0) this.onPlayerHit?.({ amount: applied, weapon: 'monster', source: attacker.group?.position ?? null });
        this.hud.setStatus(applied > 0
          ? `${attacker.label} attaque : -${applied} PV`
          : `La bulle bloque l’attaque de ${attacker.label}`);
      },
      onDeath: (deadMonster) => this.handleDeath(deadMonster),
      onTelegraph: (attacker) => this.onMonsterTelegraph?.(attacker),
      onSiege: (attacker, block, delta) => this.onSiege?.(attacker, block, delta) ?? false
    });
    monster.setHighlighted(this.highlighted);
    this.monsters.push(monster);
  }

  handleDeath(deadMonster) {
    this.monsters = this.monsters.filter((entry) => entry !== deadMonster);
    const loot = Math.max(0, deadMonster.config.loot ?? 0);
    if (loot > 0) {
      this.crystals += loot;
      localStorage.setItem(LOOT_KEY, String(this.crystals));
      this.hud.updateLoot(this.crystals);
      this.hud.setStatus(`${deadMonster.label} vaincu · +${loot} cristal${loot > 1 ? 'aux' : ''}`);
    } else {
      this.hud.setStatus(`${deadMonster.label} neutralisée · réapparition dans quelques secondes`);
    }
    this.onMonsterDeath?.(deadMonster);
    this.respawnTimer = 4.5;
  }

  update(delta) {
    updateDyingMonsters(delta); // Beta 4.25 : animations de mort
    const target = this.player.getEyePosition();
    for (const monster of this.monsters) {
      monster.update(delta, target, {
        detectMultiplier: this.aggressionMultiplier,
        attacksEnabled: this.attacksEnabled,
        telegraphSeconds: this.telegraphSeconds,
        siegeEnabled: this.siegeEnabled
      });
    }
    if (this.camera) this.healthBars.update(this.monsters, target, this.camera, this.healthBarsEnabled);

    if (this.autoRespawn && this.monsters.length < this.targetCount) {
      this.respawnTimer -= delta;
      if (this.respawnTimer <= 0) {
        this.spawnOne();
        this.respawnTimer = 4.5;
      }
    }
  }

  setCamera(camera) { this.camera = camera; }

  /** Beta 4.31 : à l'aube, tous les monstres se dissipent (sans butin ni compte d'éliminations). */
  banishAll() {
    const count = this.monsters.filter((monster) => monster.alive).length;
    for (const monster of this.monsters) monster.banish();
    this.monsters.length = 0;
    return count;
  }

  addCrystals(amount) {
    if (!(amount > 0)) return;
    this.crystals += amount;
    localStorage.setItem(LOOT_KEY, String(this.crystals));
    this.hud.updateLoot(this.crystals);
  }

  setHighlighted(value) {
    this.highlighted = Boolean(value);
    for (const monster of this.monsters) monster.setHighlighted(this.highlighted);
  }

  keepOutsideBubble(center, radius) {
    for (const monster of this.monsters) {
      if (!monster.alive) continue;
      const offset = monster.group.position.clone().sub(center);
      offset.y = 0;
      const distance = offset.length();
      if (distance >= radius || distance < 0.001) continue;
      offset.normalize().multiplyScalar(radius - distance + 0.05);
      monster.group.position.add(offset);
    }
  }

  getRadarEntries(origin, maximum = 6) {
    return this.monsters
      .filter((monster) => monster.alive)
      .map((monster) => {
        const dx = monster.group.position.x - origin.x;
        const dz = monster.group.position.z - origin.z;
        const distance = Math.hypot(dx, dz);
        const direction = Math.abs(dx) > Math.abs(dz)
          ? (dx > 0 ? 'E' : 'O')
          : (dz > 0 ? 'S' : 'N');
        return { label: monster.label, type: monster.type, distance, direction };
      })
      .sort((a, b) => a.distance - b.distance)
      .slice(0, maximum);
  }

  getRaycastTargets() {
    return this.monsters.filter((monster) => monster.alive).map((monster) => monster.group);
  }

  hitMonster(monster, damage, { slowDuration = 0, burnDuration = 0, burnDamage = 0 } = {}) {
    if (!monster?.alive) return null;
    if (slowDuration > 0) monster.applySlow(slowDuration);
    if (burnDuration > 0 && burnDamage > 0) monster.applyBurn(burnDuration, burnDamage);
    const killed = monster.hit(damage);
    return { killed, label: monster.label, health: monster.health, maxHealth: monster.maxHealth };
  }

  damageInRadius(center, radius, damage, { slowDuration = 0, burnDuration = 0, burnDamage = 0 } = {}) {
    const position = center instanceof THREE.Vector3 ? center : new THREE.Vector3(center.x, center.y, center.z);
    let touched = 0;
    let killed = 0;
    for (const monster of [...this.monsters]) {
      if (!monster.alive) continue;
      const distance = monster.group.position.distanceTo(position);
      if (distance > radius) continue;
      const factor = Math.max(0.28, 1 - distance / Math.max(radius, 0.001));
      const result = this.hitMonster(monster, Math.max(1, Math.round(damage * factor)), { slowDuration, burnDuration, burnDamage });
      if (!result) continue;
      touched += 1;
      if (result.killed) killed += 1;
    }
    return { touched, killed };
  }

  resetProgress() {
    this.crystals = 0;
    localStorage.removeItem(LOOT_KEY);
    this.hud.updateLoot(0);
  }

  clear() {
    for (const monster of this.monsters) monster.dispose();
    this.monsters.length = 0;
    this.healthBars?.clear();
  }
}
