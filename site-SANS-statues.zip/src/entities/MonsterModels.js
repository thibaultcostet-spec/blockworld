import * as THREE from 'three';

// BlockWorld V3.0 Beta 4.25 — monstres détaillés et animés.
// Chaque monstre est construit face à −z avec des pivots articulés (rig) ; animateMonster() les anime
// selon l'état (vitesse, attaque, coup reçu). Les matériaux lumineux (yeux, fissures, cœur) sont
// marqués userData.glow : l'effet de brûlure ne les éteint pas.

const mat = (color, options = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.75, metalness: 0, ...options });
const glow = (color, intensity = 1.6) => { const m = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, roughness: 0.4 }); m.userData.glow = true; return m; };

function part(parent, geometry, material, x = 0, y = 0, z = 0, name = '') {
  const mesh = new THREE.Mesh(geometry, material);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  if (name) mesh.name = name;
  parent.add(mesh);
  return mesh;
}
function pivot(parent, x = 0, y = 0, z = 0) { const g = new THREE.Group(); g.position.set(x, y, z); parent.add(g); return g; }
const sphere = (r, w = 16, h = 12) => new THREE.SphereGeometry(r, w, h);
const capsule = (r, l, s = 8) => new THREE.CapsuleGeometry(r, l, 4, s);

function eye(parent, x, y, z, radius, iris, pupil = 0x050505) {
  part(parent, sphere(radius, 12, 10), mat(0xf4f0e6, { roughness: 0.3 }), x, y, z);
  part(parent, sphere(radius * 0.55, 10, 8), glow(iris, 0.9), x, y, z - radius * 0.62);
  part(parent, sphere(radius * 0.28, 8, 6), mat(pupil, { roughness: 0.2 }), x, y, z - radius * 0.86);
}

// ─── Slime ────────────────────────────────────────────────────────────────────────────────────
function buildSlime(config) {
  const group = new THREE.Group(), rig = { kind: 'slime', bubbles: [] };
  const jelly = new THREE.MeshStandardMaterial({ color: config.color, roughness: 0.12, metalness: 0, transparent: true, opacity: 0.8, emissive: config.color, emissiveIntensity: 0.12 });
  const body = pivot(group, 0, 0, 0); rig.body = body;
  const blob = part(body, sphere(0.5, 28, 20), jelly, 0, 0.46, 0); blob.scale.set(1.05, 0.9, 1.0);
  part(body, sphere(0.42, 20, 14), jelly, 0, 0.1, 0).scale.set(1.15, 0.4, 1.1); // base étalée
  part(body, sphere(0.16, 12, 10), mat(0x1d4a24, { roughness: 0.6 }), 0.05, 0.42, 0.05); // noyau
  for (let i = 0; i < 6; i += 1) {
    const bubble = part(body, sphere(0.035 + Math.random() * 0.03, 8, 6), new THREE.MeshStandardMaterial({ color: 0xe8ffe8, transparent: true, opacity: 0.6, roughness: 0.1 }), (Math.random() - 0.5) * 0.5, 0.2 + Math.random() * 0.5, (Math.random() - 0.5) * 0.4);
    bubble.userData.phase = Math.random() * 10; rig.bubbles.push(bubble);
  }
  for (const x of [-0.17, 0.17]) eye(body, x, 0.64, -0.38, 0.09, 0x2a6b30);
  const mouth = part(body, new THREE.TorusGeometry(0.1, 0.022, 8, 18, Math.PI), mat(0x123015), 0, 0.46, -0.45); mouth.rotation.z = Math.PI; rig.mouth = mouth;
  return { group, rig };
}

// ─── Araignée ─────────────────────────────────────────────────────────────────────────────────
function buildSpider(config) {
  const group = new THREE.Group(), rig = { kind: 'spider', legs: [] };
  const chitin = mat(config.color, { roughness: 0.45, metalness: 0.1 }), dark = mat(0x161116, { roughness: 0.5 }), hair = mat(0x2a2129, { roughness: 0.95 });
  const body = pivot(group, 0, 0.28, 0); rig.body = body; // pattes au sol
  const abdomen = part(body, sphere(0.42, 22, 16), chitin, 0, 0.08, 0.42); abdomen.scale.set(0.95, 0.78, 1.15); rig.abdomen = abdomen;
  part(body, new THREE.TorusGeometry(0.16, 0.035, 6, 16), glow(0xd2321f, 0.55), 0, 0.36, 0.42).rotation.x = Math.PI / 2; // marque dorsale
  part(body, sphere(0.26, 18, 12), dark, 0, 0, -0.12).scale.set(1, 0.72, 1.1); // céphalothorax
  const head = pivot(body, 0, 0.02, -0.36); rig.head = head;
  part(head, sphere(0.17, 16, 12), chitin, 0, 0, 0).scale.set(1, 0.85, 0.9);
  [[-0.06, 0.07, 0.02], [0.06, 0.07, 0.02], [-0.11, 0.04, 0.012], [0.11, 0.04, 0.012], [-0.04, 0.12, 0.012], [0.04, 0.12, 0.012], [-0.13, 0.09, 0.009], [0.13, 0.09, 0.009]]
    .forEach(([x, y, r]) => part(head, sphere(r * 1.6, 8, 6), glow(0xff2a1a, 1.8), x, y, -0.13));
  for (const side of [-1, 1]) { const fang = part(head, new THREE.ConeGeometry(0.03, 0.14, 8), mat(0xe8dcc0, { roughness: 0.3 }), side * 0.05, -0.1, -0.12); fang.rotation.x = Math.PI * 0.9; rig[side < 0 ? 'fangL' : 'fangR'] = fang; }
  for (const side of [-1, 1]) for (let i = 0; i < 4; i += 1) {
    const hip = pivot(body, side * 0.2, 0, -0.26 + i * 0.14);
    hip.rotation.y = side * (0.55 - i * 0.36) + (side < 0 ? Math.PI : 0); // pattes avant vers −z
    const femur = pivot(hip, 0, 0, 0); femur.rotation.z = 0.75;
    part(femur, capsule(0.035, 0.42), hair, 0.24, 0, 0).rotation.z = Math.PI / 2;
    const knee = pivot(femur, 0.47, 0, 0); knee.rotation.z = -1.9;
    part(knee, capsule(0.026, 0.5), chitin, 0.27, 0, 0).rotation.z = Math.PI / 2;
    part(knee, sphere(0.04, 8, 6), dark, 0, 0, 0);
    rig.legs.push({ hip, femur, knee, side, index: i, baseYaw: hip.rotation.y });
  }
  return { group, rig };
}

// ─── Gobelin ──────────────────────────────────────────────────────────────────────────────────
function buildGoblin(config) {
  const group = new THREE.Group(), rig = { kind: 'goblin', limbs: [] };
  const skin = mat(config.color, { roughness: 0.7 }), leather = mat(0x5b3a22, { roughness: 0.85 }), cloth = mat(0x6e5b3a, { roughness: 0.95 }), bone = mat(0xe9dfc6, { roughness: 0.4 });
  const hips = pivot(group, 0, 0.62, 0); rig.hips = hips;
  part(hips, sphere(0.2, 14, 10), cloth, 0, 0, 0).scale.set(1.1, 0.7, 0.8); // pagne
  const torso = pivot(hips, 0, 0.05, 0); torso.rotation.x = -0.32; rig.torso = torso; // voûté vers l'avant (−z)
  part(torso, capsule(0.19, 0.26, 12), skin, 0, 0.27, 0).scale.set(1.1, 1, 0.85);
  part(torso, capsule(0.205, 0.2, 12), leather, 0, 0.3, 0).scale.set(1.12, 0.9, 0.9); // gilet
  part(torso, new THREE.TorusGeometry(0.19, 0.025, 6, 18), mat(0x3a2a1a), 0, 0.08, 0).rotation.x = Math.PI / 2; // ceinture
  part(torso, new THREE.BoxGeometry(0.06, 0.05, 0.02), mat(0xb89a52, { metalness: 0.6, roughness: 0.35 }), 0, 0.08, -0.19);
  const head = pivot(torso, 0, 0.6, -0.04); rig.head = head;
  part(head, sphere(0.19, 18, 14), skin, 0, 0, 0).scale.set(1.05, 0.95, 1);
  part(head, new THREE.ConeGeometry(0.05, 0.16, 10), skin, 0, -0.02, -0.21).rotation.x = -Math.PI / 2; // nez crochu
  for (const side of [-1, 1]) {
    const ear = part(head, new THREE.ConeGeometry(0.07, 0.34, 8), skin, side * 0.25, 0.06, 0.02); ear.rotation.z = side * -1.25; ear.scale.z = 0.35;
    eye(head, side * 0.075, 0.04, -0.15, 0.045, 0xffc21a);
    const tusk = part(head, new THREE.ConeGeometry(0.018, 0.07, 6), bone, side * 0.06, -0.11, -0.15); tusk.rotation.x = Math.PI;
  }
  part(head, new THREE.BoxGeometry(0.12, 0.012, 0.02), mat(0x2a1010), 0, -0.1, -0.17); // bouche
  for (const side of [-1, 1]) {
    const shoulder = pivot(torso, side * 0.24, 0.48, 0); shoulder.userData.arm = side;
    part(shoulder, capsule(0.05, 0.22), skin, 0, -0.15, 0);
    const elbow = pivot(shoulder, 0, -0.3, 0); elbow.rotation.x = 0.5; // avant-bras vers l'avant
    part(elbow, capsule(0.045, 0.2), skin, 0, -0.13, 0);
    part(elbow, new THREE.CylinderGeometry(0.055, 0.055, 0.08, 10), leather, 0, -0.14, 0); // brassard
    part(elbow, sphere(0.06, 10, 8), skin, 0, -0.28, 0);
    if (side > 0) { // massue
      const club = pivot(elbow, 0, -0.29, -0.02); club.rotation.x = -1.2; rig.club = club;
      part(club, new THREE.CylinderGeometry(0.03, 0.05, 0.5, 8), mat(0x6b4a2a, { roughness: 0.9 }), 0, -0.22, 0);
      part(club, new THREE.DodecahedronGeometry(0.09), mat(0x7a5a38, { roughness: 0.9, flatShading: true }), 0, -0.48, 0);
    }
    const hip = pivot(hips, side * 0.11, -0.05, 0); hip.userData.leg = side;
    part(hip, capsule(0.065, 0.2), skin, 0, -0.15, 0);
    const knee = pivot(hip, 0, -0.29, 0); knee.rotation.x = 0.25;
    part(knee, capsule(0.055, 0.18), skin, 0, -0.13, 0);
    part(knee, new THREE.BoxGeometry(0.12, 0.06, 0.2), leather, 0, -0.27, -0.04); // pied
    rig.limbs.push({ shoulder, elbow, hip, knee, side });
  }
  return { group, rig };
}

// ─── Golem ────────────────────────────────────────────────────────────────────────────────────
function buildGolem(config) {
  const group = new THREE.Group(), rig = { kind: 'golem', limbs: [] };
  const rock = mat(config.color, { roughness: 0.95, flatShading: true }), rockDark = mat(0x5c626a, { roughness: 1, flatShading: true });
  const moss = mat(0x4e7a32, { roughness: 1, flatShading: true }), lava = glow(0xff7a1a, 2.2);
  const chunk = (parent, r, x, y, z, m = rock, detail = 0) => { const c = part(parent, new THREE.DodecahedronGeometry(r, detail), m, x, y, z); c.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3); return c; };
  const hips = pivot(group, 0, 1.14, 0); rig.hips = hips; // pieds au sol
  chunk(hips, 0.36, 0, 0, 0, rockDark);
  const torso = pivot(hips, 0, 0.2, 0); rig.torso = torso;
  chunk(torso, 0.56, 0, 0.52, 0, rock, 1).scale.set(1.15, 1, 0.85);
  chunk(torso, 0.3, -0.34, 0.86, 0.05); chunk(torso, 0.3, 0.34, 0.86, 0.05);
  chunk(torso, 0.18, -0.2, 0.95, 0.3, moss); chunk(torso, 0.14, 0.32, 0.4, 0.38, moss);
  const core = part(torso, sphere(0.13, 14, 10), lava, 0, 0.55, -0.42); rig.core = core;
  for (const [x, y, rz] of [[-0.12, 0.72, 0.6], [0.14, 0.38, -0.5], [0.05, 0.85, -0.2], [-0.18, 0.4, 0.3]]) { const crack = part(torso, new THREE.BoxGeometry(0.03, 0.26, 0.03), lava, x, y, -0.44); crack.rotation.z = rz; }
  const head = pivot(torso, 0, 1.12, -0.06); rig.head = head;
  chunk(head, 0.26, 0, 0, 0, rock).scale.set(1.1, 0.85, 1);
  for (const side of [-1, 1]) part(head, new THREE.BoxGeometry(0.1, 0.05, 0.04), lava, side * 0.1, 0.02, -0.22);
  chunk(head, 0.1, 0.12, 0.2, 0.05, moss);
  for (const side of [-1, 1]) {
    const shoulder = pivot(torso, side * 0.72, 0.82, 0);
    chunk(shoulder, 0.26, 0, 0, 0, rockDark);
    const elbow = pivot(shoulder, 0, -0.45, 0);
    chunk(elbow, 0.22, 0, 0, 0); chunk(elbow, 0.2, 0, -0.32, 0, rock);
    const fist = chunk(elbow, 0.27, 0, -0.62, -0.04, rockDark, 0);
    const hip = pivot(hips, side * 0.3, -0.12, 0);
    chunk(hip, 0.24, 0, -0.18, 0, rock);
    const knee = pivot(hip, 0, -0.4, 0);
    chunk(knee, 0.22, 0, -0.08, 0, rockDark); chunk(knee, 0.24, 0, -0.32, -0.06, rock);
    rig.limbs.push({ shoulder, elbow, fist, hip, knee, side });
  }
  return { group, rig };
}

// ─── Spectre ──────────────────────────────────────────────────────────────────────────────────
function buildWraith(config) {
  const group = new THREE.Group(), rig = { kind: 'wraith', rags: [] };
  const cloak = new THREE.MeshStandardMaterial({ color: config.color, roughness: 0.9, transparent: true, opacity: 0.82, side: THREE.DoubleSide, emissive: 0x261449, emissiveIntensity: 0.6 });
  cloak.userData.glow = true; // lueur propre du spectre conservée
  const body = pivot(group, 0, 0, 0); rig.body = body;
  // Robe en lambeaux : profil tourné, bord inférieur déchiqueté.
  const profile = [[0.05, 1.55], [0.2, 1.42], [0.27, 1.15], [0.32, 0.8], [0.4, 0.45], [0.48, 0.12]].map(([r, y]) => new THREE.Vector2(r, y));
  const robe = new THREE.LatheGeometry(profile, 24);
  const pos = robe.attributes.position;
  for (let i = 0; i < pos.count; i += 1) if (pos.getY(i) < 0.2) pos.setY(i, pos.getY(i) - Math.abs(Math.sin(i * 1.7)) * 0.28);
  robe.computeVertexNormals();
  rig.robe = part(body, robe, cloak, 0, 0, 0);
  const hood = part(body, new THREE.SphereGeometry(0.27, 18, 14, 0, Math.PI * 2, 0, Math.PI * 0.62), cloak, 0, 1.5, 0.02); hood.scale.set(1, 1.15, 1.05);
  part(body, sphere(0.2, 14, 10), mat(0x05030a, { roughness: 1 }), 0, 1.45, -0.06); // visage d'ombre
  for (const side of [-1, 1]) part(body, sphere(0.035, 8, 6), glow(0x8ff5ff, 2.4), side * 0.075, 1.48, -0.24);
  for (const side of [-1, 1]) {
    const arm = pivot(body, side * 0.27, 1.18, -0.05); arm.rotation.set(1.1, 0, side * 0.25); rig[side < 0 ? 'armL' : 'armR'] = arm; // bras tendus vers −z
    part(arm, new THREE.CylinderGeometry(0.08, 0.13, 0.5, 10, 1, true), cloak, 0, -0.25, 0);
    const bone = mat(0xd9d2c2, { roughness: 0.5 });
    for (let f = 0; f < 4; f += 1) { const finger = part(arm, new THREE.CylinderGeometry(0.008, 0.006, 0.14, 5), bone, (f - 1.5) * 0.025, -0.56, 0); finger.rotation.x = 0.3; }
  }
  for (let i = 0; i < 5; i += 1) { // lambeaux flottants
    const rag = part(body, new THREE.PlaneGeometry(0.12, 0.42), cloak, (Math.random() - 0.5) * 0.6, 0.35 + Math.random() * 0.5, 0.25 + Math.random() * 0.15);
    rag.userData.phase = Math.random() * 6; rig.rags.push(rag);
  }
  return { group, rig };
}

// ─── Cible d'entraînement (inchangée dans l'esprit, plus soignée) ───────────────────────────
function buildDummy(config) {
  const group = new THREE.Group(), rig = { kind: 'dummy' };
  const straw = mat(0xc9a35b, { roughness: 1 }), wood = mat(0x6b4a2a, { roughness: 0.9 }), red = mat(config.color, { roughness: 0.7 });
  part(group, new THREE.CylinderGeometry(0.06, 0.08, 1.9, 8), wood, 0, 0.95, 0.05);
  part(group, new THREE.BoxGeometry(0.9, 0.14, 0.62), wood, 0, 0.07, 0);
  part(group, capsule(0.3, 0.5, 12), straw, 0, 1.15, 0);
  part(group, new THREE.CylinderGeometry(0.28, 0.28, 0.02, 24), red, 0, 1.15, -0.3).rotation.x = Math.PI / 2;
  part(group, new THREE.CylinderGeometry(0.17, 0.17, 0.025, 24), mat(0xffe7a0), 0, 1.15, -0.31).rotation.x = Math.PI / 2;
  part(group, new THREE.CylinderGeometry(0.07, 0.07, 0.03, 18), red, 0, 1.15, -0.32).rotation.x = Math.PI / 2;
  part(group, sphere(0.22, 14, 10), straw, 0, 1.72, 0);
  part(group, new THREE.CylinderGeometry(0.04, 0.04, 1.0, 6), wood, 0, 1.38, 0.02).rotation.z = Math.PI / 2;
  return { group, rig };
}

const BUILDERS = { slime: buildSlime, spider: buildSpider, goblin: buildGoblin, golem: buildGolem, wraith: buildWraith, training_dummy: buildDummy };

export function buildMonster(type, config) {
  const builder = BUILDERS[config.model] ?? BUILDERS[type] ?? buildGoblin;
  return builder(config);
}

/** Anime le monstre. state : { t (temps), speed (m/s), attack (0..1 pendant un coup), dying (0..1) }. */
export function animateMonster(rig, state) {
  const { t, speed = 0, attack = 0 } = state;
  const moving = Math.min(1, speed / 1.2);
  switch (rig.kind) {
    case 'slime': {
      const squash = Math.sin(t * 7) * (0.08 + moving * 0.06) - attack * 0.18;
      rig.body.scale.set(1 - squash * 0.5, 1 + squash, 1 - squash * 0.5);
      rig.body.rotation.z = Math.sin(t * 3.1) * 0.05;
      for (const bubble of rig.bubbles) { bubble.position.y = 0.15 + ((t * 0.35 + bubble.userData.phase) % 0.7); }
      rig.mouth.scale.y = 1 + attack * 1.5;
      break;
    }
    case 'spider': {
      const cycle = t * (4 + speed * 5);
      for (const leg of rig.legs) {
        const group = (leg.index + (leg.side > 0 ? 1 : 0)) % 2; // quadripodes alternés
        const phase = cycle + group * Math.PI;
        const lift = Math.max(0, Math.sin(phase)) * 0.45 * moving;
        leg.hip.rotation.y = leg.baseYaw + Math.cos(phase) * 0.32 * moving;
        leg.femur.rotation.z = 0.75 + lift;
        leg.knee.rotation.z = -1.9 + lift * 0.4;
      }
      rig.body.position.y = 0.28 + Math.sin(cycle * 2) * 0.02 * moving;
      rig.abdomen.rotation.x = Math.sin(t * 2.2) * 0.06;
      const bite = attack > 0 ? Math.sin(attack * Math.PI) * 0.6 : Math.sin(t * 6) * 0.05;
      rig.fangL.rotation.z = bite; rig.fangR.rotation.z = -bite;
      rig.head.rotation.x = -attack * 0.4;
      break;
    }
    case 'goblin':
    case 'golem': {
      const heavy = rig.kind === 'golem';
      const cadence = heavy ? 3.2 : 6.5;
      const swing = Math.sin(t * cadence) * (heavy ? 0.45 : 0.7) * moving;
      for (const limb of rig.limbs) {
        limb.hip.rotation.x = swing * limb.side;
        limb.knee.rotation.x = Math.max(0, -swing * limb.side) * 0.9 + (heavy ? 0 : 0.25);
        limb.shoulder.rotation.x = -swing * limb.side * 0.8;
      }
      rig.hips.position.y = (heavy ? 1.14 : 0.62) + Math.abs(Math.sin(t * cadence)) * (heavy ? 0.05 : 0.04) * moving;
      rig.torso.rotation.y = Math.sin(t * cadence) * (heavy ? 0.06 : 0.12) * moving;
      // Coup : massue abattue (gobelin), deux poings levés puis frappés (golem).
      if (attack > 0) {
        const strike = Math.sin(attack * Math.PI);
        if (heavy) for (const limb of rig.limbs) { limb.shoulder.rotation.x = -2.4 * strike; limb.elbow.rotation.x = -0.6 * strike; }
        else { const right = rig.limbs.find((l) => l.side > 0); right.shoulder.rotation.x = -2.2 * strike + (attack > 0.5 ? 1.6 * (attack - 0.5) * 2 : 0); }
      }
      if (heavy) rig.core.material.emissiveIntensity = 1.8 + Math.sin(t * 3) * 0.6 + attack * 2;
      rig.head.rotation.y = Math.sin(t * 0.7) * 0.25;
      if (!heavy) rig.torso.rotation.x = -0.32 + Math.sin(t * cadence * 2) * 0.04 * moving;
      break;
    }
    case 'wraith': {
      rig.body.rotation.z = Math.sin(t * 1.3) * 0.06;
      rig.robe.scale.set(1 + Math.sin(t * 2.4) * 0.03, 1, 1 + Math.cos(t * 2.1) * 0.03);
      const reach = attack > 0 ? Math.sin(attack * Math.PI) : 0;
      rig.armL.rotation.x = 1.1 + reach * 0.5 + Math.sin(t * 1.7) * 0.08;
      rig.armR.rotation.x = 1.1 + reach * 0.5 + Math.cos(t * 1.9) * 0.08;
      for (const rag of rig.rags) rag.rotation.set(Math.sin(t * 3 + rag.userData.phase) * 0.5, Math.sin(t * 1.7 + rag.userData.phase) * 0.6, 0);
      break;
    }
    default: break;
  }
}
