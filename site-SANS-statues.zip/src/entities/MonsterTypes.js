export const MONSTER_TYPES = {
  training_dummy: {
    label: 'Cible d’entraînement', color: 0xd94b4b, faceColor: 0xf0c38a,
    health: 100, speed: 0, attackDamage: 0, attackCooldown: 99,
    detectRange: 0, scale: 1, model: 'training_dummy', loot: 0
  },
  slime: {
    label: 'Slime', color: 0x55c85f, faceColor: 0x83ea87,
    health: 34, speed: 1.65, attackDamage: 6, attackCooldown: 1.05,
    detectRange: 10, scale: 0.9, model: 'slime', loot: 1
  },
  spider: {
    label: 'Araignée', color: 0x3b303a, faceColor: 0x665263,
    health: 28, speed: 2.65, attackDamage: 5, attackCooldown: 0.72,
    detectRange: 12, scale: 0.88, model: 'spider', loot: 1
  },
  goblin: {
    label: 'Gobelin', color: 0x6f9c45, faceColor: 0x9bcf63,
    health: 48, speed: 1.85, attackDamage: 9, attackCooldown: 1.0,
    detectRange: 13, scale: 1, model: 'goblin', loot: 2
  },
  golem: {
    label: 'Golem', color: 0x767d86, faceColor: 0x9ba2aa,
    health: 115, speed: 0.82, attackDamage: 17, attackCooldown: 1.65,
    detectRange: 10, scale: 0.92, model: 'golem', loot: 4
  },
  wraith: {
    label: 'Spectre', color: 0x7757b5, faceColor: 0xb49ae8,
    health: 52, speed: 1.72, attackDamage: 11, attackCooldown: 1.25,
    detectRange: 15, scale: 1, model: 'wraith', loot: 3, flying: true
  }
};

export const MONSTER_ORDER = ['slime', 'spider', 'goblin', 'golem', 'wraith'];

export function monsterConfig(type) {
  return MONSTER_TYPES[type] ?? MONSTER_TYPES.slime;
}
