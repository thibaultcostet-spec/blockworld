// BlockWorld V3.0 Beta 4.31 — attaque annoncée : le monstre se prépare 0,6 s (anneau rouge au sol, corps qui rougit)
// puis frappe ; si le joueur s'est éloigné d'au moins `reach + slack`, le coup est manqué (esquive).
// Module sans dépendance (testable sous Node). windup = 0 : comportement historique (coup instantané).

export const TELEGRAPH = { windup: 0.6, slack: 0.7 };

export function createTelegraph() { return { phase: 'idle', t: 0 }; }

/**
 * Fait avancer l'attaque. Renvoie null, 'start' (début de la préparation), 'hit' (coup porté) ou 'miss' (esquivé).
 * `ready` : délai de recharge écoulé ; `distance` : distance horizontale au joueur ; `reach` : portée du coup.
 */
export function stepTelegraph(state, delta, { ready, distance, reach, windup = TELEGRAPH.windup, slack = TELEGRAPH.slack }) {
  if (!(windup > 0)) return ready && distance < reach ? 'hit' : null; // 4.30 et avant : pas d'annonce
  if (state.phase === 'idle') {
    if (!(ready && distance < reach)) return null;
    state.phase = 'windup';
    state.t = 0;
    return 'start';
  }
  state.t += Math.max(0, delta);
  if (state.t < windup) return null;
  state.phase = 'idle';
  state.t = 0;
  return distance < reach + slack ? 'hit' : 'miss';
}

export function telegraphProgress(state, windup = TELEGRAPH.windup) {
  return state.phase === 'windup' && windup > 0 ? Math.min(1, state.t / windup) : 0;
}

export function cancelTelegraph(state) { state.phase = 'idle'; state.t = 0; }
