// BlockWorld V3.0 Beta 4.29 — grande carte (touche K) : relief colorié et ombré, eau, routes, monuments,
// joueur, compagnon, feux de camp et ascendances. Un clic sur un monument trace le cap sur la mini-carte.
import { hillshade, terrainColor } from './TerrainMapRules.js';

const VEGETATION = new Set(['tall_grass', 'shrub', 'flower_red', 'flower_yellow', 'tree_trunk', 'leaves']);

/** Image du relief : un pixel par mètre (224 × 224). */
export function buildTerrainImage(world, definition) {
  const size = definition.size || 224;
  const half = Math.floor(size / 2);
  const heights = new Float32Array(size * size);
  const types = new Array(size * size);
  let low = Infinity, high = -Infinity;
  for (let iz = 0; iz < size; iz += 1) {
    for (let ix = 0; ix < size; ix += 1) {
      const x = ix - half, z = iz - half;
      let top = world.getTopBlock(x, z, { solidOnly: false });
      if (top && VEGETATION.has(top.type)) top = world.getTopBlock(x, z, { solidOnly: true });
      const h = top ? top.y : 0;
      heights[iz * size + ix] = h;
      types[iz * size + ix] = top?.type ?? 'water';
      if (top) { low = Math.min(low, h); high = Math.max(high, h); }
    }
  }
  const canvas = document.createElement('canvas');
  canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext('2d');
  const image = ctx.createImageData(size, size);
  const at = (ix, iz) => heights[Math.min(size - 1, Math.max(0, iz)) * size + Math.min(size - 1, Math.max(0, ix))];
  const range = Math.max(1, high - low);
  for (let iz = 0; iz < size; iz += 1) {
    for (let ix = 0; ix < size; ix += 1) {
      const i = iz * size + ix;
      const shade = hillshade(at(ix - 1, iz), at(ix + 1, iz), at(ix, iz - 1), at(ix, iz + 1));
      const [r, g, b] = terrainColor(types[i], (heights[i] - low) / range, shade);
      image.data[i * 4] = r; image.data[i * 4 + 1] = g; image.data[i * 4 + 2] = b; image.data[i * 4 + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  return canvas;
}

export class BigMap {
  constructor(game, root) {
    this.game = game;
    this.root = root;
    this.canvas = root?.querySelector('canvas') ?? null;
    this.context = this.canvas?.getContext('2d') ?? null;
    this.terrain = null;
    this.definition = null;
    this.hotspots = [];
    root?.querySelector('[data-map-close]')?.addEventListener('click', () => this.game.toggleBigMap?.(false));
    this.canvas?.addEventListener('click', (event) => this.handleClick(event));
  }

  setWorld(definition) {
    this.definition = definition;
    try { this.terrain = buildTerrainImage(this.game.world, definition); } catch (error) { console.warn('[carte]', error?.message); this.terrain = null; }
    this.game.navigationMap?.setTerrain?.(this.terrain);
  }

  isOpen() { return Boolean(this.root && !this.root.classList.contains('hidden')); }

  toggle(force = null) {
    if (!this.root) return false;
    const open = force ?? !this.isOpen();
    this.root.classList.toggle('hidden', !open);
    document.body.classList.toggle('bigmap-open', open);
    if (open) this.render();
    return open;
  }

  toCanvas(x, z, size) {
    const half = (this.definition?.size || 224) / 2;
    return { x: ((x + half) / (half * 2)) * size, y: ((z + half) / (half * 2)) * size };
  }

  render() {
    if (!this.context || !this.definition) return;
    const css = Math.round(Math.min(window.innerWidth * 0.92, window.innerHeight * 0.8, 860));
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = css * ratio; this.canvas.height = css * ratio;
    this.canvas.style.width = `${css}px`; this.canvas.style.height = `${css}px`;
    const ctx = this.context;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.imageSmoothingEnabled = false;
    if (this.terrain) ctx.drawImage(this.terrain, 0, 0, css, css); else { ctx.fillStyle = '#26402c'; ctx.fillRect(0, 0, css, css); }
    const g = this.game;
    this.hotspots = [];
    // Ascendances thermiques.
    for (const t of g.paragliding?.thermals ?? []) { const p = this.toCanvas(t.x, t.z, css); this.drawBadge(ctx, p, '🌀', 'rgba(255,255,255,.75)', 11); }
    // Feux de camp.
    for (const fire of g.campfires?.fires ?? []) { const p = this.toCanvas(fire.position.x, fire.position.z, css); this.drawBadge(ctx, p, '🔥', 'rgba(255,170,90,.9)', 10); }
    // Point de départ.
    const spawn = this.toCanvas(this.definition.spawn?.x ?? 0, this.definition.spawn?.z ?? 0, css);
    this.drawBadge(ctx, spawn, '⛺', 'rgba(245,221,107,.95)', 11);
    // Beta 4.32 : entrée de la grotte (avec le nombre de trésors déjà trouvés une fois qu'on y est entré).
    const cave = g.caves?.plan;
    if (cave) {
      const p = this.toCanvas(cave.entrance.x, cave.entrance.z, css);
      this.drawBadge(ctx, p, '🕳️', '#8fe3ff', 14);
      const found = g.caves.progress?.chests?.length ?? 0;
      const label = g.caves.progress?.entered ? `Grotte · ${found}/${cave.chests.length} trésors` : 'Grotte';
      ctx.font = '600 12px system-ui, sans-serif'; ctx.textAlign = 'center'; ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.fillStyle = '#c9f1ff';
      ctx.strokeText(label, p.x, p.y + 28); ctx.fillText(label, p.x, p.y + 28);
    }
    // Monuments.
    for (const point of this.definition.pointsOfInterest ?? []) {
      const p = this.toCanvas(point.x, point.z, css);
      const discovered = g.passport?.isDiscovered(this.definition.id, point.id);
      const tracked = g.navigationMap?.trackedPointId === point.id;
      this.drawBadge(ctx, p, discovered ? point.icon : '?', tracked ? '#ffe45e' : '#ffffff', 15);
      ctx.font = '600 12px system-ui, sans-serif'; ctx.textAlign = 'center';
      ctx.lineWidth = 3; ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.fillStyle = '#ffffff';
      const label = discovered ? point.name : 'Monument à découvrir';
      ctx.strokeText(label, p.x, p.y + 30); ctx.fillText(label, p.x, p.y + 30);
      this.hotspots.push({ x: p.x, y: p.y, r: 22, point });
    }
    // Compagnon.
    const dog = g.companions?.companion;
    if (dog) { const p = this.toCanvas(dog.group.position.x, dog.group.position.z, css); this.drawBadge(ctx, p, '🐕', 'rgba(255,190,120,.95)', 11); }
    // Joueur.
    const eye = g.player?.getEyePosition?.();
    if (eye) {
      const p = this.toCanvas(eye.x, eye.z, css);
      const yaw = g.touchMode ? g.player.yaw : g.camera.rotation.y;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(-yaw);
      ctx.fillStyle = '#ffdf4d'; ctx.strokeStyle = '#141414'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, -13); ctx.lineTo(9, 9); ctx.lineTo(0, 5); ctx.lineTo(-9, 9); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.restore();
    }
  }

  drawBadge(ctx, p, glyph, ring, radius) {
    ctx.beginPath(); ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(12,18,26,.72)'; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = ring; ctx.stroke();
    ctx.font = `${Math.round(radius * 1.15)}px system-ui, sans-serif`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffffff'; ctx.fillText(glyph, p.x, p.y + 1);
  }

  handleClick(event) {
    const rect = this.canvas.getBoundingClientRect();
    const x = event.clientX - rect.left, y = event.clientY - rect.top;
    const hit = this.hotspots.find((h) => Math.hypot(h.x - x, h.y - y) <= h.r);
    if (!hit) return;
    this.game.navigationMap?.track(hit.point.id);
    const discovered = this.game.passport?.isDiscovered(this.definition.id, hit.point.id);
    this.game.toggleBigMap?.(false);
    this.game.hud?.setStatus?.(`🧭 Cap sur ${discovered ? hit.point.name : 'le monument à découvrir'} · suis le repère jaune de la mini-carte`);
  }
}
