const STORAGE_KEY = 'blockworld-v1.6-landmark-passport';

function safeParse(raw) {
  try {
    const value = JSON.parse(raw ?? '{}');
    return value && typeof value === 'object' ? value : {};
  } catch {
    return {};
  }
}

export class LandmarkPassport extends EventTarget {
  constructor(worldDefinitions = []) {
    super();
    this.worldDefinitions = worldDefinitions;
    this.world = null;
    this.lastNearestId = null;
    this.data = safeParse(localStorage.getItem(STORAGE_KEY));
  }

  setWorld(worldDefinition) {
    this.world = worldDefinition;
    this.lastNearestId = null;
    this.dispatchEvent(new Event('change'));
  }

  worldEntries(worldId) {
    const value = this.data[worldId];
    if (!value || typeof value !== 'object') {
      this.data[worldId] = {};
      return this.data[worldId];
    }
    return value;
  }

  isDiscovered(worldId, landmarkId) {
    return Boolean(this.worldEntries(worldId)[landmarkId]?.discoveredAt);
  }

  discovery(worldId, landmarkId) {
    return this.worldEntries(worldId)[landmarkId] ?? null;
  }

  progress(worldId) {
    const world = this.worldDefinitions.find((entry) => entry.id === worldId);
    const total = world?.pointsOfInterest?.length ?? 0;
    const discovered = world?.pointsOfInterest?.filter((point) => this.isDiscovered(worldId, point.id)).length ?? 0;
    return { discovered, total };
  }

  totalProgress() {
    return this.worldDefinitions.reduce((summary, world) => {
      const progress = this.progress(world.id);
      summary.discovered += progress.discovered;
      summary.total += progress.total;
      return summary;
    }, { discovered: 0, total: 0 });
  }

  save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
  }

  discover(point) {
    if (!this.world || this.isDiscovered(this.world.id, point.id)) return false;
    this.worldEntries(this.world.id)[point.id] = {
      discoveredAt: new Date().toISOString(),
      x: point.x,
      z: point.z
    };
    this.save();
    this.dispatchEvent(new CustomEvent('discover', { detail: { world: this.world, point } }));
    this.dispatchEvent(new Event('change'));
    return true;
  }

  nearest(position) {
    if (!this.world?.pointsOfInterest?.length || !position) return null;
    let nearest = null;
    for (const point of this.world.pointsOfInterest) {
      const distance = Math.hypot(position.x - point.x, position.z - point.z);
      if (!nearest || distance < nearest.distance) nearest = { point, distance };
    }
    return nearest;
  }

  update(position) {
    const nearest = this.nearest(position);
    if (!nearest || !position) return null;
    for (const point of this.world.pointsOfInterest ?? []) {
      const distance = Math.hypot(position.x - point.x, position.z - point.z);
      if (distance <= (point.discoveryRadius ?? 13)) this.discover(point);
    }
    this.lastNearestId = nearest.point.id;
    return nearest;
  }

  reset() {
    this.data = {};
    localStorage.removeItem(STORAGE_KEY);
    this.dispatchEvent(new Event('change'));
  }
}
