const TWO_PI = Math.PI * 2;

function cardinal(degrees) {
  const names = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
  return names[Math.round(degrees / 45) % 8];
}

function roundedRect(context, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  context.beginPath();
  context.roundRect?.(x, y, width, height, r);
  if (!context.roundRect) context.rect(x, y, width, height);
}

export class NavigationMap {
  constructor({ canvas, headingElement, nearestElement, progressElement, titleElement, panel, toggleButton }) {
    this.cave = null; // Beta 4.32 : entrée de la grotte
    this.canvas = canvas;
    this.context = canvas?.getContext('2d') ?? null;
    this.headingElement = headingElement;
    this.nearestElement = nearestElement;
    this.progressElement = progressElement;
    this.titleElement = titleElement;
    this.panel = panel;
    this.toggleButton = toggleButton;
    this.world = null;
    this.passport = null;
    this.trackedPointId = null;
    this.collapsed = localStorage.getItem('blockworld-v1.6-minimap-collapsed') === '1';
    this.applyCollapsedState();
    this.toggleButton?.addEventListener('click', () => this.toggle());
  }

  /** Beta 4.32 : entrée de la grotte du continent courant ({ x, z }) ou null. */
  setCave(entrance) { this.cave = entrance ? { x: entrance.x, z: entrance.z } : null; }

  setWorld(world, passport) {
    this.world = world;
    this.passport = passport;
    this.trackedPointId = null;
    if (this.titleElement) this.titleElement.textContent = `${world.icon} ${world.label}`;
    this.resize();
  }

  toggle(force) {
    this.collapsed = typeof force === 'boolean' ? force : !this.collapsed;
    localStorage.setItem('blockworld-v1.6-minimap-collapsed', this.collapsed ? '1' : '0');
    this.applyCollapsedState();
    if (!this.collapsed) this.resize();
  }

  applyCollapsedState() {
    this.panel?.classList.toggle('collapsed', this.collapsed);
    if (this.toggleButton) {
      this.toggleButton.textContent = this.collapsed ? '🗺️' : '−';
      this.toggleButton.title = this.collapsed ? 'Afficher la mini-carte (K)' : 'Replier la mini-carte (K)';
      this.toggleButton.setAttribute('aria-expanded', String(!this.collapsed));
    }
  }

  // Beta 4.29 : relief colorié en fond de mini-carte (image produite par la grande carte).
  setTerrain(canvas) {
    this.terrain = canvas || null;
  }

  track(pointId) {
    this.trackedPointId = pointId || null;
  }

  resize() {
    if (!this.canvas || !this.context) return;
    const cssSize = Math.max(140, Math.round(this.canvas.getBoundingClientRect().width || 190));
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.round(cssSize * ratio);
    this.canvas.height = Math.round(cssSize * ratio);
    this.context.setTransform(ratio, 0, 0, ratio, 0, 0);
    this.cssSize = cssSize;
  }

  worldToCanvas(x, z, size, padding) {
    const half = size / 2;
    const usable = this.cssSize - padding * 2;
    return {
      x: padding + ((x + half) / size) * usable,
      y: padding + ((z + half) / size) * usable
    };
  }

  render(position, yaw = 0, nearest = null) {
    if (!this.world || !this.context || this.collapsed) return;
    if (!this.cssSize) this.resize();
    const context = this.context;
    const size = this.cssSize;
    const padding = 11;
    context.clearRect(0, 0, size, size);

    const gradient = context.createLinearGradient(0, 0, size, size);
    gradient.addColorStop(0, `${this.world.accent}55`);
    gradient.addColorStop(1, '#071018e8');
    context.fillStyle = gradient;
    roundedRect(context, 0, 0, size, size, 16);
    context.fill();

    if (this.terrain) {
      const usable = size - padding * 2;
      context.save();
      context.globalAlpha = 0.9;
      context.imageSmoothingEnabled = false;
      context.drawImage(this.terrain, padding, padding, usable, usable);
      context.restore();
    }
    context.strokeStyle = this.terrain ? 'rgba(255,255,255,.07)' : 'rgba(255,255,255,.12)';
    context.lineWidth = 1;
    for (let step = 1; step < 4; step += 1) {
      const value = padding + ((size - padding * 2) * step) / 4;
      context.beginPath(); context.moveTo(value, padding); context.lineTo(value, size - padding); context.stroke();
      context.beginPath(); context.moveTo(padding, value); context.lineTo(size - padding, value); context.stroke();
    }

    context.strokeStyle = 'rgba(255,255,255,.28)';
    context.strokeRect(padding, padding, size - padding * 2, size - padding * 2);

    const spawn = this.worldToCanvas(this.world.spawn.x, this.world.spawn.z, this.world.size, padding);
    context.fillStyle = '#f5dd6b';
    context.beginPath(); context.arc(spawn.x, spawn.y, 3.5, 0, TWO_PI); context.fill();

    if (this.cave) { // Beta 4.32 : entrée de la grotte du continent
      const mouth = this.worldToCanvas(this.cave.x, this.cave.z, this.world.size, padding);
      context.save(); context.translate(mouth.x, mouth.y);
      context.fillStyle = '#10151c'; context.strokeStyle = '#8fe3ff'; context.lineWidth = 1.5;
      context.beginPath(); context.arc(0, 0, 5.5, 0, TWO_PI); context.fill(); context.stroke();
      context.fillStyle = '#8fe3ff'; context.font = '8px system-ui'; context.textAlign = 'center'; context.textBaseline = 'middle'; context.fillText('G', 0, .5);
      context.restore();
    }

    for (const point of this.world.pointsOfInterest ?? []) {
      const marker = this.worldToCanvas(point.x, point.z, this.world.size, padding);
      const discovered = this.passport?.isDiscovered(this.world.id, point.id);
      const tracked = point.id === this.trackedPointId;
      context.save();
      context.translate(marker.x, marker.y);
      context.fillStyle = tracked ? '#ffe45e' : discovered ? '#ffffff' : 'rgba(255,255,255,.34)';
      context.strokeStyle = tracked ? '#ff9f1c' : this.world.accent;
      context.lineWidth = tracked ? 3 : 1.5;
      context.beginPath(); context.arc(0, 0, tracked ? 8 : 6, 0, TWO_PI); context.fill(); context.stroke();
      context.fillStyle = '#111820';
      context.font = `${tracked ? 10 : 9}px system-ui`;
      context.textAlign = 'center';
      context.textBaseline = 'middle';
      context.fillText(discovered ? point.icon : '?', 0, .5);
      context.restore();
    }

    const player = this.worldToCanvas(position.x, position.z, this.world.size, padding);
    context.save();
    context.translate(player.x, player.y);
    context.rotate(-yaw);
    context.fillStyle = '#ffdf4d';
    context.strokeStyle = '#141414';
    context.lineWidth = 2;
    context.beginPath();
    context.moveTo(0, -10);
    context.lineTo(7, 7);
    context.lineTo(0, 4);
    context.lineTo(-7, 7);
    context.closePath();
    context.fill(); context.stroke();
    context.restore();

    const degrees = (-yaw * 180 / Math.PI + 360) % 360;
    if (this.headingElement) this.headingElement.textContent = `${cardinal(degrees)} · ${Math.round(degrees).toString().padStart(3, '0')}°`;
    if (this.nearestElement) {
      this.nearestElement.textContent = nearest
        ? `${nearest.point.icon} ${nearest.point.name} · ${Math.round(nearest.distance)} m`
        : 'Aucun monument à proximité';
    }
    if (this.progressElement) {
      const progress = this.passport?.progress(this.world.id) ?? { discovered: 0, total: 0 };
      this.progressElement.textContent = `${progress.discovered}/${progress.total} découverts`;
    }
  }
}
