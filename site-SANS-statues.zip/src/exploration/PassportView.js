import { readAlbum } from '../ui/PhotoAlbum.js';

function formatDate(isoDate) {
  if (!isoDate) return '';
  try {
    return new Intl.DateTimeFormat('fr-FR', { dateStyle: 'medium' }).format(new Date(isoDate));
  } catch {
    return '';
  }
}

// Beta 4.29 : début de la description, en minuscule, comme indice avant la découverte.
function hintOf(text = '') {
  const first = String(text).split(',')[0].replace(/[.…\s]+$/, '');
  return first ? first[0].toLocaleLowerCase('fr') + first.slice(1) : 'un monument célèbre';
}

export class PassportView extends EventTarget {
  constructor({ overlay, closeButton, resetButton, content, summary, openButtons = [] }, passport, worldDefinitions) {
    super();
    this.overlay = overlay;
    this.closeButton = closeButton;
    this.resetButton = resetButton;
    this.content = content;
    this.summary = summary;
    this.openButtons = openButtons.filter(Boolean);
    this.passport = passport;
    this.worldDefinitions = worldDefinitions;
    this.visible = false;

    for (const button of this.openButtons) button.addEventListener('click', () => this.toggle());
    this.closeButton?.addEventListener('click', () => this.close());
    this.overlay?.addEventListener('click', (event) => {
      if (event.target === this.overlay) this.close();
    });
    this.resetButton?.addEventListener('click', () => {
      if (!window.confirm('Effacer tous les tampons du passeport ?')) return;
      this.passport.reset();
      this.render();
    });
    this.passport.addEventListener('change', () => this.render());
    this.render();
  }

  toggle(force) {
    const next = typeof force === 'boolean' ? force : !this.visible;
    if (next) this.open(); else this.close();
  }

  open() {
    this.visible = true;
    this.overlay?.classList.remove('hidden');
    this.overlay?.setAttribute('aria-hidden', 'false');
    document.body.classList.add('passport-open');
    this.render();
    this.dispatchEvent(new Event('opened'));
  }

  close() {
    this.visible = false;
    this.overlay?.classList.add('hidden');
    this.overlay?.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('passport-open');
    this.dispatchEvent(new Event('closed'));
  }

  render() {
    if (!this.content) return;
    const total = this.passport.totalProgress();
    if (this.summary) this.summary.textContent = `${total.discovered} monument${total.discovered > 1 ? 's' : ''} découvert${total.discovered > 1 ? 's' : ''} sur ${total.total}`;
    this.content.replaceChildren();

    for (const world of this.worldDefinitions) {
      const section = document.createElement('section');
      section.className = 'passport-continent';
      section.style.setProperty('--passport-accent', world.accent);
      const heading = document.createElement('header');
      const title = document.createElement('h3');
      title.textContent = `${world.icon} ${world.label}`;
      const progress = this.passport.progress(world.id);
      const badge = document.createElement('span');
      badge.textContent = `${progress.discovered}/${progress.total}`;
      heading.append(title, badge);
      section.append(heading);

      const grid = document.createElement('div');
      grid.className = 'passport-grid';
      for (const point of world.pointsOfInterest ?? []) {
        const discovery = this.passport.discovery(world.id, point.id);
        const discovered = Boolean(discovery?.discoveredAt);
        const card = document.createElement('article');
        card.className = `passport-card${discovered ? ' discovered' : ' locked'}`;

        // Beta 4.29 : passeport vivant — silhouette avant la découverte, tampon encré (animé s'il est récent) après.
        const stamp = document.createElement('div');
        stamp.className = `passport-stamp${discovered ? ' inked' : ' silhouette'}${discovered && Date.now() - Date.parse(discovery.discoveredAt) < 180000 ? ' fresh' : ''}`;
        const glyph = document.createElement('span');
        glyph.className = 'passport-glyph';
        glyph.textContent = point.icon;
        stamp.append(glyph);
        if (discovered) {
          const ring = document.createElement('span');
          ring.className = 'passport-ring';
          ring.textContent = `${(point.region ?? world.label).split('·')[0].trim().toUpperCase()} · ${new Date(discovery.discoveredAt).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' })}`;
          stamp.append(ring);
        }
        const body = document.createElement('div');
        const name = document.createElement('strong');
        name.textContent = discovered ? point.name : 'Monument à découvrir';
        const description = document.createElement('p');
        description.textContent = discovered ? point.passportText : `Indice : ${hintOf(point.passportText)}… Repère « ? » sur la carte (K).`;
        const footer = document.createElement('small');
        footer.textContent = discovered ? `Tampon obtenu le ${formatDate(discovery.discoveredAt)}` : `Zone : ${point.region ?? world.label}`;
        body.append(name, description, footer);
        card.append(stamp, body);
        // Beta 4.29 : photo du carnet prise près de ce monument, s'il y en a une.
        const photo = discovered ? readAlbum().find((entry) => (entry.caption ?? '').includes(point.name)) : null;
        if (photo) {
          const image = document.createElement('img');
          image.className = 'passport-photo';
          image.src = photo.src;
          image.alt = `Photo près de ${point.name}`;
          card.append(image);
        }

        if (discovered) {
          const track = document.createElement('button');
          track.type = 'button';
          track.textContent = '🧭 Suivre';
          track.addEventListener('click', () => {
            this.dispatchEvent(new CustomEvent('track', { detail: { worldId: world.id, point } }));
            this.close();
          });
          card.append(track);
        }
        grid.append(card);
      }
      section.append(grid);
      this.content.append(section);
    }
  }
}
