// BlockWorld V3.0 Beta 4.29 — carte en relief : couleurs et ombrage (fonctions pures, testables sous Node).

const BASE = {
  water: [62, 142, 208], sand: [215, 194, 122], snow: [238, 246, 255], stone: [139, 146, 154], road: [150, 120, 92],
  grass: [98, 168, 74], dirt: [138, 90, 54], wood: [139, 90, 43], planks: [181, 122, 63], bricks: [168, 79, 67], concrete: [185, 190, 195]
};

/** Couleur RVB d'une case : type du bloc de surface, altitude relative (0 = plus bas, 1 = plus haut) et ombrage (0..1). */
export function terrainColor(type, relative, shade) {
  const base = BASE[type] ?? (type === 'water' ? BASE.water : BASE.stone);
  let [r, g, b] = base;
  if (type === 'grass') { // les prairies d'altitude virent à l'olive, les fonds de vallée restent verts
    const k = Math.min(1, Math.max(0, relative));
    r += (128 - r) * k * 0.45; g += (150 - g) * k * 0.45; b += (90 - b) * k * 0.45;
  }
  if (type === 'water') return [r, g, b].map((v) => Math.round(v * (0.85 + 0.15 * shade)));
  const light = 0.55 + 0.75 * Math.min(1, Math.max(0, shade));
  return [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v * light))));
}

/** Ombrage par la pente, lumière venant du nord-ouest (comme les cartes topographiques). */
export function hillshade(hWest, hEast, hNorth, hSouth) {
  return Math.min(1, Math.max(0, 0.5 + ((hWest - hEast) + (hNorth - hSouth)) * 0.09));
}
