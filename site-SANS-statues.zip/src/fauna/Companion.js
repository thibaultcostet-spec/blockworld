// BlockWorld V3.0 Beta 4.28 — compagnon animal : chiens errants à apprivoiser, puis un fidèle compagnon qui suit,
// grogne quand un monstre approche, défend le joueur et dort près de lui la nuit ou au coin du feu.
import * as THREE from 'three';
import {
  COMPANION_RULES as R, COMPANION_STORAGE_KEY, cardinal, feedTrust, pickName, shouldAlert, shouldSleep, trustNeeded
} from './CompanionRules.js';

function makeLabel(text, color = '#ffffff') {
  const canvas = document.createElement('canvas');
  canvas.width = 128; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.font = 'bold 40px sans-serif';
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(0,0,0,.65)';
  ctx.strokeText(text, 64, 34);
  ctx.fillStyle = color;
  ctx.fillText(text, 64, 34);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthWrite: false }));
  sprite.scale.set(0.9, 0.45, 1);
  sprite.visible = false;
  return sprite;
}

function hash(text) { let h = 2166136261; for (const c of text) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function rng(seed) { let s = seed >>> 0; return () => ((s = Math.imul(1664525, s) + 1013904223 >>> 0) / 4294967296); }

export class CompanionSystem {
  constructor(game) {
    this.game = game;
    this.group = new THREE.Group();
    this.group.name = 'Companions';
    game.scene.add(this.group);
    this.dogs = [];
    this.idleSeconds = 0;
    this.lastEye = null;
    this.chip = document.getElementById('companion-chip');
  }

  get companion() { return this.dogs.find((dog) => dog.tamed) ?? null; }

  saved() {
    try { return JSON.parse(localStorage.getItem(COMPANION_STORAGE_KEY) ?? 'null'); } catch (_error) { return null; }
  }

  save(dog) {
    try { localStorage.setItem(COMPANION_STORAGE_KEY, JSON.stringify({ name: dog.name, tamedAt: Date.now() })); } catch (_error) {}
  }

  clear() {
    for (const dog of this.dogs) this.group.remove(dog.group);
    this.dogs = [];
  }

  createDog(random, x, z) {
    const fauna = this.game.fauna;
    const group = fauna.createQuadruped('dog', random);
    group.name = 'Companion_dog';
    group.scale.setScalar(0.6);
    const collar = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.035, 6, 14), new THREE.MeshStandardMaterial({ color: 0xd8322a, roughness: 0.6 }));
    collar.rotation.x = Math.PI / 2 - 0.55; collar.position.set(0, 1.05, -0.42); collar.visible = false;
    group.add(collar);
    const alert = makeLabel('!', '#ffcf3a'); alert.position.set(0, 2.4, 0); group.add(alert);
    const sleep = makeLabel('Zzz', '#cfe6ff'); sleep.position.set(0, 1.9, 0); group.add(sleep);
    const heart = makeLabel('♥', '#ff5d7a'); heart.position.set(0, 2.2, 0); group.add(heart);
    group.position.set(x, 0, z);
    group.updateMatrixWorld(true);
    fauna.grounding.calibrate(group);
    fauna.grounding.settle(group, x, z, 0);
    this.group.add(group);
    const dog = {
      group, collar, alert, sleep, heart, tamed: false, trust: 0, name: pickName(random() * 1000), mode: 'follow', state: 'wander',
      origin: new THREE.Vector3(x, 0, z), phase: random() * Math.PI * 2, netUntil: 0, alertTimer: 0, heartTimer: 0, lastAlertAt: -99,
      lastAlertTarget: null, attackTimer: 0, target: null
    };
    group.userData.companionDog = dog;
    this.dogs.push(dog);
    return dog;
  }

  setWorld(definition) {
    this.clear();
    if (!this.game.fauna?.grounding) return;
    const random = rng(hash(`dogs:${definition.id}`));
    const spawn = definition.spawn ?? { x: 0, z: 22 };
    let made = 0;
    for (let attempt = 0; attempt < 60 && made < 2; attempt += 1) {
      const angle = random() * Math.PI * 2, radius = 16 + random() * 30;
      const x = Math.round(spawn.x + Math.cos(angle) * radius), z = Math.round(spawn.z + Math.sin(angle) * radius);
      const ground = this.game.fauna.grounding.sample(x, z);
      if (!ground || !this.game.fauna.grounding.isDryGround(ground)) continue;
      this.createDog(random, x, z); made += 1;
    }
    const saved = this.saved();
    if (saved?.name) {
      const eye = this.game.player?.getEyePosition?.() ?? new THREE.Vector3(spawn.x, 0, spawn.z);
      const dog = this.createDog(random, Math.round(eye.x + 1.5), Math.round(eye.z + 1.5));
      this.tame(dog, { silent: true, name: saved.name });
    }
    this.updateChip();
  }

  dogFromHit(hit) {
    let node = hit?.object;
    while (node && !node.userData?.companionDog) node = node.parent;
    return node?.userData?.companionDog ?? null;
  }

  getRaycastTargets() { return this.dogs.map((dog) => dog.group); }

  /** Clic droit / ▣ sur un chien : le nourrir (errant) ou lui dire « assis » / « au pied » (compagnon). */
  interact(dog) {
    const g = this.game;
    if (dog.tamed) { this.toggleMode(); return; }
    const hunger = g.hunger;
    if (!hunger || (hunger.food <= 0 && hunger.cooked <= 0)) { g.hud.setStatus('Ce chien a faim : apporte-lui de la viande ou un poisson (cuit, c’est encore mieux)'); return; }
    const cooked = hunger.cooked > 0;
    if (cooked) hunger.cooked -= 1; else hunger.food -= 1;
    g.hud.updateHunger?.(hunger, hunger.isActive(g.selectedModeId));
    dog.trust += feedTrust(cooked);
    dog.heartTimer = 1.6;
    g.sfx?.playHappyDog?.();
    const netted = dog.netUntil > performance.now();
    const needed = trustNeeded(netted);
    if (dog.trust >= needed) this.tame(dog);
    else g.hud.setStatus(`Le chien remue la queue · confiance ${dog.trust} / ${needed}${cooked ? '' : ' (le cuit compte double)'}`);
  }

  tame(dog, { silent = false, name = null } = {}) {
    for (const other of this.dogs) if (other !== dog && other.tamed) { other.tamed = false; other.collar.visible = false; }
    dog.tamed = true;
    dog.name = name ?? dog.name;
    dog.collar.visible = true;
    dog.mode = 'follow';
    dog.state = 'follow';
    this.save(dog);
    if (!silent) {
      this.game.sfx?.playBark?.();
      this.game.hud.setStatus(`🐕 ${dog.name} est ton compagnon ! Il te suit · X : assis / au pied`);
    }
    this.updateChip();
  }

  toggleMode() {
    const dog = this.companion;
    if (!dog) { this.game.hud.setStatus('Pas encore de compagnon : nourris un chien errant (clic droit ou ▣)'); return; }
    dog.mode = dog.mode === 'follow' ? 'stay' : 'follow';
    this.game.hud.setStatus(dog.mode === 'stay' ? `${dog.name}, pas bouger ! Il t’attend ici` : `${dog.name}, au pied ! Il te suit`);
    this.updateChip();
  }

  net(dog, seconds = 8) {
    dog.netUntil = performance.now() + seconds * 1000;
  }

  updateChip() {
    if (!this.chip) return;
    const dog = this.companion;
    this.chip.classList.toggle('hidden', !dog);
    if (!dog) return;
    const state = dog.state === 'sleep' ? 'dort' : dog.state === 'attack' ? 'défend' : dog.mode === 'stay' ? 'assis' : 'te suit';
    this.chip.textContent = `🐕 ${dog.name} · ${state}`;
  }

  move(dog, x, z, delta, speed) {
    const fauna = this.game.fauna;
    const before = dog.group.position.clone();
    const ok = fauna.motion.move(dog.group, { x, z }, delta, { speed, maxStep: 0.95, bob: 0, alignSlope: true });
    fauna.motion.snap(dog.group);
    return ok ? Math.hypot(dog.group.position.x - before.x, dog.group.position.z - before.z) : 0;
  }

  animate(dog, travelled, delta, t) {
    const data = dog.group.userData;
    this.game.fauna.motion.snap(dog.group); // hauteur recalée chaque image (le décalage « couché » s'ajoute ensuite)
    data.gaitPhase = ((data.gaitPhase ?? dog.phase) + travelled * 7) % (Math.PI * 2);
    data.gaitBlend = THREE.MathUtils.damp(data.gaitBlend ?? 0, THREE.MathUtils.clamp((delta > 0 ? travelled / delta : 0) / 1.4, 0, 1), 8, delta);
    const lying = dog.state === 'sleep';
    const sitting = dog.mode === 'stay' && dog.tamed && !lying && data.gaitBlend < 0.1;
    const stride = Math.sin(data.gaitPhase) * 0.55 * data.gaitBlend;
    for (const limb of data.limbs || []) {
      const folded = lying ? -1.25 * limb.userData.front : sitting && limb.userData.front > 0 ? 1.1 : 0;
      limb.rotation.x = limb.userData.leg * stride + folded;
    }
    if (data.tail) data.tail.rotation.z = Math.sin(t * (dog.heartTimer > 0 || dog.tamed ? 12 : 4) + dog.phase) * (dog.tamed ? 0.55 : 0.25);
    if (data.head) data.head.rotation.x = lying ? 0.45 : 0;
    dog.group.rotation.x = sitting ? -0.32 : 0;
    dog.lieOffset = THREE.MathUtils.damp(dog.lieOffset ?? 0, lying ? -0.32 : 0, 4, delta);
    dog.group.position.y += dog.lieOffset;
    dog.sleep.visible = lying;
    dog.sleep.position.y = 1.9 + Math.sin(t * 1.5) * 0.12;
    dog.heart.visible = dog.heartTimer > 0;
    dog.alert.visible = dog.alertTimer > 0;
  }

  update(delta, eye) {
    if (!this.dogs.length || !eye) return;
    const g = this.game;
    const t = performance.now() * 0.001;
    const now = performance.now();
    if (this.lastEye && Math.hypot(eye.x - this.lastEye.x, eye.z - this.lastEye.z) > 0.05 * Math.max(1, delta * 60)) this.idleSeconds = 0; else this.idleSeconds += delta;
    this.lastEye = eye.clone();
    let chipDirty = false;
    for (const dog of this.dogs) {
      dog.alertTimer = Math.max(0, dog.alertTimer - delta);
      dog.heartTimer = Math.max(0, dog.heartTimer - delta);
      const pos = dog.group.position;
      if (dog.netUntil > now) { this.animate(dog, 0, delta, t); dog.group.rotation.z = Math.sin(t * 14) * 0.08; continue; }
      dog.group.rotation.z = 0;
      let travelled = 0;
      const previousState = dog.state;
      if (!dog.tamed) {
        // Errant : flâne autour de son coin, s'approche un peu du joueur qui l'a nourri.
        const a = t * 0.18 + dog.phase;
        const tx = dog.trust > 0 ? eye.x + Math.cos(a) * 3 : dog.origin.x + Math.cos(a) * 5;
        const tz = dog.trust > 0 ? eye.z + Math.sin(a) * 3 : dog.origin.z + Math.sin(a * 0.8) * 5;
        travelled = this.move(dog, THREE.MathUtils.damp(pos.x, tx, 1.2, delta), THREE.MathUtils.damp(pos.z, tz, 1.2, delta), delta, 1.1);
        this.animate(dog, travelled, delta, t);
        continue;
      }
      const toPlayer = Math.hypot(eye.x - pos.x, eye.z - pos.z);
      // Alerte et défense.
      const nearest = this.nearestMonster(pos, eye);
      if (nearest && shouldAlert({ distance: nearest.distance, sinceLast: t - dog.lastAlertAt, sameTarget: nearest.monster === dog.lastAlertTarget })) {
        dog.lastAlertAt = t; dog.lastAlertTarget = nearest.monster; dog.alertTimer = 2;
        g.sfx?.playBark?.();
        g.hud.setStatus(`🐕 ${dog.name} grogne : ${nearest.monster.label} à ${Math.round(nearest.distance)} m (${cardinal(nearest.monster.group.position.x - eye.x, nearest.monster.group.position.z - eye.z)})`);
      }
      const canDefend = g.modeController?.allowsCombat && dog.mode === 'follow' && nearest && nearest.distanceToPlayer < R.defendRange;
      if (canDefend && toPlayer < R.leashRange) {
        dog.state = 'attack';
        const mp = nearest.monster.group.position;
        const reach = Math.hypot(mp.x - pos.x, mp.z - pos.z);
        if (reach > R.attackReach) travelled = this.move(dog, THREE.MathUtils.damp(pos.x, mp.x, 3, delta), THREE.MathUtils.damp(pos.z, mp.z, 3, delta), delta, 5.5);
        dog.group.rotation.y = Math.atan2(mp.x - pos.x, mp.z - pos.z) + Math.PI;
        dog.attackTimer -= delta;
        if (reach <= R.attackReach + 0.2 && dog.attackTimer <= 0) {
          dog.attackTimer = R.attackInterval;
          const result = g.monsters.hitMonster(nearest.monster, R.attackDamage);
          g.sfx?.playBark?.();
          if (result?.killed) g.hud.setStatus(`🐕 ${dog.name} a mis en fuite le ${result.label} !`);
        }
      } else if (shouldSleep({ idleSeconds: this.idleSeconds, daylight: g.atmosphere?.daylight ?? 1, nearFire: (g.campfires?.nearestDistance?.(pos) ?? 99) < R.fireRange }) && toPlayer < 8) {
        dog.state = 'sleep';
      } else if (dog.mode === 'stay') {
        dog.state = 'stay';
        if (toPlayer > R.teleportDistance * 2) dog.mode = 'follow';
      } else {
        dog.state = 'follow';
        if (toPlayer > R.teleportDistance) {
          const back = new THREE.Vector3(eye.x - 1.5, 0, eye.z + 1.5);
          g.fauna.grounding.settle(dog.group, back.x, back.z, 0);
        } else if (toPlayer > R.followDistance) {
          const k = (toPlayer - R.followDistance) / toPlayer;
          const tx = pos.x + (eye.x - pos.x) * k, tz = pos.z + (eye.z - pos.z) * k;
          const speed = toPlayer > R.runDistance ? 5.8 : 2.4;
          travelled = this.move(dog, THREE.MathUtils.damp(pos.x, tx, 2.5, delta), THREE.MathUtils.damp(pos.z, tz, 2.5, delta), delta, speed);
        } else if (travelled === 0) {
          dog.group.rotation.y = THREE.MathUtils.lerp(dog.group.rotation.y, Math.atan2(eye.x - pos.x, eye.z - pos.z) + Math.PI, Math.min(1, delta * 3));
        }
      }
      if (dog.state !== previousState) chipDirty = true;
      this.animate(dog, travelled, delta, t);
    }
    if (chipDirty) this.updateChip();
  }

  nearestMonster(dogPos, eye) {
    let best = null;
    for (const monster of this.game.monsters?.monsters ?? []) {
      if (!monster.alive || monster.config?.model === 'training_dummy') continue;
      const mp = monster.group.position;
      const distance = Math.min(Math.hypot(mp.x - dogPos.x, mp.z - dogPos.z), Math.hypot(mp.x - eye.x, mp.z - eye.z));
      if (!best || distance < best.distance) best = { monster, distance, distanceToPlayer: Math.hypot(mp.x - eye.x, mp.z - eye.z) };
    }
    return best;
  }
}
