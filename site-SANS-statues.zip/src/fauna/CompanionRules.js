// BlockWorld V3.0 Beta 4.28 — compagnon : règles pures (testables sous Node).
// Un chien errant s'apprivoise en le nourrissant : 3 points de confiance (cru +1, cuit +2) ; pris au filet, 1 suffit.
// Apprivoisé, il suit, grogne quand un monstre approche, défend le joueur et dort près de lui la nuit ou au coin du feu.

export const COMPANION_RULES = {
  trustToTame: 3, trustRaw: 1, trustCooked: 2, nettedTrust: 1,
  followDistance: 2.4, runDistance: 6, teleportDistance: 35,
  alertRange: 14, defendRange: 8, leashRange: 16, attackDamage: 9, attackInterval: 0.9, attackReach: 1.6,
  sleepAfterIdle: 10, fireRange: 6, alertCooldown: 7
};
export const DOG_NAMES = ['Rex', 'Filou', 'Moka', 'Pixel', 'Câline', 'Biscotte', 'Gaston', 'Nala'];
export const COMPANION_STORAGE_KEY = 'blockworld-v4.28-companion';

/** Confiance gagnée en donnant une portion (cuite ou crue). */
export function feedTrust(cooked) {
  return cooked ? COMPANION_RULES.trustCooked : COMPANION_RULES.trustRaw;
}

/** Confiance requise pour apprivoiser (moins s'il est pris au filet). */
export function trustNeeded(netted) {
  return netted ? COMPANION_RULES.nettedTrust : COMPANION_RULES.trustToTame;
}

/** Nom stable tiré d'une graine entière. */
export function pickName(seed = 0) {
  return DOG_NAMES[Math.abs(Math.floor(seed)) % DOG_NAMES.length];
}

/** Le compagnon s'endort : joueur immobile depuis 10 s, la nuit ou près d'un feu de camp. */
export function shouldSleep({ idleSeconds = 0, daylight = 1, nearFire = false } = {}) {
  return idleSeconds >= COMPANION_RULES.sleepAfterIdle && (daylight < 0.3 || nearFire);
}

/** Alerte : monstre le plus proche dans le rayon, si l'alerte précédente est assez ancienne ou si c'est un autre monstre. */
export function shouldAlert({ distance = Infinity, sinceLast = Infinity, sameTarget = false } = {}) {
  if (distance > COMPANION_RULES.alertRange) return false;
  return !sameTarget || sinceLast >= COMPANION_RULES.alertCooldown;
}

/** Direction cardinale (N, NE, E…) d'un vecteur au sol ; le nord est −z comme sur la mini-carte. */
export function cardinal(dx, dz) {
  const names = ['N', 'NE', 'E', 'SE', 'S', 'SO', 'O', 'NO'];
  const angle = Math.atan2(dx, -dz);
  return names[(Math.round(angle / (Math.PI / 4)) + 8) % 8];
}
