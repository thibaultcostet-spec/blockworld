import * as THREE from 'three';
import { GroundingSystem } from '../world/GroundingSystem.js';
import { EntityMotionEngine } from '../movement/EntityMotionEngine.js';
import { CreatureCombat } from '../combat/CreatureCombat.js';
import { HERD_RULES, birdEscapeTarget, birdsShouldTakeOff, groupSize, herdPosition, isGrazing } from './HerdRules.js';

const PROFILES = {
  europe: ['deer','rabbit','bird'],
  africa: ['gazelle','zebra','bird'],
  asia: ['panda','yak','bird'],
  americas: ['bison','llama','bird'],
  oceania: ['kangaroo','koala','bird']
};
const COLORS = {
  deer:0x9b6a3c,rabbit:0xc7b79f,bird:0x476a92,gazelle:0xc88d43,zebra:0xe8e4d8,
  panda:0x292929,yak:0x563b2d,dog:0x8a5a32,bison:0x5b3a25,llama:0xd3b98f,kangaroo:0xb77c4c,koala:0x8c9398
};
function hash(text){let h=2166136261;for(const c of text){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function rng(seed){let s=seed>>>0;return()=>((s=Math.imul(1664525,s)+1013904223>>>0)/4294967296);}
function shadows(mesh){mesh.castShadow=true;mesh.receiveShadow=true;return mesh;}
function sphere(radius,material,segments=10){return shadows(new THREE.Mesh(new THREE.SphereGeometry(radius,segments,Math.max(6,segments-2)),material));}
function capsule(radius,length,material){return shadows(new THREE.Mesh(new THREE.CapsuleGeometry(radius,length,4,8),material));}
function cylinder(top,bottom,height,material,segments=8){return shadows(new THREE.Mesh(new THREE.CylinderGeometry(top,bottom,height,segments),material));}

export class FaunaManager {
  constructor(scene,world,{touchMode=false}={}){
    this.scene=scene;this.world=world;this.touchMode=touchMode;
    this.group=new THREE.Group();this.group.name='LivingFaunaV3';scene.add(this.group);
    this.animals=[];this.worldId='';this.grounding=new GroundingSystem(world,{maxStep:1.0});this.motion=new EntityMotionEngine(world);
  }
  clear(){for(const child of [...this.group.children])this.group.remove(child);this.animals=[];}
  setWorld(definition){
    this.clear();this.worldId=definition.id;const random=rng(hash(`fauna-v3:${definition.id}`));
    const species=PROFILES[definition.id]||PROFILES.europe;const target=this.touchMode?12:22; // Beta 4.22 : un peu plus d'animaux (chasse)
    // Beta 4.28 : troupeaux (3-4), couples de petits animaux, volées de 4 oiseaux posés au sol.
    this.herds=[];let attempts=0;
    while(this.animals.length<target&&attempts<200){
      attempts+=1;
      const type=species[(this.herds.length)%species.length];const angle=random()*Math.PI*2;const radius=14+random()*72; // Beta 4.22 : répartis sur les cartes 224 × 224
      const cx=Math.round(Math.cos(angle)*radius),cz=Math.round(Math.sin(angle)*radius);const centerGround=this.grounding.sample(cx,cz);
      if(!centerGround||!this.grounding.isDryGround(centerGround))continue;
      const herd={type,center:new THREE.Vector3(cx,centerGround.y,cz),phase:random()*Math.PI*2,speed:.05+random()*.04,radius:HERD_RULES.wanderRadius[0]+random()*(HERD_RULES.wanderRadius[1]-HERD_RULES.wanderRadius[0]),travel:0,members:[],state:'perched',flight:null};
      const size=Math.min(groupSize(type,random()),target-this.animals.length);
      for(let k=0;k<size;k++){
        const offset=new THREE.Vector3((random()-.5)*2*HERD_RULES.memberSpread,0,(random()-.5)*2*HERD_RULES.memberSpread);
        const x=Math.round(cx+offset.x),z=Math.round(cz+offset.z);const ground=this.grounding.sample(x,z);
        if(!ground||!this.grounding.isDryGround(ground))continue;
        const animal=CreatureCombat.tag(this.createAnimal(type,random),'animal',type);animal.userData.groundFootprint=['bison','yak','zebra'].includes(type)?.43:.28;
        animal.userData.origin=new THREE.Vector3(x,0,z);animal.userData.phase=random()*Math.PI*2;animal.userData.speed=.22+random()*.30;animal.userData.radius=2.5+random()*6;
        animal.userData.herd=herd;animal.userData.offset=offset;herd.members.push(animal);
        if(type==='bird'){animal.position.set(x,ground.y+.15,z);animal.userData.origin.y=ground.y;}
        else{
          animal.updateMatrixWorld(true);
          this.grounding.calibrate(animal);
          const shadow=new THREE.Mesh(new THREE.CircleGeometry(.66,20),new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.24,depthWrite:false}));
          shadow.rotation.x=-Math.PI/2;shadow.position.y=(animal.userData.modelBottom??0)+.012;shadow.scale.y=.62;shadow.userData.contactShadow=true;animal.add(shadow);
          this.grounding.settle(animal,x,z,0);
        }
        this.group.add(animal);this.animals.push(animal);
      }
      if(herd.members.length)this.herds.push(herd);
    }
  }

  createAnimal(type,random){
    if(type==='bird')return this.createBird(type,random);
    if(type==='rabbit'||type==='koala')return this.createSmall(type,random);
    if(type==='kangaroo')return this.createKangaroo(random);
    return this.createQuadruped(type,random);
  }

  createBird(type,random){
    const group=new THREE.Group();group.name='Fauna_bird';group.userData.type=type;group.userData.flying=true;
    const bodyMat=new THREE.MeshStandardMaterial({color:0x436b91,roughness:.74});
    const wingMat=new THREE.MeshStandardMaterial({color:0x2f4d6a,roughness:.8,side:THREE.DoubleSide});
    const body=capsule(.14,.30,bodyMat);body.rotation.x=Math.PI/2;body.scale.set(1,1,1.15);group.add(body);
    const head=sphere(.13,bodyMat,10);head.position.set(0,.07,-.27);group.add(head);
    const beak=new THREE.Mesh(new THREE.ConeGeometry(.055,.18,6),new THREE.MeshStandardMaterial({color:0xe6a53d,roughness:.7}));beak.rotation.x=Math.PI/2;beak.position.set(0,.04,-.42);group.add(beak);
    for(const side of [-1,1]){const pivot=new THREE.Group();pivot.position.set(side*.12,.02,0);const wing=new THREE.Mesh(new THREE.PlaneGeometry(.52,.22),wingMat);wing.position.x=side*.25;wing.rotation.y=side*Math.PI/2;pivot.add(wing);pivot.userData.wing=side;group.add(pivot);}
    group.scale.setScalar(.9+random()*.35);return group;
  }

  createSmall(type,random){
    const group=new THREE.Group();group.name=`Fauna_${type}`;group.userData.type=type;group.userData.limbs=[];
    const color=type==='koala'?0x8c9398:0xc7b79f;const mat=new THREE.MeshStandardMaterial({color,roughness:.92});
    const dark=new THREE.MeshStandardMaterial({color:type==='koala'?0x394047:0x8f806d,roughness:.9});
    const body=sphere(.34,mat,12);body.scale.set(.85,.95,1.2);body.position.y=.38;group.add(body);
    const head=sphere(.27,mat,12);head.position.set(0,.68,-.27);group.add(head);
    const muzzle=sphere(.12,dark,10);muzzle.scale.set(1,.75,.65);muzzle.position.set(0,.62,-.49);group.add(muzzle);
    for(const side of [-1,1]){const ear=sphere(type==='koala'?.16:.09,mat,10);ear.scale.set(.72,type==='rabbit'?1.8:1,.52);ear.position.set(side*.19,type==='rabbit'?1.03:.84,-.25);group.add(ear);}
    for(const side of [-1,1]){const leg=capsule(.065,.18,dark);leg.position.set(side*.17,.14,.12);leg.userData.leg=side;group.userData.limbs.push(leg);group.add(leg);}
    for(const side of [-1,1]){const sole=new THREE.Object3D();sole.position.set(side*.17,-.016,.12);sole.userData.footMarker=true;group.add(sole);}
    if(type==='rabbit'){const tail=sphere(.12,new THREE.MeshStandardMaterial({color:0xeee7da,roughness:1}),8);tail.position.set(0,.42,.38);group.add(tail);}
    group.userData.head=head;group.userData.body=body;
    group.scale.setScalar(.9+random()*.25);return group;
  }

  createKangaroo(random){
    const group=new THREE.Group();group.name='Fauna_kangaroo';group.userData.type='kangaroo';group.userData.limbs=[];
    const mat=new THREE.MeshStandardMaterial({color:0xb77c4c,roughness:.9});
    const body=capsule(.24,.55,mat);body.position.y=.86;body.rotation.z=.08;group.add(body);
    const head=sphere(.19,mat,10);head.position.set(0,1.38,-.16);group.add(head);
    const muzzle=capsule(.075,.15,mat);muzzle.rotation.x=Math.PI/2;muzzle.position.set(0,1.33,-.34);group.add(muzzle);
    for(const side of [-1,1]){const ear=capsule(.055,.25,mat);ear.position.set(side*.09,1.66,-.13);ear.rotation.z=side*.12;group.add(ear);}
    for(const side of [-1,1]){const hip=new THREE.Group();hip.position.set(side*.18,.72,.08);const thigh=capsule(.095,.32,mat);thigh.position.y=-.23;thigh.rotation.z=side*.12;hip.add(thigh);const foot=capsule(.07,.30,mat);foot.rotation.x=Math.PI/2;foot.position.set(0,-.48,-.13);hip.add(foot);const sole=new THREE.Object3D();sole.position.set(0,-.56,-.18);sole.userData.footMarker=true;hip.add(sole);hip.userData.leg=side;group.userData.limbs.push(hip);group.add(hip);}
    const tail=capsule(.10,.9,mat);tail.rotation.x=Math.PI/2+.27;tail.position.set(0,.52,.56);group.add(tail);
    group.userData.head=head;group.userData.body=body;group.userData.tail=tail;
    group.scale.setScalar(.92+random()*.18);return group;
  }

  createQuadruped(type,random){
    const group=new THREE.Group();group.name=`Fauna_${type}`;group.userData.type=type;group.userData.limbs=[];
    const color=COLORS[type]||0x8c6b45;const bodyMat=new THREE.MeshStandardMaterial({color,roughness:.88});
    const darkMat=new THREE.MeshStandardMaterial({color:new THREE.Color(color).multiplyScalar(.55),roughness:.92});
    const lightMat=new THREE.MeshStandardMaterial({color:new THREE.Color(color).lerp(new THREE.Color(0xffffff),.38),roughness:.88});
    const heavy=['bison','yak'].includes(type);const tall=['llama','gazelle','deer'].includes(type);
    const body=capsule(heavy?.34:.27,heavy?.80:.68,bodyMat);body.rotation.x=Math.PI/2;body.position.y=heavy?.82:.76;body.scale.set(heavy?1.18:1,tall?.92:1,1.12);group.add(body);
    if(type==='bison'||type==='yak'){const hump=sphere(.35,darkMat,10);hump.scale.set(1.1,.8,1);hump.position.set(0,1.03,.18);group.add(hump);}
    const neck=capsule(tall?.14:.17,tall?.48:.28,bodyMat);neck.position.set(0,tall?1.16:1.02,-.38);neck.rotation.x=tall?-.22:-.55;group.add(neck);
    const head=sphere(heavy?.25:.21,bodyMat,12);head.scale.set(.88,.92,1.14);head.position.set(0,tall?1.47:1.17,-.62);group.add(head);
    const muzzle=sphere(heavy?.16:.13,lightMat,10);muzzle.scale.set(.95,.72,.72);muzzle.position.set(0,tall?1.39:1.10,-.82);group.add(muzzle);
    const eyeMat=new THREE.MeshStandardMaterial({color:0x111417,roughness:.38});
    for(const side of [-1,1]){const eye=sphere(.027,eyeMat,8);eye.position.set(side*.105,tall?1.52:1.22,-.805);group.add(eye);}
    for(const side of [-1,1]){const ear=new THREE.Mesh(new THREE.ConeGeometry(.075,.22,6),bodyMat);ear.rotation.z=side*(Math.PI/2-.25);ear.position.set(side*.19,tall?1.59:1.29,-.60);group.add(ear);}
    if(['deer','gazelle','bison','yak'].includes(type)){
      const hornMat=new THREE.MeshStandardMaterial({color:0xddd0ac,roughness:.72});
      for(const side of [-1,1]){const horn=new THREE.Mesh(new THREE.ConeGeometry(.045,heavy?.38:.48,7),hornMat);horn.position.set(side*.16,tall?1.72:1.42,-.58);horn.rotation.z=side*(heavy?1.0:.55);group.add(horn);}
    }
    const legHeight=heavy?.58:tall?.72:.62;
    for(const side of [-1,1])for(const front of [-1,1]){
      const pivot=new THREE.Group();pivot.position.set(side*(heavy?.30:.24),heavy?.61:.55,front*(heavy?.34:.28));
      const upper=cylinder(.075,.09,legHeight*.56,bodyMat,7);upper.position.y=-legHeight*.28;pivot.add(upper);
      const lower=cylinder(.055,.072,legHeight*.48,darkMat,7);lower.position.y=-legHeight*.78;pivot.add(lower);
      const hoof=new THREE.Mesh(new THREE.BoxGeometry(.15,.08,.20),darkMat);hoof.position.set(0,-legHeight-0.015,-.02);pivot.add(hoof);
      const sole=new THREE.Object3D();sole.position.set(0,-legHeight-.057,-.02);sole.userData.footMarker=true;pivot.add(sole);
      pivot.userData.leg=side*front;pivot.userData.front=front;group.userData.limbs.push(pivot);group.add(pivot);
    }
    const tail=capsule(.045,heavy?.28:.36,darkMat);tail.position.set(0,.82,.62);tail.rotation.x=-.58;group.add(tail);
    group.userData.head=head;group.userData.neck=neck;group.userData.tail=tail;group.userData.body=body;
    if(type==='zebra'){
      const stripeMat=new THREE.MeshStandardMaterial({color:0x202020,roughness:.9});
      for(let index=-2;index<=2;index++){const stripe=new THREE.Mesh(new THREE.TorusGeometry(.30,.035,5,10,Math.PI*1.35),stripeMat);stripe.rotation.x=Math.PI/2;stripe.rotation.z=index*.12;stripe.position.set(0,.78,index*.16);stripe.scale.set(1,.72,1);group.add(stripe);}
    }
    if(type==='panda'){
      const white=new THREE.MeshStandardMaterial({color:0xe7e3da,roughness:.95});body.material=white;head.material=white;
      for(const side of [-1,1]){const patch=sphere(.075,darkMat,8);patch.scale.set(1.1,.75,.4);patch.position.set(side*.08,1.20,-.82);group.add(patch);}
    }
    group.scale.setScalar(.92+random()*.18);return group;
  }

  // Beta 4.28 : les troupeaux avancent ensemble puis broutent (tête baissée) ; les oiseaux se posent, picorent et
  // s'envolent quand on approche ; un animal pris au filet reste immobile et se débat.
  updateHerds(delta,t,playerPosition){
    for(const herd of this.herds??[]){
      if(herd.type==='bird'){
        const flockPos=herd.flight?herd.flight.to:herdPosition(herd);
        const d=playerPosition?Math.hypot(playerPosition.x-flockPos.x,playerPosition.z-flockPos.z):99;
        if(birdsShouldTakeOff(d,herd.state)&&playerPosition){
          const from=herdPosition(herd);const to=birdEscapeTarget(from,playerPosition);
          herd.state='flying';herd.flight={from,to,age:0};herd.members.forEach((m)=>{m.userData.flyFrom=m.position.clone();});
        }
        if(herd.state==='flying'){
          herd.flight.age+=delta;
          if(herd.flight.age>=HERD_RULES.birdFlightSeconds){
            const ground=this.grounding.sample(Math.round(herd.flight.to.x),Math.round(herd.flight.to.z));
            if(ground&&this.grounding.isDryGround(ground)){herd.center.set(herd.flight.to.x,ground.y,herd.flight.to.z);herd.travel=0;herd.phase=-Math.PI/2;herd.radius=.01;}
            herd.state='perched';herd.flight=null;
          }
        }
        continue;
      }
      if(!isGrazing(t,herd.phase))herd.travel+=delta;
    }
  }

  update(delta,playerPosition){
    const t=performance.now()*.001;const now=performance.now();
    this.updateHerds(delta,t,playerPosition);
    for(const animal of this.animals){
      const data=animal.userData;if(data.dead)continue; // Beta 4.22 : abattu, il ne bouge plus
      const herd=data.herd;
      // Beta 4.28 : pris au filet → immobile, se débat.
      if((data.netUntil??0)>now){animal.rotation.z=Math.sin(t*14)*.06;for(const limb of data.limbs||[])limb.rotation.x=Math.sin(t*16+limb.userData.leg)*.25;continue;}
      if(animal.rotation.z!==0&&!data.dead)animal.rotation.z=0;
      if(data.flying){this.updateBird(animal,data,herd,delta,t);animal.visible=!playerPosition||animal.position.distanceToSquared(playerPosition)<15000;continue;}
      const grazing=herd?isGrazing(t,herd.phase):false;
      let targetX,targetZ;
      if(herd){const hp=herdPosition(herd);targetX=hp.x+data.offset.x;targetZ=hp.z+data.offset.z;}
      else{const phase=t*data.speed+data.phase;targetX=data.origin.x+Math.cos(phase)*data.radius;targetZ=data.origin.z+Math.sin(phase)*data.radius;}
      if((data.fleeUntil??0)>now&&data.fleeDirection){targetX=animal.position.x+data.fleeDirection.x*6;targetZ=animal.position.z+data.fleeDirection.z*6;}
      const fleeing=(data.fleeUntil??0)>now;const nextX=THREE.MathUtils.damp(animal.position.x,targetX,fleeing?2.4:1.15,delta);const nextZ=THREE.MathUtils.damp(animal.position.z,targetZ,fleeing?2.4:1.15,delta);
      let moving=true;const px=animal.position.x,pz=animal.position.z;
      if(!this.motion.move(animal,{x:nextX,z:nextZ},delta,{speed:Math.max(.48,data.speed),maxStep:.88,bob:0,alignSlope:true})){data.phase+=Math.PI*.65;if(herd)data.offset.multiplyScalar(-.6);moving=false;}
      data.origin.x=animal.position.x;data.origin.z=animal.position.z;
      this.motion.snap(animal);
      // Beta 4.11 : foulée pilotée par la distance réellement parcourue (plus de pattes qui
      // courent sur place quand l'animal ralentit, est bloqué ou broute).
      const travelled=moving?Math.hypot(animal.position.x-px,animal.position.z-pz):0;
      data.gaitPhase=((data.gaitPhase??data.phase)+travelled*5.2)%(Math.PI*2);
      data.gaitBlend=THREE.MathUtils.damp(data.gaitBlend??0,THREE.MathUtils.clamp((delta>0?travelled/delta:0)/.9,0,1),7,delta);
      const stride=Math.sin(data.gaitPhase)*.48*data.gaitBlend;
      for(const limb of data.limbs||[])limb.rotation.x=limb.userData.leg*stride;
      if(data.body)data.body.scale.y=1+Math.sin(t*1.9+data.phase)*.012;
      const graze=grazing&&!fleeing&&data.gaitBlend<.2;data.grazeBlend=THREE.MathUtils.damp(data.grazeBlend??0,graze?1:0,3,delta);
      if(data.head)data.head.rotation.x=Math.sin(t*1.25+data.phase)*.055-Math.abs(stride)*.025+data.grazeBlend*(.55+Math.sin(t*3+data.phase)*.08);
      if(data.neck)data.neck.rotation.z=Math.sin(t*.72+data.phase)*.025;
      if(data.neck)data.neck.rotation.x=(data.neck.userData.baseRx??(data.neck.userData.baseRx=data.neck.rotation.x))-data.grazeBlend*.55;
      if(data.tail)data.tail.rotation.z=Math.sin(t*3.1+data.phase)*.20;
      animal.visible=!playerPosition||animal.position.distanceToSquared(playerPosition)<15000;
    }
  }

  updateBird(animal,data,herd,delta,t){
    const wings=animal.children.filter((c)=>c.userData.wing);
    if(herd?.state==='flying'&&herd.flight){
      const p=Math.min(1,herd.flight.age/HERD_RULES.birdFlightSeconds);const from=data.flyFrom??animal.position;
      const x=THREE.MathUtils.lerp(from.x,herd.flight.to.x+data.offset.x*.6,p),z=THREE.MathUtils.lerp(from.z,herd.flight.to.z+data.offset.z*.6,p);
      const ground=this.grounding.groundY(x,z,0)??from.y;
      animal.position.set(x,ground+.15+Math.sin(p*Math.PI)*7.5+Math.sin(t*6+data.phase)*.15,z);
      animal.rotation.y=Math.atan2(herd.flight.to.x-from.x,herd.flight.to.z-from.z)+Math.PI;
      for(const w of wings)w.rotation.z=w.userData.wing*Math.sin(t*18+data.phase)*.85;
      return;
    }
    // Posé : petits pas et coups de bec, ailes repliées.
    const hp=herd?herdPosition(herd):data.origin;const hop=Math.max(0,Math.sin(t*2.2+data.phase));
    const x=hp.x+data.offset.x*.5+Math.cos(t*.4+data.phase)*.4,z=hp.z+data.offset.z*.5+Math.sin(t*.37+data.phase)*.4;
    const ground=this.grounding.groundY(x,z,0);
    animal.position.set(x,(ground??animal.position.y-.15)+.15+hop*.06,z);
    animal.rotation.x=Math.max(0,Math.sin(t*3.3+data.phase))*.35;
    for(const w of wings)w.rotation.z=w.userData.wing*.1;
  }
}
