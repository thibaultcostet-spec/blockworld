// BlockWorld V3.0 Beta 4.28 — comportements visibles de la faune : règles pures (testables sous Node).
// Troupeaux qui broutent puis se déplacent ensemble, volées d'oiseaux posées qui s'envolent à l'approche.

export const HERD_RULES = { grazeShare: 0.4, wanderRadius: [6, 14], memberSpread: 3.2, birdAlarm: 9, birdFlight: 26, birdFlightSeconds: 5 };

/** Taille d'un groupe selon l'espèce. */
export function groupSize(type, random = 0.5) {
  if (type === 'bird') return 4;
  if (type === 'rabbit' || type === 'koala') return 2;
  return 3 + (random > 0.5 ? 1 : 0);
}

/** Le troupeau broute-t-il en ce moment ? (≈ 40 % du temps, par périodes de quelques dizaines de secondes) */
export function isGrazing(time, phase) {
  return Math.sin(time * 0.11 + phase * 3) > 1 - 2 * HERD_RULES.grazeShare;
}

/** Position du troupeau sur sa boucle de pâture (n'avance que lorsqu'il ne broute pas). */
export function herdPosition(herd) {
  const angle = herd.travel * herd.speed + herd.phase;
  return { x: herd.center.x + Math.cos(angle) * herd.radius, z: herd.center.z + Math.sin(angle * 0.83) * herd.radius };
}

/** Une volée posée s'envole quand le joueur s'approche à moins de 9 m. */
export function birdsShouldTakeOff(distanceToPlayer, state) {
  return state === 'perched' && distanceToPlayer < HERD_RULES.birdAlarm;
}

/** Destination de fuite d'une volée : à l'opposé du joueur, à environ 26 m. */
export function birdEscapeTarget(flock, player) {
  const dx = flock.x - player.x, dz = flock.z - player.z;
  const length = Math.hypot(dx, dz) || 1;
  return { x: flock.x + (dx / length) * HERD_RULES.birdFlight, z: flock.z + (dz / length) * HERD_RULES.birdFlight };
}
