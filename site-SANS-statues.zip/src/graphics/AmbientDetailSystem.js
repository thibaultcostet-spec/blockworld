import * as THREE from 'three';

function hash2D(x,z,seed=0){const v=Math.sin((x+seed*13.17)*127.1+(z-seed*7.91)*311.7)*43758.5453;return v-Math.floor(v);}

function makeReedTexture(){
  const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d');ctx.clearRect(0,0,128,128);
  for(let i=0;i<11;i++){
    const x=12+i*10+(i%2)*3;const height=58+(i%5)*12;
    const gradient=ctx.createLinearGradient(0,128,0,128-height);gradient.addColorStop(0,'rgba(39,91,42,.98)');gradient.addColorStop(.75,'rgba(89,139,55,.96)');gradient.addColorStop(1,'rgba(166,177,85,.1)');
    ctx.strokeStyle=gradient;ctx.lineWidth=3+(i%3);ctx.beginPath();ctx.moveTo(x,127);ctx.quadraticCurveTo(x+(i%2?7:-7),92,x+(i%3)-1,128-height);ctx.stroke();
    if(i%3===0){ctx.fillStyle='rgba(92,65,37,.90)';ctx.beginPath();ctx.ellipse(x+(i%3)-1,128-height,4,12,.05,0,Math.PI*2);ctx.fill();}
  }
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;return texture;
}

function addWind(material,amplitude=.08){
  material.onBeforeCompile=(shader)=>{
    shader.uniforms.uWindTime={value:0};shader.uniforms.uWindAmplitude={value:amplitude};
    shader.vertexShader=shader.vertexShader.replace('#include <common>','#include <common>\nuniform float uWindTime;uniform float uWindAmplitude;');
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>\nfloat bwPhase=uWindTime+position.x*2.1+position.z*1.7;\n#ifdef USE_INSTANCING\nbwPhase+=instanceMatrix[3].x*.19+instanceMatrix[3].z*.17;\n#endif\ntransformed.x+=sin(bwPhase)*uWindAmplitude*max(position.y,0.0);transformed.z+=cos(bwPhase*.73)*uWindAmplitude*.45*max(position.y,0.0);`);
    material.userData.windUniform=shader.uniforms.uWindTime;
  };
  material.customProgramCacheKey=()=>`bw-ambient-wind-${amplitude}`;
}

export class AmbientDetailSystem{
  constructor(scene,world,{touchMode=false}={}){
    this.scene=scene;this.world=world;this.touchMode=touchMode;this.quality=touchMode?'mobile':'high';this.elapsed=0;this.definition=null;
    this.group=new THREE.Group();this.group.name='AmbientDetailsV3Beta3';scene.add(this.group);
    this.followGroup=new THREE.Group();this.followGroup.name='PollenAndFireflies';scene.add(this.followGroup);
    this.reedTexture=makeReedTexture();this.butterflies=[];this.windMaterials=[];this.motes=null;
  }
  clear(){
    for(const root of [this.group,this.followGroup])for(const child of [...root.children]){root.remove(child);child.traverse?.((o)=>{o.geometry?.dispose?.();const ms=Array.isArray(o.material)?o.material:[o.material];for(const m of ms)m?.dispose?.();});}
    this.butterflies=[];this.windMaterials=[];this.motes=null;
  }
  setQuality(id){this.quality=id;if(this.definition)this.rebuild();}
  setWorld(definition){this.definition=definition;this.rebuild();}
  isWater(x,y,z){return this.world.blocks?.get?.(`${x}|${y}|${z}`)?.type==='water';}
  rebuild(){
    this.clear();if(!this.definition||this.quality==='mobile')return;
    this.buildShoreDetails();
    if(this.quality==='high'||this.quality==='ultra'){this.buildButterflies();this.buildMotes();}
  }
  buildShoreDetails(){
    const candidates=[];
    for(const block of this.world.blocks.values()){
      if(block.type!=='water'||this.isWater(block.x,block.y+1,block.z))continue;
      const shore=!this.isWater(block.x+1,block.y,block.z)||!this.isWater(block.x-1,block.y,block.z)||!this.isWater(block.x,block.y,block.z+1)||!this.isWater(block.x,block.y,block.z-1);
      if(!shore)continue;
      const n=hash2D(block.x,block.z,this.definition.seed+201);if(n<.34)candidates.push({x:block.x+(n-.5)*.5,y:block.y+.49,z:block.z+(hash2D(block.z,block.x,this.definition.seed)-.5)*.5,n});
    }
    const limit=this.quality==='ultra'?360:this.quality==='high'?210:90;const reeds=candidates.slice(0,limit);
    if(reeds.length){
      const geo=new THREE.PlaneGeometry(.82,1.72,2,4);geo.translate(0,.86,0);
      const mat=new THREE.MeshStandardMaterial({map:this.reedTexture,transparent:true,alphaTest:.20,side:THREE.DoubleSide,color:0x84a94d,roughness:.92,depthWrite:true});
      addWind(mat,.035);this.windMaterials.push(mat);
      const dummy=new THREE.Object3D();
      for(const offset of [0,Math.PI/2]){
        const mesh=new THREE.InstancedMesh(geo,mat,reeds.length);mesh.name='ShoreReeds';
        reeds.forEach((r,i)=>{dummy.position.set(r.x,r.y,r.z);dummy.rotation.set(0,r.n*Math.PI*2+offset,0);const s=.65+r.n*.75;dummy.scale.set(s,s,s);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});
        mesh.instanceMatrix.needsUpdate=true;mesh.castShadow=true;mesh.receiveShadow=true;this.group.add(mesh);
      }
      const rockGeo=new THREE.DodecahedronGeometry(.23,0);const rockMat=new THREE.MeshStandardMaterial({color:0x7f8079,roughness:.98});
      const rockCount=Math.min(reeds.length, this.quality==='ultra'?180:90);const rocks=new THREE.InstancedMesh(rockGeo,rockMat,rockCount);
      for(let i=0;i<rockCount;i++){const r=reeds[i];dummy.position.set(r.x+.35,r.y-.02,r.z-.25);dummy.rotation.set(r.n,r.n*5,r.n*.4);dummy.scale.set(.55+r.n*.8,.35+r.n*.35,.62+r.n*.9);dummy.updateMatrix();rocks.setMatrixAt(i,dummy.matrix);rocks.setColorAt(i,new THREE.Color().setHSL(.12,.04,.34+r.n*.18));}
      rocks.instanceMatrix.needsUpdate=true;if(rocks.instanceColor)rocks.instanceColor.needsUpdate=true;rocks.castShadow=true;rocks.receiveShadow=true;this.group.add(rocks);
    }
  }
  buildButterflies(){
    const count=this.quality==='ultra'?26:14;const size=this.definition.size||160;
    const wingGeo=new THREE.PlaneGeometry(.22,.14);const colors=[0xf2c84b,0x6aaee8,0xee7a9f,0xf39b45];
    for(let i=0;i<count;i++){
      const n=hash2D(i*7,i*13,this.definition.seed+403);const x=(n-.5)*size*.68,z=(hash2D(i*17,i*5,this.definition.seed)-.5)*size*.68;
      const top=this.world.getTopBlock(Math.round(x),Math.round(z),{solidOnly:true});if(!top||top.type!=='grass')continue;
      const group=new THREE.Group();group.position.set(x,top.y+1.2+n*1.1,z);group.userData.origin=group.position.clone();group.userData.phase=n*Math.PI*2;group.userData.radius=.8+n*1.6;
      const mat=new THREE.MeshStandardMaterial({color:colors[i%colors.length],side:THREE.DoubleSide,roughness:.62,emissive:colors[i%colors.length],emissiveIntensity:.08});
      for(const side of [-1,1]){const pivot=new THREE.Group();pivot.position.x=side*.045;const wing=new THREE.Mesh(wingGeo,mat);wing.position.x=side*.10;wing.rotation.y=side*.28;pivot.add(wing);pivot.userData.side=side;group.add(pivot);}
      this.group.add(group);this.butterflies.push(group);
    }
  }
  // Beta 4.26 : poussières et lucioles plafonnées à 9 px (halos blancs géants quand une particule frôlait la caméra).
  buildMotes(){
    const count=this.quality==='ultra'?140:75;const positions=new Float32Array(count*3);const seeds=new Float32Array(count);
    for(let i=0;i<count;i++){const a=i/count*Math.PI*2,r=4+(i%17)*.62;positions[i*3]=Math.cos(a)*r;positions[i*3+1]=.4+(i%13)*.38;positions[i*3+2]=Math.sin(a)*r;seeds[i]=hash2D(i,17,this.definition.seed);}
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(positions,3));geo.setAttribute('aSeed',new THREE.BufferAttribute(seeds,1));
    const mat=new THREE.ShaderMaterial({transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,uniforms:{uTime:{value:0},uNight:{value:0}},vertexShader:`#define MAX_MOTE_PX 9.0
attribute float aSeed;uniform float uTime;varying float vSeed;void main(){vec3 p=position;p.x+=sin(uTime*.55+aSeed*13.0+p.y)*.55;p.z+=cos(uTime*.43+aSeed*17.0+p.x)*.45;p.y+=sin(uTime*.8+aSeed*21.0)*.22;vec4 mv=modelViewMatrix*vec4(p,1.0);gl_PointSize=min(mix(1.6,4.2,aSeed)*(260.0/max(-mv.z,1.0)),MAX_MOTE_PX);gl_Position=projectionMatrix*mv;vSeed=aSeed;}`,fragmentShader:`uniform float uNight;varying float vSeed;void main(){float d=distance(gl_PointCoord,vec2(.5));float a=smoothstep(.5,.08,d);vec3 day=mix(vec3(1.0,.78,.38),vec3(.76,.91,1.0),vSeed);vec3 night=mix(vec3(.42,1.0,.32),vec3(1.0,.86,.30),vSeed);gl_FragColor=vec4(mix(day,night,uNight),a*mix(.16,.62,uNight));}`});
    this.motes=new THREE.Points(geo,mat);this.followGroup.add(this.motes);
  }
  update(delta,player){
    this.elapsed+=delta;
    for(const material of this.windMaterials)if(material.userData.windUniform)material.userData.windUniform.value=this.elapsed;
    for(const butterfly of this.butterflies){const d=butterfly.userData;const t=this.elapsed*1.15+d.phase;butterfly.position.x=d.origin.x+Math.cos(t)*d.radius;butterfly.position.z=d.origin.z+Math.sin(t*.86)*d.radius;butterfly.position.y=d.origin.y+Math.sin(t*2.1)*.28;butterfly.rotation.y=-t;for(const pivot of butterfly.children)pivot.rotation.y=pivot.userData.side*(.18+Math.sin(this.elapsed*12+d.phase)*.82);}
    if(player)this.followGroup.position.set(player.x,player.y-1.2,player.z);
    if(this.motes){this.motes.material.uniforms.uTime.value=this.elapsed;const l=this.scene.background?.isColor?this.scene.background.getHSL({h:0,s:0,l:0}).l:.7;this.motes.material.uniforms.uNight.value=THREE.MathUtils.clamp((.55-l)*3.2,0,1);}
  }
}
