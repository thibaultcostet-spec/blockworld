import * as THREE from 'three';

function celestialTexture(kind) {
  const canvas=document.createElement('canvas');
  canvas.width=canvas.height=256;
  const ctx=canvas.getContext('2d');
  const gradient=ctx.createRadialGradient(128,128,10,128,128,124);
  if(kind==='sun'){
    gradient.addColorStop(0,'rgba(255,255,235,1)');
    gradient.addColorStop(.18,'rgba(255,232,166,.98)');
    gradient.addColorStop(.52,'rgba(255,176,88,.45)');
    gradient.addColorStop(1,'rgba(255,145,50,0)');
  }else{
    gradient.addColorStop(0,'rgba(247,251,255,1)');
    gradient.addColorStop(.34,'rgba(210,226,255,.94)');
    gradient.addColorStop(.62,'rgba(118,151,217,.28)');
    gradient.addColorStop(1,'rgba(82,115,190,0)');
  }
  ctx.fillStyle=gradient;ctx.fillRect(0,0,256,256);
  if(kind==='moon'){
    ctx.globalCompositeOperation='multiply';
    for(let i=0;i<22;i++){
      const x=72+(i*47)%112,y=66+(i*71)%118,r=4+(i%6)*2;
      ctx.fillStyle=`rgba(112,129,162,${.08+(i%4)*.025})`;
      ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();
    }
    ctx.globalCompositeOperation='source-over';
  }
  const texture=new THREE.CanvasTexture(canvas);
  texture.colorSpace=THREE.SRGBColorSpace;
  texture.minFilter=THREE.LinearMipmapLinearFilter;
  texture.magFilter=THREE.LinearFilter;
  return texture;
}

export class AtmosphereSystem {
  constructor(game) {
    this.game = game;
    // Beta 4.13 : journée de 8 min (4 auparavant) ; départ en fin d'après-midi, avant l'heure dorée.
    this.dayLength = 480;
    this.elapsed = this.dayLength * .70;
    this.hazeColor = new THREE.Color();
    this.sunGlowColor = new THREE.Color();
    this.sunTint = new THREE.Color();
    this.goldenSun = new THREE.Color(1.0, 0.62, 0.34);
    this.noonSun = new THREE.Color(1.0, 0.95, 0.87);
    this.coolHaze = new THREE.Color(0x9bb6cf);
    this.warmHaze = new THREE.Color(0xd9b58c);
    this.skyDay = new THREE.Color(0x77c8ff);
    this.skyHorizon = new THREE.Color(0xd8ecf5);
    this.skyDawn = new THREE.Color(0xf3a26f);
    this.skyNight = new THREE.Color(0x5577ad); // repère historique 0x253a68 ; relevé nettement pour une nuit jouable et lisible
    this.nightHorizon = new THREE.Color(0x89a8d2);
    this.skyDeepNight = new THREE.Color(0x1b2a4f); // Beta 4.27 : ciel du cœur de la nuit
    this.fogColor = new THREE.Color();
    this.sunDisc = this.createDisc('sun', 19);
    this.moonDisc = this.createDisc('moon', 14);
    this.moonHalo = this.createHalo();
    this.stars = this.createStars();
    this.skyDome = this.createSkyDome();
    this.moonLight = new THREE.DirectionalLight(0x9dbdff,0);
    this.moonLight.castShadow=false;
    game.scene.add(this.skyDome,this.sunDisc,this.moonDisc,this.moonHalo,this.stars,this.moonLight,this.moonLight.target);
  }

  createDisc(kind,size) {
    const material=new THREE.SpriteMaterial({
      map:celestialTexture(kind),transparent:true,depthWrite:false,depthTest:false,
      blending:THREE.AdditiveBlending,fog:false,color:0xffffff
    });
    const sprite=new THREE.Sprite(material);
    sprite.scale.set(size,size,1);
    sprite.renderOrder=-780;
    return sprite;
  }

  createHalo(){
    const material=new THREE.SpriteMaterial({
      map:celestialTexture('moon'),transparent:true,opacity:.22,depthWrite:false,depthTest:false,
      blending:THREE.AdditiveBlending,fog:false,color:0x8ab3ff
    });
    const halo=new THREE.Sprite(material);halo.scale.set(31,31,1);halo.renderOrder=-790;return halo;
  }

  createStars() {
    const count = 520;
    const positions = new Float32Array(count * 3);
    const sizes = new Float32Array(count);
    for (let index = 0; index < count; index += 1) {
      const radius = 340;
      const phi = Math.acos(2 * Math.random() - 1);
      const theta = Math.random() * Math.PI * 2;
      positions[index * 3] = radius * Math.sin(phi) * Math.cos(theta);
      positions[index * 3 + 1] = Math.abs(radius * Math.cos(phi)) + 25;
      positions[index * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
      sizes[index]=.65+Math.random()*1.2;
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aSize',new THREE.BufferAttribute(sizes,1));
    const stars = new THREE.Points(geometry,new THREE.ShaderMaterial({
      transparent:true,depthWrite:false,depthTest:false,fog:false,blending:THREE.AdditiveBlending,
      uniforms:{uOpacity:{value:0},uTime:{value:0}},
      vertexShader:`attribute float aSize;varying float vBlink;uniform float uTime;void main(){vec4 mv=modelViewMatrix*vec4(position,1.0);vBlink=.72+.28*sin(uTime*(1.2+aSize*.4)+position.x*.13);gl_PointSize=aSize*(280.0/-mv.z);gl_Position=projectionMatrix*mv;}`,
      fragmentShader:`varying float vBlink;uniform float uOpacity;void main(){float d=distance(gl_PointCoord,vec2(.5));float a=smoothstep(.5,.06,d)*uOpacity*vBlink;gl_FragColor=vec4(vec3(.82,.91,1.0),a);}`
    }));
    stars.renderOrder=-700;
    return stars;
  }

  createSkyDome() {
    const material = new THREE.ShaderMaterial({
      side: THREE.BackSide,depthWrite:false,depthTest:false,fog:false,
      uniforms: {
        uTop:{value:this.skyDay.clone()},uHorizon:{value:this.skyHorizon.clone()},uBottom:{value:new THREE.Color(0x9fc3ca)},
        uSunDir:{value:new THREE.Vector3(.3,.8,.2).normalize()},uMoonDir:{value:new THREE.Vector3(-.3,-.8,-.2).normalize()},
        uSunColor:{value:new THREE.Color(0xffd6a0)},uSunGlow:{value:.45},uMoonGlow:{value:0},uCloudShade:{value:0}
      },
      vertexShader:`varying vec3 vDirection;void main(){vDirection=normalize(position);gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
      fragmentShader:`
        uniform vec3 uTop;uniform vec3 uHorizon;uniform vec3 uBottom;uniform vec3 uSunDir;uniform vec3 uMoonDir;uniform vec3 uSunColor;
        uniform float uSunGlow;uniform float uMoonGlow;uniform float uCloudShade;varying vec3 vDirection;
        void main(){
          vec3 direction=normalize(vDirection);float height=clamp(direction.y*.5+.5,0.0,1.0);float horizon=smoothstep(0.0,.52,height);
          vec3 color=mix(uBottom,uHorizon,smoothstep(0.0,.22,height));color=mix(color,uTop,smoothstep(.18,.92,height));
          float sun=max(dot(direction,normalize(uSunDir)),0.0);float glow=pow(sun,18.0)*uSunGlow+pow(sun,240.0)*2.0;color+=uSunColor*glow;
          float moon=max(dot(direction,normalize(uMoonDir)),0.0);color+=vec3(.38,.55,.92)*(pow(moon,20.0)*uMoonGlow+pow(moon,260.0)*uMoonGlow*1.5);
          float horizonBand=pow(1.0-abs(direction.y),7.0);color+=vec3(.08,.14,.25)*horizonBand*(1.0-uSunGlow*.3);
          color=mix(color,color*.70,uCloudShade*(1.0-horizon*.35));gl_FragColor=vec4(color,1.0);
        }`
    });
    const dome = new THREE.Mesh(new THREE.SphereGeometry(390,36,24),material);
    dome.renderOrder=-1000;dome.frustumCulled=false;return dome;
  }

  update(delta, player) {
    this.elapsed=(this.elapsed+delta)%this.dayLength;
    const phase=this.elapsed/this.dayLength;
    const angle=phase*Math.PI*2-Math.PI*.55;
    const altitude=Math.sin(angle);
    const daylight=THREE.MathUtils.smoothstep(altitude,-.20,.26);
    const night=1-daylight;
    const dawn=Math.max(0,1-Math.abs(altitude)/.36)*(1-daylight*.22);
    const civilTwilight=THREE.MathUtils.smoothstep(altitude,-.34,.04);
    const nightLift=.38+.62*civilTwilight;
    // Beta 4.27 : nuit contrastée — lisible au crépuscule et à l'aube (réglages Beta 4), plus profonde au cœur de la nuit.
    const deepNight=1-THREE.MathUtils.smoothstep(altitude,-.92,-.42);
    this.daylight=daylight;this.night=night;this.deepNight=deepNight;
    const sky=this.skyNight.clone().lerp(this.skyDawn,dawn*.85).lerp(this.skyDay,daylight).lerp(this.skyDeepNight,deepNight*.55);
    const horizon=this.nightHorizon.clone().lerp(new THREE.Color(0xf4c19e),dawn*.92).lerp(this.skyHorizon,daylight).lerp(this.skyDeepNight,deepNight*.42);
    const bottom=this.nightHorizon.clone().multiplyScalar(.72).lerp(new THREE.Color(0xb3cad3),daylight*.92);

    const sunHeight=THREE.MathUtils.clamp((altitude-.02)/.6,0,1);
    this.sunTint.copy(this.goldenSun).lerp(this.noonSun,sunHeight*sunHeight*(3-2*sunHeight));
    this.game.scene.background.copy(sky);
    this.fogColor.copy(horizon).lerp(daylight>.4?new THREE.Color(0xbfdadf):new THREE.Color(0x7996c4),.22);
    this.game.scene.fog.color.copy(this.fogColor);

    const radius=260;
    const sunDirection=new THREE.Vector3(Math.cos(angle),altitude,Math.sin(angle*.72)).normalize();
    const moonDirection=sunDirection.clone().negate();
    this.sunDisc.position.set(player.x+sunDirection.x*radius,player.y+sunDirection.y*radius,player.z+sunDirection.z*radius);
    this.moonDisc.position.set(player.x+moonDirection.x*radius,player.y+moonDirection.y*radius,player.z+moonDirection.z*radius);
    this.moonHalo.position.copy(this.moonDisc.position);
    this.sunDisc.visible=altitude>-.34;
    this.moonDisc.visible=altitude<.42;
    this.moonHalo.visible=this.moonDisc.visible;
    this.moonDisc.material.opacity=.65+night*.35;
    this.moonHalo.material.opacity=.10+night*.22;
    this.stars.visible=true;
    this.stars.position.copy(player);
    this.stars.material.uniforms.uOpacity.value=THREE.MathUtils.clamp(1-daylight*1.35,0,.90);
    this.stars.material.uniforms.uTime.value=this.elapsed;
    this.skyDome.position.copy(player);
    this.skyDome.material.uniforms.uTop.value.copy(sky);
    this.skyDome.material.uniforms.uHorizon.value.copy(horizon);
    this.skyDome.material.uniforms.uBottom.value.copy(bottom);
    this.skyDome.material.uniforms.uSunDir.value.copy(sunDirection);
    this.skyDome.material.uniforms.uMoonDir.value.copy(moonDirection);
    // Beta 4.13 : halo du ciel teinté comme le soleil (doré soleil bas au lieu d'un blanc fixe).
    if(daylight<.25)this.skyDome.material.uniforms.uSunColor.value.set(0xffa878);else this.skyDome.material.uniforms.uSunColor.value.copy(this.sunTint).lerp(new THREE.Color(0xffa060),.25);
    this.skyDome.material.uniforms.uSunGlow.value=.18+dawn*1.35+daylight*.42;
    this.skyDome.material.uniforms.uMoonGlow.value=.34+night*.92;

    this.game.sun.position.set(player.x+sunDirection.x*148,Math.max(10,player.y+altitude*167),player.z+sunDirection.z*118); // Beta 4.13 : éloigné pour que les crêtes côté soleil portent leur ombre
    // Beta 4.10 : sans cible mobile, le soleil visait l'origine (0,0,0) : direction de lumière
    // fausse et cadre d'ombres (±62) décentré dès qu'on s'éloigne du centre de la carte.
    if(!this.game.sun.target.parent)this.game.scene.add(this.game.sun.target);
    this.game.sun.target.position.copy(player);
    this.moonLight.position.set(player.x+moonDirection.x*70,player.y+Math.max(20,moonDirection.y*90),player.z+moonDirection.z*70);
    this.moonLight.target.position.copy(player);
    const weather=this.game.climate?.state||'clair';
    const weatherFactor=weather==='orage'?.38:weather==='pluie'||weather==='neige'?.68:weather==='brouillard'?.72:1;
    this.skyDome.material.uniforms.uCloudShade.value=weather==='orage'?.58:weather==='pluie'?.32:weather==='brouillard'?.18:0;
    // Beta 4.13 : le soleil domine l'ambiance le jour (ombres et volumes lisibles) ; teinte continue,
    // dorée soleil bas, blanc chaud au zénith. La nuit conserve les réglages de lisibilité Beta 4.
    this.game.sun.intensity=(.12+3.4*daylight)*weatherFactor;
    this.moonLight.intensity=(.38+night*1.05)*weatherFactor;
    // Repère historique conservé : 1.18 + 1.34 * daylight, puis 1.42 + 1.22 * daylight. Beta 4 : forte remontée de la visibilité nocturne.
    this.game.hemisphere.intensity=THREE.MathUtils.lerp(2.39,1.25,daylight)*(.85+.15*weatherFactor)*(1-.42*deepNight);
    this.game.hemisphere.color.set(daylight>.45?0xe8f6ff:0xb4cbff);
    this.game.hemisphere.groundColor.set(daylight>.45?0x536241:0x39527b);
    if(daylight<.22)this.game.sun.color.set(0xc5d7ff);else this.game.sun.color.copy(this.sunTint);
    this.hazeColor.copy(this.coolHaze).lerp(this.warmHaze,dawn*.55).lerp(this.fogColor,.35+night*.5);
    this.sunGlowColor.copy(this.sunTint).multiplyScalar(daylight*weatherFactor).lerp(new THREE.Color(0x6f86b8),night*.4);

    const profileExposure=this.game.graphicsQuality?.profile?.exposure??1.03;
    const targetExposure=profileExposure+nightLift*.28+night*.16+dawn*.10-deepNight*.2;
    this.game.renderer.toneMappingExposure=THREE.MathUtils.lerp(this.game.renderer.toneMappingExposure,targetExposure,.08);
    // Beta 4.32 : dans la grotte, le soleil et le ciel disparaissent ; l'ambiance se resserre autour de la lampe frontale.
    const caveDark=THREE.MathUtils.clamp((this.game.caves?.factor??0)*(this.game.caves?.darkness??.9),0,1);
    if(caveDark>.001){
      const keep=1-caveDark;
      this.game.sun.intensity*=keep*keep;
      this.moonLight.intensity*=keep*keep;
      this.game.hemisphere.intensity*=Math.max(.1,keep);
      const black=Math.min(1,caveDark*1.08);
      this.game.scene.fog.color.lerp(new THREE.Color(0x020308),black);
      this.game.scene.background.lerp(new THREE.Color(0x020308),black);
      this.hazeColor.lerp(new THREE.Color(0x020308),black);
      this.sunGlowColor.multiplyScalar(keep);
      // le soleil, la lune et les étoiles ne se voient pas à travers la roche
      if(caveDark>.35){this.sunDisc.visible=false;this.moonDisc.visible=false;this.moonHalo.visible=false;this.stars.visible=false;}
    }
    if(this.game.renderPipeline?.setAtmosphere){
      this.game.renderPipeline.setAtmosphere({ daylight:daylight*(1-caveDark), night, dawn:dawn*(1-caveDark), twilight:civilTwilight, visibility:nightLift, sunDirection, hazeColor:this.hazeColor, sunGlowColor:this.sunGlowColor });
    }
  }
}
