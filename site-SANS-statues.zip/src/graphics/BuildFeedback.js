// BlockWorld V3.0 Beta 4.26 — retours visuels de construction :
// contour du bloc visé, aperçu translucide avant la pose, fissures progressives, poussière à la pose et à la casse.
import * as THREE from 'three';
import { BLOCK_TYPES } from '../world/BlockTypes.js';
import { CRACK_STAGES, DUST_LIFETIME, TARGET_REACH, TARGET_REFRESH, crackStage, showsBlockTarget, showsPlacementGhost } from './BuildFeedbackRules.js';

// Fissures dessinées une fois sur un canvas (pas de blob:, compatible avec la politique de sécurité du serveur).
export function makeCrackTexture(stage) {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size; canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, size, size);
  ctx.strokeStyle = 'rgba(20,16,12,0.92)';
  ctx.lineCap = 'round';
  let seed = 17;
  const rand = () => { seed = (seed * 9301 + 49297) % 233280; return seed / 233280; };
  const branches = 2 + stage * 2;
  for (let b = 0; b < branches; b += 1) {
    let x = size / 2 + (rand() - 0.5) * 10;
    let y = size / 2 + (rand() - 0.5) * 10;
    let angle = (b / branches) * Math.PI * 2 + rand() * 0.6;
    const steps = 3 + stage * 2;
    ctx.lineWidth = 2.2 - b * 0.12;
    ctx.beginPath(); ctx.moveTo(x, y);
    for (let i = 0; i < steps; i += 1) {
      angle += (rand() - 0.5) * 0.9;
      x += Math.cos(angle) * (4 + rand() * 3);
      y += Math.sin(angle) * (4 + rand() * 3);
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.magFilter = THREE.NearestFilter;
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export class BuildFeedback {
  constructor(game) {
    this.game = game;
    this.scene = game.scene;
    this.refresh = 0;
    this.target = null;      // { block, position, normal }
    this.group = new THREE.Group();
    this.group.name = 'BuildFeedback';
    this.scene.add(this.group);

    const edges = new THREE.EdgesGeometry(new THREE.BoxGeometry(1.012, 1.012, 1.012));
    this.outline = new THREE.LineSegments(edges, new THREE.LineBasicMaterial({ color: 0x101418, transparent: true, opacity: 0.62, depthWrite: false }));
    this.outline.visible = false;
    this.outline.renderOrder = 5;

    this.ghostMaterial = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.26, depthWrite: false });
    this.ghost = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.98, 0.98), this.ghostMaterial);
    this.ghostEdges = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(0.985, 0.985, 0.985)), new THREE.LineBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.55, depthWrite: false }));
    this.ghost.add(this.ghostEdges);
    this.ghost.visible = false;

    this.crackTextures = Array.from({ length: CRACK_STAGES }, (_, i) => makeCrackTexture(i + 1));
    this.crackMaterial = new THREE.MeshBasicMaterial({ map: this.crackTextures[0], transparent: true, alphaTest: 0.25, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    this.crack = new THREE.Mesh(new THREE.BoxGeometry(1.006, 1.006, 1.006), this.crackMaterial);
    this.crack.visible = false;

    this.group.add(this.outline, this.ghost, this.crack);
    this.bursts = [];
  }

  blockColor(type) {
    return new THREE.Color(BLOCK_TYPES[type]?.color ?? 0xbfbfbf);
  }

  hide() {
    this.outline.visible = false;
    this.ghost.visible = false;
    this.crack.visible = false;
    this.target = null;
  }

  // Recalcule le bloc visé (au plus ~11 fois par seconde) puis place contour, fantôme et fissures.
  update(delta) {
    this.updateBursts(delta);
    const g = this.game;
    const active = g.player?.isActive?.() && !g.inventoryOpen && !g.zoomActive;
    const item = g.selectedItem;
    if (!active || !showsBlockTarget(item)) { this.hide(); return; }
    this.refresh -= delta;
    if (this.refresh <= 0) {
      this.refresh = TARGET_REFRESH;
      const { blockHit } = g.raycastScene(TARGET_REACH);
      let resolved = blockHit ? g.world.resolveRaycastHit(blockHit) : null;
      // Beta 4.28 : pas de contour ni de fantôme quand on vise un chien (clic droit = le nourrir).
      if (resolved && g.companions?.dogs.length) {
        const [dogHit] = g.raycaster.intersectObjects(g.companions.getRaycastTargets(), true);
        if (dogHit && dogHit.distance < blockHit.distance) resolved = null;
      }
      this.target = resolved ? { block: resolved.block, position: resolved.position, normal: blockHit.face?.normal?.clone() ?? null } : null;
    }
    if (!this.target) { this.hide(); return; }
    const { block, position, normal } = this.target;
    this.outline.position.copy(position);
    this.outline.visible = true;

    // Fissures : étape selon les coups déjà portés sur ce bloc.
    const key = g.world.key(block.x, block.y, block.z);
    const hits = g.blockDamage?.get(key) ?? 0;
    const required = hits > 0 ? (g.hitsToBreak?.(block.type) ?? 0) : 0;
    const stage = crackStage(hits, required);
    this.crack.visible = stage > 0;
    if (stage > 0) {
      this.crack.position.copy(position);
      if (this.crackMaterial.map !== this.crackTextures[stage - 1]) { this.crackMaterial.map = this.crackTextures[stage - 1]; this.crackMaterial.needsUpdate = true; }
    }

    // Fantôme : où le bloc tenu en main sera posé.
    if (showsPlacementGhost(item) && normal) {
      const spot = position.clone().add(normal);
      const free = !g.world.getBlock(spot.x, spot.y, spot.z) || g.world.getBlock(spot.x, spot.y, spot.z)?.type === 'water';
      const clear = spot.distanceTo(g.player.getEyePosition()) >= 1.4;
      this.ghost.visible = free && clear;
      if (this.ghost.visible) {
        this.ghost.position.copy(spot);
        this.ghostMaterial.color.copy(this.blockColor(item.type));
      }
    } else {
      this.ghost.visible = false;
    }
  }

  // Petite bouffée de poussière de la couleur du bloc (pose, casse, coup porté).
  burst(position, type, { count = 14, spread = 0.55, lift = 1.6 } = {}) {
    if (this.bursts.length > 6) this.disposeBurst(this.bursts.shift());
    const positions = new Float32Array(count * 3);
    const velocities = [];
    for (let i = 0; i < count; i += 1) {
      positions[i * 3] = position.x + (Math.random() - 0.5) * 0.9;
      positions[i * 3 + 1] = position.y + (Math.random() - 0.2) * 0.6;
      positions[i * 3 + 2] = position.z + (Math.random() - 0.5) * 0.9;
      velocities.push(new THREE.Vector3((Math.random() - 0.5) * spread * 2, Math.random() * lift, (Math.random() - 0.5) * spread * 2));
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({ color: this.blockColor(type), size: 0.11, sizeAttenuation: true, transparent: true, opacity: 0.95, depthWrite: false });
    const points = new THREE.Points(geometry, material);
    this.group.add(points);
    this.bursts.push({ points, velocities, age: 0 });
  }

  // Beta 4.27 : chaque geste a aussi son son, selon le matériau du bloc.
  onPlace(position, type) { this.burst(position, type, { count: 10, spread: 0.45, lift: 1.0 }); this.refresh = 0; this.game.sfx?.playBlock?.(type, 'place'); }
  onHit(position, type) { this.burst(position, type, { count: 6, spread: 0.35, lift: 0.9 }); this.game.sfx?.playBlock?.(type, 'hit'); }
  onBreak(position, type) { this.burst(position, type, { count: 22, spread: 0.8, lift: 2.2 }); this.refresh = 0; this.game.sfx?.playBlock?.(type, 'break'); }

  updateBursts(delta) {
    for (let i = this.bursts.length - 1; i >= 0; i -= 1) {
      const burst = this.bursts[i];
      burst.age += delta;
      const attribute = burst.points.geometry.getAttribute('position');
      for (let p = 0; p < burst.velocities.length; p += 1) {
        const v = burst.velocities[p];
        v.y -= 6.5 * delta;
        attribute.array[p * 3] += v.x * delta;
        attribute.array[p * 3 + 1] += v.y * delta;
        attribute.array[p * 3 + 2] += v.z * delta;
      }
      attribute.needsUpdate = true;
      burst.points.material.opacity = Math.max(0, 0.95 * (1 - burst.age / DUST_LIFETIME));
      if (burst.age >= DUST_LIFETIME) { this.disposeBurst(burst); this.bursts.splice(i, 1); }
    }
  }

  disposeBurst(burst) {
    if (!burst) return;
    this.group.remove(burst.points);
    burst.points.geometry.dispose();
    burst.points.material.dispose();
  }
}
