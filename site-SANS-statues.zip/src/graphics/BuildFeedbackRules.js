// BlockWorld V3.0 Beta 4.26 — règles pures des retours de construction (testables sous Node).

export const CRACK_STAGES = 4;          // 4 dessins de fissures, du léger au presque rompu
export const TARGET_REACH = 7;          // portée de visée des blocs (identique à handleInteraction)
export const TARGET_REFRESH = 0.09;     // le bloc visé est recalculé ~11 fois par seconde
export const DUST_LIFETIME = 0.65;      // durée d'une bouffée de poussière (s)

/** Étape de fissure (0 = intact, 1..4) d'après les coups déjà portés et ceux qu'il faut pour casser. */
export function crackStage(hits, required) {
  const h = Number(hits) || 0;
  const r = Math.max(1, Number(required) || 1);
  if (h <= 0 || r <= 1) return 0;
  return Math.min(CRACK_STAGES, Math.max(1, Math.ceil((h / (r - 1)) * CRACK_STAGES)));
}

/** Le contour du bloc visé n'apparaît qu'avec un bloc, un outil ou les mains (pas avec une arme ou un sort). */
export function showsBlockTarget(item) {
  if (!item) return true;
  return item.kind === 'block' || item.kind === 'tool';
}

/** L'aperçu translucide (fantôme) n'apparaît qu'avec un bloc en main. */
export function showsPlacementGhost(item) {
  return item?.kind === 'block';
}
