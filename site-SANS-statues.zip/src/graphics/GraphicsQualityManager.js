import * as THREE from 'three';
export const GRAPHICS_STORAGE_KEY='blockworld-graphics-quality';
// Beta 4.23 : profil « Très léger » pour les PC anciens (ex. Windows 7, 2 cœurs, GeForce 310) :
// rendu à 55 % de la résolution puis agrandi, sans ombres, vue courte, arbres et nuages plus grossiers.
export const LOW_SPEC_GPU=/GeForce\s*(8\d{3}|9\d{3}|[1-4]\d{2}\b|GT\s*[1-4]\d{2}\b)|Quadro\s*FX|Intel.*(GMA|G4[15]|(?<![A-Z])HD Graphics(?:\s+[2-4]\d{3}\b|(?![\s\d]*\d))|Q45|Q35)|\bGMA\s*X?\d{3,4}|Radeon\s*HD\s*[2-6]\d{3}|Mobility Radeon|SwiftShader|llvmpipe|Software/i;
export function detectLowSpec(renderer='',cores=8){return cores<=2||LOW_SPEC_GPU.test(String(renderer));}
export const GRAPHICS_PROFILES={
 lite:{label:'Très léger',pixelRatio:.55,shadowSize:0,viewDistance:30,fogNear:18,fogFar:62,clouds:2,waterDensity:.18,exposure:1.02,textures:false,bump:0,filter:'saturate(.9) contrast(.96) brightness(1.03)',foliage:false},
 mobile:{label:'Mobile',pixelRatio:.82,shadowSize:0,viewDistance:34,fogFar:82,clouds:3,waterDensity:.22,exposure:1.02,textures:false,bump:0,filter:'saturate(.86) contrast(.94) brightness(1.02)',foliage:false},
 standard:{label:'Standard',pixelRatio:1.15,shadowSize:1024,viewDistance:58,fogFar:138,clouds:7,waterDensity:.55,exposure:1.09,textures:true,bump:.025,filter:'saturate(1.03) contrast(1.01) brightness(1.03)',foliage:true},
 high:{label:'Élevée',pixelRatio:1.65,shadowSize:2048,shadowExtent:84,viewDistance:110,fogNear:70,fogFar:128,clouds:13,waterDensity:.88,exposure:1.18,textures:true,bump:.075,filter:'saturate(1.02) contrast(1.04) brightness(1.05)',foliage:true},
 ultra:{label:'Ultra',pixelRatio:2.35,shadowSize:4096,shadowExtent:104,viewDistance:150,fogNear:96,fogFar:172,clouds:22,waterDensity:1,exposure:1.24,textures:true,bump:.13,filter:'saturate(1.04) contrast(1.06) brightness(1.07)',foliage:true}
};
export class GraphicsQualityManager{
 constructor(game,select){this.game=game;this.select=select;this.id=this.detect();this.profile=GRAPHICS_PROFILES[this.id];if(select){select.value=this.id;select.addEventListener('change',()=>this.apply(select.value,true));}}
 detect(){let saved;try{saved=localStorage.getItem(GRAPHICS_STORAGE_KEY);}catch(_e){}if(GRAPHICS_PROFILES[saved])return saved;if(this.game.touchMode)return 'mobile';return detectLowSpec(this.rendererName(),navigator.hardwareConcurrency||8)?'lite':'high';}
 rendererName(){try{const gl=this.game.renderer.getContext();const info=gl.getExtension('WEBGL_debug_renderer_info');return info?gl.getParameter(info.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER);}catch(_e){return '';}}
 apply(id,persist=false){
  this.id=GRAPHICS_PROFILES[id]?id:'standard';this.profile=GRAPHICS_PROFILES[this.id];const g=this.game,p=this.profile;const sub=this.id==='lite'?'mobile':this.id; // sous-systèmes : « Très léger » se comporte comme « Mobile »
  g.renderer.setPixelRatio(Math.min(devicePixelRatio,p.pixelRatio));g.renderer.shadowMap.enabled=p.shadowSize>0;g.renderer.shadowMap.type=this.id==='ultra'?THREE.PCFSoftShadowMap:THREE.PCFShadowMap;
  if(p.shadowSize){g.sun.shadow.mapSize.set(p.shadowSize,p.shadowSize);g.sun.shadow.map?.dispose?.();g.sun.shadow.map=null;const ext=p.shadowExtent??62,sc=g.sun.shadow.camera;sc.left=sc.bottom=-ext;sc.right=sc.top=ext;sc.near=1;sc.far=420;sc.updateProjectionMatrix();g.sun.shadow.bias=-.00028;g.sun.shadow.normalBias=.035;}
  g.renderer.toneMapping=THREE.ACESFilmicToneMapping;g.renderer.toneMappingExposure=p.exposure;g.renderer.domElement.style.filter=p.filter;
  g.scene.fog.near=p.fogNear??(sub==='mobile'?24:46);g.scene.fog.far=p.fogFar;g.viewDistance=p.viewDistance;g.rebuildClouds?.(p.clouds,this.id);g.livingWater?.setQuality?.(p.waterDensity,sub);g.renderPipeline?.setQuality?.(sub);g.scenicVegetation?.setQuality?.(sub);g.microDecor?.setQuality?.(this.id);g.updateHDCharacters?.(this.id==='high'||this.id==='ultra');g.ambientDetails?.setQuality?.(sub);g.monumentEnhancer?.setQuality?.(sub);g.nightLights?.setQuality?.(this.id);g.caves?.setQuality?.(this.id);
  const maxAniso=g.renderer.capabilities.getMaxAnisotropy();
  for(const material of Object.values(g.world?.materials||{})){
    const data=material.userData||{};material.map=p.textures?data.baseMap:null;if(data.baseColor!==undefined)material.color.set(p.textures?0xffffff:data.baseColor);material.bumpMap=p.textures?data.baseBumpMap:null;material.normalMap=(p.textures&&this.id!=='mobile')?data.baseNormalMap:null;material.normalScale?.set?.(this.id==='ultra'?.72:this.id==='high'?.48:.24,this.id==='ultra'?.72:this.id==='high'?.48:.24);material.bumpScale=p.bump;
    material.roughness=this.id==='ultra'?Math.max(.32,(data.baseRoughness??.85)-.16):data.baseRoughness??.85;
    material.flatShading=sub==='mobile';material.alphaTest=data.foliage?(p.foliage?.28:.62):0;
    if(data.baseMap){data.baseMap.magFilter=sub==='mobile'?THREE.NearestFilter:THREE.LinearFilter;data.baseMap.minFilter=sub==='mobile'?THREE.NearestMipmapNearestFilter:THREE.LinearMipmapLinearFilter;data.baseMap.anisotropy=this.id==='ultra'?maxAniso:this.id==='high'?Math.min(8,maxAniso):Math.min(2,maxAniso);data.baseMap.needsUpdate=true;}
    material.needsUpdate=true;
  }
  g.hemisphere.intensity=sub==='mobile'?1.25:1.85;g.sun.castShadow=p.shadowSize>0;
  if(persist)try{localStorage.setItem(GRAPHICS_STORAGE_KEY,this.id);}catch(_e){}
  g.hud?.setStatus?.(`Qualité ${p.label} appliquée · ${p.textures?'textures relief':'rendu simplifié'} · ombres ${p.shadowSize||'désactivées'}`);
 }
}
