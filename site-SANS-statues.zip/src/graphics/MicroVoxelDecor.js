import * as THREE from 'three';
import { MICRO_VOXEL_SIZE, CLOUD_VOXEL_SIZE, rng, buildTreeGrid, buildCloudGrid, meshVoxelArrays } from './MicroVoxelShapes.js';

// BlockWorld V3.0 Beta 4.14 — décor en mini-blocs : affichage Three.js des formes de MicroVoxelShapes.
// Arbres instanciés par espèce, variante et secteur (deux niveaux de détail) ; nuages en mini-blocs.
export { MICRO_VOXEL_SIZE, CLOUD_VOXEL_SIZE };

export function meshVoxels(grid, unit, options) {
  const data = meshVoxelArrays(grid, unit, options);
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(data.positions, 3));
  geometry.setAttribute('normal', new THREE.Float32BufferAttribute(data.normals, 3));
  geometry.setAttribute('color', new THREE.Float32BufferAttribute(data.colors, 3));
  geometry.setAttribute('aSway', new THREE.Float32BufferAttribute(data.sway, 1));
  geometry.setIndex(data.positions.length / 3 > 65535 ? new THREE.Uint32BufferAttribute(data.indices, 1) : new THREE.Uint16BufferAttribute(data.indices, 1));
  geometry.computeBoundingSphere();
  return geometry;
}

export function buildCloudGeometry(unit, seed) { return meshVoxels(buildCloudGrid(unit, seed), unit, { center: false }); }

export function buildVoxelClouds({ size = 224, quality = 'high', count = 12, seed = 7 } = {}) {
  const unit = CLOUD_VOXEL_SIZE[quality] ?? 1;
  const group = new THREE.Group();
  group.name = 'AtmosphericClouds';
  const material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0, emissive: 0xffffff, emissiveIntensity: 0.18, fog: false });
  const half = size / 2 + 30;
  const random = rng(seed);
  for (let index = 0; index < Math.max(6, count); index += 1) {
    const mesh = new THREE.Mesh(buildCloudGeometry(unit, seed * 131 + index * 17), material);
    mesh.position.set((random() * 2 - 1) * half, 60 + random() * 22, (random() * 2 - 1) * half);
    mesh.userData.speed = 0.8 + random() * 1.1;
    mesh.userData.wrap = half;
    mesh.castShadow = false;
    mesh.receiveShadow = false;
    group.add(mesh);
  }
  group.userData.material = material;
  return group;
}

export function updateVoxelClouds(group, delta) {
  if (!group) return;
  for (const cloud of group.children) {
    if (!cloud.userData.wrap) continue;
    cloud.position.x += cloud.userData.speed * delta;
    if (cloud.position.x > cloud.userData.wrap) cloud.position.x -= cloud.userData.wrap * 2;
  }
}

// ─── Système : arbres instanciés par espèce, variante et secteur ────────────────────────────

export class MicroVoxelDecor {
  constructor(scene, world, { touchMode = false } = {}) {
    this.scene = scene;
    this.world = world;
    this.quality = touchMode ? 'mobile' : 'high';
    this.group = new THREE.Group();
    this.group.name = 'MicroVoxelDecor';
    this.scene.add(this.group);
    this.windUniform = { value: 0 };
    this.material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.88, metalness: 0 });
    this.material.onBeforeCompile = (shader) => {
      shader.uniforms.uWindTime = this.windUniform;
      shader.vertexShader = shader.vertexShader
        .replace('#include <common>', '#include <common>\nattribute float aSway;\nuniform float uWindTime;')
        .replace('#include <begin_vertex>', `#include <begin_vertex>
          #ifdef USE_INSTANCING
            float phase = instanceMatrix[3].x * 0.37 + instanceMatrix[3].z * 0.29;
          #else
            float phase = 0.0;
          #endif
          transformed.x += sin(uWindTime * 1.4 + phase + transformed.y * 0.6) * aSway * 0.045;
          transformed.z += cos(uWindTime * 1.1 + phase * 1.3) * aSway * 0.035;`);
    };
    this.stats = { trees: 0, templates: 0, meshes: 0, triangles: 0 };
  }

  setQuality(id) {
    if (!MICRO_VOXEL_SIZE[id] || id === this.quality) { this.quality = MICRO_VOXEL_SIZE[id] ? id : this.quality; return; }
    this.quality = id;
    this.rebuild();
  }

  setWorld(definition) { this.definition = definition; this.rebuild(); }

  clear() {
    for (const mesh of [...this.group.children]) { this.group.remove(mesh); mesh.geometry?.dispose?.(); mesh.dispose?.(); }
  }

  rebuild() {
    this.clear();
    const trees = this.world.decorTrees ?? [];
    const unit = MICRO_VOXEL_SIZE[this.quality] ?? 0.25;
    const variants = 3;
    const templates = new Map();
    const sector = 32;
    const buckets = new Map();
    for (const tree of trees) {
      const variant = Math.floor(tree.variant * 997) % variants;
      const templateKey = `${tree.species}:${variant}`;
      const bucketKey = `${templateKey}|${Math.floor(tree.x / sector)}|${Math.floor(tree.z / sector)}`;
      if (!buckets.has(bucketKey)) buckets.set(bucketKey, { templateKey, trees: [] });
      buckets.get(bucketKey).trees.push(tree);
      if (!templates.has(templateKey)) {
        // Deux niveaux de détail d'une même forme (même graine) : fin près de la caméra, 2,5× plus grossier au loin.
        const seed = (this.definition?.seed ?? 1) * 7919 + variant * 104729 + tree.species.length * 131;
        const coarse = Math.min(0.75, unit * 2.5);
        templates.set(templateKey, { fine: meshVoxels(buildTreeGrid(tree.species, unit, seed), unit), coarse: meshVoxels(buildTreeGrid(tree.species, coarse, seed), coarse) });
      }
    }
    const matrix = new THREE.Matrix4(), quaternion = new THREE.Quaternion(), scale = new THREE.Vector3(), position = new THREE.Vector3(), up = new THREE.Vector3(0, 1, 0);
    const tint = new THREE.Color();
    let triangles = 0;
    this.sectors = [];
    for (const { templateKey, trees: list } of buckets.values()) {
      const lods = templates.get(templateKey);
      const center = new THREE.Vector3();
      list.forEach((tree) => center.add(new THREE.Vector3(tree.x, tree.y, tree.z)));
      center.divideScalar(list.length);
      const pair = {};
      for (const level of ['fine', 'coarse']) {
      const geometry = lods[level];
      const mesh = new THREE.InstancedMesh(geometry, this.material, list.length);
      mesh.name = `MicroTrees_${templateKey}_${level}`;
      list.forEach((tree, index) => {
        const s = 0.86 + (tree.variant * 7.13 % 1) * 0.3;
        quaternion.setFromAxisAngle(up, Math.floor(tree.variant * 4000) % 4 * Math.PI / 2 + (tree.variant * 13.7 % 1) * 0.5);
        position.set(tree.x, tree.y + 0.5, tree.z);
        scale.set(s, s * (0.92 + (tree.variant * 3.3 % 1) * 0.16), s);
        mesh.setMatrixAt(index, matrix.compose(position, quaternion, scale));
        mesh.setColorAt(index, tint.setHSL(0, 0, 0.9 + (tree.variant * 5.1 % 1) * 0.16));
      });
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.instanceMatrix.needsUpdate = true;
      mesh.computeBoundingSphere();
      mesh.visible = level === 'coarse';
      this.group.add(mesh);
      pair[level] = mesh;
      if (level === 'fine') triangles += (geometry.index.count / 3) * list.length;
      }
      this.sectors.push({ center, ...pair, fineTriangles: (lods.fine.index.count / 3) * list.length, coarseTriangles: (lods.coarse.index.count / 3) * list.length });
    }
    this.stats = { trees: trees.length, templates: templates.size, meshes: this.group.children.length, trianglesMaxFins: Math.round(triangles), unit };
  }

  // Niveau de détail par secteur : fin dans un rayon ≈ 60 m (horizontal) autour de la caméra.
  update(delta, cameraPosition = null) {
    this.windUniform.value += delta;
    if (!cameraPosition || !this.sectors) return;
    let active = 0;
    for (const sector of this.sectors) {
      const near = Math.hypot(sector.center.x - cameraPosition.x, sector.center.z - cameraPosition.z) < 60;
      sector.fine.visible = near;
      sector.coarse.visible = !near;
      active += near ? sector.fineTriangles : sector.coarseTriangles;
    }
    this.stats.activeTriangles = Math.round(active);
  }
}
