
// BlockWorld V3.0 Beta 4.14 — formes du décor en mini-blocs (module pur, sans Three.js, testable sous Node).
// Les éléments purement visuels (arbres, nuages) ne sont plus construits avec les blocs de jeu
// (1 m) mais avec des mini-blocs 2 à 6 fois plus fins. Seules les faces visibles sont maillées
// (une face collée à une voisine n'est jamais dessinée) et chaque forme est instanciée par le GPU.
// Le terrain, les monuments et les constructions du joueur restent en blocs de 1 m.

export const MICRO_VOXEL_SIZE = { lite: 0.75, mobile: 0.5, standard: 0.25, high: 0.2, ultra: 1 / 6 };
export const CLOUD_VOXEL_SIZE = { lite: 3, mobile: 2, standard: 1.5, high: 1, ultra: 0.75 };

const FACES = [
  { n: [1, 0, 0], c: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]] },
  { n: [-1, 0, 0], c: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]] },
  { n: [0, 1, 0], c: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]] },
  { n: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]] },
  { n: [0, 0, 1], c: [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]] },
  { n: [0, 0, -1], c: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]] }
];


const toLinear = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
function hexToHsl(hex) {
  const r = ((hex >> 16) & 255) / 255, g = ((hex >> 8) & 255) / 255, b = (hex & 255) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2;
  if (max === min) return { h: 0, s: 0, l };
  const d = max - min, s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  const h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return { h: h / 6, s, l };
}
function hslToLinear(h, s, l) {
  const hue = (p, q, t) => { t = ((t % 1) + 1) % 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < 1 / 2) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; };
  if (s === 0) return { r: toLinear(l), g: toLinear(l), b: toLinear(l) };
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  return { r: toLinear(hue(p, q, h + 1 / 3)), g: toLinear(hue(p, q, h)), b: toLinear(hue(p, q, h - 1 / 3)) };
}
export function hexToLinear(hex) { const { h, s, l } = hexToHsl(hex); return hslToLinear(h, s, l); }

export function rng(seed) {
  let state = (seed * 2654435761) >>> 0 || 1;
  return () => { state ^= state << 13; state ^= state >>> 17; state ^= state << 5; return ((state >>> 0) % 100000) / 100000; };
}

/** Grille de mini-blocs : clé entière → { r, g, b, sway }. */
export class VoxelGrid {
  constructor() { this.cells = new Map(); }
  key(x, y, z) { return ((x + 512) * 1024 + (y + 512)) * 1024 + (z + 512); }
  set(x, y, z, color, sway = 0) { this.cells.set(this.key(x, y, z), { x, y, z, r: color.r, g: color.g, b: color.b, sway }); }
  has(x, y, z) { return this.cells.has(this.key(x, y, z)); }
  delete(x, y, z) { this.cells.delete(this.key(x, y, z)); }
  get size() { return this.cells.size; }
}

/** Maillage « faces visibles seulement » (tableaux bruts) d'une grille, à l'échelle `unit` (mètres par mini-bloc). */
export function meshVoxelArrays(grid, unit, { center = true } = {}) {
  const positions = [], normals = [], colors = [], sway = [], indices = [];
  let offsetX = 0, offsetZ = 0;
  if (center) { offsetX = -0.5; offsetZ = -0.5; }
  for (const cell of grid.cells.values()) {
    for (const face of FACES) {
      if (grid.has(cell.x + face.n[0], cell.y + face.n[1], cell.z + face.n[2])) continue;
      const base = positions.length / 3;
      // Ombrage de face léger (lisible même en lumière rasante) + occlusion par le dessous.
      const shade = face.n[1] === 1 ? 1.06 : face.n[1] === -1 ? 0.78 : 0.9;
      for (const corner of face.c) {
        positions.push((cell.x + corner[0] + offsetX) * unit, (cell.y + corner[1]) * unit, (cell.z + corner[2] + offsetZ) * unit);
        normals.push(face.n[0], face.n[1], face.n[2]);
        colors.push(cell.r * shade, cell.g * shade, cell.b * shade);
        sway.push(cell.sway);
      }
      indices.push(base, base + 1, base + 2, base, base + 2, base + 3);
    }
  }
  return { positions, normals, colors, sway, indices };
}

// ─── Formes d'arbres (en mètres, converties en mini-blocs) ──────────────────────────────────────

const SPECIES = {
  oak: { bark: 0x5b3d24, leaf: 0x3f7a32, leafAlt: 0x5a8f36 },
  pine: { bark: 0x4a3322, leaf: 0x24553a, leafAlt: 0x2f6a44 },
  acacia: { bark: 0x6d4a2c, leaf: 0x6c8a34, leafAlt: 0x87983c },
  palm: { bark: 0x8a6a45, leaf: 0x4f8f3a, leafAlt: 0x6aa345 },
  bamboo: { bark: 0x7fa04a, leaf: 0x5f9a3c, leafAlt: 0x7bb04b },
  eucalyptus: { bark: 0xb9ab93, leaf: 0x6f8f6a, leafAlt: 0x87a07c }
};

function tinted(hex, random, spread = 0.06, lift = 0) {
  const hsl = hexToHsl(hex);
  return hslToLinear(hsl.h + (random() - 0.5) * spread * 0.4, Math.min(1, hsl.s * (0.85 + random() * 0.3)), Math.max(0, Math.min(1, hsl.l * (0.82 + random() * 0.36) + lift)));
}

function fillBlob(grid, unit, cx, cy, cz, rx, ry, rz, palette, random, holes = 0.1) {
  const ix = Math.ceil(rx / unit), iy = Math.ceil(ry / unit), iz = Math.ceil(rz / unit);
  const bx = Math.round(cx / unit), by = Math.round(cy / unit), bz = Math.round(cz / unit);
  for (let x = -ix; x <= ix; x += 1) for (let y = -iy; y <= iy; y += 1) for (let z = -iz; z <= iz; z += 1) {
    const d = (x * unit / rx) ** 2 + (y * unit / ry) ** 2 + (z * unit / rz) ** 2;
    const edge = 0.78 + random() * 0.3;
    if (d > edge) continue;
    if (d > 0.55 && random() < holes) continue; // trouées de feuillage
    const top = (y + iy) / (2 * iy);
    const color = tinted(random() < 0.35 ? palette.leafAlt : palette.leaf, random, 0.08, (top - 0.5) * 0.10);
    grid.set(bx + x, by + y, bz + z, color, 1);
  }
}

function trunk(grid, unit, height, width, palette, random, { lean = 0, flare = true } = {}) {
  const steps = Math.ceil(height / unit);
  for (let s = 0; s < steps; s += 1) {
    const t = s / steps;
    const base = flare && s * unit < 0.45 ? 1.6 - s * unit / 0.45 * 0.6 : 1;
    const half = Math.max(0.5, (width * base) / unit / 2);
    const ox = Math.round((lean * t * t) / unit);
    for (let x = -Math.floor(half); x <= Math.floor(half - 0.01); x += 1) for (let z = -Math.floor(half); z <= Math.floor(half - 0.01); z += 1) {
      if (half >= 1.5 && Math.abs(x) === Math.floor(half) && Math.abs(z) === Math.floor(half)) continue; // arêtes adoucies
      grid.set(x + ox, s, z, tinted(palette.bark, random, 0.03, (random() < 0.15 ? -0.06 : 0)), t * 0.25);
    }
  }
  return Math.round((lean) / unit);
}

function branch(grid, unit, from, to, width, palette, random) {
  const length = Math.hypot(to[0] - from[0], to[1] - from[1], to[2] - from[2]);
  const steps = Math.ceil(length / (unit * 0.6));
  const r = Math.max(0, Math.floor(width / unit / 2));
  for (let i = 0; i <= steps; i += 1) {
    const t = i / steps;
    const x = Math.round((from[0] + (to[0] - from[0]) * t) / unit), y = Math.round((from[1] + (to[1] - from[1]) * t) / unit), z = Math.round((from[2] + (to[2] - from[2]) * t) / unit);
    for (let dx = -r; dx <= r; dx += 1) for (let dz = -r; dz <= r; dz += 1) grid.set(x + dx, y, z + dz, tinted(palette.bark, random, 0.03), 0.4 + t * 0.4);
  }
}

export function buildTreeGrid(species, unit, seed) {
  const random = rng(seed);
  const palette = SPECIES[species] ?? SPECIES.oak;
  const grid = new VoxelGrid();
  if (species === 'pine') {
    const height = 5.2 + random() * 1.6;
    trunk(grid, unit, height, 0.42, palette, random);
    const tiers = 5;
    for (let tier = 0; tier < tiers; tier += 1) {
      const t = tier / (tiers - 1);
      const y = height * 0.35 + t * height * 0.62;
      const radius = 2.1 - t * 1.55 + random() * 0.2;
      fillBlob(grid, unit, 0, y, 0, radius, 0.55, radius, palette, random, 0.06);
    }
    fillBlob(grid, unit, 0, height + 0.25, 0, 0.35, 0.6, 0.35, palette, random, 0);
  } else if (species === 'acacia') {
    const height = 3.4 + random() * 0.8;
    trunk(grid, unit, height * 0.6, 0.45, palette, random);
    const a = random() * Math.PI * 2;
    for (const side of [0, Math.PI * 0.9]) {
      const dx = Math.cos(a + side) * 1.3, dz = Math.sin(a + side) * 1.3;
      branch(grid, unit, [0, height * 0.55, 0], [dx, height, dz], 0.3, palette, random);
    }
    fillBlob(grid, unit, 0, height + 0.25, 0, 3.0 + random() * 0.4, 0.45, 2.6 + random() * 0.4, palette, random, 0.14);
  } else if (species === 'palm') {
    const height = 5 + random() * 1.2;
    const lean = (random() - 0.5) * 1.6;
    const top = trunk(grid, unit, height, 0.36, palette, random, { lean, flare: false });
    for (let f = 0; f < 8; f += 1) {
      const angle = (f / 8) * Math.PI * 2 + random() * 0.3;
      const length = 2.2 + random() * 0.8;
      const steps = Math.ceil(length / unit);
      for (let s = 0; s <= steps; s += 1) {
        const t = s / steps;
        const x = top + Math.round((Math.cos(angle) * length * t) / unit);
        const z = Math.round((Math.sin(angle) * length * t) / unit);
        const y = Math.round((height + 0.3 + Math.sin(t * Math.PI * 0.8) * 0.5 - t * t * 1.3) / unit);
        const w = Math.max(0, Math.round((1 - t) * 0.35 / unit));
        for (let k = -w; k <= w; k += 1) grid.set(x - Math.round(Math.sin(angle) * k), y, z + Math.round(Math.cos(angle) * k), tinted(random() < 0.4 ? palette.leafAlt : palette.leaf, random), 1);
      }
    }
  } else if (species === 'bamboo') {
    for (let stalk = 0; stalk < 6; stalk += 1) {
      const ox = (random() - 0.5) * 1.4, oz = (random() - 0.5) * 1.4;
      const height = 4.5 + random() * 2.5;
      const steps = Math.ceil(height / unit);
      for (let s = 0; s < steps; s += 1) {
        const node = (s * unit) % 0.9 < unit;
        grid.set(Math.round(ox / unit), s, Math.round(oz / unit), tinted(palette.bark, random, 0.03, node ? -0.08 : 0), s / steps * 0.6);
      }
      fillBlob(grid, unit, ox, height - 0.4, oz, 0.7, 0.45, 0.7, palette, random, 0.3);
    }
  } else if (species === 'eucalyptus') {
    const height = 5.4 + random() * 1.4;
    trunk(grid, unit, height * 0.8, 0.4, palette, random);
    for (let blob = 0; blob < 4; blob += 1) {
      const a = random() * Math.PI * 2, r = 0.6 + random() * 1.1;
      fillBlob(grid, unit, Math.cos(a) * r, height * (0.72 + random() * 0.25), Math.sin(a) * r, 1.2 + random() * 0.5, 0.8, 1.2 + random() * 0.5, palette, random, 0.2);
    }
  } else {
    // Chêne : tronc évasé, 2–3 branches, houppier en 4–5 masses.
    const height = 3.1 + random() * 1.0;
    trunk(grid, unit, height, 0.6, palette, random);
    for (let b = 0; b < 3; b += 1) {
      const a = random() * Math.PI * 2;
      branch(grid, unit, [0, height * 0.7, 0], [Math.cos(a) * 1.2, height + 0.6, Math.sin(a) * 1.2], 0.26, palette, random);
    }
    const masses = 4 + Math.floor(random() * 2);
    for (let m = 0; m < masses; m += 1) {
      const a = (m / masses) * Math.PI * 2 + random();
      const r = m === 0 ? 0 : 0.9 + random() * 0.6;
      fillBlob(grid, unit, Math.cos(a) * r, height + 0.9 + random() * 0.8, Math.sin(a) * r, 1.5 + random() * 0.5, 1.15 + random() * 0.35, 1.5 + random() * 0.5, palette, random, 0.12);
    }
  }
  return grid;
}

// ─── Nuages en mini-blocs ─────────────────────────────────────────────────────────────────────

export function buildCloudGrid(unit, seed) {
  const random = rng(seed);
  const grid = new VoxelGrid();
  const top = hexToLinear(0xffffff), bottom = hexToLinear(0xb9c4d6);
  const blobs = 4 + Math.floor(random() * 5);
  const length = 14 + random() * 22;
  for (let b = 0; b < blobs; b += 1) {
    const cx = (random() - 0.5) * length, cz = (random() - 0.5) * length * 0.55, cy = random() * 2.2;
    const rx = 4 + random() * 6, ry = 1.6 + random() * 2.2, rz = 3 + random() * 4.5;
    const ix = Math.ceil(rx / unit), iy = Math.ceil(ry / unit), iz = Math.ceil(rz / unit);
    for (let x = -ix; x <= ix; x += 1) for (let y = -iy; y <= iy; y += 1) for (let z = -iz; z <= iz; z += 1) {
      const d = (x * unit / rx) ** 2 + (Math.max(y, -iy * 0.35) * unit / ry) ** 2 + (z * unit / rz) ** 2;
      if (d > 0.82 + random() * 0.2) continue;
      if (y * unit < -ry * 0.35) continue; // base plate, comme un vrai cumulus
      const h = (y * unit + ry * 0.35 + cy) / (ry * 1.35 + 2.2);
      const k = Math.min(1, Math.max(0, h)) ** 0.8;
      const color = { r: bottom.r + (top.r - bottom.r) * k, g: bottom.g + (top.g - bottom.g) * k, b: bottom.b + (top.b - bottom.b) * k };
      grid.set(Math.round(cx / unit) + x, Math.round(cy / unit) + y, Math.round(cz / unit) + z, color, 0);
    }
  }
  return grid;
}

