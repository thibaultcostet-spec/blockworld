import * as THREE from 'three';
import { MAPUTO_BRIDGE } from '../worlds/continents/AfricaWorld.js';
import { GOLDEN_GATE, HARBOUR_BRIDGE, archRibY } from '../worlds/monuments/Bridges.js';

function canvasTexture(draw) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const context = canvas.getContext('2d');
  draw(context, canvas);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  return texture;
}

function plaqueTexture(name, region) {
  return canvasTexture((ctx, canvas) => {
    const gradient = ctx.createLinearGradient(0,0,canvas.width,canvas.height);
    gradient.addColorStop(0,'#251a12');
    gradient.addColorStop(1,'#6b4b2d');
    ctx.fillStyle=gradient;
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.strokeStyle='#e5c277';
    ctx.lineWidth=10;
    ctx.strokeRect(12,12,canvas.width-24,canvas.height-24);
    ctx.fillStyle='#fff2cf';
    ctx.textAlign='center';
    ctx.font='bold 38px sans-serif';
    ctx.fillText(name.slice(0,28),canvas.width/2,105);
    ctx.fillStyle='#d6bd91';
    ctx.font='24px sans-serif';
    ctx.fillText((region||'Patrimoine mondial').slice(0,38),canvas.width/2,158);
  });
}

function pavingTexture(theme) {
  return canvasTexture((ctx, canvas) => {
    const base = theme==='africa'?'#c8a66a':theme==='asia'?'#a89a86':theme==='oceania'?'#8f9b91':'#96999a';
    ctx.fillStyle=base;
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.strokeStyle='rgba(255,255,255,.20)';
    ctx.lineWidth=3;
    for(let y=0;y<canvas.height;y+=32){for(let x=(y/32)%2?16:0;x<canvas.width;x+=64)ctx.strokeRect(x,y,64,32);}
    ctx.strokeStyle='rgba(35,30,24,.23)';
    ctx.lineWidth=2;
    for(let i=0;i<180;i++){const x=(i*83)%canvas.width,y=(i*47)%canvas.height;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+8+(i%9),y+3);ctx.stroke();}
  });
}


function softDiscTexture(color='#ffffff') {
  return canvasTexture((ctx,canvas)=>{
    const g=ctx.createRadialGradient(canvas.width/2,canvas.height/2,8,canvas.width/2,canvas.height/2,canvas.width*.48);
    g.addColorStop(0,color.replace(')',',.72)').replace('rgb','rgba'));
    g.addColorStop(.45,color.replace(')',',.28)').replace('rgb','rgba'));
    g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(0,0,canvas.width,canvas.height);
  });
}

export class MonumentVisualEnhancer {
  constructor(scene,world){
    this.scene=scene;this.world=world;this.group=new THREE.Group();this.group.name='MonumentsV3Hybrid';scene.add(this.group);this.quality='high';this.elapsed=0;
  }
  clear(){
    for(const child of [...this.group.children]){
      this.group.remove(child);
      child.traverse?.((object)=>{object.geometry?.dispose?.();const materials=Array.isArray(object.material)?object.material:[object.material];for(const material of materials)material?.dispose?.();});
    }
  }
  setQuality(id){this.quality=id;if(this.definition)this.setWorld(this.definition);}
  setWorld(definition){this.definition=definition;this.clear();for(const poi of definition.pointsOfInterest||[])this.decorate(poi,definition.theme);}

  // Beta 4.10 : altitude du sol naturel autour du monument. Avant, l'esplanade était calée sur
  // le bloc le plus haut au centre du point d'intérêt, c'est-à-dire le sommet du monument
  // (≈ 34 m pour la tour Eiffel) : bancs, lampadaires et plaques flottaient dans le ciel.
  // On échantillonne trois couronnes (11, 13, 15 blocs), on écarte les blocs du monument qui
  // mordraient sur une partie des couronnes, puis on retient la médiane du terrain restant.
  naturalGround(poi){
    const samples=[];
    for(const radius of [11,13,15])for(let index=0;index<16;index++){
      const angle=index/16*Math.PI*2;
      const height=this.world.getSurfaceHeight(poi.x+Math.cos(angle)*radius,poi.z+Math.sin(angle)*radius);
      if(height>0)samples.push(height);
    }
    const center=this.world.getSurfaceHeight(poi.x,poi.z)||1;
    if(!samples.length)return center;
    samples.sort((a,b)=>a-b);
    // Écarte les murs du monument (> 3 blocs au-dessus du bas du terrain), puis médiane du reste.
    const floor=samples[Math.floor(samples.length*.1)];
    const terrain=samples.filter((height)=>height<=floor+3);
    return Math.min(center,terrain[Math.floor(terrain.length/2)]);
  }

  decorate(poi,theme){
    const group=new THREE.Group();group.name=`HeritageScene_${poi.id}`;
    group.position.set(poi.x,this.naturalGround(poi)+.035,poi.z);
    // Beta 4.30 : un monument peut placer son esplanade sur un belvédère (le pont Maputo est au-dessus de la baie).
    if(poi.viewpoint)group.position.set(poi.viewpoint.x,this.naturalGround(poi.viewpoint)+.035,poi.viewpoint.z);
    const plazaTexture=pavingTexture(theme);
    plazaTexture.wrapS=plazaTexture.wrapT=THREE.RepeatWrapping;
    plazaTexture.repeat.set(4,4);
    const stone=new THREE.MeshStandardMaterial({map:plazaTexture,color:0xffffff,roughness:.86,metalness:0});
    const darkStone=new THREE.MeshStandardMaterial({color:theme==='africa'?0x8f6e42:0x555b5d,roughness:.93});
    const metal=new THREE.MeshStandardMaterial({color:0x27333a,roughness:.34,metalness:.62});
    const warm=new THREE.MeshStandardMaterial({color:0xffd382,emissive:0xff8a35,emissiveIntensity:2.1,roughness:.28});
    const wood=new THREE.MeshStandardMaterial({color:0x6a4328,roughness:.9});

    const plaza=new THREE.Mesh(new THREE.CircleGeometry(10.5,64),stone);plaza.rotation.x=-Math.PI/2;plaza.receiveShadow=true;group.add(plaza);
    const ring=new THREE.Mesh(new THREE.RingGeometry(10.4,11.05,64),darkStone);ring.rotation.x=-Math.PI/2;ring.position.y=.012;ring.receiveShadow=true;group.add(ring);
    for(let arm=0;arm<4;arm++){
      const path=new THREE.Mesh(new THREE.PlaneGeometry(5.5,2.2),stone);path.rotation.x=-Math.PI/2;path.rotation.z=arm*Math.PI/2;path.position.set(Math.sin(arm*Math.PI/2)*12.7,.018,Math.cos(arm*Math.PI/2)*12.7);path.receiveShadow=true;group.add(path);
    }

    const lampCount=this.quality==='mobile'?4:this.quality==='standard'?8:12;
    for(let index=0;index<lampCount;index++){
      const angle=index/lampCount*Math.PI*2;
      const lamp=new THREE.Group();
      const pole=new THREE.Mesh(new THREE.CylinderGeometry(.055,.09,2.05,8),metal);pole.position.y=1.02;pole.castShadow=true;lamp.add(pole);
      const crown=new THREE.Mesh(new THREE.CylinderGeometry(.16,.11,.24,8),warm);crown.position.y=2.08;lamp.add(crown);
      const cap=new THREE.Mesh(new THREE.ConeGeometry(.22,.18,8),metal);cap.position.y=2.29;lamp.add(cap);
      lamp.position.set(Math.cos(angle)*9.55,0,Math.sin(angle)*9.55);group.add(lamp);
    }

    const planterMaterial=new THREE.MeshStandardMaterial({color:theme==='africa'?0xb28a56:0x797c76,roughness:.92});
    const leafMaterial=new THREE.MeshStandardMaterial({color:theme==='africa'?0x6f8f42:0x3f7f48,roughness:.88});
    for(let index=0;index<6;index++){
      const angle=index/6*Math.PI*2+Math.PI/6;
      const planter=new THREE.Mesh(new THREE.CylinderGeometry(.52,.62,.42,10),planterMaterial);planter.position.set(Math.cos(angle)*7.7,.21,Math.sin(angle)*7.7);planter.castShadow=true;planter.receiveShadow=true;group.add(planter);
      const shrub=new THREE.Mesh(new THREE.IcosahedronGeometry(.52,1),leafMaterial);shrub.scale.set(1,1.2,1);shrub.position.set(planter.position.x,.82,planter.position.z);shrub.castShadow=true;group.add(shrub);
    }

    for(let side of [-1,1]){
      const bench=new THREE.Group();
      const seat=new THREE.Mesh(new THREE.BoxGeometry(2.1,.16,.48),wood);seat.position.y=.62;seat.castShadow=true;bench.add(seat);
      const back=new THREE.Mesh(new THREE.BoxGeometry(2.1,.65,.12),wood);back.position.set(0,.94,.19);back.rotation.x=-.12;bench.add(back);
      for(const x of [-.78,.78]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.12,.55,.38),metal);leg.position.set(x,.28,0);bench.add(leg);}
      bench.position.set(side*5.2,0,8.45);bench.rotation.y=side*.08;group.add(bench);
    }

    const plaqueMap=plaqueTexture(poi.name,poi.region);
    const plaque=new THREE.Mesh(new THREE.PlaneGeometry(3.15,1.55),new THREE.MeshStandardMaterial({map:plaqueMap,roughness:.62,metalness:.08,side:THREE.DoubleSide}));
    plaque.position.set(0,1.15,10.3);plaque.rotation.x=-.15;group.add(plaque);
    const plaqueBase=new THREE.Mesh(new THREE.BoxGeometry(3.4,.72,.42),darkStone);plaqueBase.position.set(0,.36,10.45);plaqueBase.castShadow=true;group.add(plaqueBase);

    this.addThemeDetails(group,theme,metal,warm,stone,darkStone);
    this.addIdentityDetails(group,poi,theme,{metal,warm,stone,darkStone,wood});
    const beacon=new THREE.PointLight(0xffbd78,this.quality==='mobile'?0:this.quality==='ultra'?3.0:1.8,22,2);beacon.position.y=5.4;beacon.castShadow=false;group.add(beacon);
    group.userData.beacon=beacon;group.userData.baseIntensity=beacon.intensity;group.userData.poi=poi;
    this.group.add(group);
  }

  addThemeDetails(group,theme,metal,warm,stone,darkStone){
    if(theme==='asia'){
      const red=new THREE.MeshStandardMaterial({color:0x8f2f2e,roughness:.78});
      for(const side of [-1,1]){
        const gate=new THREE.Group();
        for(const x of [-1,1]){const post=new THREE.Mesh(new THREE.CylinderGeometry(.12,.15,2.5,8),red);post.position.set(x*.85,1.25,0);gate.add(post);}
        const beam=new THREE.Mesh(new THREE.BoxGeometry(2.4,.22,.3),red);beam.position.y=2.35;gate.add(beam);
        const roof=new THREE.Mesh(new THREE.BoxGeometry(2.8,.18,.5),darkStone);roof.position.y=2.65;roof.rotation.z=side*.03;gate.add(roof);
        gate.position.set(side*12.6,0,0);gate.rotation.y=Math.PI/2;group.add(gate);
      }
    } else if(theme==='africa'){
      for(const side of [-1,1]){const obelisk=new THREE.Mesh(new THREE.ConeGeometry(.42,3.2,4),stone);obelisk.position.set(side*8.7,1.6,-5.8);obelisk.rotation.y=Math.PI/4;obelisk.castShadow=true;group.add(obelisk);}
    } else if(theme==='oceania'){
      const waterMat=new THREE.MeshPhysicalMaterial({color:0x48a8bd,roughness:.18,metalness:.02,transparent:true,opacity:.72});
      for(const side of [-1,1]){const basin=new THREE.Mesh(new THREE.CylinderGeometry(1.25,1.4,.26,24),darkStone);basin.position.set(side*6.8,.13,-7.2);group.add(basin);const water=new THREE.Mesh(new THREE.CircleGeometry(1.16,24),waterMat);water.rotation.x=-Math.PI/2;water.position.set(side*6.8,.28,-7.2);group.add(water);}
    } else if(theme==='americas'){
      for(const side of [-1,1]){const flag=new THREE.Group();const pole=new THREE.Mesh(new THREE.CylinderGeometry(.035,.05,3.1,8),metal);pole.position.y=1.55;flag.add(pole);const cloth=new THREE.Mesh(new THREE.PlaneGeometry(1.15,.65),new THREE.MeshStandardMaterial({color:side<0?0x3e6aa3:0xb84a3e,side:THREE.DoubleSide,roughness:.82}));cloth.position.set(.58,2.45,0);flag.add(cloth);flag.position.set(side*8.4,0,-6.5);group.add(flag);}
    } else {
      for(const side of [-1,1]){const arch=new THREE.Group();for(const x of [-1,1]){const pillar=new THREE.Mesh(new THREE.BoxGeometry(.35,2.4,.35),stone);pillar.position.set(x*.95,1.2,0);arch.add(pillar);}const top=new THREE.Mesh(new THREE.BoxGeometry(2.35,.38,.5),stone);top.position.y=2.42;arch.add(top);arch.position.set(side*12.6,0,0);arch.rotation.y=Math.PI/2;group.add(arch);}
    }
  }

  addIdentityDetails(group,poi,theme,{metal,warm,stone,darkStone,wood}){
    const id=poi.id;
    const leaf=new THREE.MeshStandardMaterial({color:theme==='africa'?0x6f8744:0x315f3a,roughness:.92});
    const sand=new THREE.MeshStandardMaterial({color:0xcaa469,roughness:1});
    const water=new THREE.MeshPhysicalMaterial({color:0x2a91b8,roughness:.10,metalness:.02,transparent:true,opacity:.72,clearcoat:.45});
    const redStone=new THREE.MeshStandardMaterial({color:0x9d4f32,roughness:.96});
    const addTree=(x,z,height=3)=>{
      const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.10,.15,height*.55,7),wood);trunk.position.set(x,height*.275,z);trunk.castShadow=true;group.add(trunk);
      const crown=new THREE.Mesh(new THREE.ConeGeometry(.55,height*.72,9,2),leaf);crown.position.set(x,height*.72,z);crown.castShadow=true;group.add(crown);
    };
    const addApproachLights=(spacing=2.3,count=7)=>{
      for(const side of [-1,1])for(let i=0;i<count;i++){
        const lamp=new THREE.Mesh(new THREE.SphereGeometry(.075,8,6),warm);lamp.position.set(side*(2.2+i*spacing),.24,-8.9);group.add(lamp);
      }
    };

    if(id==='taj-mahal'){
      const poolBase=new THREE.Mesh(new THREE.BoxGeometry(3.2,.18,13.5),darkStone);poolBase.position.set(0,.10,-7.6);group.add(poolBase);
      const pool=new THREE.Mesh(new THREE.PlaneGeometry(2.85,13.1),water);pool.rotation.x=-Math.PI/2;pool.position.set(0,.205,-7.6);group.add(pool);
      for(const side of [-1,1])for(const z of [-3.1,-6.2,-9.3,-12.0])addTree(side*2.55,z,2.8);
    }else if(id==='giza'){
      for(let i=0;i<10;i++){const mound=new THREE.Mesh(new THREE.SphereGeometry(1.6+(i%3)*.55,14,8,0,Math.PI*2,0,Math.PI/2),sand);mound.scale.set(1.8,.42,1);mound.position.set(-13+(i*3.1)%26,-.05,-10+(i%4)*6.1);mound.rotation.y=i*.61;group.add(mound);}
    }else if(id==='machu-picchu'){
      const mistMap=softDiscTexture('rgb(220,238,245)');
      for(let i=0;i<7;i++){const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:mistMap,transparent:true,opacity:.16+(i%3)*.05,depthWrite:false,fog:true}));sprite.scale.set(7+(i%4)*2.2,2.2+(i%3),1);sprite.position.set(-11+i*3.6,1.1+(i%2)*.9,-8+(i%3)*7);sprite.userData.mist=true;sprite.userData.phase=i*.8;group.add(sprite);}
      for(const side of [-1,1])for(let step=0;step<4;step++){const terrace=new THREE.Mesh(new THREE.BoxGeometry(4.2-step*.35,.18,1.1),stone);terrace.position.set(side*(6.4+step*.55),.12+step*.18,-5+step*2.2);group.add(terrace);}
    }else if(['eiffel','liberty','christ','sky-tower'].includes(id)){
      for(let side=0;side<4;side++){const a=side*Math.PI/2;const light=new THREE.SpotLight(side%2?0x9fc8ff:0xffcf8c,this.quality==='ultra'?8:4.2,34,.30,.75,1.3);light.position.set(Math.cos(a)*8.7,.35,Math.sin(a)*8.7);light.target.position.set(0,8,0);group.add(light,light.target);}
    }else if(id==='colosseum'){
      for(const side of [-1,1])for(const z of [-7,-2.5,2.5,7])addTree(side*10.2,z,4.2);
      for(let i=0;i<5;i++){const fragment=new THREE.Mesh(new THREE.CylinderGeometry(.18,.23,1.5+i*.15,10),stone);fragment.position.set(-4+i*2,fragment.geometry.parameters.height/2,11.6);group.add(fragment);}
    }else if(id==='maputo'){
      this.addSuspensionCables(group,poi);
    }else if(id==='golden-gate'){
      addApproachLights(2.15,6);
      this.addSuspensionCables(group,poi,GOLDEN_GATE); // vrais câbles porteurs et suspentes, comme à Maputo
    }else if(id==='harbour-bridge'){
      addApproachLights(2.15,6);
      this.addArchHangers(group,poi,HARBOUR_BRIDGE); // l'arche est en blocs, ses suspentes sont de fins fils
    }else if(id==='great-wall'){
      for(let i=-6;i<=6;i++){const lantern=new THREE.Mesh(new THREE.SphereGeometry(.09,8,6),warm);lantern.position.set(i*1.6,.55+Math.abs(i)*.08,-9.2+Math.sin(i*.8)*.7);group.add(lantern);}
    }else if(id==='angkor'){
      for(const side of [-1,1])for(const z of [-8,-4,0,4,8])addTree(side*10.4,z,3.5+(Math.abs(z)%3)*.3);
      const moat=new THREE.Mesh(new THREE.RingGeometry(11.4,13.1,64),water);moat.rotation.x=-Math.PI/2;moat.position.y=.03;group.add(moat);
    }else if(id==='sydney-opera'){
      const harbour=new THREE.Mesh(new THREE.CircleGeometry(12.8,64,0,Math.PI),water);harbour.rotation.x=-Math.PI/2;harbour.rotation.z=Math.PI;harbour.position.set(0,.03,-1.2);group.add(harbour);
      for(let i=-5;i<=5;i++){const bollard=new THREE.Mesh(new THREE.CylinderGeometry(.09,.12,.65,8),metal);bollard.position.set(i*1.7,.33,9.2);group.add(bollard);}
    }else if(id==='uluru'){
      for(let i=0;i<18;i++){const rock=new THREE.Mesh(new THREE.DodecahedronGeometry(.35+(i%4)*.16,0),redStone);rock.scale.set(1.4,.7,1);rock.position.set(-12+(i*3.7)%24,.2,-10+(i%5)*4.6);rock.rotation.set(i*.17,i*.41,i*.08);group.add(rock);}
    }else if(id==='moai'){
      for(let i=-5;i<=5;i++){const platform=new THREE.Mesh(new THREE.BoxGeometry(1.05,.22,2.2),darkStone);platform.position.set(i*1.65,.11,-9.8);group.add(platform);}
    }else if(id==='petronas'){
      const fountainBase=new THREE.Mesh(new THREE.CylinderGeometry(3.0,3.2,.25,32),darkStone);fountainBase.position.set(0,.13,-8.4);group.add(fountainBase);
      const fountain=new THREE.Mesh(new THREE.CircleGeometry(2.85,32),water);fountain.rotation.x=-Math.PI/2;fountain.position.set(0,.27,-8.4);group.add(fountain);
    }
  }

  // Beta 4.30 : câbles porteurs (paraboles entre les pylônes, droites vers les massifs d'ancrage) et suspentes
  // verticales tous les 2 m jusqu'aux poutres de rive du tablier. Coordonnées du monde ramenées au groupe.
  addSuspensionCables(group,poi,B=MAPUTO_BRIDGE){ // Beta 4.34 : fiche du pont en paramètre (Maputo par défaut, Golden Gate)
    const o=group.position;
    const cableMat=new THREE.MeshStandardMaterial({color:0xd8dde2,roughness:.35,metalness:.75});
    const hangerMat=new THREE.MeshStandardMaterial({color:0xb9c0c7,roughness:.4,metalness:.7});
    const deckTop=B.deckY+.5, top=B.topY+.4, sag=B.deckY+B.sagY;
    const P=(x,y,z)=>new THREE.Vector3(B.cx+x-o.x,y-o.y,B.cz+z-o.z);
    const mainY=(x)=>{const t=x/B.pylonX;return sag+(top-sag)*t*t;};
    for(const side of [-1,1]){
      const z=side*B.cableZ;
      const main=[];for(let x=-B.pylonX;x<=B.pylonX;x+=1)main.push(P(x,mainY(x),z));
      group.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(main),88,.16,8,false),cableMat));
      for(const end of [-1,1]){
        const back=[];for(let i=0;i<=10;i+=1){const t=i/10;const x=end*(B.pylonX+(B.anchorX+1-B.pylonX)*t);const y=top+(B.deckY+2.6-top)*t-Math.sin(t*Math.PI)*1.2;back.push(P(x,y,z));}
        group.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(back),24,.16,8,false),cableMat));
      }
      const hanger=new THREE.CylinderGeometry(.045,.045,1,6);
      for(let x=-B.pylonX+2;x<=B.pylonX-2;x+=2){
        const yTop=mainY(x),length=Math.max(.2,yTop-deckTop);
        const h=new THREE.Mesh(hanger,hangerMat);h.scale.y=length;h.position.copy(P(x,deckTop+length/2,z));group.add(h);
      }
    }
  }

  // Beta 4.34 : suspentes verticales de l'arche (tous les 2 m, de la nervure à la poutre de rive), comme les suspentes de Maputo.
  addArchHangers(group,poi,B){
    const o=group.position;
    const mat=new THREE.MeshStandardMaterial({color:0xc4cbd1,roughness:.4,metalness:.7});
    const geometry=new THREE.CylinderGeometry(.05,.05,1,6);
    const deckTop=B.deckY+.5;
    for(const side of [-1,1])for(let x=-B.archX+2;x<=B.archX-2;x+=2){
      const bottom=archRibY(B,x)-1.5,length=Math.max(.2,bottom-deckTop);
      const h=new THREE.Mesh(geometry,mat);h.scale.y=length;h.position.set(B.cx+x-o.x,deckTop+length/2-o.y,B.cz+side*B.ribZ-o.z);group.add(h);
    }
  }

  update(player){
    this.elapsed+=.016;
    if(!player)return;
    for(const group of this.group.children){
      const distance=group.position.distanceTo(player);group.visible=distance<190;
      if(group.userData.beacon){const night=this.scene.background?.isColor?Math.max(0,.52-this.scene.background.getHSL({h:0,s:0,l:0}).l):0;group.userData.beacon.intensity=group.userData.baseIntensity*(.55+night*3.4);}
      for(const child of group.children)if(child.userData?.mist){child.position.x+=Math.sin(this.elapsed*.22+child.userData.phase)*.0025;child.material.opacity=.14+.055*Math.sin(this.elapsed*.45+child.userData.phase);}
    }
  }
}
