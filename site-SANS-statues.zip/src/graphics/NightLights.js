// BlockWorld V3.0 Beta 4.27 — lumières de nuit : lanternes (blocs) et feux de camp éclairent réellement leurs abords.
// Un petit lot fixe de lumières ponctuelles est réattribué aux sources les plus proches (nombre constant : pas de
// recompilation des matériaux). Les lanternes s'allument au crépuscule ; les feux de camp brûlent jour et nuit.
import * as THREE from 'three';

export const NIGHT_LIGHT_POOL = { lite: 0, mobile: 2, standard: 3, high: 5, ultra: 6 };
export const LANTERN_LIGHT = { color: 0xffb25a, intensity: 1.7, distance: 9 };

/** Choisit les `count` sources les plus proches dans un rayon donné (pur, testable). */
export function pickNearestSources(sources, eye, count, radius = 42) {
  if (count <= 0) return [];
  return sources
    .map((source) => ({ source, d: Math.hypot(source.position.x - eye.x, source.position.y - eye.y, source.position.z - eye.z) }))
    .filter((entry) => entry.d <= radius)
    .sort((a, b) => a.d - b.d)
    .slice(0, count)
    .map((entry) => entry.source);
}

export class NightLights {
  constructor(game) {
    this.game = game;
    this.lights = [];
    this.lanterns = [];
    this.headDirection = new THREE.Vector3();
    this.refresh = 0;
    this.active = [];
    this.setQuality(game.graphicsQuality?.id ?? 'standard');
  }

  setQuality(id) {
    const count = NIGHT_LIGHT_POOL[id] ?? 3;
    if (count === this.lights.length) return;
    for (const light of this.lights) this.game.scene.remove(light);
    this.lights = Array.from({ length: count }, () => {
      const light = new THREE.PointLight(0xffb25a, 0, 9, 1.6);
      light.castShadow = false;
      this.game.scene.add(light);
      return light;
    });
  }

  /** Relevé des lanternes du monde (au chargement d'une carte et après une pose / casse de lanterne). */
  scanLanterns() {
    const blocks = this.game.world?.blocks;
    this.lanterns = [];
    if (!blocks?.values) return;
    for (const block of blocks.values()) {
      if (block.type === 'lantern') this.lanterns.push({ position: new THREE.Vector3(block.x, block.y, block.z), ...LANTERN_LIGHT, lantern: true });
    }
  }

  update(delta, eye) {
    if (!this.lights.length || !eye) return;
    const daylight = this.game.atmosphere?.daylight ?? 1;
    const cave = this.game.caves?.factor ?? 0;   // Beta 4.32 : 0 dehors → 1 au fond de la grotte
    const dusk = Math.max(THREE.MathUtils.clamp((0.62 - daylight) / 0.4, 0, 1), cave);   // 0 de jour → 1 la nuit (ou dans la grotte)
    this.refresh -= delta;
    if (this.refresh <= 0) {
      this.refresh = 0.4;
      const fires = this.game.campfires?.lightSources?.() ?? [];
      const crystals = this.game.caves?.lightSources?.() ?? [];
      const candidates = dusk > 0.02 ? [...fires, ...this.lanterns, ...crystals] : fires;
      this.active = pickNearestSources(candidates, eye, this.lights.length);
    }
    const fires = this.game.campfires?.lightSources?.() ?? [];
    this.lights.forEach((light, index) => {
      const source = this.active[index];
      if (!source) { light.intensity = 0; return; }
      const live = source.lantern ? source : (fires.find((f) => f.position.distanceToSquared(source.position) < 0.01) ?? source);
      light.position.copy(live.position);
      light.color.setHex(live.color);
      light.distance = live.distance;
      const strength = live.lantern ? dusk : 0.35 + 0.65 * dusk;
      light.intensity = live.intensity * strength;
    });
    // Beta 4.32 : lampe frontale automatique dans la grotte (dernière lumière du lot : les sources les plus proches gardent la leur).
    if (cave > 0.03 && this.lights.length) {
      const lamp = this.lights[this.lights.length - 1];
      this.game.camera.getWorldDirection(this.headDirection);
      lamp.position.set(eye.x + this.headDirection.x * 0.5, eye.y + this.headDirection.y * 0.5, eye.z + this.headDirection.z * 0.5);
      lamp.color.setHex(0xffe6bf);
      lamp.distance = 24;
      lamp.decay = 1.2; // atténuation douce : la lampe éclaire encore les parois d'une salle de 6 m de rayon
      lamp.intensity = 5.5 * cave;
    }
  }
}
