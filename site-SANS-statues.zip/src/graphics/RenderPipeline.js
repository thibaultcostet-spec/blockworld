import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { FXAAShader } from 'three/addons/shaders/FXAAShader.js';

const DETAIL_SHADER={
  uniforms:{tDiffuse:{value:null},uResolution:{value:new THREE.Vector2(1/1280,1/720)},uSharpness:{value:.28},uClarity:{value:.10}},
  vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
  fragmentShader:`
    uniform sampler2D tDiffuse;uniform vec2 uResolution;uniform float uSharpness;uniform float uClarity;varying vec2 vUv;
    void main(){
      vec3 c=texture2D(tDiffuse,vUv).rgb;
      vec3 n=texture2D(tDiffuse,vUv+vec2(0.0,uResolution.y)).rgb;
      vec3 s=texture2D(tDiffuse,vUv-vec2(0.0,uResolution.y)).rgb;
      vec3 e=texture2D(tDiffuse,vUv+vec2(uResolution.x,0.0)).rgb;
      vec3 w=texture2D(tDiffuse,vUv-vec2(uResolution.x,0.0)).rgb;
      vec3 blur=(n+s+e+w)*.25;vec3 detail=c-blur;
      float edge=clamp(length(detail)*2.4,0.0,1.0);
      vec3 result=c+detail*uSharpness*(.45+edge*.55);
      float luma=dot(result,vec3(.299,.587,.114));result=mix(result,vec3(luma),-uClarity*edge);
      gl_FragColor=vec4(result,1.0);
    }`
};

const CINEMATIC_SHADER={
  uniforms:{tDiffuse:{value:null},uStrength:{value:.5},uVignette:{value:.14},uWarmth:{value:.035},uLift:{value:.015}},
  vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
  fragmentShader:`
    uniform sampler2D tDiffuse;
    uniform float uStrength;
    uniform float uVignette;
    uniform float uWarmth;
    uniform float uLift;
    varying vec2 vUv;
    void main(){
      vec4 c=texture2D(tDiffuse,vUv);
      float l=dot(c.rgb,vec3(.299,.587,.114));
      c.rgb=mix(c.rgb,vec3(l),-.13*uStrength);
      c.rgb+=vec3(uWarmth,-uWarmth*.12,-uWarmth*.42)*uStrength;
      c.rgb=(c.rgb-.5)*(1.0+.18*uStrength)+.5+uLift;
      float d=distance(vUv,vec2(.5));
      c.rgb*=1.0-uVignette*smoothstep(.24,.73,d);
      c.rgb=pow(max(c.rgb,vec3(0.0)),vec3(.98));
      gl_FragColor=c;
    }`
};

// Beta 4.13 — perspective aérienne + rayons de soleil (post-traitement lisant la profondeur).
// Brume dont la densité décroît avec l'altitude, bleutée à l'opposé du soleil et dorée vers lui ;
// rayons obtenus en remontant de chaque pixel vers le soleil à l'écran à travers les trouées de ciel.
const ATMOSPHERE_SHADER={
  defines:{RAY_SAMPLES:24},
  uniforms:{
    tDiffuse:{value:null},tDepth:{value:null},uProjInv:{value:new THREE.Matrix4()},uViewInv:{value:new THREE.Matrix4()},
    uCamPos:{value:new THREE.Vector3()},uSunDir:{value:new THREE.Vector3(0,1,0)},uSunScreen:{value:new THREE.Vector2(.5,.5)},
    uSunVisible:{value:0},uFogCool:{value:new THREE.Color(0x9fb8d0)},uFogWarm:{value:new THREE.Color(0xffc27a)},
    uDensity:{value:.006},uHeightFalloff:{value:.055},uBaseHeight:{value:2},uMaxFog:{value:.82},
    uRayStrength:{value:.55},uGlow:{value:.5},uAspect:{value:1.78}
  },
  vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
  fragmentShader:`
    uniform sampler2D tDiffuse;uniform sampler2D tDepth;uniform mat4 uProjInv;uniform mat4 uViewInv;
    uniform vec3 uCamPos;uniform vec3 uSunDir;uniform vec2 uSunScreen;uniform float uSunVisible;
    uniform vec3 uFogCool;uniform vec3 uFogWarm;uniform float uDensity;uniform float uHeightFalloff;
    uniform float uBaseHeight;uniform float uMaxFog;uniform float uRayStrength;uniform float uGlow;uniform float uAspect;
    varying vec2 vUv;
    void main(){
      vec4 base=texture2D(tDiffuse,vUv);
      float depth=texture2D(tDepth,vUv).x;
      bool sky=depth>=.99999;
      vec4 view=uProjInv*vec4(vUv*2.0-1.0,depth*2.0-1.0,1.0);view/=view.w;
      vec3 world=(uViewInv*vec4(view.xyz,1.0)).xyz;
      vec3 ray=world-uCamPos;float dist=length(ray);vec3 dir=ray/max(dist,1e-4);
      float mu=max(dot(dir,normalize(uSunDir)),0.0);
      vec3 haze=mix(uFogCool,uFogWarm*.72,clamp(pow(mu,5.0)*.85+mu*.10,0.0,1.0));
      vec3 color=base.rgb;
      if(!sky){
        float height=max(0.0,(uCamPos.y+world.y)*.5-uBaseHeight);
        float fog=1.0-exp(-uDensity*dist*exp(-height*uHeightFalloff));
        color=mix(color,haze,clamp(fog,0.0,uMaxFog));
        color+=uFogWarm*pow(mu,18.0)*uGlow*fog*.35;
      }else{
        color+=uFogWarm*pow(mu,28.0)*uGlow*.12;
      }
      if(uSunVisible>0.001){
        vec2 toSun=uSunScreen-vUv;
        vec2 stepUv=toSun/float(RAY_SAMPLES);
        vec2 uv=vUv;float light=0.0;float weight=1.0;float total=0.0;
        for(int i=0;i<RAY_SAMPLES;i++){
          uv+=stepUv;
          if(uv.x>0.0&&uv.x<1.0&&uv.y>0.0&&uv.y<1.0)light+=step(.99999,texture2D(tDepth,uv).x)*weight;
          total+=weight;weight*=.94;
        }
        light/=total;
        vec2 d=vec2(toSun.x*uAspect,toSun.y);
        float falloff=exp(-dot(d,d)*3.2);
        color+=uFogWarm*light*falloff*uRayStrength*uSunVisible*(sky?.2:1.0);
      }
      gl_FragColor=vec4(color,base.a);
    }`
};

class AtmospherePass extends ShaderPass{
  render(renderer,writeBuffer,readBuffer,deltaTime,maskActive){
    this.uniforms.tDepth.value=readBuffer.depthTexture;
    super.render(renderer,writeBuffer,readBuffer,deltaTime,maskActive);
  }
}

export class RenderPipeline{
  constructor(game){this.game=game;this.mode='standard';this.enabled=false;this.composer=null;this.atmosphere={daylight:1,night:0,dawn:0,twilight:1,visibility:1};this.build();}
  build(){
    const game=this.game;
    const width=Math.max(1,innerWidth),height=Math.max(1,innerHeight);
    // Beta 4.13 : cibles de rendu avec texture de profondeur (lue par la passe d'atmosphère).
    const ratio=game.renderer.getPixelRatio?.()||1;
    const target=new THREE.WebGLRenderTarget(Math.round(width*ratio),Math.round(height*ratio),{type:THREE.HalfFloatType,depthTexture:new THREE.DepthTexture()});
    this.composer=new EffectComposer(game.renderer,target);
    this.composer.renderTarget2.depthTexture=new THREE.DepthTexture();
    this.composer.setSize(width,height);
    this.renderPass=new RenderPass(game.scene,game.camera);
    this.composer.addPass(this.renderPass);
    this.ssao=new SSAOPass(game.scene,game.camera,width,height);
    this.ssao.kernelRadius=10;
    this.ssao.minDistance=.002;
    this.ssao.maxDistance=.13;
    this.ssao.enabled=false;
    this.composer.addPass(this.ssao);
    this.atmospherePass=new AtmospherePass(ATMOSPHERE_SHADER);
    this.atmospherePass.enabled=false;
    this.composer.addPass(this.atmospherePass);
    this.sunScreen=new THREE.Vector3();
    this.bloom=new UnrealBloomPass(new THREE.Vector2(width,height),.14,.38,.88);
    this.composer.addPass(this.bloom);
    this.grade=new ShaderPass(CINEMATIC_SHADER);
    this.composer.addPass(this.grade);
    this.sharpen=new ShaderPass(DETAIL_SHADER);
    this.composer.addPass(this.sharpen);
    this.fxaa=new ShaderPass(FXAAShader);
    this.composer.addPass(this.fxaa);
    this.output=new OutputPass();
    this.composer.addPass(this.output);
  }
  setQuality(id){
    this.mode=id;
    this.enabled=id==='high'||id==='ultra';
    const ultra=id==='ultra';
    // Beta 4.10 : le SSAO redessine toute la scène (et sa carte d'ombres) une seconde fois
    // à chaque image ; il est réservé au profil Ultra, Élevée garde bloom, étalonnage et FXAA.
    this.ssao.enabled=ultra;
    this.composer.setPixelRatio?.(this.game.renderer.getPixelRatio?.()||1);
    this.atmospherePass.enabled=this.enabled;
    this.atmospherePass.material.defines.RAY_SAMPLES=ultra?40:24;
    this.atmospherePass.material.needsUpdate=true;
    this.atmospherePass.uniforms.uDensity.value=ultra?.0068:.0058;
    this.atmospherePass.uniforms.uRayStrength.value=ultra?.26:.19;
    this.ssao.kernelRadius=ultra?18:10;
    this.ssao.minDistance=ultra?.0015:.0025;
    this.ssao.maxDistance=ultra?.18:.11;
    this.bloom.enabled=this.enabled;
    this.grade.enabled=this.enabled;
    this.sharpen.enabled=this.enabled;
    this.fxaa.enabled=this.enabled;
    this.bloom.strength=ultra?.34:.19;
    this.bloom.radius=ultra?.58:.36;
    this.bloom.threshold=ultra?.70:.82;
    this.grade.uniforms.uStrength.value=ultra?1:.58;
    this.grade.uniforms.uVignette.value=ultra?.18:.08;
    this.grade.uniforms.uWarmth.value=ultra?.045:.025;
    this.grade.uniforms.uLift.value=ultra?.020:.009;
    this.sharpen.uniforms.uSharpness.value=ultra?.48:.27;
    this.sharpen.uniforms.uClarity.value=ultra?.16:.08;
    this.updateResolution();
  }
  updateResolution(){
    const ratio=this.game.renderer.getPixelRatio?.()||1;
    const width=Math.max(1,this.game.renderer.domElement.clientWidth*ratio),height=Math.max(1,this.game.renderer.domElement.clientHeight*ratio);
    this.sharpen?.uniforms.uResolution.value.set(1/width,1/height);
    this.fxaa?.material.uniforms.resolution.value.set(1/width,1/height);
  }
  resize(width,height){this.composer?.setSize(width,height);this.ssao?.setSize?.(width,height);this.updateResolution();}
  setAtmosphere(state={}){
    this.atmosphere={...this.atmosphere,...state};
    const night=this.atmosphere.night??0;
    const dawn=this.atmosphere.dawn??0;
    if(this.grade?.uniforms){
      const ultra=this.mode==='ultra';
      const baseStrength=ultra?1:.58;
      const baseVignette=ultra?.18:.08;
      const baseWarmth=ultra?.045:.025;
      const baseLift=ultra?.020:.009;
      this.grade.uniforms.uStrength.value=baseStrength*(1-night*.08);
      this.grade.uniforms.uVignette.value=Math.max(.02,baseVignette-night*.07);
      this.grade.uniforms.uWarmth.value=Math.max(.008,baseWarmth-dawn*.01-night*.02);
      this.grade.uniforms.uLift.value=baseLift+night*.065+dawn*.02;
    }
    if(this.bloom){
      const ultra=this.mode==='ultra';
      this.bloom.strength=(ultra?.34:.19)+night*.03;
    }
  }
  updateAtmosphereUniforms(){
    const pass=this.atmospherePass;if(!pass?.enabled)return;
    const camera=this.game.camera,u=pass.uniforms,state=this.atmosphere;
    camera.updateMatrixWorld();
    u.uProjInv.value.copy(camera.projectionMatrixInverse);
    u.uViewInv.value.copy(camera.matrixWorld);
    u.uCamPos.value.setFromMatrixPosition(camera.matrixWorld);
    if(state.sunDirection)u.uSunDir.value.copy(state.sunDirection);
    if(state.hazeColor)u.uFogCool.value.copy(state.hazeColor);
    if(state.sunGlowColor)u.uFogWarm.value.copy(state.sunGlowColor);
    u.uAspect.value=camera.aspect||1;
    // Position du soleil à l'écran ; rayons coupés s'il est derrière la caméra ou sous l'horizon.
    this.sunScreen.copy(u.uCamPos.value).addScaledVector(u.uSunDir.value,500).project(camera);
    const inFront=this.sunScreen.z<1&&u.uSunDir.value.clone().dot(camera.getWorldDirection(new THREE.Vector3()))>0;
    u.uSunScreen.value.set(this.sunScreen.x*.5+.5,this.sunScreen.y*.5+.5);
    const offscreen=Math.max(Math.abs(this.sunScreen.x),Math.abs(this.sunScreen.y));
    const low=THREE.MathUtils.clamp(1-(u.uSunDir.value.y-.05)/.75,.35,1);
    u.uSunVisible.value=inFront?THREE.MathUtils.clamp(1.6-offscreen*.6,0,1)*(state.daylight??1)*low:0;
    u.uGlow.value=.25+.55*(state.dawn??0)+.2*(state.daylight??1);
  }
  render(delta){if(this.enabled){this.updateAtmosphereUniforms();this.composer.render(delta);}else this.game.renderer.render(this.game.scene,this.game.camera);}
}
