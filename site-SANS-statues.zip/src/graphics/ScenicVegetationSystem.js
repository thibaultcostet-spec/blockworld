import * as THREE from 'three';

const GROUND_TYPES = new Set(['grass','dirt','stone','sand','snow']);
// Beta 4.14 : 'leaves' n'est plus masqué (arbres en mini-blocs) : haies et feuilles posées restent visibles.
const HIDDEN_FOLIAGE_TYPES = ['shrub','tall_grass','flower_red','flower_yellow'];

function hash2D(x, z, seed = 0) {
  const value = Math.sin((x + seed * 17.31) * 127.1 + (z - seed * 9.73) * 311.7) * 43758.5453123;
  return value - Math.floor(value);
}

function makeBladeTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createLinearGradient(0, 128, 0, 0);
  gradient.addColorStop(0, 'rgba(32,82,28,0.96)');
  gradient.addColorStop(0.55, 'rgba(74,145,50,0.92)');
  gradient.addColorStop(1, 'rgba(175,214,99,0)');
  ctx.fillStyle = gradient;
  for (let index = 0; index < 13; index += 1) {
    const x = 10 + index * 9 + (index % 3) * 2;
    ctx.beginPath();
    ctx.moveTo(x - 4, 126);
    ctx.quadraticCurveTo(x - 8 + (index % 2) * 12, 62, x + (index % 3) * 2, 6 + (index % 4) * 7);
    ctx.quadraticCurveTo(x + 7, 64, x + 5, 126);
    ctx.closePath();
    ctx.fill();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  return texture;
}

// Beta 4.10 : les textures de feuillage portent leur propre canal alpha. Elles ne servent plus
// de masque alpha (alphaMap) — Three.js y lisait le canal vert, assombri par le décodage sRGB, et le produit
// passait sous alphaTest → houppiers et herbes quasi invisibles en Standard/Élevée/Ultra.
function makeLeafTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0,0,128,128);
  const random = (() => { let s=987654321; return () => ((s=Math.imul(s,1664525)+1013904223>>>0)/4294967296); })();
  for (let index = 0; index < 210; index += 1) {
    const x = random()*128;
    const y = random()*128;
    const r = 3 + random()*8;
    // Beta 4.10 : motif clair, la teinte vient de material.color (sinon vert × vert ≈ noir).
    ctx.fillStyle = `rgba(${178+Math.round(random()*52)},${205+Math.round(random()*50)},${170+Math.round(random()*50)},${0.35+random()*0.6})`;
    ctx.beginPath();
    ctx.ellipse(x,y,r,r*(0.55+random()*0.55),random()*Math.PI,0,Math.PI*2);
    ctx.fill();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.magFilter = THREE.LinearFilter;
  texture.generateMipmaps = true;
  return texture;
}

function topNatural(world, x, z) {
  const column = world.columns.get(world.columnKey(x,z));
  if (!column) return null;
  let best = null;
  for (const block of column.values()) {
    if (!GROUND_TYPES.has(block.type)) continue;
    if (!best || block.y > best.y) best = block;
  }
  return best;
}

function isReserved(x,z,definition) {
  if (Math.hypot(x-(definition.spawn?.x??0), z-(definition.spawn?.z??0)) < 8) return true;
  return (definition.pointsOfInterest||[]).some((poi) => Math.hypot(x-poi.x,z-poi.z) < Math.max(12,(poi.discoveryRadius||12)*0.78));
}


function addWind(material, amplitude = 0.035, speed = 1) {
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uWindTime = { value: 0 };
    shader.uniforms.uWindAmplitude = { value: amplitude };
    shader.uniforms.uWindSpeed = { value: speed };
    shader.vertexShader = shader.vertexShader.replace('#include <common>', '#include <common>\nuniform float uWindTime;uniform float uWindAmplitude;uniform float uWindSpeed;');
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
float bwPhase=uWindTime*uWindSpeed+position.x*1.7+position.z*1.3;
#ifdef USE_INSTANCING
bwPhase+=instanceMatrix[3].x*.17+instanceMatrix[3].z*.13;
#endif
float bwHeight=max(position.y,0.0);transformed.x+=sin(bwPhase)*uWindAmplitude*bwHeight;transformed.z+=cos(bwPhase*.71)*uWindAmplitude*.45*bwHeight;`);
    material.userData.windUniform = shader.uniforms.uWindTime;
  };
  material.customProgramCacheKey = () => `bw-scenic-wind-${amplitude}-${speed}`;
}

/**
 * Couche végétale hybride : les blocs restent la donnée de jeu, tandis que les
 * arbres, herbes et rochers visibles sont rendus par des géométries instanciées.
 */
export class ScenicVegetationSystem {
  constructor(scene, world, { touchMode = false } = {}) {
    this.scene = scene;
    this.world = world;
    this.touchMode = touchMode;
    this.group = new THREE.Group();
    this.group.name = 'ScenicVegetationV3';
    this.scene.add(this.group);
    this.quality = touchMode ? 'mobile' : 'high';
    this.elapsed = 0;
    this.baseOpacities = new Map();
    this.bladeTexture = makeBladeTexture();
    this.leafTexture = makeLeafTexture();
    this.windMaterials = [];
  }

  clear() {
    this.windMaterials = [];
    for (const child of [...this.group.children]) {
      this.group.remove(child);
      child.geometry?.dispose?.();
      const materials = Array.isArray(child.material) ? child.material : [child.material];
      for (const material of materials) material?.dispose?.();
    }
  }

  restoreVoxelFoliage() {
    for (const type of HIDDEN_FOLIAGE_TYPES) {
      const material = this.world.materials?.[type];
      if (!material) continue;
      const saved = this.baseOpacities.get(type);
      material.opacity = saved?.opacity ?? material.userData?.baseOpacity ?? 1;
      material.depthWrite = saved?.depthWrite ?? true;
      material.colorWrite = true;
      material.needsUpdate = true;
    }
  }

  hideVoxelFoliage() {
    for (const type of HIDDEN_FOLIAGE_TYPES) {
      const material = this.world.materials?.[type];
      if (!material) continue;
      if (!this.baseOpacities.has(type)) this.baseOpacities.set(type, { opacity: material.opacity, depthWrite: material.depthWrite });
      material.opacity = 0;
      material.depthWrite = false;
      material.colorWrite = false;
      material.needsUpdate = true;
    }
  }

  setQuality(id) {
    this.quality = id;
    this.rebuild(this.definition);
  }

  setWorld(definition) {
    this.definition = definition;
    this.rebuild(definition);
  }

  findTreeAnchors() {
    const anchors = [];
    for (const [columnKey, column] of this.world.columns) {
      const woods = [...column.values()].filter((block) => block.type === 'wood').sort((a,b) => a.y-b.y);
      if (!woods.length) continue;
      const base = woods[0];
      const ground = topNatural(this.world, base.x, base.z);
      if (!ground || Math.abs(base.y - (ground.y + 1)) > 1) continue;
      let nearbyLeaves = 0;
      for (let dx=-3; dx<=3; dx+=1) for (let dz=-3; dz<=3; dz+=1) {
        const neighbour = this.world.columns.get(this.world.columnKey(base.x+dx,base.z+dz));
        if (!neighbour) continue;
        for (const block of neighbour.values()) {
          if (block.type === 'leaves' && block.y >= base.y + 2) nearbyLeaves += 1;
        }
      }
      if (nearbyLeaves < 3) continue;
      anchors.push({ x:base.x, z:base.z, y:ground.y+.49, height:woods.length, key:columnKey });
    }
    return anchors;
  }

  rebuild(definition = this.definition) {
    if (!definition) return;
    this.clear();
    const cinematic = this.quality === 'high' || this.quality === 'ultra';
    if (!cinematic) {
      this.restoreVoxelFoliage();
      if (this.quality === 'standard') this.addUnderstory(definition, 0.25);
      return;
    }
    this.hideVoxelFoliage();
    // Beta 4.14 : houppiers lisses remplacés par les arbres en mini-blocs (MicroVoxelDecor).
    this.addUnderstory(definition, this.quality === 'ultra' ? 1 : 0.62);
  }

  addTrees(definition) {
    const anchors = this.findTreeAnchors();
    // Beta 4.10 : les feuilles voxel sont masquées pour TOUS les arbres ; chaque arbre doit donc
    // recevoir son houppier. Avant (105 / 165 max, zones réservées exclues), l'Europe gardait
    // 187 troncs nus sur 292. Rendu instancié : coût en appels de dessin inchangé.
    const limit = this.quality === 'ultra' ? 520 : 400;
    const selected = anchors
      .sort((a,b) => hash2D(a.x,a.z,definition.seed)-hash2D(b.x,b.z,definition.seed))
      .slice(0,limit);
    if (!selected.length) return;

    const trunkGeometry = new THREE.CylinderGeometry(0.62,0.74,1,8,1,false);
    const broadGeometry = new THREE.IcosahedronGeometry(1,1);
    const pineGeometry = new THREE.ConeGeometry(1,2.2,9,2);
    const trunkMaterial = new THREE.MeshStandardMaterial({ color:0x6d4628,roughness:0.94,bumpScale:0.03 });
    const leafMaterial = new THREE.MeshStandardMaterial({
      color: definition.theme==='oceania'?0x5f9864:definition.theme==='africa'?0x688c42:0x3f8c48,
      map:this.leafTexture,alphaTest:0.22,transparent:true,side:THREE.DoubleSide,
      roughness:0.84,metalness:0
    });
    const pineMaterial = leafMaterial.clone();
    pineMaterial.color.offsetHSL(-0.03,-0.05,-0.05); // Beta 4.10 : -0.12 donnait des pins noirs à contre-jour
    addWind(leafMaterial,this.quality==='ultra'?.052:.034,.92);
    addWind(pineMaterial,this.quality==='ultra'?.035:.024,.82);
    this.windMaterials.push(leafMaterial,pineMaterial);

    const trunks = new THREE.InstancedMesh(trunkGeometry,trunkMaterial,selected.length);
    const broadCanopies = [];
    const pineCanopies = [];
    const branchItems = [];
    const dummy = new THREE.Object3D();
    selected.forEach((anchor,index) => {
      const random = hash2D(anchor.x,anchor.z,definition.seed);
      const height = Math.max(3.7,anchor.height*(0.82+random*0.2));
      const lean = (hash2D(anchor.z,anchor.x,definition.seed+11)-0.5)*0.08;
      dummy.position.set(anchor.x,anchor.y+height/2,anchor.z);
      dummy.rotation.set(lean*0.45,random*Math.PI*2,lean);
      dummy.scale.set(0.72+random*0.24,height,0.72+random*0.24);
      dummy.updateMatrix();
      trunks.setMatrixAt(index,dummy.matrix);
      trunks.setColorAt(index,new THREE.Color().setHSL(0.075+random*.02,.42,.28+random*.08));

      const pine = definition.theme==='asia' || definition.theme==='americas'
        ? hash2D(anchor.x+7,anchor.z-4,definition.seed) > 0.56
        : definition.theme==='europe' && random > 0.72;
      const crownY = anchor.y + height*0.78;
      const branchCount=this.quality==='ultra'?(pine?3:4):(pine?1:2);
      for(let branch=0;branch<branchCount;branch+=1){
        const branchAngle=random*Math.PI*2+branch/branchCount*Math.PI*2;
        const length=(pine?1.35:1.85)+hash2D(anchor.x+branch,anchor.z-branch,definition.seed)*.85;
        branchItems.push({x:anchor.x,y:anchor.y+height*(.52+branch*.07),z:anchor.z,angle:branchAngle,length,radius:.08+random*.035,tilt:pine?.38:.62});
      }
      if (pine) {
        for (let layer=0; layer<3; layer+=1) {
          pineCanopies.push({
            x:anchor.x,y:crownY+layer*.75,z:anchor.z,
            sx:2.45-layer*.4+random*.35,sy:2.5-layer*.2,sz:2.45-layer*.4+random*.35,
            ry:random*Math.PI*2+layer*.4,color:random
          });
        }
      } else {
        const clusterCount = this.quality==='ultra'?4:3;
        for (let cluster=0; cluster<clusterCount; cluster+=1) {
          const angle=cluster/clusterCount*Math.PI*2+random*2;
          broadCanopies.push({
            x:anchor.x+Math.cos(angle)*(cluster?0.62:0),
            y:crownY+(cluster%2)*.55,
            z:anchor.z+Math.sin(angle)*(cluster?0.62:0),
            sx:2.15+random*.65,sy:1.55+hash2D(cluster,anchor.x,definition.seed)*.55,sz:2.05+random*.55,
            ry:angle,color:random+cluster*.07
          });
        }
      }
    });
    trunks.instanceMatrix.needsUpdate=true;
    if (trunks.instanceColor) trunks.instanceColor.needsUpdate=true;
    trunks.castShadow=true; trunks.receiveShadow=true; this.group.add(trunks);
    if(branchItems.length){
      const branchGeometry=new THREE.CylinderGeometry(1,1,1,7,1,false);
      const branches=new THREE.InstancedMesh(branchGeometry,trunkMaterial,branchItems.length);
      const up=new THREE.Vector3(0,1,0),direction=new THREE.Vector3(),quaternion=new THREE.Quaternion();
      branchItems.forEach((item,index)=>{
        direction.set(Math.cos(item.angle),item.tilt,Math.sin(item.angle)).normalize();
        quaternion.setFromUnitVectors(up,direction);
        dummy.position.set(item.x+direction.x*item.length*.42,item.y+direction.y*item.length*.42,item.z+direction.z*item.length*.42);
        dummy.quaternion.copy(quaternion);dummy.scale.set(item.radius,item.length,item.radius);dummy.updateMatrix();branches.setMatrixAt(index,dummy.matrix);
      });
      branches.instanceMatrix.needsUpdate=true;branches.castShadow=true;branches.receiveShadow=true;branches.name='ProceduralBranches';this.group.add(branches);
    }

    const addCanopies=(items,geometry,material,name)=>{
      if(!items.length)return;
      const mesh=new THREE.InstancedMesh(geometry,material,items.length);mesh.name=name;
      items.forEach((item,index)=>{dummy.position.set(item.x,item.y,item.z);dummy.rotation.set(0,item.ry,0);dummy.scale.set(item.sx,item.sy,item.sz);dummy.updateMatrix();mesh.setMatrixAt(index,dummy.matrix);mesh.setColorAt(index,new THREE.Color().setHSL(.29+(item.color%1)*.035,.43,.30+(item.color%1)*.12));});
      mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;mesh.castShadow=true;mesh.receiveShadow=true;this.group.add(mesh);
    };
    addCanopies(broadCanopies,broadGeometry,leafMaterial,'BroadleafCanopies');
    addCanopies(pineCanopies,pineGeometry,pineMaterial,'PineCanopies');
  }

  addUnderstory(definition, density) {
    const size = definition.size || 160;
    const step = this.quality === 'ultra' ? 2 : this.quality === 'high' ? 3 : 5;
    const grassItems=[];
    const flowerItems=[];
    const rockItems=[];
    for(let x=-size/2+2;x<size/2-2;x+=step){
      for(let z=-size/2+2;z<size/2-2;z+=step){
        if(isReserved(x,z,definition))continue;
        const ground=topNatural(this.world,Math.round(x),Math.round(z));
        if(!ground || !['grass','dirt','sand','stone'].includes(ground.type))continue;
        const n=hash2D(x,z,definition.seed+71);
        if(ground.type==='grass' && n<.54*density){
          grassItems.push({x:x+(n-.5)*1.5,y:ground.y+.5,z:z+(hash2D(z,x,definition.seed)-.5)*1.5,s:.65+hash2D(x+3,z-2,definition.seed)*.9,r:n*Math.PI});
          if(n<.08*density)flowerItems.push({x:x+.4,y:ground.y+.55,z:z-.25,s:.45+n*2,r:n*Math.PI});
        } else if((ground.type==='stone'||ground.type==='sand') && n<.08*density){
          rockItems.push({x,y:ground.y+.48,z,s:.25+n*1.5,r:n*Math.PI});
        }
      }
    }
    const maxGrass=this.quality==='ultra'?1250:this.quality==='high'?620:180;
    this.addCrossPlanes(grassItems.slice(0,maxGrass),false);
    this.addCrossPlanes(flowerItems.slice(0,Math.round(maxGrass*.12)),true);
    if(rockItems.length){
      const geometry=new THREE.DodecahedronGeometry(.45,0);
      const material=new THREE.MeshStandardMaterial({color:0x85847e,roughness:.96});
      const mesh=new THREE.InstancedMesh(geometry,material,rockItems.length);const dummy=new THREE.Object3D();
      rockItems.forEach((item,index)=>{dummy.position.set(item.x,item.y+item.s*.18,item.z);dummy.rotation.set(item.r*.2,item.r,item.r*.13);dummy.scale.set(item.s*1.4,item.s*.75,item.s);dummy.updateMatrix();mesh.setMatrixAt(index,dummy.matrix);mesh.setColorAt(index,new THREE.Color().setHSL(.10,.05,.38+(item.r%1)*.16));});
      mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;mesh.castShadow=true;mesh.receiveShadow=true;this.group.add(mesh);
    }
  }

  addCrossPlanes(items, flowers) {
    if(!items.length)return;
    const geometry=new THREE.PlaneGeometry(flowers?.55:.72,flowers?.72:1.25,1,2);
    geometry.translate(0,flowers?.36:.625,0);
    const material=new THREE.MeshStandardMaterial({
      map:this.bladeTexture,transparent:true,alphaTest:.24,side:THREE.DoubleSide,
      color:flowers?0xffd45c:0x7eb85a,roughness:.9,depthWrite:true
    });
    addWind(material,flowers?.018:(this.quality==='ultra'?.055:.034),flowers?.75:1.15);this.windMaterials.push(material);
    const build=(rotationOffset)=>{
      const mesh=new THREE.InstancedMesh(geometry,material,items.length);const dummy=new THREE.Object3D();
      items.forEach((item,index)=>{dummy.position.set(item.x,item.y,item.z);dummy.rotation.set(0,item.r+rotationOffset,0);dummy.scale.set(item.s,item.s,item.s);dummy.updateMatrix();mesh.setMatrixAt(index,dummy.matrix);if(flowers)mesh.setColorAt(index,new THREE.Color(index%3===0?0xf16f7c:index%3===1?0xf4d35e:0x8ab6ff));});
      mesh.instanceMatrix.needsUpdate=true;if(mesh.instanceColor)mesh.instanceColor.needsUpdate=true;mesh.receiveShadow=true;this.group.add(mesh);
    };
    build(0);build(Math.PI/2);
  }

  update(delta, playerPosition) {
    this.elapsed += delta;
    for(const material of this.windMaterials)if(material.userData.windUniform)material.userData.windUniform.value=this.elapsed;
    if(playerPosition)this.group.children.forEach((child)=>{child.visible=child.position.distanceTo?.(playerPosition)>175?false:true;});
  }
}
