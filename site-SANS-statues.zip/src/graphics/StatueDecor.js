import * as THREE from 'three';

// BlockWorld V3.0 Beta 4.20 — statues de chevaliers (décor).
// Modèles 3D importés, allégés (14–34 Mo → 0,3–0,4 Mo) puis convertis en géométrie brute servie par
// le jeu (pas de textures embarquées : compatible avec la CSP img-src 'self' data:). Les détails de la
// texture d'origine sont reportés en nuances sur chaque sommet : rendu « bronze patiné ».
// Deux statues encadrent l'entrée de chaque monument, côté route, tournées vers les visiteurs.

export const STATUE_MODELS = ['black-knight', 'dark-knight'];
const cache = new Map();

export function parseStatue(buffer) {
  const view = new DataView(buffer);
  const headerLength = view.getUint32(0, true);
  const header = JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, 4, headerLength)));
  if (header.format !== 'blockworld-statue-1') throw new Error('format de statue inconnu');
  let offset = 4 + headerLength + ((4 - headerLength % 4) % 4);
  const n = header.vertices;
  const positions = new Float32Array(buffer, offset, n * 3); offset += n * 12;
  const normals = new Int8Array(buffer, offset, n * 3); offset += n * 3 + ((4 - (n * 3) % 4) % 4);
  const lum = new Uint8Array(buffer, offset, n); offset += n + ((4 - n % 4) % 4);
  const indices = new Uint32Array(buffer, offset, header.triangles * 3);
  return { header, positions, normals, lum, indices };
}

function statueGeometry(data, tint) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(data.positions), 3));
  geometry.setAttribute('normal', new THREE.BufferAttribute(new Float32Array(Array.from(data.normals, (v) => v / 127)), 3));
  // Bronze patiné : creux (texture sombre) verdis, reliefs (texture claire) dorés et polis.
  const colors = new Float32Array(data.header.vertices * 3);
  const bronze = new THREE.Color(tint.bronze), verdigris = new THREE.Color(tint.patina), color = new THREE.Color();
  for (let i = 0; i < data.header.vertices; i += 1) {
    const l = data.lum[i] / 255;
    color.copy(verdigris).lerp(bronze, Math.min(1, l * 1.6)).multiplyScalar(0.55 + l * 0.75);
    colors.set([color.r, color.g, color.b], i * 3);
  }
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.setIndex(new THREE.BufferAttribute(new Uint32Array(data.indices), 1));
  geometry.computeBoundingSphere();
  return geometry;
}

async function loadStatue(name) {
  if (!cache.has(name)) {
    cache.set(name, fetch(`./assets/statues/${name}.bin`).then((response) => {
      if (!response.ok) throw new Error(`statue ${name} : ${response.status}`);
      return response.arrayBuffer();
    }).then(parseStatue));
  }
  return cache.get(name);
}

const TINTS = {
  'black-knight': { bronze: 0x8a6a3c, patina: 0x3f6b5c },
  'dark-knight': { bronze: 0x7d6a55, patina: 0x40584f }
};

export class StatueDecor {
  constructor(scene, world) {
    this.scene = scene;
    this.world = world;
    this.group = new THREE.Group();
    this.group.name = 'KnightStatues';
    this.scene.add(this.group);
    this.material = new THREE.MeshStandardMaterial({ vertexColors: true, metalness: 0.55, roughness: 0.42 });
    this.stone = new THREE.MeshStandardMaterial({ color: 0xa49a8a, roughness: 0.9 });
    this.stoneDark = new THREE.MeshStandardMaterial({ color: 0x7d7468, roughness: 0.92 });
    this.generation = 0;
    this.stats = { statues: 0, triangles: 0 };
  }

  clear() {
    for (const child of [...this.group.children]) {
      this.group.remove(child);
      child.traverse((object) => { if (object.isMesh && object.geometry && object.userData.ownGeometry) object.geometry.dispose(); });
    }
  }

  async setWorld(definition) {
    const generation = ++this.generation;
    this.clear();
    this.stats = { statues: 0, triangles: 0 };
    if (!definition?.pointsOfInterest?.length) return;
    let models;
    try { models = await Promise.all(STATUE_MODELS.map(loadStatue)); } catch (error) { console.warn('[statues]', error.message); return; }
    if (generation !== this.generation) return; // monde changé entre-temps
    const geometries = STATUE_MODELS.map((name, index) => statueGeometry(models[index], TINTS[name]));
    const hub = definition.spawn ?? { x: 0, z: 0 };
    definition.pointsOfInterest.forEach((poi, index) => {
      const toHub = new THREE.Vector2(hub.x - poi.x, hub.z - poi.z);
      if (toHub.lengthSq() < 1) toHub.set(0, 1);
      toHub.normalize();
      const side = new THREE.Vector2(-toHub.y, toHub.x);
      const radius = (poi.discoveryRadius || 16) * 0.72;
      for (const sign of [-1, 1]) {
        const x = poi.x + toHub.x * radius + side.x * sign * 3.2;
        const z = poi.z + toHub.y * radius + side.y * sign * 3.2;
        const geometry = geometries[(index + (sign > 0 ? 1 : 0)) % geometries.length];
        this.placeStatue(geometry, x, z, Math.atan2(toHub.x, toHub.y));
      }
    });
  }

  placeStatue(geometry, x, z, yaw) {
    const ground = this.world.getSurfaceHeight?.(x, z);
    const base = (Number.isFinite(ground) ? ground : 2) + 0.5;
    const statue = new THREE.Group();
    statue.name = 'KnightStatue';
    // Socle en pierre : plinthe, fût, corniche.
    const parts = [[1.5, 0.22, 1.5, this.stoneDark, 0.11], [1.18, 0.9, 1.18, this.stone, 0.22 + 0.45], [1.4, 0.16, 1.4, this.stoneDark, 0.22 + 0.9 + 0.08]];
    for (const [w, h, d, material, y] of parts) {
      const block = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
      block.position.y = y; block.castShadow = true; block.receiveShadow = true; block.userData.ownGeometry = true;
      statue.add(block);
    }
    const figure = new THREE.Mesh(geometry, this.material);
    figure.position.y = 0.22 + 0.9 + 0.16;
    figure.castShadow = true;
    figure.receiveShadow = true;
    statue.add(figure);
    statue.position.set(x, base, z);
    statue.rotation.y = yaw;
    this.group.add(statue);
    this.stats.statues += 1;
    this.stats.triangles += geometry.index.count / 3;
  }
}
