import * as THREE from 'three';

function seededNoise(seed) { let value=seed>>>0; return()=>{value=(value*1664525+1013904223)>>>0;return value/4294967296;}; }
function rgb(hex){return{r:(hex>>16)&255,g:(hex>>8)&255,b:hex&255};}
function tone(c,n){return `rgb(${Math.max(0,Math.min(255,c.r+n))},${Math.max(0,Math.min(255,c.g+n))},${Math.max(0,Math.min(255,c.b+n))})`;}
function seedOf(text){let h=2166136261;for(const ch of text){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}

export function createProceduralTexture(type,color){
  const size=128, canvas=document.createElement('canvas'); canvas.width=canvas.height=size;
  const c=canvas.getContext('2d'), base=rgb(color), random=seededNoise(seedOf(type));
  c.fillStyle=tone(base,-4); c.fillRect(0,0,size,size);

  // Grain multi-échelle : supprime l'aspect couleur unie sans devenir bruyant.
  for(const scale of [16,8,4,2]){
    const alpha=scale===16?.08:scale===8?.10:scale===4?.13:.16;
    for(let y=0;y<size;y+=scale)for(let x=0;x<size;x+=scale){
      c.globalAlpha=alpha;c.fillStyle=tone(base,Math.round((random()-.5)*(scale===2?34:24)));
      c.fillRect(x,y,scale,scale);
    }
  }
  c.globalAlpha=1;

  if(type==='grass'){
    for(let i=0;i<180;i++){const x=random()*size,y=random()*size;c.strokeStyle=random()>.5?'rgba(32,92,35,.38)':'rgba(181,210,87,.28)';c.beginPath();c.moveTo(x,y+4);c.lineTo(x+(random()-.5)*3,y);c.stroke();}
  }
  if(['dirt','sand','stone','concrete','snow'].includes(type)){
    for(let i=0;i<95;i++){const r=1+random()*2,x=random()*size,y=random()*size;c.fillStyle=tone(base,Math.round((random()-.5)*58));c.globalAlpha=.18+random()*.24;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}c.globalAlpha=1;
  }
  if(['wood','planks','crate','door','fence','ladder'].includes(type)){
    c.lineWidth=2;
    for(let y=10;y<size;y+=18){c.strokeStyle='rgba(54,25,9,.38)';c.beginPath();c.moveTo(0,y);for(let x=0;x<=size;x+=8)c.lineTo(x,y+Math.sin((x+y)*.08)*1.8);c.stroke();}
    for(let i=0;i<8;i++){c.strokeStyle='rgba(235,184,112,.18)';const x=random()*size;c.beginPath();c.moveTo(x,0);c.lineTo(x+(random()-.5)*9,size);c.stroke();}
  }
  if(type==='bricks'){
    c.strokeStyle='rgba(238,224,203,.62)';c.lineWidth=4;
    for(let y=0;y<=size;y+=24){c.beginPath();c.moveTo(0,y);c.lineTo(size,y);c.stroke();const off=(y/24)%2?16:0;for(let x=off;x<size;x+=32){c.beginPath();c.moveTo(x,y);c.lineTo(x,y+24);c.stroke();}}
  }
  if(type==='roof'){
    c.strokeStyle='rgba(45,15,15,.48)';c.lineWidth=3;
    for(let y=0;y<size;y+=18){for(let x=(y/18)%2?9:0;x<size;x+=18){c.strokeRect(x,y,18,18);}}
  }
  // Beta 4.13 : route en pavés (la bande jaune sur chaque bloc zébrait les routes de 3 blocs).
  if(type==='road'){c.strokeStyle='rgba(28,26,24,.42)';c.lineWidth=3;for(let y=0;y<=size;y+=32){c.beginPath();c.moveTo(0,y);c.lineTo(size,y);c.stroke();const off=(y/32)%2?16:0;for(let x=off;x<size;x+=32){c.beginPath();c.moveTo(x,y);c.lineTo(x,y+32);c.stroke();}}}
  // Beta 4.30 : acier — tôle rivetée avec une âme de profilé en I.
  if(type==='steel'){c.fillStyle='rgba(30,38,46,.35)';c.fillRect(0,0,size,14);c.fillRect(0,size-14,size,14);c.fillRect(56,0,16,size);c.fillStyle='rgba(225,232,238,.55)';for(const y of [7,size-7])for(let x=10;x<size;x+=22){c.beginPath();c.arc(x,y,2.6,0,Math.PI*2);c.fill();}c.strokeStyle='rgba(255,255,255,.18)';c.lineWidth=2;c.strokeRect(1,1,size-2,size-2);}
  if(type==='rail'){c.fillStyle='rgba(215,220,225,.78)';c.fillRect(20,0,7,size);c.fillRect(101,0,7,size);for(let y=0;y<size;y+=18)c.fillRect(16,y,96,5);}
  if(['glass','window'].includes(type)){c.strokeStyle='rgba(230,250,255,.78)';c.lineWidth=5;c.strokeRect(3,3,size-6,size-6);c.strokeStyle='rgba(255,255,255,.22)';c.beginPath();c.moveTo(8,size-10);c.lineTo(size-10,8);c.stroke();}
  if(type==='water'){c.strokeStyle='rgba(220,250,255,.30)';c.lineWidth=2;for(let y=10;y<size;y+=14){c.beginPath();for(let x=0;x<=size;x+=4)c.lineTo(x,y+Math.sin((x+y)*.16)*2.4);c.stroke();}}
  if(['leaves','shrub','tall_grass'].includes(type)){
    c.clearRect(0,0,size,size);c.fillStyle=tone(base,-3);
    for(let i=0;i<280;i++){const x=random()*size,y=random()*size,r=2+random()*6;c.globalAlpha=.42+random()*.52;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}c.globalAlpha=1;
  }

  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
  texture.magFilter=THREE.LinearFilter;texture.minFilter=THREE.LinearMipmapLinearFilter;
  texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.generateMipmaps=true;texture.userData.type=type;
  return texture;
}

function createHeightTexture(source){
  const canvas=document.createElement('canvas');canvas.width=source.image.width;canvas.height=source.image.height;
  const c=canvas.getContext('2d');c.drawImage(source.image,0,0);const image=c.getImageData(0,0,canvas.width,canvas.height);
  for(let i=0;i<image.data.length;i+=4){const lum=Math.round(image.data[i]*.299+image.data[i+1]*.587+image.data[i+2]*.114);image.data[i]=image.data[i+1]=image.data[i+2]=lum;image.data[i+3]=255;}
  c.putImageData(image,0,0);const texture=new THREE.CanvasTexture(canvas);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=true;return texture;
}

function createNormalTexture(source){
  const width=source.image.width,height=source.image.height;
  const input=document.createElement('canvas');input.width=width;input.height=height;
  const context=input.getContext('2d');context.drawImage(source.image,0,0);
  const pixels=context.getImageData(0,0,width,height);const luminance=new Float32Array(width*height);
  for(let i=0;i<luminance.length;i++){const p=i*4;luminance[i]=(pixels.data[p]*.299+pixels.data[p+1]*.587+pixels.data[p+2]*.114)/255;}
  const output=context.createImageData(width,height);const sample=(x,y)=>luminance[((y+height)%height)*width+((x+width)%width)];
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const dx=(sample(x+1,y-1)+2*sample(x+1,y)+sample(x+1,y+1))-(sample(x-1,y-1)+2*sample(x-1,y)+sample(x-1,y+1));
    const dy=(sample(x-1,y+1)+2*sample(x,y+1)+sample(x+1,y+1))-(sample(x-1,y-1)+2*sample(x,y-1)+sample(x+1,y-1));
    const normal=new THREE.Vector3(-dx*1.45,-dy*1.45,1).normalize();const index=(y*width+x)*4;
    output.data[index]=Math.round((normal.x*.5+.5)*255);output.data[index+1]=Math.round((normal.y*.5+.5)*255);output.data[index+2]=Math.round((normal.z*.5+.5)*255);output.data[index+3]=255;
  }
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;canvas.getContext('2d').putImageData(output,0,0);
  const texture=new THREE.CanvasTexture(canvas);texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.minFilter=THREE.LinearMipmapLinearFilter;texture.magFilter=THREE.LinearFilter;texture.generateMipmaps=true;return texture;
}

export function createBlockMaterial(type,config){
  const map=createProceduralTexture(type,config.color); const bumpMap=createHeightTexture(map); const normalMap=createNormalTexture(map);
  const foliage=['leaves','shrub','tall_grass'].includes(type);
  const material=new THREE.MeshStandardMaterial({
    map,bumpMap,normalMap,bumpScale:.05,normalScale:new THREE.Vector2(.35,.35),color:0xffffff,roughness:['glass','window','water'].includes(type)?.24:.86,
    metalness:['rail','crystal'].includes(type)?.2:0,transparent:Boolean(config.transparent),
    opacity:config.opacity??1,alphaTest:foliage?.28:0,side:foliage?THREE.DoubleSide:THREE.FrontSide,
    depthWrite:!['water','glass','window'].includes(type),emissive:config.emissive??0x000000,
    emissiveIntensity:config.emissiveIntensity??0
    // Beta 4.10 : vertexColors retiré. Le cube n'a pas d'attribut « color » : WebGL
    // injectait (0,0,0) et tous les blocs sortaient noirs. La variation par bloc passe par instanceColor.
  });
  material.userData={baseColor:config.color??0xffffff,baseMap:map,baseBumpMap:bumpMap,baseNormalMap:normalMap,baseRoughness:material.roughness,baseOpacity:material.opacity,foliage};
  return material;
}
