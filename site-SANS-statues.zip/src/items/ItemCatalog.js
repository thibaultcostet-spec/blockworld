import { BLOCK_TYPES } from '../world/BlockTypes.js';

export const ITEM_CATEGORIES = [
  { id: 'landscape', label: 'Paysages', icon: '🌿' },
  { id: 'construction', label: 'Construction', icon: '🏗️' },
  { id: 'tools', label: 'Outils', icon: '🧰' },
  { id: 'weapons', label: 'Armes', icon: '⚔️' },
  { id: 'clothing', label: 'Vêtements', icon: '👕' },
  { id: 'vehicles', label: 'Transports', icon: '🚙' },
  { id: 'health', label: 'Énergie / vie', icon: '❤️' },
  { id: 'magic', label: 'Magie', icon: '✨' }
];

function block(id, category, icon, description) {
  const config = BLOCK_TYPES[id];
  return {
    id: `block-${id}`,
    kind: 'block',
    type: id,
    category,
    label: config.label,
    icon,
    description,
    color: config.color
  };
}

export const ITEM_CATALOG = [
  block('grass', 'landscape', '🌱', 'Bloc naturel de surface.'),
  block('dirt', 'landscape', '🟫', 'Terre pour modeler le relief.'),
  block('stone', 'landscape', '🪨', 'Pierre résistante.'),
  block('sand', 'landscape', '🏖️', 'Sable pour plages et déserts.'),
  block('snow', 'landscape', '❄️', 'Neige pour zones froides.'),
  block('water', 'landscape', '💧', 'Bloc d’eau traversable.'),
  block('wood', 'landscape', '🪵', 'Tronc et bois brut.'),
  block('leaves', 'landscape', '🍃', 'Feuillage semi-transparent.'),

  block('planks', 'construction', '🟧', 'Planches pour maisons et ponts.'),
  block('bricks', 'construction', '🧱', 'Mur en briques.'),
  block('concrete', 'construction', '⬜', 'Bloc de béton robuste.'),
  block('glass', 'construction', '🔲', 'Verre transparent.'),
  block('window', 'construction', '🪟', 'Fenêtre décorative transparente.'),
  block('door', 'construction', '🚪', 'Porte bloc ; ouverture prévue plus tard.'),
  block('roof', 'construction', '🏠', 'Bloc de toiture rouge.'),
  block('road', 'construction', '🛣️', 'Route sombre pour créer des voies.'),
  block('rail', 'construction', '🛤️', 'Rail décoratif traversable.'),
  block('ladder', 'construction', '🪜', 'Échelle décorative ; escalade future.'),
  block('fence', 'construction', '🚧', 'Barrière de délimitation.'),
  block('obsidian', 'construction', '⬛', 'Obsidienne très résistante.'),
  block('steel', 'construction', '🔩', 'Poutre en acier : résiste à la traction comme à la compression (3 points dans les défis).'),
  block('crystal', 'construction', '💎', 'Cristal lumineux.'),
  block('lantern', 'construction', '🏮', 'Lanterne lumineuse.'),
  block('crate', 'construction', '📦', 'Caisse de rangement décorative.'),

  { id: 'pickaxe', kind: 'tool', type: 'pickaxe', category: 'tools', label: 'Pioche', icon: '⛏️', damage: 16, description: 'Récolte rapidement pierre, verre et cristaux.' },
  { id: 'axe', kind: 'tool', type: 'axe', category: 'tools', label: 'Hache', icon: '🪓', damage: 24, description: 'Récolte bois, planches, feuilles et caisses.' },
  { id: 'shovel', kind: 'tool', type: 'shovel', category: 'tools', label: 'Pelle', icon: '🥄', damage: 12, description: 'Récolte terre, herbe, sable et neige.' },
  { id: 'hammer', kind: 'tool', type: 'hammer', category: 'tools', label: 'Marteau', icon: '🔨', damage: 27, description: 'Récolte briques, béton et obsidienne.' },
  // Beta 4.27 : pêche et feu de camp.
  { id: 'fishing-rod', kind: 'tool', type: 'fishing-rod', category: 'tools', label: 'Canne à pêche', icon: '🎣', damage: 4, description: 'Clic droit ou ▣ sur l’eau pour lancer, puis ferrer quand le bouchon plonge.' },
  { id: 'campfire', kind: 'placeable', type: 'campfire', category: 'tools', label: 'Feu de camp', icon: '🔥', description: 'Clic droit ou ▣ pour le poser · cuit viande et poisson à proximité · éclaire la nuit · clic gauche pour l’éteindre.' },

  { id: 'sword', kind: 'weapon', type: 'sword', category: 'weapons', label: 'Épée', icon: '⚔️', damage: 38, range: 3.2, cooldown: 0.35, recoil: 0.08, description: 'Arme de mêlée rapide et silencieuse.' },
  { id: 'pistol', kind: 'weapon', type: 'pistol', category: 'weapons', label: 'Pistolet', icon: '🔫', damage: 24, range: 24, cooldown: 0.30, magazineSize: 12, reloadTime: 1.25, spread: 0.010, recoil: 0.28, tracerColor: 0xffdf8a, description: 'Arme légère, précise et rapide à recharger.' },
  { id: 'revolver', kind: 'weapon', type: 'revolver', category: 'weapons', label: 'Revolver', icon: '🔫', damage: 48, range: 27, cooldown: 0.62, magazineSize: 6, reloadTime: 1.75, spread: 0.008, recoil: 0.55, tracerColor: 0xffc86b, description: 'Six tirs puissants, cadence lente et recul marqué.' },
  { id: 'shotgun', kind: 'weapon', type: 'shotgun', category: 'weapons', label: 'Fusil à pompe', icon: '💥', damage: 13, pellets: 7, range: 12, cooldown: 0.82, magazineSize: 6, reloadTime: 1.85, spread: 0.070, recoil: 0.82, tracerColor: 0xffd7a2, description: 'Très efficace à courte portée grâce à plusieurs projectiles.' },
  { id: 'sniper', kind: 'weapon', type: 'sniper', category: 'weapons', label: 'Fusil à lunette', icon: '🎯', damage: 82, range: 55, cooldown: 1.05, magazineSize: 5, reloadTime: 2.15, zoomFov: 18, spread: 0.002, recoil: 0.72, tracerColor: 0xaee8ff, description: 'Longue portée. Clic droit, F ou 🔭 pour utiliser la lunette.' },
  { id: 'dmr', kind: 'weapon', type: 'dmr', category: 'weapons', label: 'Carabine de précision', icon: '🧿', damage: 46, range: 40, cooldown: 0.38, magazineSize: 10, reloadTime: 1.75, zoomFov: 30, spread: 0.006, recoil: 0.42, tracerColor: 0xd4eeff, description: 'Précise à moyenne et longue portée avec un zoom modéré.' },
  { id: 'smg', kind: 'weapon', type: 'smg', category: 'weapons', label: 'Mitraillette', icon: '🔫', damage: 14, range: 20, cooldown: 0.095, magazineSize: 28, reloadTime: 1.45, spread: 0.028, recoil: 0.18, automatic: true, tracerColor: 0xffefaa, description: 'Arme automatique compacte, rapide mais moins précise.' },
  { id: 'carbine', kind: 'weapon', type: 'carbine', category: 'weapons', label: 'Carabine tactique', icon: '🔫', damage: 22, range: 32, cooldown: 0.15, magazineSize: 24, reloadTime: 1.65, spread: 0.014, recoil: 0.25, automatic: true, tracerColor: 0xffe6a0, description: 'Automatique équilibrée pour les combats à moyenne portée.' },
  { id: 'ak47', kind: 'weapon', type: 'ak47', category: 'weapons', label: 'AK-47', icon: '🔫', damage: 27, range: 29, cooldown: 0.19, magazineSize: 30, reloadTime: 1.9, spread: 0.020, recoil: 0.34, automatic: true, tracerColor: 0xffd080, description: 'Puissante et robuste, avec davantage de recul.' },
  { id: 'grenade', kind: 'weapon', type: 'grenade', category: 'weapons', label: 'Grenade d’entraînement', icon: '💣', damage: 72, range: 18, radius: 4.2, cooldown: 1.6, magazineSize: 1, reloadTime: 2.1, recoil: 0.1, description: 'Explosion fictive de zone sans destruction du terrain ni des monuments.' },
  // Beta 4.28 : outils doux — viser, ralentir, capturer plutôt qu'abattre.
  { id: 'bow', kind: 'weapon', type: 'bow', category: 'weapons', label: 'Arc', icon: '🏹', damage: 26, range: 32, cooldown: 0.8, spread: 0.004, recoil: 0.04, projectile: 'arrow', description: 'Flèche silencieuse à longue portée ; la flèche vole en courbe jusqu’à la cible.' },
  { id: 'slingshot', kind: 'weapon', type: 'slingshot', category: 'weapons', label: 'Lance-pierre', icon: '🪨', damage: 10, range: 20, cooldown: 0.45, slowDuration: 1.2, spread: 0.012, recoil: 0.03, projectile: 'stone', description: 'Petit caillou qui étourdit et ralentit un instant.' },
  { id: 'net', kind: 'weapon', type: 'net', category: 'weapons', label: 'Filet', icon: '🕸️', damage: 0, range: 12, cooldown: 1.2, netDuration: 6, netRadius: 1.8, recoil: 0.02, description: 'Immobilise monstres et animaux 6 à 8 s sans les blesser ; un chien errant pris au filet s’apprivoise plus vite.' },

  { id: 'tshirt', kind: 'clothing', type: 'tshirt', category: 'clothing', label: 'T-shirt', icon: '👕', slot: 'torso', color: 0x3f82d9, description: 'T-shirt bleu visible en vue extérieure.' },
  { id: 'shirt', kind: 'clothing', type: 'shirt', category: 'clothing', label: 'Chemise', icon: '👔', slot: 'torso', color: 0xf1f3f5, description: 'Chemise claire visible en vue extérieure.' },
  { id: 'jeans', kind: 'clothing', type: 'jeans', category: 'clothing', label: 'Pantalon jeans', icon: '👖', slot: 'legs', color: 0x315a91, description: 'Jean bleu visible en vue extérieure.' },
  { id: 'shorts', kind: 'clothing', type: 'shorts', category: 'clothing', label: 'Short', icon: '🩳', slot: 'legs', color: 0xc59b57, description: 'Short clair visible en vue extérieure.' },
  { id: 'armor', kind: 'clothing', type: 'armor', category: 'clothing', label: 'Armure', icon: '🛡️', slot: 'torso', color: 0x8f99a5, protection: 0.7, description: 'Armure légère réduisant les dégâts.' },

  { id: 'motorcycle', kind: 'vehicle', type: 'motorcycle', category: 'vehicles', label: 'Moto', icon: '🏍️', speedMultiplier: 1.65, gravityMultiplier: 1, jumpMultiplier: 1.05, description: 'Mode déplacement rapide prototype.' },
  { id: 'car', kind: 'vehicle', type: 'car', category: 'vehicles', label: 'Voiture', icon: '🚙', speedMultiplier: 2, gravityMultiplier: 1, jumpMultiplier: 0.8, description: 'Mode route rapide prototype.' },
  { id: 'plane', kind: 'vehicle', type: 'plane', category: 'vehicles', label: 'Avion', icon: '✈️', speedMultiplier: 2.35, gravityMultiplier: 0.35, jumpMultiplier: 1.55, description: 'Prototype de planeur : sauts longs et chute ralentie.' },
  { id: 'jetpack', kind: 'vehicle', type: 'jetpack', category: 'vehicles', label: 'Jetpack', icon: '🚀', speedMultiplier: 1.45, gravityMultiplier: 0.24, jumpMultiplier: 2.05, description: 'Prototype : forte impulsion et chute ralentie.' },
  { id: 'paraglider', kind: 'glider', type: 'paraglider', category: 'vehicles', label: 'Parapente', icon: '🪂', description: 'Saute d’un sommet puis Espace (ou ↑) en l’air pour ouvrir la voile · Z accélère, S freine · les colonnes blanches au-dessus des sommets font monter.' }, // Beta 4.29

  { id: 'health-potion', kind: 'consumable', type: 'health-potion', category: 'health', label: 'Potion de vie', icon: '🧪', heal: 40, description: 'Rend 40 points de vie.' },
  { id: 'medkit', kind: 'consumable', type: 'medkit', category: 'health', label: 'Kit de soins', icon: '🩹', heal: 75, description: 'Rend 75 points de vie.' },
  { id: 'energy-cell', kind: 'consumable', type: 'energy-cell', category: 'health', label: 'Cellule d’énergie', icon: '⚡', speedBoost: 1.45, duration: 15, description: 'Accélère les déplacements pendant 15 secondes.' },
  { id: 'shield', kind: 'consumable', type: 'shield', category: 'health', label: 'Bouclier énergétique', icon: '🔰', protection: 0.5, duration: 18, description: 'Réduit les dégâts pendant 18 secondes.' },

  { id: 'fireball', kind: 'magic', type: 'fireball', category: 'magic', label: 'Boule de feu', icon: '🔥', damage: 42, range: 25, radius: 3.2, cooldown: 0.85, burnDuration: 4, burnDamage: 6, recoil: 0.08, description: 'Explose dans un groupe et brûle les créatures pendant 4 secondes, sans détruire le terrain.' },
  { id: 'icebolt', kind: 'magic', type: 'icebolt', category: 'magic', label: 'Éclair de glace', icon: '🧊', damage: 27, range: 22, cooldown: 0.55, slowDuration: 4, description: 'Blesse et ralentit temporairement la cible.' },
  { id: 'heal-spell', kind: 'magic', type: 'heal-spell', category: 'magic', label: 'Soin magique', icon: '✨', heal: 55, cooldown: 4, description: 'Rend 55 points de vie.' },
  { id: 'teleport', kind: 'magic', type: 'teleport', category: 'magic', label: 'Téléportation', icon: '🌀', range: 16, cooldown: 2.5, description: 'Téléporte au-dessus du bloc visé.' }
];

export const ITEM_BY_ID = new Map(ITEM_CATALOG.map((item) => [item.id, item]));

export const DEFAULT_QUICKBAR = [
  'block-grass', 'block-stone', 'block-planks', 'block-bricks', 'block-glass',
  'pickaxe', 'sword', 'health-potion', 'fireball'
];

export function getItem(id) {
  return ITEM_BY_ID.get(id) ?? ITEM_BY_ID.get(DEFAULT_QUICKBAR[0]);
}

export function getAttackProfile(item) {
  if (!item) return { damage: 6, range: 3, cooldown: 0.45 };
  if (['weapon', 'magic'].includes(item.kind)) {
    return {
      damage: item.damage ?? 6,
      range: item.range ?? 7,
      radius: item.radius ?? 0,
      cooldown: item.cooldown ?? 0.45,
      slowDuration: item.slowDuration ?? 0,
      burnDuration: item.burnDuration ?? 0,
      burnDamage: item.burnDamage ?? 0,
      pellets: item.pellets ?? 1,
      spread: item.spread ?? 0,
      recoil: item.recoil ?? 0,
      automatic: Boolean(item.automatic),
      tracerColor: item.tracerColor ?? 0xffe5a6,
      magazineSize: item.magazineSize ?? 0,
      reloadTime: item.reloadTime ?? 0,
      zoomFov: item.zoomFov ?? 0
    };
  }
  if (item.kind === 'tool') return { damage: item.damage ?? 6, range: 5.5, cooldown: 0.4 };
  return { damage: 6, range: 4.5, cooldown: 0.45 };
}

export function getHitsToBreak(blockType, item) {
  const blockConfig = BLOCK_TYPES[blockType];
  if (!blockConfig || blockConfig.hardness <= 0) return Infinity;

  if (item?.kind === 'tool' && item.type === blockConfig.preferredTool) return 1;
  if (item?.kind === 'weapon') return Math.max(4, blockConfig.hardness + 2);
  if (item?.kind === 'tool') return Math.max(2, blockConfig.hardness);
  return Math.max(2, blockConfig.hardness + 1);
}
