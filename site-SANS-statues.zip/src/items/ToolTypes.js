export const TOOL_TYPES = {
  sword: {
    label: 'Épée', icon: '⚔', damage: 38, description: 'Arme rapide contre les monstres'
  },
  pickaxe: {
    label: 'Pioche', icon: '⛏', damage: 16, description: 'Pierre, verre et cristaux'
  },
  axe: {
    label: 'Hache', icon: '🪓', damage: 24, description: 'Bois, planches, feuilles et caisses'
  },
  shovel: {
    label: 'Pelle', icon: '⌁', damage: 12, description: 'Terre, herbe et sable'
  },
  hammer: {
    label: 'Marteau', icon: '🔨', damage: 27, description: 'Briques et obsidienne'
  }
};

export const TOOL_ORDER = ['sword', 'pickaxe', 'axe', 'shovel', 'hammer'];

export function getMonsterDamage(item) {
  if (item?.kind !== 'tool') return 6;
  return TOOL_TYPES[item.type]?.damage ?? 6;
}

export function getHitsToBreak(blockType, item, blockTypes) {
  const block = blockTypes[blockType];
  if (!block || block.hardness <= 0) return Infinity;

  if (item?.kind === 'tool' && item.type === block.preferredTool) return 1;
  if (item?.kind === 'tool' && item.type === 'sword') return Math.max(3, block.hardness + 1);
  if (item?.kind === 'tool') return Math.max(2, block.hardness);
  return Math.max(2, block.hardness + 1);
}
