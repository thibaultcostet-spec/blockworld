import * as THREE from 'three';
import { GroundingSystem } from '../world/GroundingSystem.js';
import { buildCharacter, rosterCharacter } from '../characters/CharacterFactory.js';
import { CreatureCombat } from '../combat/CreatureCombat.js';

const NAMES=['Maya','Léo','Amina','Paul','Nora','Yanis','Elena','Noah','Sofia','Hugo','Lina','Adam'];
const JOBS=['Guide','Jardinier','Bâtisseur','Garde'];
function shadowed(mesh){mesh.castShadow=true;mesh.receiveShadow=true;return mesh;}
function sphere(radius,material,segments=12){return shadowed(new THREE.Mesh(new THREE.SphereGeometry(radius,segments,Math.max(8,segments-2)),material));}
function capsule(radius,length,material){return shadowed(new THREE.Mesh(new THREE.CapsuleGeometry(radius,length,4,8),material));}

export class AIManager {
  constructor(scene,world,{touchMode=false}={}){
    this.scene=scene;this.world=world;this.touchMode=touchMode;this.group=new THREE.Group();this.group.name='LifeCitizensV3';scene.add(this.group);this.agents=[];this.grounding=new GroundingSystem(world,{maxStep:1.15,footprint:.18});
  }
  clear(){this.group.clear();this.agents=[];}
  spawn(worldId){
    this.clear();const count=this.touchMode?6:10;
    for(let index=0;index<count;index++){
      const agent=this.createAgent(index,worldId);const angle=index/count*Math.PI*2;const radius=7+(index%4)*3;const x=Math.round(Math.cos(angle)*radius),z=Math.round(Math.sin(angle)*radius);
      agent.userData.groundFootprint=.18;this.grounding.calibrate(agent);
      const shadow=new THREE.Mesh(new THREE.CircleGeometry(.34,18),new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.22,depthWrite:false}));
      shadow.rotation.x=-Math.PI/2;shadow.position.y=(agent.userData.modelBottom??0)+.012;shadow.scale.y=.52;shadow.userData.contactShadow=true;agent.add(shadow);
      this.grounding.settle(agent,x,z,0);agent.userData.home={x,z};agent.userData.work={x:Math.round(-z*.7),z:Math.round(x*.7)};this.group.add(agent);this.agents.push(agent);
    }
  }
  createAgent(index,worldId){
    // Beta 4.19 : habitants tirés de la galerie de 8 personnages originaux (CharacterFactory).
    const spec=rosterCharacter(index);
    const group=buildCharacter(spec);
    group.traverse((object)=>{if(object.isMesh){object.castShadow=true;object.receiveShadow=true;}});
    CreatureCombat.tag(group,'citizen');
    group.userData={...group.userData,name:spec.name,age:spec.age,profession:spec.profession,mood:'Heureux',needs:{energy:80,hunger:15,social:75},activity:'home',activityLabel:'Chez soi',path:[],pathIndex:0,speed:.9+(index%3)*.08,worldId,groundFootprint:.18};
    return group;
  }
}
