export class InteractionSystem {
  nearest(agents, position, range=4.5){ let best=null,bestD=range*range; for(const a of agents){const d=a.position.distanceToSquared(position);if(d<bestD){best=a;bestD=d;}} return best; }
  describe(agent){ if(!agent) return 'Aucun habitant à proximité.'; const d=agent.userData; return `${d.name} · ${d.profession} · ${d.mood} · ${d.activityLabel}`; }
}
