import * as THREE from 'three';
import { AIManager } from './AIManager.js';
import { NeedsSystem } from './NeedsSystem.js';
import { ScheduleSystem } from './ScheduleSystem.js';
import { PathFinder } from './PathFinder.js';
import { InteractionSystem } from './InteractionSystem.js';
import { GroundingSystem } from '../world/GroundingSystem.js';
import { EntityMotionEngine } from '../movement/EntityMotionEngine.js';
const LABELS={sleep:'Dort',home:'À la maison',work:'Travaille',meal:'Prend un repas',walk:'Se promène',landmark:'Visite un monument'};
export class LifeEngine {
  constructor(scene,world,options={}){this.world=world;this.ai=new AIManager(scene,world,options);this.needs=new NeedsSystem();this.schedule=new ScheduleSystem();this.paths=new PathFinder(world);this.interactions=new InteractionSystem();this.grounding=new GroundingSystem(world,{maxStep:1.15});this.motion=new EntityMotionEngine(world);this.elapsed=0;this.hour=7;this.worldId='';}
  setWorld(def){this.worldId=def.id;this.ai.spawn(def.id);this.elapsed=0;this.hour=7;}
  targetFor(a,activity){const d=a.userData;if(activity==='home'||activity==='sleep'||activity==='meal')return d.home;if(activity==='work')return d.work;const n=this.elapsed*.04+d.age;return{x:d.home.x+Math.cos(n)*8,z:d.home.z+Math.sin(n)*8};}
  update(delta,playerPosition){this.elapsed+=delta;this.hour=(7+this.elapsed/18)%24;for(const a of this.ai.agents){const d=a.userData;if(d.dead)continue;this.needs.update(a,delta,this.hour);const activity=this.schedule.getActivity(d.profession,this.hour);if(activity!==d.activity||!d.path.length){d.activity=activity;d.activityLabel=LABELS[activity];const target=this.targetFor(a,activity);d.path=this.paths.findPath(a.position,target);d.pathIndex=0;}let travelled=0;const node=d.path[d.pathIndex];if(node&&activity!=='sleep'){const targetY=(this.grounding.groundY(node.x,node.z,0)??a.position.y)+(a.userData.footOffset??0);const target=new THREE.Vector3(node.x,targetY,node.z);const direction=target.clone().sub(a.position);direction.y=0;if(direction.lengthSq()<.12)d.pathIndex+=1;else{direction.normalize();const px=a.position.x,pz=a.position.z;this.motion.move(a,{x:a.position.x+direction.x*d.speed*delta,z:a.position.z+direction.z*d.speed*delta},delta,{speed:d.speed,maxStep:.92,bob:.01});travelled=Math.hypot(a.position.x-px,a.position.z-pz);
          // Beta 4.11 : un habitant bloqué ne piétine plus : après 1,2 s il saute l'étape puis recalcule son trajet.
          if(travelled<.002){d.stuckTime=(d.stuckTime||0)+delta;if(d.stuckTime>1.2){d.stuckTime=0;d.pathIndex+=1;if(d.pathIndex>=d.path.length)d.path=[];}}else d.stuckTime=0;}}
        this.animateGait(a,d,travelled,delta);a.visible=!playerPosition||a.position.distanceToSquared(playerPosition)<10000;}}
  // Beta 4.11 : démarche pilotée par le déplacement réel. La phase avance avec la distance
  // parcourue (≈ 1 m par cycle) et l'amplitude suit la vitesse mesurée : à l'arrêt ou contre
  // un obstacle, les membres reviennent en douceur au repos au lieu de marcher sur place.
  animateGait(a,d,travelled,delta){
    if(d.hd&&!d.dead)d.hd.update(delta,delta>0?travelled/delta:0); // Beta 4.24 : personnage HD
    const speed=delta>0?travelled/delta:0;
    d.gaitPhase=((d.gaitPhase??d.age*.17)+travelled*6)%(Math.PI*2);
    d.gaitBlend=THREE.MathUtils.damp(d.gaitBlend??0,THREE.MathUtils.clamp(speed/Math.max(.1,d.speed),0,1),8,delta);
    const wave=Math.sin(d.gaitPhase),k=d.gaitBlend;
    for(const c of a.children){
      if(c.userData.leg){c.rotation.x=c.userData.leg*wave*.48*k;if(c.userData.knee)c.userData.knee.rotation.x=Math.max(0,-c.userData.leg*wave)*.32*k;}
      if(c.userData.arm){c.rotation.x=-c.userData.arm*wave*.42*k;c.rotation.z=c.userData.arm*-.035;if(c.userData.elbow)c.userData.elbow.rotation.x=.10+Math.max(0,c.userData.arm*wave)*.18*k;}
    }
  }
  interact(position){return this.interactions.describe(this.interactions.nearest(this.ai.agents,position));}
  get count(){return this.ai.agents.length;}
}
