export class NeedsSystem {
  update(agent, delta, hour) {
    const needs = agent.userData.needs;
    needs.energy = Math.max(0, Math.min(100, needs.energy + (hour >= 22 || hour < 6 ? 4 : -0.42) * delta));
    needs.hunger = Math.max(0, Math.min(100, needs.hunger + 0.28 * delta));
    needs.social = Math.max(0, Math.min(100, needs.social - 0.12 * delta));
    agent.userData.mood = needs.energy < 25 ? 'Fatigué' : needs.hunger > 75 ? 'Affamé' : needs.social < 30 ? 'Solitaire' : 'Heureux';
  }
}
