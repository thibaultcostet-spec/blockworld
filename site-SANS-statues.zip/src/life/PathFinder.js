import { GroundingSystem } from '../world/GroundingSystem.js';
const DIRS = [[1,0],[-1,0],[0,1],[0,-1]];
export class PathFinder {
  constructor(world) { this.world = world; this.grounding = new GroundingSystem(world,{maxStep:1.15}); }
  isWalkable(x, z) {
    const sample = this.grounding.sample(x,z);
    return this.grounding.isDryGround(sample) && !this.world.isSolidAt(Math.round(x), Math.ceil(sample.y + 0.5), Math.round(z));
  }
  findPath(start, goal, limit = 180) {
    const sx=Math.round(start.x), sz=Math.round(start.z), gx=Math.round(goal.x), gz=Math.round(goal.z);
    const key=(x,z)=>`${x},${z}`; const queue=[[sx,sz]]; const came=new Map([[key(sx,sz),null]]);
    let found=null;
    while(queue.length && came.size<limit){ const [x,z]=queue.shift(); if(Math.abs(x-gx)+Math.abs(z-gz)<=1){found=[x,z];break;}
      const ordered=[...DIRS].sort((a,b)=>Math.abs(x+a[0]-gx)+Math.abs(z+a[1]-gz)-Math.abs(x+b[0]-gx)-Math.abs(z+b[1]-gz));
      for(const [dx,dz] of ordered){const nx=x+dx,nz=z+dz,k=key(nx,nz); if(came.has(k)||!this.isWalkable(nx,nz)||!this.grounding.canStep(x,z,nx,nz))continue; came.set(k,[x,z]);queue.push([nx,nz]);}
    }
    if(!found) return [{x:goal.x,z:goal.z}]; const path=[]; let cur=found;
    while(cur){path.push({x:cur[0],z:cur[1]});cur=came.get(key(cur[0],cur[1]));} return path.reverse().slice(1);
  }
}
