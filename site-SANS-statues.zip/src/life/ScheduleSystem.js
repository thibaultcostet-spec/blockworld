export class ScheduleSystem {
  getActivity(profession, hour) {
    if (hour < 6 || hour >= 22) return 'sleep';
    if (hour < 8) return 'home';
    if (hour < 12) return 'work';
    if (hour < 13) return 'meal';
    if (hour < 18) return 'work';
    if (hour < 20) return profession === 'Guide' ? 'landmark' : 'walk';
    return 'home';
  }
}
