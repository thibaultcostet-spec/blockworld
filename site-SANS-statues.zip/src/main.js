import { Game } from './core/Game.js';
import { DEFAULT_VEGETATION_DENSITY, VEGETATION_STORAGE_KEY, normalizeVegetationDensity } from './worlds/ProceduralVegetation.js';

const q = (selector) => document.querySelector(selector);
const elements = {
  container: q('#game'),
  startScreen: q('#start-screen'),
  startButton: q('#start-button'),
  deviceMessage: q('#device-message'),
  multiplayerPanel: q('#multiplayer-panel'),
  networkStatus: q('#network-status'),
  networkMessage: q('#network-message'),
  networkSetup: q('#network-setup'),
  networkRoom: q('#network-room'),
  nicknameInput: q('#nickname-input'),
  roomModeSelect: q('#room-mode-select'),
  roomWorldSelect: q('#room-world-select'),
  createRoomButton: q('#create-room-button'),
  roomCodeInput: q('#room-code-input'),
  joinRoomButton: q('#join-room-button'),
  roomCodeDisplay: q('#room-code-display'),
  copyRoomCodeButton: q('#copy-room-code-button'),
  roomHostLabel: q('#room-host-label'),
  playerList: q('#player-list'),
  leaveRoomButton: q('#leave-room-button'),
  multiplayerIndicator: q('#multiplayer-indicator'),
  worldSelector: q('#world-selector'),
  worldDescription: q('#world-description'),
  worldLandmarks: q('#world-landmarks'),
  modeSelector: q('#mode-selector'),
  modeDescription: q('#mode-description'),
  statusElement: q('#status'),
  healthElement: q('#health'),
  lootElement: q('#loot'),
  modeElement: q('#mode-indicator'),
  modeTimerElement: q('#mode-timer'),
  objectiveElement: q('#objective'),
  protectionElement: q('#protection-indicator'),
  radarElement: q('#radar'),
  hotbarElement: q('#hotbar'),
  saveButton: q('#save-button'),
  resetButton: q('#reset-button'),
  fullscreenButton: q('#fullscreen-button'),
  gameFullscreenButton: q('#game-fullscreen-button'),
  musicButton: q('#music-button'),
  gameMusicButton: q('#game-music-button'),
  musicVolume: q('#music-volume'),
  musicVolumeValue: q('#music-volume-value'),
  sfxButton: q('#sfx-button'),
  gameSfxButton: q('#game-sfx-button'),
  sfxVolume: q('#sfx-volume'),
  sfxVolumeValue: q('#sfx-volume-value'),
  vegetationDensity: q('#vegetation-density'),
  vegetationDensityValue: q('#vegetation-density-value'),
  graphicsQualitySelect: q('#graphics-quality'),
  installButton: q('#install-button'),
  inventoryButton: q('#inventory-button'),
  passportButton: q('#passport-button'),
  gamePassportButton: q('#game-passport-button'),
  mobilePassportButton: q('#mobile-passport-button'),
  stabilityButton: q('#stability-button'),
  gameStabilityButton: q('#game-stability-button'),
  mobileStabilityButton: q('#mobile-stability-button'),
  stabilityPanel: q('#stability-panel'),
  stabilitySummary: q('#stability-summary'),
  stabilityCounts: q('#stability-counts'),
  stabilityDetails: q('#stability-details'),
  stabilityToggleButton: q('#stability-toggle-button'),
  disasterButton: q('#disaster-button'),
  gameDisasterButton: q('#game-disaster-button'),
  mobileDisasterButton: q('#mobile-disaster-button'),
  mobileTalkButton: q('#mobile-talk-button'),
  disasterPanel: q('#disaster-panel'),
  disasterTitle: q('#disaster-title'),
  disasterTimer: q('#disaster-timer'),
  disasterRisk: q('#disaster-risk'),
  cameraViewButton: q('#camera-view-button'),
  inventoryScreen: q('#inventory-screen'),
  inventoryCloseButton: q('#inventory-close-button'),
  inventoryCategories: q('#inventory-categories'),
  inventoryGrid: q('#inventory-grid'),
  inventorySearch: q('#inventory-search'),
  inventorySelection: q('#inventory-selection'),
  passportScreen: q('#passport-screen'),
  passportCloseButton: q('#passport-close-button'),
  passportResetButton: q('#passport-reset-button'),
  passportContent: q('#passport-content'),
  passportSummary: q('#passport-summary'),
  navigationPanel: q('#navigation-panel'),
  minimapCanvas: q('#minimap-canvas'),
  mapToggleButton: q('#map-toggle-button'),
  mapWorldTitle: q('#map-world-title'),
  compassHeading: q('#compass-heading'),
  nearestLandmark: q('#nearest-landmark'),
  mapProgress: q('#map-progress'),
  joystick: q('#joystick'),
  joystickKnob: q('#joystick-knob'),
  lookZone: q('#look-zone'),
  attackButton: q('#attack-button'),
  placeButton: q('#place-button'),
  jumpButton: q('#jump-button'),
  pauseButton: q('#pause-button'),
  mobileInventoryButton: q('#mobile-inventory-button'),
  mobileCameraButton: q('#mobile-camera-button'),
  mobileZoomButton: q('#mobile-zoom-button'),
  mobileReloadButton: q('#mobile-reload-button'),
  reloadButton: q('#reload-button'),
  weaponElement: q('#weapon-status'),
  scopeOverlay: q('#scope-overlay'),
  scopeDistance: q('#scope-distance')
};

if (elements.vegetationDensity) {
  let storedDensity = DEFAULT_VEGETATION_DENSITY;
  try { storedDensity = normalizeVegetationDensity(localStorage.getItem(VEGETATION_STORAGE_KEY)); } catch (_error) {}
  elements.vegetationDensity.value = String(storedDensity);
  elements.vegetationDensityValue.textContent = `${storedDensity} %`;
  elements.vegetationDensity.addEventListener('input', () => {
    const density = normalizeVegetationDensity(elements.vegetationDensity.value);
    elements.vegetationDensityValue.textContent = `${density} %`;
    try { localStorage.setItem(VEGETATION_STORAGE_KEY, String(density)); } catch (_error) {}
  });
}

let installPrompt = null;
window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  installPrompt = event;
  elements.installButton.classList.remove('hidden');
});
elements.installButton.addEventListener('click', async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  elements.installButton.classList.add('hidden');
});
window.addEventListener('appinstalled', () => elements.installButton.classList.add('hidden'));
// Beta 4.21 : main.js est chargé par boot.js APRÈS l'événement « load » (depuis la 4.9) : l'écouteur
// ne se déclenchait jamais, le service worker n'était pas enregistré (ni hors ligne, ni installation).
const whenLoaded = (callback) => { if (document.readyState === 'complete') callback(); else window.addEventListener('load', callback, { once: true }); };
if ('serviceWorker' in navigator) {
  whenLoaded(async () => {
    const hadController=Boolean(navigator.serviceWorker.controller);
    try {
      const registration=await navigator.serviceWorker.register('./service-worker.js?v=3.0-beta4.35',{updateViaCache:'none'});
      await registration.update();
      if(registration.waiting)registration.waiting.postMessage({type:'SKIP_WAITING'});
      registration.addEventListener('updatefound',()=>{
        const worker=registration.installing;
        worker?.addEventListener('statechange',()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)worker.postMessage({type:'SKIP_WAITING'});});
      });
      navigator.serviceWorker.addEventListener('controllerchange',()=>{
        if(!hadController||sessionStorage.getItem('blockworld-beta49-reloaded'))return;
        sessionStorage.setItem('blockworld-beta49-reloaded','1');
        location.reload();
      });
    } catch(error) { console.warn('Mise à jour PWA impossible',error); }
  });
}

const game = new Game(elements);
if (new URLSearchParams(location.search).get('debug') === '1') window.__blockWorldGame = game;
game.start().catch((error) => {
  console.error(error);
  elements.statusElement.textContent = `Erreur : ${error.message}`;
  elements.deviceMessage.textContent = 'Le moteur 3D n’a pas pu être initialisé. Consulte la console du navigateur.';
});
