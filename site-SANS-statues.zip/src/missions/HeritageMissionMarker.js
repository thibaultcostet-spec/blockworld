import * as THREE from 'three';

export class HeritageMissionMarker {
  constructor(scene, world) {
    this.scene = scene;
    this.world = world;
    this.group = new THREE.Group();
    this.group.name = 'HeritageMissionZone';
    this.group.visible = false;

    const ringMaterial = new THREE.MeshBasicMaterial({
      color: 0xffd95a,
      transparent: true,
      opacity: 0.5,
      side: THREE.DoubleSide,
      depthWrite: false
    });
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.86, 1, 64), ringMaterial);
    this.ring.rotation.x = -Math.PI / 2;
    this.group.add(this.ring);

    const beamMaterial = new THREE.MeshBasicMaterial({
      color: 0xffe88a,
      transparent: true,
      opacity: 0.16,
      depthWrite: false
    });
    this.beam = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 8, 12, 1, true), beamMaterial);
    this.beam.position.y = 4;
    this.group.add(this.beam);
    this.scene.add(this.group);
    this.radius = 0;
  }

  setDisplay(display) {
    const zone = display?.zone;
    if (!zone?.point) {
      this.group.visible = false;
      return;
    }
    this.radius = Math.max(4, zone.radius ?? 18);
    const y = this.world.getSurfaceHeight(zone.point.x, zone.point.z) + 0.55;
    this.group.position.set(zone.point.x, y, zone.point.z);
    this.ring.scale.setScalar(this.radius);
    this.group.visible = true;
  }

  update(delta, elapsed = performance.now() * 0.001) {
    if (!this.group.visible) return;
    const pulse = 0.92 + Math.sin(elapsed * 2.6) * 0.08;
    this.ring.scale.setScalar(this.radius * pulse);
    this.ring.material.opacity = 0.38 + Math.sin(elapsed * 3.1) * 0.12;
    this.group.rotation.y += delta * 0.12;
  }

  dispose() {
    this.scene.remove(this.group);
    this.ring.geometry.dispose();
    this.ring.material.dispose();
    this.beam.geometry.dispose();
    this.beam.material.dispose();
  }
}
