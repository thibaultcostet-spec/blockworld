import { getWorldDefinition } from '../worlds/WorldRegistry.js';

export const MISSION_INITIAL_ITEMS = [
  'block-grass', 'block-dirt', 'block-stone', 'block-sand', 'block-wood', 'block-leaves',
  'axe', 'shovel', 'health-potion', 'tshirt', 'jeans',
  'fishing-rod', 'campfire', 'paraglider' // Beta 4.27 (+ parapente en 4.29) : la faim est active en Missions, on doit pouvoir pêcher et cuisiner
];

export const MISSION_QUICKBAR = [
  'block-grass', 'block-dirt', 'block-stone', 'block-wood', 'block-leaves',
  'axe', 'shovel', 'health-potion', 'tshirt'
];

const WORLD_RESTORATION = {
  europe: {
    solid: ['bricks', 'stone', 'concrete'],
    solidLabel: 'briques, pierre ou béton',
    decoration: ['lantern', 'glass', 'window'],
    decorationLabel: 'lanternes, verre ou fenêtres'
  },
  africa: {
    solid: ['bricks', 'sand', 'concrete'],
    solidLabel: 'briques, sable ou béton',
    decoration: ['lantern', 'glass', 'window'],
    decorationLabel: 'lanternes, verre ou fenêtres'
  },
  asia: {
    solid: ['stone', 'bricks', 'concrete'],
    solidLabel: 'pierre, briques ou béton',
    decoration: ['lantern', 'glass', 'window'],
    decorationLabel: 'lanternes, verre ou fenêtres'
  },
  americas: {
    solid: ['stone', 'planks', 'concrete'],
    solidLabel: 'pierre, planches ou béton',
    decoration: ['lantern', 'glass', 'window'],
    decorationLabel: 'lanternes, verre ou fenêtres'
  },
  oceania: {
    solid: ['stone', 'wood', 'planks'],
    solidLabel: 'pierre, bois ou planches',
    decoration: ['lantern', 'glass', 'window'],
    decorationLabel: 'lanternes, verre ou fenêtres'
  }
};

export function getMissionLibrary(worldId) {
  const world = getWorldDefinition(worldId);
  const points = world.pointsOfInterest ?? [];
  const first = points[0];
  const second = points[1] ?? first;
  const profile = WORLD_RESTORATION[world.id] ?? WORLD_RESTORATION.europe;

  return [
    {
      id: `${world.id}-first-landmarks`,
      title: `Premiers repères · ${world.label}`,
      summary: 'Découvre les deux premiers monuments indiqués sur la mini-carte.',
      objectives: points.slice(0, 2).map((point) => ({
        id: `discover-${point.id}`,
        event: 'discover',
        targetType: point.id,
        target: 1,
        landmarkId: point.id,
        label: `Découvrir ${point.name}`
      })),
      unlocks: ['block-planks', 'block-bricks', 'block-concrete', 'pickaxe', 'hammer']
    },
    {
      id: `${world.id}-grand-tour`,
      title: `Grand tour du patrimoine · ${world.label}`,
      summary: 'Complète le passeport du continent en visitant tous ses monuments.',
      objectives: points.map((point) => ({
        id: `tour-${point.id}`,
        event: 'discover',
        targetType: point.id,
        target: 1,
        landmarkId: point.id,
        label: `Tampon ${point.name}`
      })),
      unlocks: ['block-glass', 'block-window', 'block-door', 'block-lantern', 'sword']
    },
    {
      id: `${world.id}-consolidation`,
      title: `Consolidation · ${first?.name ?? world.label}`,
      summary: `Renforce la zone balisée avec ${profile.solidLabel}.`,
      objectives: [{
        id: `restore-${first?.id ?? world.id}`,
        event: 'place',
        targetTypes: profile.solid,
        target: 10,
        landmarkId: first?.id,
        radius: Math.max(18, first?.discoveryRadius ?? 16),
        label: `Poser 10 blocs de consolidation près de ${first?.name ?? 'la zone'}`
      }],
      unlocks: ['medkit', 'shield', 'fireball', 'icebolt']
    },
    {
      id: `${world.id}-showcase`,
      title: `Mise en valeur · ${second?.name ?? world.label}`,
      summary: `Éclaire et embellis le site avec ${profile.decorationLabel}.`,
      objectives: [{
        id: `enhance-${second?.id ?? world.id}`,
        event: 'place',
        targetTypes: profile.decoration,
        target: 6,
        landmarkId: second?.id,
        radius: Math.max(18, second?.discoveryRadius ?? 16),
        label: `Installer 6 éléments de mise en valeur près de ${second?.name ?? 'la zone'}`
      }],
      unlocks: [
        'pistol', 'revolver', 'shotgun', 'sniper', 'dmr', 'smg', 'carbine', 'ak47', 'grenade',
        'heal-spell', 'teleport', 'jetpack', 'armor', 'energy-cell'
      ]
    }
  ];
}

// Compatibilité avec les imports historiques et les outils d’inspection.
export const MISSION_LIBRARY = getMissionLibrary('europe');
