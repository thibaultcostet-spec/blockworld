import { MISSION_INITIAL_ITEMS, getMissionLibrary } from './MissionLibrary.js';
import { ITEM_CATALOG } from '../items/ItemCatalog.js';
import { getWorldDefinition } from '../worlds/WorldRegistry.js';

const SAVE_KEY = 'blockworld-v1.7-heritage-missions';

function safeParse(raw) {
  try {
    const value = JSON.parse(raw ?? '{}');
    return value && typeof value === 'object' ? value : {};
  } catch {
    return {};
  }
}

export class MissionManager {
  constructor({ onChange, onComplete } = {}) {
    this.onChange = onChange;
    this.onComplete = onComplete;
    this.data = safeParse(localStorage.getItem(SAVE_KEY));
    this.world = getWorldDefinition('europe');
    this.library = getMissionLibrary(this.world.id);
    this.ensureWorldState();
  }

  defaultState() {
    return { currentIndex: 0, progress: {}, completedIds: [] };
  }

  ensureWorldState() {
    if (!this.data.worlds || typeof this.data.worlds !== 'object') this.data.worlds = {};
    const value = this.data.worlds[this.world.id];
    if (!value || !Number.isInteger(value.currentIndex) || !value.progress || !Array.isArray(value.completedIds)) {
      this.data.worlds[this.world.id] = this.defaultState();
    }
    return this.data.worlds[this.world.id];
  }

  get state() {
    return this.ensureWorldState();
  }

  setWorld(worldDefinition, passport = null) {
    this.world = worldDefinition ?? getWorldDefinition('europe');
    this.library = getMissionLibrary(this.world.id);
    this.ensureWorldState();
    if (passport) this.syncDiscoveries(passport, { notify: false });
    this.notify();
  }

  save() {
    localStorage.setItem(SAVE_KEY, JSON.stringify(this.data));
  }

  reset() {
    this.data.worlds ??= {};
    this.data.worlds[this.world.id] = this.defaultState();
    this.save();
    this.notify();
  }

  get currentMission() {
    return this.library[this.state.currentIndex] ?? null;
  }

  getAllowedItemIds() {
    if (!this.currentMission) return new Set(ITEM_CATALOG.map((item) => item.id));
    const allowed = new Set(MISSION_INITIAL_ITEMS);
    for (let index = 0; index < Math.min(this.state.currentIndex, this.library.length); index += 1) {
      for (const itemId of this.library[index].unlocks ?? []) allowed.add(itemId);
    }
    return allowed;
  }

  getProgressValue(objective) {
    return Math.min(objective.target, this.state.progress[objective.id] ?? 0);
  }

  pointForObjective(objective) {
    return this.world.pointsOfInterest?.find((point) => point.id === objective?.landmarkId) ?? null;
  }

  objectiveMatches(objective, event) {
    if (objective.event !== event.type) return false;
    if (objective.targetType && objective.targetType !== event.targetType) return false;
    if (objective.targetTypes && !objective.targetTypes.includes(event.targetType)) return false;
    if (objective.landmarkId && objective.event === 'place') {
      const point = this.pointForObjective(objective);
      if (!point || !Number.isFinite(event.x) || !Number.isFinite(event.z)) return false;
      const distance = Math.hypot(event.x - point.x, event.z - point.z);
      if (distance > (objective.radius ?? 18)) return false;
    }
    return true;
  }

  firstIncompleteObjective() {
    const mission = this.currentMission;
    return mission?.objectives?.find((objective) => this.getProgressValue(objective) < objective.target) ?? null;
  }

  getDisplay() {
    const mission = this.currentMission;
    if (!mission) {
      return {
        title: `Patrimoine ${this.world.label} terminé`,
        text: 'Toutes les missions de découverte et de restauration sont accomplies. Le catalogue complet est débloqué.',
        complete: true,
        trackPointId: null,
        zone: null
      };
    }
    const details = mission.objectives
      .map((objective) => `${objective.label} : ${this.getProgressValue(objective)}/${objective.target}`)
      .join(' · ');
    const active = this.firstIncompleteObjective();
    const point = this.pointForObjective(active);
    return {
      title: mission.title,
      text: `${mission.summary} · ${details}`,
      complete: false,
      trackPointId: point?.id ?? null,
      zone: active?.event === 'place' && point
        ? { point, radius: active.radius ?? 18, event: active.event, targetTypes: active.targetTypes ?? [] }
        : null
    };
  }

  advanceIfComplete() {
    const mission = this.currentMission;
    if (!mission) return false;
    const completed = mission.objectives.every((objective) => this.getProgressValue(objective) >= objective.target);
    if (!completed) return false;
    if (!this.state.completedIds.includes(mission.id)) this.state.completedIds.push(mission.id);
    this.state.currentIndex += 1;
    this.state.progress = {};
    this.onComplete?.(mission, this.world);
    return true;
  }

  handleEvent(event, { notify = true } = {}) {
    let mission = this.currentMission;
    if (!mission) return false;
    let changed = false;

    for (const objective of mission.objectives) {
      if (!this.objectiveMatches(objective, event)) continue;
      const previous = this.getProgressValue(objective);
      if (previous >= objective.target) continue;
      this.state.progress[objective.id] = Math.min(objective.target, previous + (event.amount ?? 1));
      changed = true;
    }
    if (!changed) return false;

    this.advanceIfComplete();
    this.save();
    if (notify) this.notify();
    return true;
  }

  syncDiscoveries(passport, { notify = true } = {}) {
    if (!passport) return;
    // Rejoue les tampons existants sur la mission active, puis sur la suivante si elle se complète.
    let guard = 0;
    let changed = false;
    while (this.currentMission && guard < this.library.length + 1) {
      guard += 1;
      const beforeIndex = this.state.currentIndex;
      for (const point of this.world.pointsOfInterest ?? []) {
        if (passport.isDiscovered(this.world.id, point.id)) {
          changed = this.handleEvent({ type: 'discover', targetType: point.id, amount: 1 }, { notify: false }) || changed;
        }
      }
      if (this.state.currentIndex === beforeIndex) break;
    }
    if (changed) this.save();
    if (notify) this.notify();
  }

  notify() {
    this.onChange?.(this.getDisplay(), this.getAllowedItemIds(), this.world);
  }
}
