import { BLOCK_TYPES } from '../world/BlockTypes.js';

// BlockWorld V3.0 Beta 4.31 — barricades : résistance des blocs posés face au « siège » des monstres.
// Un monstre bloqué par un mur construit par le joueur le ronge ; plusieurs monstres s'additionnent ;
// un bloc délaissé se répare lentement. Résistance = 40 PV × dureté (planches 80, pierre 120, béton 160).
// Un mur de N blocs de haut est franchi quand N − 1 blocs ont cédé (les monstres montent une marche d'un bloc).
// Module pur (testable sous Node).

export const SIEGE_DPS = { slime: 4, spider: 3, goblin: 6, golem: 22, wraith: 5 }; // dégâts par seconde sur un bloc
export const SIEGE_REGEN = { delay: 4, perSecond: 8 };

export function siegeDps(type) { return SIEGE_DPS[type] ?? 3; }

export function blockHealth(type) {
  const hardness = BLOCK_TYPES[type]?.hardness ?? 1;
  return Math.max(30, 40 * hardness);
}

/** Un bloc peut être rongé s'il est plein et ajouté par le joueur (jamais le terrain, les monuments ni la base). */
export function isSiegeable({ type, y, playerBuilt, protectedBlock = false }) {
  return Boolean(playerBuilt) && !protectedBlock && y > 0 && Boolean(BLOCK_TYPES[type]?.solid) && (BLOCK_TYPES[type]?.hardness ?? 0) < 90;
}

export class SiegeTracker {
  constructor({ regenDelay = SIEGE_REGEN.delay, regenPerSecond = SIEGE_REGEN.perSecond } = {}) {
    this.regenDelay = regenDelay;
    this.regenPerSecond = regenPerSecond;
    this.entries = new Map();
    this.clock = 0;
  }

  /** Inflige `amount` PV au bloc. Renvoie { broken, ratio } ; un bloc cassé est oublié. */
  hit(key, type, amount) {
    let entry = this.entries.get(key);
    if (!entry) { const max = blockHealth(type); entry = { hp: max, max, last: this.clock }; this.entries.set(key, entry); }
    entry.hp -= Math.max(0, amount);
    entry.last = this.clock;
    if (entry.hp <= 0) { this.entries.delete(key); return { broken: true, ratio: 0 }; }
    return { broken: false, ratio: entry.hp / entry.max };
  }

  forget(key) { this.entries.delete(key); }
  clear() { this.entries.clear(); this.clock = 0; }

  /** Répare les blocs délaissés depuis plus de `regenDelay` secondes. */
  update(delta) {
    this.clock += Math.max(0, delta);
    for (const [key, entry] of this.entries) {
      if (this.clock - entry.last < this.regenDelay) continue;
      entry.hp = Math.min(entry.max, entry.hp + this.regenPerSecond * delta);
      if (entry.hp >= entry.max) this.entries.delete(key);
    }
  }

  get damagedCount() { return this.entries.size; }
}
