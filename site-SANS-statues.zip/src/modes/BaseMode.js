export class BaseMode {
  constructor(game, definition) {
    this.game = game;
    this.definition = definition;
    this.id = definition.id;
  }

  select() {
    this.game.hud.setMode(this.definition.label, this.definition.icon);
  }

  startSession() {}
  update() {}
  onEvent() {}
  reset() {}

  get allowsCombat() { return true; }
  get spawnProtectionSeconds() { return 7; }
  get targetMonsterCount() { return 0; }
  get allowedItemIds() { return null; }
  get quickbarTemplate() { return null; }
}
