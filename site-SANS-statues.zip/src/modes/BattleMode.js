import { BaseMode } from './BaseMode.js';

const PREPARATION_SECONDS = 60;
const COMBAT_SECONDS = 180;
const BLOCK_BUDGET = 80;
const TRAINING_OFFSETS = [[8,0],[-8,0],[0,8],[0,-8],[11,7],[-11,-7]];

export class BattleMode extends BaseMode {
  constructor(game, definition) {
    super(game, definition);
    this.phase = 'idle';
    this.remaining = 0;
    this.blocksRemaining = BLOCK_BUDGET;
    this.phaseEndsAt = 0;
    this.lastHudSecond = -1;
    this.trainingHits = 0;
  }

  get allowsCombat() { return this.phase === 'combat'; }
  get allowsConstruction() { return this.phase === 'preparation'; }
  get spawnProtectionSeconds() { return this.phase === 'combat' ? 8 : 0; }

  trainingPositions() {
    const origin = this.game.world.getSpawnPoint();
    return TRAINING_OFFSETS.map(([dx,dz]) => {
      const position = origin.clone();
      position.x += dx; position.z += dz;
      position.y = this.game.world.getSurfaceHeight(position.x, position.z);
      return position;
    });
  }

  startSession() {
    this.game.hud.setItemAvailability(null);
    this.trainingHits = 0;
    this.blocksRemaining = BLOCK_BUDGET;
    this.lastHudSecond = -1;
    if (this.game.multiplayerActive) {
      this.game.monsters.configure({ targetCount: 0, aggressionMultiplier: 0, attacksEnabled: false });
      this.game.monsters.clear();
      this.applyServerState(this.game.multiplayer.battleState);
    } else {
      this.phase = 'preparation';
      this.phaseEndsAt = performance.now() + PREPARATION_SECONDS * 1000;
      const positions = this.trainingPositions();
      this.game.monsters.configure({ targetCount: positions.length, aggressionMultiplier: 0, attacksEnabled: false, spawnTypes: ['training_dummy'] });
      this.game.monsters.spawnInitial({ positions });
    }
    this.refreshHud(true);
  }

  applyServerState(state) {
    if (!state) return;
    this.phase = state.phase || 'preparation';
    this.remaining = Math.max(0, Number(state.remaining) || 0);
    this.blocksRemaining = Math.max(0, Number(state.blocksRemaining ?? BLOCK_BUDGET));
    this.phaseEndsAt = performance.now() + this.remaining * 1000;
    this.refreshHud(true);
  }

  update() {
    if (this.phase === 'idle' || this.phase === 'finished') return;
    this.remaining = Math.max(0, (this.phaseEndsAt - performance.now()) / 1000);
    // Beta 4.16 : en multijoueur, bascule locale au même instant que le serveur (calendrier
    // déterministe 60 s + 180 s), puis recalage auprès du serveur, qui reste l'arbitre des tirs.
    if (this.game.multiplayerActive && this.remaining <= 0) {
      if (this.phase === 'preparation') {
        this.phase = 'combat';
        this.phaseEndsAt = performance.now() + COMBAT_SECONDS * 1000;
        this.game.spawnProtection?.start?.(8);
        this.game.hud.setStatus('Combat lancé : armes débloquées, construction verrouillée');
      } else if (this.phase === 'combat') {
        this.phase = 'finished';
        this.game.hud.setStatus('Manche Battle terminée');
      }
      this.game.multiplayer?.requestBattleSync?.();
    }
    if (!this.game.multiplayerActive && this.remaining <= 0) {
      if (this.phase === 'preparation') {
        this.phase = 'combat';
        this.phaseEndsAt = performance.now() + COMBAT_SECONDS * 1000;
        this.game.spawnProtection.start(8);
        this.game.hud.setStatus('Combat lancé : armes débloquées, construction verrouillée');
      } else {
        this.phase = 'finished';
        this.game.hud.setStatus('Manche Battle terminée');
      }
    }
    // Temps restant recalculé après une éventuelle bascule (sinon une image « 0:00 » en début de phase).
    this.remaining = Math.max(0, (this.phaseEndsAt - performance.now()) / 1000);
    this.refreshHud();
  }

  refreshHud(force = false) {
    const second = Math.max(0, Math.ceil(this.remaining));
    if (!force && second === this.lastHudSecond) return;
    this.lastHudSecond = second;
    const clock = `${Math.floor(second / 60)}:${String(second % 60).padStart(2, '0')}`;
    if (this.phase === 'preparation') {
      this.game.hud.setModeTimer(`Préparation · ${clock} · ${this.blocksRemaining}/${BLOCK_BUDGET} blocs`);
      this.game.hud.setObjective('Construis ta défense. Armes verrouillées. B contrôle les états vert, orange et rouge.');
    } else if (this.phase === 'combat') {
      this.game.hud.setModeTimer(`Combat · ${clock}`);
      this.game.hud.setObjective('Armes débloquées. Les constructions sont conservées et toute nouvelle modification est verrouillée.');
    } else {
      this.game.hud.setModeTimer('Battle · manche terminée');
      this.game.hud.setObjective('Relance la partie pour démarrer une nouvelle manche.');
    }
  }

  onEvent(event) {
    if (event.type === 'place' && this.phase === 'preparation') {
      this.blocksRemaining = Math.max(0, this.blocksRemaining - (event.amount ?? 1));
      this.refreshHud(true);
    }
    if (!this.game.multiplayerActive && event.type === 'kill' && event.targetType === 'training_dummy') this.trainingHits += event.amount ?? 1;
  }

  canPlaceBlock() { return this.phase === 'preparation' && this.blocksRemaining > 0; }
  canBreakBlock() { return this.phase === 'preparation'; }
  constructionMessage() {
    if (this.phase === 'preparation' && this.blocksRemaining <= 0) return 'Budget Battle épuisé : 80 blocs maximum';
    return this.phase === 'combat' ? 'Construction verrouillée pendant le combat' : 'La manche Battle est terminée';
  }
  combatMessage() { return this.phase === 'preparation' ? 'Armes verrouillées pendant la préparation' : 'Le combat est terminé'; }

  reset() {
    this.phase = 'idle'; this.remaining = 0; this.blocksRemaining = BLOCK_BUDGET; this.trainingHits = 0;
  }
}
