import { BaseMode } from './BaseMode.js';

export class CreativeMode extends BaseMode {
  get allowsCombat() { return false; }
  get spawnProtectionSeconds() { return 0; }
  get targetMonsterCount() { return 0; }

  startSession() {
    this.game.monsters.configure({ targetCount: 0, aggressionMultiplier: 0 });
    this.game.monsters.clear();
    this.game.hud.setObjective('Création libre · catalogue complet · monde sans monstres');
    this.game.hud.setModeTimer('∞');
  }
}
