import { BaseMode } from './BaseMode.js';
import { TELEGRAPH } from '../entities/TelegraphRules.js';
import { DEFENSE, nightState, secondsUntilChange, waveBudget, waveCap, spawnInterval, waveComposition, spawnPoint, waveReward } from './DefenseRules.js';
import { SiegeTracker, siegeDps, isSiegeable } from './BarricadeRules.js';

// BlockWorld V3.0 Beta 4.31 — mode Défense : le jour on bâtit des barricades, la nuit (la vraie nuit du ciel) une vague
// de monstres attaque, l'aube la dissipe. Joueur seul derrière ses murs : un mur construit arrête les monstres, qui le
// rongent (BarricadeRules) ; un mur de N blocs de haut tient tant que N − 1 blocs n'ont pas cédé. Attaques annoncées
// (0,6 s) et jauges de vie visibles à moins de 25 m. Les blocs posés puisent dans un stock rechargé à chaque vague.
// La Survie reste inchangée (autre mode, autres réglages du gestionnaire de monstres).

const BEST_KEY = 'blockworld-v4.31-defense-best';
const mmss = (seconds) => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;

export class DefenseMode extends BaseMode {
  constructor(game, definition) {
    super(game, definition);
    this.siege = new SiegeTracker();
    this.fxClock = new Map();
    this.best = this.loadBest();
    this.resetState();
  }

  loadBest() {
    try { return Number.parseInt(localStorage.getItem(BEST_KEY) ?? '0', 10) || 0; } catch { return 0; }
  }

  resetState() {
    this.completed = 0; // vagues repoussées
    this.wave = 0; // vague en cours (ou dernière)
    this.nightPhase = 'day';
    this.waveActive = false;
    this.queue = [];
    this.spawnTimer = 0;
    this.waveKills = 0;
    this.stock = DEFENSE.startBlocks;
    this.hudClock = 0;
    this.noticeClock = -Infinity; // limiteurs de fréquence : jamais « trop tôt » au premier événement
    this.lastText = '';
    this.tipTimer = 0;
  }

  get allowsCombat() { return true; }
  get spawnProtectionSeconds() { return 0; } // aucun monstre au départ : pas de bulle (elle est rendue après une défaite)
  get targetMonsterCount() { return this.monstersLeft(); }

  monstersLeft() {
    return this.queue.length + this.game.monsters.monsters.filter((monster) => monster.alive).length;
  }

  startSession() {
    const { game } = this;
    this.resetState();
    this.siege.clear();
    game.hud.setItemAvailability(null);
    game.monsters.clear();
    game.monsters.configure({ targetCount: 99, aggressionMultiplier: DEFENSE.aggression, telegraphSeconds: TELEGRAPH.windup, siege: true, healthBars: true, autoRespawn: false });
    if (game.atmosphere) game.atmosphere.elapsed = DEFENSE.startPhase * (game.atmosphere.dayLength ?? DEFENSE.dayLength);
    this.tipTimer = 1.5; // l'astuce est affichée après le message de démarrage du jeu, qui l'écraserait
    this.updateHud(true);
  }

  canPlaceBlock() { return this.stock > 0; }
  constructionMessage() { return 'Plus de blocs : récupère ceux de tes murs en les cassant, ou attends l’aube'; }

  daylight() {
    const value = this.game.atmosphere?.daylight;
    return Number.isFinite(value) ? value : 1;
  }

  update(delta) {
    const previous = this.nightPhase;
    this.nightPhase = nightState(this.nightPhase, this.daylight());
    if (previous === 'day' && this.nightPhase === 'night') this.startNight();
    else if (previous === 'night' && this.nightPhase === 'day') this.endNight();
    if (this.tipTimer > 0) {
      this.tipTimer -= delta;
      if (this.tipTimer <= 0) this.game.hud.setStatus('Défense : bâtis des murs de 3 blocs de haut avant la nuit');
    }
    if (this.waveActive) this.updateWave(delta);
    this.siege.update(delta);
    this.hudClock -= delta;
    if (this.hudClock <= 0) { this.hudClock = 0.25; this.updateHud(); }
  }

  startNight() {
    this.wave = this.completed + 1;
    this.queue = waveComposition(this.wave);
    this.waveActive = true;
    this.waveKills = 0;
    this.spawnTimer = 3;
    this.game.hud.setStatus(`Vague ${this.wave} : la nuit tombe, ${this.queue.length} monstres approchent`);
    this.updateHud(true);
  }

  updateWave(delta) {
    const alive = this.game.monsters.monsters.filter((monster) => monster.alive).length;
    if (this.queue.length && alive < waveCap(this.wave)) {
      this.spawnTimer -= delta;
      if (this.spawnTimer <= 0) {
        this.spawnTimer = spawnInterval(this.wave);
        this.game.monsters.spawnOne(this.queue.shift(), this.pickSpawn());
      }
    }
    if (!this.queue.length && alive === 0) this.completeWave(true);
  }

  pickSpawn() {
    const { world, player } = this.game;
    const eye = player.getEyePosition();
    for (let attempt = 0; attempt < 14; attempt += 1) {
      const point = spawnPoint(eye);
      const top = world.getTopBlock(point.x, point.z, { solidOnly: true });
      if (!top || top.y <= 0) continue;
      if (world.getBlock(top.x, top.y + 1, top.z)?.type === 'water') continue; // pas dans un lac
      if (Math.abs(top.y + 0.5 - (eye.y - player.eyeHeight)) > 6) continue; // ni sur une falaise lointaine
      return { x: top.x, y: top.y + 0.5, z: top.z }; // MonsterManager.spawnOne accepte une position simple
    }
    return world.findSpawnPosition();
  }

  endNight() {
    if (!this.waveActive) return;
    const left = this.game.monsters.banishAll();
    this.queue = [];
    this.game.hud.setStatus(left ? 'L’aube se lève : les monstres se dissipent' : 'L’aube se lève');
    this.completeWave(false);
  }

  completeWave(cleared) {
    const { game } = this;
    this.waveActive = false;
    this.completed = Math.max(this.completed, this.wave);
    const reward = waveReward(this.wave, this.waveKills, cleared);
    this.stock = Math.min(DEFENSE.maxBlocks, this.stock + reward.blocks);
    const healed = game.player.heal(reward.heal);
    game.monsters.addCrystals(reward.crystals);
    if (this.completed > this.best) { this.best = this.completed; try { localStorage.setItem(BEST_KEY, String(this.best)); } catch { /* stockage refusé : tant pis */ } }
    game.hud.setStatus(`Vague ${this.wave} ${cleared ? 'repoussée' : 'tenue jusqu’à l’aube'} ! +${reward.blocks} blocs · +${reward.crystals} cristaux${healed ? ` · +${healed} PV` : ''}`);
    this.updateHud(true);
  }

  failWave() {
    if (!this.waveActive) return;
    this.waveActive = false;
    this.queue = [];
    this.game.monsters.clear();
    this.game.hud.setStatus(`Tu as été vaincu pendant la vague ${this.wave} : elle sera rejouée à la prochaine nuit`);
    this.updateHud(true);
  }

  /** Un monstre bloqué par un mur ronge le bloc. Renvoie true si le bloc est « rongeable » (sinon : comportement normal). */
  onSiege(monster, block, delta) {
    const { world } = this.game;
    const key = world.key(block.x, block.y, block.z);
    const siegeable = isSiegeable({ type: block.type, y: block.y, playerBuilt: world.addedBlocks?.has(key), protectedBlock: block.protectedBlock });
    if (!siegeable || this.game.bridges?.isSiteBlock?.(block.x, block.y, block.z)) return false;
    const result = this.siege.hit(key, block.type, siegeDps(monster.type) * delta);
    const position = { x: block.x, y: block.y, z: block.z };
    const now = performance.now();
    if (result.broken) {
      world.removeBlock(block.x, block.y, block.z);
      this.game.buildFeedback?.onBreak(position, block.type);
      this.game.stability?.scan();
      this.fxClock.delete(key);
      if (now - this.noticeClock > 2500) { this.noticeClock = now; this.game.hud.setStatus('Une barricade cède !'); }
    } else if (now - (this.fxClock.get(key) ?? -Infinity) > 450) {
      this.fxClock.set(key, now);
      this.game.buildFeedback?.onHit(position, block.type);
    }
    return true;
  }

  onEvent(event) {
    if (event.type === 'kill' && this.waveActive) this.waveKills += event.amount ?? 1;
    else if (event.type === 'place') this.stock = Math.max(0, this.stock - 1);
    else if (event.type === 'harvest' && event.playerBuilt) this.stock = Math.min(DEFENSE.maxBlocks, this.stock + 1); // casser son propre mur rend le bloc
    else if (event.type === 'player_death') this.failWave();
  }

  updateHud(force = false) {
    const { hud, atmosphere } = this.game;
    const elapsed = atmosphere?.elapsed ?? 0;
    let timer;
    if (this.nightPhase === 'night' && this.waveActive) timer = `Vague ${this.wave} · ${this.monstersLeft()} monstre${this.monstersLeft() > 1 ? 's' : ''}`;
    else if (this.nightPhase === 'night') timer = `Nuit calme · aube dans ${mmss(secondsUntilChange(elapsed, 'night', atmosphere?.dayLength) ?? 0)}`;
    else timer = `Jour · nuit dans ${mmss(secondsUntilChange(elapsed, 'day', atmosphere?.dayLength) ?? 0)}`;
    const next = this.nightPhase === 'day' ? ` · vague ${this.completed + 1} à venir (${waveBudget(this.completed + 1)} monstres)` : '';
    const text = `${timer}|Défense${next} · 🧱 ${this.stock} blocs · record : vague ${this.best}`;
    if (!force && text === this.lastText) return;
    this.lastText = text;
    const [top, objective] = text.split('|');
    hud.setModeTimer(top);
    hud.setObjective(objective);
  }

  reset() {
    this.resetState();
    this.siege.clear();
  }
}
