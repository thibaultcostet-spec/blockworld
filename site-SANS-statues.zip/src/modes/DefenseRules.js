// BlockWorld V3.0 Beta 4.31 — mode Défense : vagues calées sur la vraie nuit du ciel, composition, apparitions, récompenses.
// Le jour sert à bâtir, la nuit une vague attaque, l'aube la dissipe. Module pur (testable sous Node).
// La formule du ciel reproduit celle d'AtmosphereSystem.update (journée de 480 s) : un test garde les deux alignées.

export const DEFENSE = {
  dayLength: 480,
  startPhase: 0.40, // début d'après-midi : ≈ 3 min pour bâtir avant le premier crépuscule
  nightEnter: 0.30, nightExit: 0.55, // seuils de lumière du jour, avec hystérésis
  startBlocks: 80, maxBlocks: 400,
  spawnRing: { min: 20, max: 30 },
  aggression: 3.2, // multiplicateur de détection : ils foncent sur le joueur dès leur apparition
  nightSecondsHint: 240
};

const smoothstep = (x, min, max) => {
  if (x <= min) return 0;
  if (x >= max) return 1;
  const t = (x - min) / (max - min);
  return t * t * (3 - 2 * t);
};

/** Lumière du jour (0 nuit … 1 plein jour), identique à AtmosphereSystem. */
export function skyDaylight(elapsed, dayLength = DEFENSE.dayLength) {
  const phase = (((elapsed % dayLength) + dayLength) % dayLength) / dayLength;
  const altitude = Math.sin(phase * Math.PI * 2 - Math.PI * 0.55);
  return smoothstep(altitude, -0.20, 0.26);
}

/** 'day' ou 'night' avec hystérésis (évite les allers-retours au crépuscule). */
export function nightState(previous, daylight, { enter = DEFENSE.nightEnter, exit = DEFENSE.nightExit } = {}) {
  if (previous === 'night') return daylight > exit ? 'day' : 'night';
  return daylight < enter ? 'night' : 'day';
}

/** Secondes avant le prochain changement (nuit si `state` vaut 'day', aube sinon) ; null si introuvable. */
export function secondsUntilChange(elapsed, state, dayLength = DEFENSE.dayLength) {
  for (let t = 0; t <= dayLength; t += 1) {
    const light = skyDaylight(elapsed + t, dayLength);
    if (state === 'day' ? light < DEFENSE.nightEnter : light > DEFENSE.nightExit) return t;
  }
  return null;
}

export function waveBudget(wave) { return Math.min(48, 6 + 3 * (wave - 1)); }
export function waveCap(wave) { return Math.min(16, Math.round(3 + wave * 1.5)); }
export function spawnInterval(wave, nightSeconds = DEFENSE.nightSecondsHint) {
  return Math.min(18, Math.max(2.5, (nightSeconds * 0.7) / waveBudget(wave)));
}

/** Liste ordonnée des monstres de la vague : fretin d'abord, spectres au milieu, golems à la fin. */
export function waveComposition(wave) {
  const total = waveBudget(wave);
  const golems = wave >= 4 ? Math.min(6, Math.floor((wave - 1) / 3)) : 0;
  const wraiths = wave >= 3 ? Math.min(10, Math.floor(wave / 2)) : 0;
  let goblins = wave >= 2 ? Math.round(total * 0.25) : 0;
  const fodderMin = 2;
  while (total - golems - wraiths - goblins < fodderMin && goblins > 0) goblins -= 1;
  const fodderCount = total - golems - wraiths - goblins;
  const list = Array.from({ length: fodderCount }, (_, i) => (i % 2 === 0 ? 'slime' : 'spider'));
  const insertEvenly = (type, count, from, to) => {
    for (let i = 0; i < count; i += 1) {
      const index = Math.floor(list.length * (from + ((to - from) * (i + 1)) / (count + 1)));
      list.splice(Math.min(list.length, index), 0, type);
    }
  };
  insertEvenly('goblin', goblins, 0.15, 1);
  insertEvenly('wraith', wraiths, 0.4, 0.95);
  for (let i = 0; i < golems; i += 1) list.push('golem');
  return list;
}

/** Point d'apparition sur l'anneau 20–30 m autour du joueur (rng ∈ [0,1[ injectable). */
export function spawnPoint(center, rng = Math.random, ring = DEFENSE.spawnRing) {
  const angle = rng() * Math.PI * 2;
  const radius = ring.min + rng() * (ring.max - ring.min);
  return { x: center.x + Math.cos(angle) * radius, z: center.z + Math.sin(angle) * radius };
}

/** Récompense de fin de vague (aube ou vague éliminée avant l'aube). */
export function waveReward(wave, kills, cleared) {
  return { blocks: Math.min(120, 30 + 10 * wave) + (cleared ? 20 : 0), heal: 30, crystals: 3 * wave + kills };
}
