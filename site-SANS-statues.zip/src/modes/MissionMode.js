import { BaseMode } from './BaseMode.js';
import { MissionManager } from '../missions/MissionManager.js';
import { MISSION_QUICKBAR } from '../missions/MissionLibrary.js';
import { HeritageMissionMarker } from '../missions/HeritageMissionMarker.js';
import { getWorldDefinition } from '../worlds/WorldRegistry.js';

export class MissionMode extends BaseMode {
  constructor(game, definition) {
    super(game, definition);
    this.marker = new HeritageMissionMarker(game.scene, game.world);
    this.missions = new MissionManager({
      onChange: (display, allowedItems) => {
        this.game.hud.setObjective(`${display.title} · ${display.text}`);
        this.game.hud.setItemAvailability(allowedItems);
        this.game.navigationMap?.track(display.trackPointId);
        this.marker.setDisplay(display);
      },
      onComplete: (mission, world) => {
        const unlockText = mission.unlocks?.length ? ` · ${mission.unlocks.length} nouveaux objets débloqués` : '';
        this.game.hud.setStatus(`Mission « ${mission.title} » accomplie sur ${world.label}${unlockText}`);
      }
    });
  }

  get targetMonsterCount() { return 4; }
  get spawnProtectionSeconds() { return 8; }
  get allowedItemIds() { return this.missions.getAllowedItemIds(); }
  get quickbarTemplate() { return MISSION_QUICKBAR; }

  setWorld(definition) {
    const world = definition ?? getWorldDefinition(this.game.selectedWorldId);
    this.missions.setWorld(world, this.game.passport);
  }

  select() {
    super.select();
    this.setWorld(getWorldDefinition(this.game.selectedWorldId));
    this.game.hud.setItemAvailability(this.allowedItemIds);
  }

  deselect() {
    this.marker.setDisplay(null);
  }

  startSession() {
    this.setWorld(getWorldDefinition(this.game.selectedWorldId));
    this.game.monsters.configure({ targetCount: this.targetMonsterCount, aggressionMultiplier: 0.65 });
    this.game.monsters.spawnInitial();
    this.game.hud.setModeTimer('Patrimoine');
    this.missions.notify();
  }

  update(delta) {
    this.marker.update(delta);
  }

  onEvent(event) {
    this.missions.handleEvent(event);
  }

  reset() {
    this.missions.reset();
  }
}
