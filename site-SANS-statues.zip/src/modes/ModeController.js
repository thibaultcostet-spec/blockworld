import { MODE_BY_ID } from './ModeRegistry.js';
import { CreativeMode } from './CreativeMode.js';
import { MissionMode } from './MissionMode.js';
import { SurvivalMode } from './SurvivalMode.js';
import { DefenseMode } from './DefenseMode.js';
import { BattleMode } from './BattleMode.js';

const MODE_CLASSES = {
  creative: CreativeMode,
  missions: MissionMode,
  survival: SurvivalMode,
  defense: DefenseMode,
  battle: BattleMode
};

export class ModeController {
  constructor(game) {
    this.game = game;
    this.instances = new Map();
    this.current = null;
  }

  select(id) {
    const definition = MODE_BY_ID.get(id) ?? MODE_BY_ID.get('creative');
    if (this.current && this.current.definition?.id !== definition.id) this.current.deselect?.();
    const ModeClass = MODE_CLASSES[definition.id];
    if (!this.instances.has(definition.id)) {
      this.instances.set(definition.id, new ModeClass(this.game, definition));
    }
    this.current = this.instances.get(definition.id);
    return definition;
  }

  startSession() {
    this.current?.startSession();
  }

  update(delta) {
    this.current?.update(delta);
  }

  onEvent(event) {
    this.current?.onEvent(event);
  }

  reset() {
    this.current?.reset();
  }

  get allowsCombat() {
    return this.current?.allowsCombat ?? true;
  }

  /** Beta 4.31 : un monstre bloqué ronge un mur (mode Défense) ; faux = comportement normal. */
  onSiege(monster, block, delta) { return this.current?.onSiege?.(monster, block, delta) ?? false; }

  canPlaceBlock() { return this.current?.canPlaceBlock?.() ?? true; }
  canBreakBlock() { return this.current?.canBreakBlock?.() ?? true; }
  constructionMessage() { return this.current?.constructionMessage?.() ?? 'Construction indisponible'; }
  combatMessage() { return this.current?.combatMessage?.() ?? 'Combat indisponible'; }
  applyBattleState(state) { this.instances.get('battle')?.applyServerState?.(state); }

  get spawnProtectionSeconds() {
    return this.current?.spawnProtectionSeconds ?? 0;
  }
}
