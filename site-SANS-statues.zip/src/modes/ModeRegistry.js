export const MODE_DEFINITIONS = [
  {
    id: 'creative',
    label: 'Créatif',
    icon: '🏗️',
    accent: '#67c56b',
    available: true,
    description: 'Tous les blocs, outils, vêtements et transports sont disponibles. Aucun monstre et aucun combat.'
  },
  {
    id: 'missions',
    label: 'Missions',
    icon: '🧭',
    accent: '#5ea6e8',
    available: true,
    description: 'Une bibliothèque de missions débloque progressivement les objets en récoltant, construisant et combattant.'
  },
  {
    id: 'survival',
    label: 'Survie',
    icon: '🌙',
    accent: '#e18a4e',
    available: true,
    description: 'Survis aux nuits successives. Les monstres te détectent à des distances propres à chaque espèce.'
  },
  {
    id: 'defense',
    label: 'Défense',
    icon: '🛡️',
    accent: '#d9b24a',
    available: true,
    description: 'Le jour, bâtis des barricades ; la nuit, une vague de monstres ronge tes murs. Tiens jusqu’à l’aube !'
  },
  {
    id: 'battle',
    label: 'Battle',
    icon: '⚔️',
    accent: '#d55c62',
    available: true,
    description: 'En solo, entraîne-toi sur des cibles sans danger. En multijoueur, le serveur valide portée, cadence, dégâts et réapparitions.'
  }
];

export const MODE_BY_ID = new Map(MODE_DEFINITIONS.map((mode) => [mode.id, mode]));
