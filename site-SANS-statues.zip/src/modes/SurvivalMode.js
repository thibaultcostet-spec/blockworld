import { BaseMode } from './BaseMode.js';

const NIGHT_DURATION = 75;

export class SurvivalMode extends BaseMode {
  constructor(game, definition) {
    super(game, definition);
    this.night = 1;
    this.remaining = NIGHT_DURATION;
    this.kills = 0;
  }

  get targetMonsterCount() {
    return Math.min(22, 7 + Math.floor((this.night - 1) / 2));
  }

  get spawnProtectionSeconds() { return 8; }

  startSession() {
    this.game.hud.setItemAvailability(null);
    this.game.monsters.configure({
      targetCount: this.targetMonsterCount,
      aggressionMultiplier: 1 + Math.min(0.75, (this.night - 1) * 0.035)
    });
    this.game.monsters.spawnInitial();
    this.updateHud();
  }

  update(delta) {
    this.remaining -= delta;
    if (this.remaining <= 0) {
      this.night = Math.min(99, this.night + 1);
      this.remaining = NIGHT_DURATION;
      this.game.player.heal(12);
      this.game.monsters.configure({
        targetCount: this.targetMonsterCount,
        aggressionMultiplier: 1 + Math.min(0.75, (this.night - 1) * 0.035)
      });
      this.game.hud.setStatus(`Vague ${this.night} : la meute devient plus nombreuse et plus attentive`);
    }
    const phase = 1 - this.remaining / NIGHT_DURATION;
    this.game.setNightIntensity(0.38 + Math.sin(phase * Math.PI) * 0.42);
    this.updateHud();
  }

  onEvent(event) {
    if (event.type === 'kill') this.kills += event.amount ?? 1;
  }

  updateHud() {
    const seconds = Math.max(0, Math.ceil(this.remaining));
    const minutes = String(Math.floor(seconds / 60)).padStart(2, '0');
    const remainder = String(seconds % 60).padStart(2, '0');
    // Beta 4.26 : « Vague » et non « Nuit » — ce cycle de 75 s n'est pas la nuit du ciel (journée de 8 min).
    this.game.hud.setModeTimer(`Vague ${this.night}/99 · ${minutes}:${remainder}`);
    this.game.hud.setObjective(`Survivre · ${this.targetMonsterCount} monstres actifs · ${this.kills} éliminés`);
  }

  reset() {
    this.night = 1;
    this.remaining = NIGHT_DURATION;
    this.kills = 0;
  }
}
