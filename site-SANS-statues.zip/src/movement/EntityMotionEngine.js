import * as THREE from 'three';
import { GroundingSystem } from '../world/GroundingSystem.js';

/** Déplacement unifié V3 Beta 3 : terrain continu, pente, rotation et contact au sol. */
export class EntityMotionEngine {
  constructor(world){this.world=world;this.grounding=new GroundingSystem(world,{maxStep:.92,footprint:.30});}
  move(entity,target,delta,{speed=1,maxStep=.92,turn=8,bob=.018,alignSlope=false}={}){
    const position=entity.position;const dx=target.x-position.x,dz=target.z-position.z;const length=Math.hypot(dx,dz);
    if(length<.04){this.snap(entity);return true;}
    const step=Math.min(length,speed*delta),nextX=position.x+dx/length*step,nextZ=position.z+dz/length*step;
    if(!this.grounding.canStep(position.x,position.z,nextX,nextZ,maxStep)){this.snap(entity);return false;}
    position.x=nextX;position.z=nextZ;
    const footprint=entity.userData.groundFootprint??.3;
    let ground=this.grounding.groundY(nextX,nextZ,0,footprint);
    // Beta 4.22 : le sol lissé forme une rampe entre deux colonnes ; au pied d'une marche l'entité flottait
    // à mi-hauteur. On suit le dessus du bloc réellement sous le centre (transition amortie ci-dessous).
    const under=this.grounding.sample(nextX,nextZ);
    if(this.grounding.isDryGround(under)&&ground!==null&&Math.abs(under.y-ground)<1.05)ground=under.y;
    if(ground!==null){
      const desired=ground+(entity.userData.footOffset??0);
      position.y=THREE.MathUtils.damp(position.y,desired,24,delta);
      entity.userData.lastGroundY=ground;
    }
    const wanted=Math.atan2(dx,dz);
    // Beta 4.22 : animaux et personnages sont modélisés tête vers −z ; le cap de marche (wanted, convention +z)
    // était appliqué tel quel : ils avançaient à reculons. Le modèle est tourné d'un demi-tour.
    entity.rotation.y=lerpAngle(entity.rotation.y,wanted+Math.PI,1-Math.exp(-turn*delta));
    if(alignSlope){
      const forwardX=Math.sin(wanted)*footprint,forwardZ=Math.cos(wanted)*footprint;
      const sideX=Math.cos(wanted)*footprint,sideZ=-Math.sin(wanted)*footprint;
      const front=this.grounding.groundY(nextX+forwardX,nextZ+forwardZ,0,0);
      const back=this.grounding.groundY(nextX-forwardX,nextZ-forwardZ,0,0);
      const left=this.grounding.groundY(nextX-sideX,nextZ-sideZ,0,0);
      const right=this.grounding.groundY(nextX+sideX,nextZ+sideZ,0,0);
      const pitch=front!==null&&back!==null?Math.atan2(front-back,footprint*2):0;
      const roll=left!==null&&right!==null?Math.atan2(left-right,footprint*2):0;
      entity.rotation.x=THREE.MathUtils.damp(entity.rotation.x,pitch*.42,8,delta);
      entity.rotation.z=THREE.MathUtils.damp(entity.rotation.z,roll*.34,8,delta);
    }else{
      entity.rotation.x=THREE.MathUtils.damp(entity.rotation.x,0,8,delta);
      entity.rotation.z=THREE.MathUtils.damp(entity.rotation.z,0,8,delta);
    }
    entity.userData.motionPhase=(entity.userData.motionPhase||0)+delta*speed*8;
    entity.userData.visualBob=Math.sin(entity.userData.motionPhase)*bob;
    return true;
  }
  snap(entity){return this.grounding.settle(entity,entity.position.x,entity.position.z,0);}
  calibrate(entity){entity.userData.footOffset=this.grounding.calibrate(entity);this.snap(entity);return entity.userData.footOffset;}
}
function lerpAngle(a,b,t){let d=(b-a+Math.PI)%(Math.PI*2)-Math.PI;if(d<-Math.PI)d+=Math.PI*2;return a+d*t;}
