const STATE_INTERVAL_MS = 80;

export class MultiplayerClient extends EventTarget {
  constructor() {
    super();
    this.socket = null;
    this.connected = false;
    this.joined = false;
    this.clientId = null;
    this.sessionToken = null;
    this.roomCode = null;
    this.hostId = null;
    this.roomMode = null;
    this.roomWorldId = null;
    this.battleState = null;
    this.lastStateSentAt = 0;
    this.heartbeat = null;
    this.intentionalClose = false;
  }

  get endpoint() {
    const scheme = location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${scheme}//${location.host}/ws`;
  }

  async connect() {
    if (this.socket?.readyState === WebSocket.OPEN) return;
    if (this.socket?.readyState === WebSocket.CONNECTING) {
      await new Promise((resolve, reject) => {
        this.socket.addEventListener('open', resolve, { once: true });
        this.socket.addEventListener('error', reject, { once: true });
      });
      return;
    }

    this.intentionalClose = false;
    await new Promise((resolve, reject) => {
      const socket = new WebSocket(this.endpoint);
      this.socket = socket;
      const timeout = window.setTimeout(() => reject(new Error('Le serveur multijoueur ne répond pas.')), 5000);
      socket.addEventListener('open', () => {
        window.clearTimeout(timeout);
        this.connected = true;
        this.dispatchEvent(new CustomEvent('status', { detail: { state: 'connected' } }));
        resolve();
      }, { once: true });
      socket.addEventListener('message', (event) => this.handleMessage(event.data));
      socket.addEventListener('close', () => this.handleClose());
      socket.addEventListener('error', () => {
        window.clearTimeout(timeout);
        reject(new Error('Connexion réseau impossible.'));
      }, { once: true });
    });
  }

  async createRoom({ nickname, mode, worldId }) {
    await this.connect();
    this.send({ type: 'create_room', nickname, mode, worldId });
  }

  async joinRoom({ nickname, code }) {
    await this.connect();
    this.send({ type: 'join_room', nickname, code: String(code || '').toUpperCase() });
  }

  leave() {
    if (this.joined) this.send({ type: 'leave' });
    this.intentionalClose = true;
    this.socket?.close(1000, 'leave');
    this.reset();
  }

  reset() {
    this.stopHeartbeat();
    this.connected = false;
    this.joined = false;
    this.clientId = null;
    this.sessionToken = null;
    this.roomCode = null;
    this.hostId = null;
    this.roomMode = null;
    this.roomWorldId = null;
    this.battleState = null;
    this.socket = null;
  }

  startHeartbeat() {
    this.stopHeartbeat();
    this.heartbeat = window.setInterval(() => {
      if (this.socket?.readyState === WebSocket.OPEN) this.send({ type: 'ping', at: Date.now() });
    }, 10000);
  }

  stopHeartbeat() {
    if (this.heartbeat) window.clearInterval(this.heartbeat);
    this.heartbeat = null;
  }

  send(payload) {
    if (this.socket?.readyState !== WebSocket.OPEN) return false;
    const data = JSON.stringify(payload);
    if (data.length > 12000) return false;
    this.socket.send(data);
    return true;
  }

  sendState(state) {
    const timestamp = performance.now();
    if (!this.joined || timestamp - this.lastStateSentAt < STATE_INTERVAL_MS) return;
    this.lastStateSentAt = timestamp;
    this.send({ type: 'state', state });
  }

  addBlock(x, y, z, blockType) {
    return this.send({ type: 'block_add', x: Math.round(x), y: Math.round(y), z: Math.round(z), blockType });
  }

  removeBlock(x, y, z) {
    return this.send({ type: 'block_remove', x: Math.round(x), y: Math.round(y), z: Math.round(z) });
  }

  attackPlayer(targetId, weapon) {
    return this.send({ type: 'attack_player', targetId, weapon });
  }

  requestBattleSync() {
    return this.joined ? this.send({ type: 'battle_sync' }) : false;
  }

  reloadWeapon(weapon) {
    return this.send({ type: 'reload_weapon', weapon });
  }

  handleMessage(raw) {
    let message;
    try {
      message = JSON.parse(raw);
    } catch {
      return;
    }
    if (message.type === 'joined') {
      this.joined = true;
      this.clientId = message.clientId;
      this.sessionToken = message.sessionToken;
      this.roomCode = message.roomCode;
      this.hostId = message.hostId;
      this.roomMode = message.snapshot?.mode ?? 'creative';
      this.roomWorldId = message.snapshot?.worldId ?? 'europe';
      this.battleState = message.snapshot?.battleState ?? null;
      this.startHeartbeat();
    }
    if (message.type === 'host_changed') this.hostId = message.hostId;
    this.dispatchEvent(new CustomEvent('message', { detail: message }));
  }

  handleClose() {
    const wasJoined = this.joined;
    const intentional = this.intentionalClose;
    this.reset();
    this.dispatchEvent(new CustomEvent('status', {
      detail: { state: intentional ? 'closed' : 'disconnected', wasJoined }
    }));
  }
}
