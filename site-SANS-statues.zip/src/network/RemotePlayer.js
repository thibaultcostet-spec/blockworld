import * as THREE from 'three';
import { buildCharacter, rosterCharacter, rosterIndexFromId } from '../characters/CharacterFactory.js';

function mesh(geometry, material, x = 0, y = 0, z = 0) {
  const value = new THREE.Mesh(geometry, material);
  value.position.set(x, y, z);
  value.castShadow = true;
  return value;
}

function makeLabel(text) {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 128;
  const context = canvas.getContext('2d');
  context.clearRect(0, 0, canvas.width, canvas.height);
  context.fillStyle = 'rgba(5,10,16,0.78)';
  if (typeof context.roundRect === 'function') {
    context.beginPath();
    context.roundRect(8, 8, 496, 104, 28);
    context.fill();
  } else {
    context.fillRect(8, 8, 496, 104);
  }
  context.fillStyle = '#ffffff';
  context.font = '700 52px system-ui, sans-serif';
  context.textAlign = 'center';
  context.textBaseline = 'middle';
  context.fillText(text, 256, 60, 470);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const material = new THREE.SpriteMaterial({ map: texture, transparent: true, depthTest: false });
  const sprite = new THREE.Sprite(material);
  sprite.scale.set(2.2, 0.55, 1);
  sprite.position.y = 2.45;
  return sprite;
}

export class RemotePlayer {
  constructor(scene, data) {
    this.scene = scene;
    this.id = data.id;
    this.nickname = data.nickname || 'Joueur';
    this.targetPosition = new THREE.Vector3();
    this.lastPosition = new THREE.Vector3();
    this.targetYaw = 0;
    this.walkTime = 0;
    this.moving = false;
    this.health = data.health ?? 100;
    this.group = this.createModel(data.state || {});
    this.group.userData.remotePlayer = this;
    this.group.traverse((object) => { object.userData.remotePlayer = this; });
    this.scene.add(this.group);
    this.group.visible = false;
    this.applyState(data.state || {}, true);
  }

  createModel(state) {
    // Beta 4.19 : chaque joueur distant reçoit un personnage de la galerie, stable d'une partie à l'autre.
    // Beta 4.20 : personnage choisi par le joueur (repli : attribution stable d'après l'identifiant).
    this.characterIndex = Number.isInteger(state.character) ? state.character : rosterIndexFromId(this.id);
    const group = buildCharacter(rosterCharacter(this.characterIndex));
    group.name = `RemotePlayer-${this.id}`;
    this.torsoMaterial = group.userData.materials.top;
    this.legsMaterial = group.userData.materials.pants;
    if (Number.isInteger(state.torsoColor)) this.torsoMaterial.color.setHex(state.torsoColor);
    if (Number.isInteger(state.legsColor)) this.legsMaterial.color.setHex(state.legsColor);
    const pivot = (key, side) => group.children.find((child) => child.userData[key] === side);
    this.leftArm = pivot('arm', -1);
    this.rightArm = pivot('arm', 1);
    this.leftLeg = pivot('leg', -1);
    this.rightLeg = pivot('leg', 1);
    this.label = makeLabel(this.nickname);
    group.add(this.label);
    return group;
  }

  applyState(state, immediate = false) {
    if (!state || typeof state.x !== 'number') return;
    this.group.visible = true;
    this.targetPosition.set(state.x, state.y - 1.7, state.z);
    this.targetYaw = state.yaw ?? 0;
    this.moving = Boolean(state.moving);
    if (Number.isInteger(state.character) && state.character !== this.characterIndex) this.rebuildModel(state);
    if (Number.isInteger(state.torsoColor)) this.torsoMaterial.color.setHex(state.torsoColor);
    if (Number.isInteger(state.legsColor)) this.legsMaterial.color.setHex(state.legsColor);
    if (immediate) {
      this.group.position.copy(this.targetPosition);
      this.group.rotation.y = this.targetYaw;
      this.lastPosition.copy(this.targetPosition);
    }
  }

  rebuildModel(state) {
    const old = this.group;
    const position = old.position.clone(), rotation = old.rotation.y, visible = old.visible;
    this.scene.remove(old);
    old.traverse((object) => { if (object.isMesh) { object.geometry?.dispose?.(); } });
    this.group = this.createModel(state);
    this.group.userData.remotePlayer = this;
    this.group.traverse((object) => { object.userData.remotePlayer = this; });
    this.group.position.copy(position);
    this.group.rotation.y = rotation;
    this.group.visible = visible;
    this.scene.add(this.group);
  }

  setHealth(value) {
    this.health = Math.max(0, Math.min(100, Number(value) || 0));
    this.label.material.opacity = this.health <= 0 ? 0.3 : 1;
  }

  update(delta) {
    this.group.position.lerp(this.targetPosition, 1 - Math.exp(-12 * delta));
    let difference = (this.targetYaw - this.group.rotation.y + Math.PI) % (Math.PI * 2) - Math.PI;
    if (difference < -Math.PI) difference += Math.PI * 2;
    this.group.rotation.y += difference * (1 - Math.exp(-10 * delta));
    const displacement = this.group.position.distanceTo(this.lastPosition);
    this.group.userData.hd?.update(delta, delta > 0 ? displacement / delta : 0); // Beta 4.24 : personnage HD
    // Beta 4.19 : démarche pilotée par le déplacement réel (comme les habitants depuis la 4.11).
    const speed = delta > 0 ? displacement / delta : 0;
    this.walkTime += displacement * 2.2;
    this.walkBlend = THREE.MathUtils.damp(this.walkBlend ?? 0, Math.min(1, speed / 3), 10, delta);
    const blend = this.walkBlend;
    const stride = Math.sin(this.walkTime) * 0.65 * blend;
    this.leftArm.rotation.x = -stride * 0.75;
    this.rightArm.rotation.x = stride * 0.75;
    this.leftLeg.rotation.x = stride;
    this.rightLeg.rotation.x = -stride;
    this.lastPosition.copy(this.group.position);
  }

  getRaycastTargets() {
    return this.group.children;
  }

  dispose() {
    this.scene.remove(this.group);
    this.group.traverse((object) => {
      object.geometry?.dispose?.();
      if (object.material?.map) object.material.map.dispose();
      object.material?.dispose?.();
    });
  }
}
