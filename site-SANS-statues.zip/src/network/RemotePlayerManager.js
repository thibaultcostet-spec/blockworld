import { RemotePlayer } from './RemotePlayer.js';

export class RemotePlayerManager {
  constructor(scene) {
    this.scene = scene;
    this.players = new Map();
  }

  upsert(data) {
    if (!data?.id) return null;
    let remote = this.players.get(data.id);
    if (!remote) {
      remote = new RemotePlayer(this.scene, data);
      this.players.set(data.id, remote);
    } else if (data.state) {
      remote.applyState(data.state);
    }
    if (typeof data.health === 'number') remote.setHealth(data.health);
    return remote;
  }

  applyState(id, state, health) {
    const remote = this.players.get(id);
    if (!remote) return;
    remote.applyState(state);
    if (typeof health === 'number') remote.setHealth(health);
  }

  remove(id) {
    const remote = this.players.get(id);
    if (!remote) return;
    remote.dispose();
    this.players.delete(id);
  }

  clear() {
    for (const remote of this.players.values()) remote.dispose();
    this.players.clear();
  }

  update(delta) {
    for (const remote of this.players.values()) remote.update(delta);
  }

  getRaycastTargets() {
    const targets = [];
    for (const remote of this.players.values()) targets.push(remote.group);
    return targets;
  }

  get(id) {
    return this.players.get(id) ?? null;
  }

  list() {
    return [...this.players.values()];
  }
}
