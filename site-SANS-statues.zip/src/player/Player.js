import * as THREE from 'three';
import { GroundingSystem, PLAYER_WALKABLE_GROUND } from '../world/GroundingSystem.js';
import { buildCharacter, rosterCharacter, CHARACTER_ROSTER } from '../characters/CharacterFactory.js';

function enableShadows(mesh) {
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

function makeBox(width, height, depth, material, x = 0, y = 0, z = 0) {
  const mesh = enableShadows(new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), material));
  mesh.position.set(x, y, z);
  return mesh;
}

function makeSphere(radius, material, x = 0, y = 0, z = 0, widthSegments = 12, heightSegments = 8) {
  const mesh = enableShadows(new THREE.Mesh(new THREE.SphereGeometry(radius, widthSegments, heightSegments), material));
  mesh.position.set(x, y, z);
  return mesh;
}

function makeCapsule(radius, length, material, x = 0, y = 0, z = 0) {
  const mesh = enableShadows(new THREE.Mesh(new THREE.CapsuleGeometry(radius, length, 4, 8), material));
  mesh.position.set(x, y, z);
  return mesh;
}

function damp(current, target, smoothing, delta) {
  return THREE.MathUtils.lerp(current, target, 1 - Math.exp(-smoothing * delta));
}

function dampAngle(current, target, smoothing, delta) {
  let difference = (target - current + Math.PI) % (Math.PI * 2) - Math.PI;
  if (difference < -Math.PI) difference += Math.PI * 2;
  return current + difference * (1 - Math.exp(-smoothing * delta));
}

export class Player {
  constructor(scene, camera, domElement, input, world, { onHealthChange, onDeath, touchMode = false } = {}) {
    this.scene = scene;
    this.camera = camera;
    this.domElement = domElement;
    this.input = input;
    this.world = world;
    this.touchMode = touchMode;
    this.events = new EventTarget();

    this.baseSpeed = 6;
    this.eyeHeight = 1.7;
    this.gravity = 18;
    this.jumpStrength = 7.2;
    this.verticalVelocity = 0;
    this.grounded = false;
    this.health = 100;
    this.maxHealth = 100;
    this.onHealthChange = onHealthChange;
    this.onDeath = onDeath;
    this.active = false;
    this.viewMode = 'first';
    this.aimZoomed = false;

    this.speedBoostMultiplier = 1;
    this.speedBoostTimer = 0;
    this.shieldMultiplier = 1;
    this.shieldTimer = 0;
    this.clothingProtection = 1;
    this.vehicle = null;
    this.invulnerable = false;
    this.bodyRadius = 0.31;
    this.grounding = new GroundingSystem(this.world, {
      maxStep: 0.92,
      footprint: this.bodyRadius,
      walkableTypes: PLAYER_WALKABLE_GROUND
    });

    this.spawnPoint = new THREE.Vector3(0, 7, 9);
    this.eyePosition = this.spawnPoint.clone();
    this.camera.position.copy(this.eyePosition);
    this.camera.rotation.order = 'YXZ';
    this.yaw = 0;
    this.pitch = 0;

    this.forwardVector = new THREE.Vector3();
    this.rightVector = new THREE.Vector3();
    this.moveVector = new THREE.Vector3();
    this.cameraOffset = new THREE.Vector3();

    this.avatarTime = 0;
    this.walkCycle = 0;
    this.walkBlend = 0;
    this.avatarTargetYaw = 0;

    this.avatar = this.createAvatar();
    this.scene.add(this.avatar);
    this.updateCameraAndAvatar();
    this.avatar.rotation.y = this.avatarTargetYaw;

    // Beta 4.2 : aucun verrouillage du pointeur par défaut.
    // Le curseur reste visible ; la caméra est pilotée par les deltas transmis par Game.
    this.controls = null;
  }

  createAvatar() {
    const group = new THREE.Group();
    group.name = 'PlayerAvatar';

    this.skinMaterial = new THREE.MeshStandardMaterial({ color: 0xd7a27c, roughness: 0.82 });
    this.skinShadeMaterial = new THREE.MeshStandardMaterial({ color: 0xbe805f, roughness: 0.86 });
    this.torsoMaterial = new THREE.MeshStandardMaterial({ color: 0x377ec9, roughness: 0.72 });
    this.legsMaterial = new THREE.MeshStandardMaterial({ color: 0x284e7f, roughness: 0.82 });
    this.shoesMaterial = new THREE.MeshStandardMaterial({ color: 0x20252b, roughness: 0.68 });
    this.hairMaterial = new THREE.MeshStandardMaterial({ color: 0x3a251b, roughness: 0.95 });
    this.eyeWhiteMaterial = new THREE.MeshStandardMaterial({ color: 0xf6f8fb, roughness: 0.45 });
    this.eyeMaterial = new THREE.MeshStandardMaterial({ color: 0x315f76, roughness: 0.35 });
    this.pupilMaterial = new THREE.MeshStandardMaterial({ color: 0x101318, roughness: 0.4 });
    this.detailMaterial = new THREE.MeshStandardMaterial({ color: 0x713f35, roughness: 0.8 });

    this.avatarBody = new THREE.Group();
    this.avatarBody.name = 'AvatarBodyRig';
    group.add(this.avatarBody);

    const pelvis = makeBox(0.48, 0.22, 0.28, this.legsMaterial, 0, 0.84, 0);
    pelvis.name = 'Pelvis';
    this.avatarBody.add(pelvis);

    this.torsoPivot = new THREE.Group();
    this.torsoPivot.name = 'TorsoPivot';
    this.torsoPivot.position.set(0, 1.16, 0);
    const torso = enableShadows(new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.23, 0.52, 8, 1), this.torsoMaterial));
    torso.name = 'Torso';
    this.torsoPivot.add(torso);
    this.torsoPivot.add(makeBox(0.34, 0.045, 0.018, this.skinShadeMaterial, 0, 0.12, -0.257));
    this.avatarBody.add(this.torsoPivot);

    const neck = makeCapsule(0.075, 0.04, this.skinMaterial, 0, 1.475, 0);
    neck.name = 'Neck';
    this.avatarBody.add(neck);

    this.headPivot = new THREE.Group();
    this.headPivot.name = 'HeadPivot';
    this.headPivot.position.set(0, 1.64, 0);
    const head = makeSphere(0.235, this.skinMaterial, 0, 0, 0, 16, 12);
    head.scale.set(0.9, 1.04, 0.94);
    head.name = 'Head';
    this.headPivot.add(head);

    // Cheveux, oreilles et visage détaillé à faible coût graphique.
    this.headPivot.add(makeBox(0.43, 0.105, 0.40, this.hairMaterial, 0, 0.205, 0.018));
    this.headPivot.add(makeBox(0.10, 0.16, 0.035, this.hairMaterial, -0.15, 0.125, -0.205));
    this.headPivot.add(makeBox(0.10, 0.13, 0.035, this.hairMaterial, 0.02, 0.145, -0.205));
    this.headPivot.add(makeSphere(0.052, this.skinMaterial, -0.225, 0, 0, 8, 6));
    this.headPivot.add(makeSphere(0.052, this.skinMaterial, 0.225, 0, 0, 8, 6));

    for (const x of [-0.085, 0.085]) {
      this.headPivot.add(makeBox(0.070, 0.047, 0.020, this.eyeWhiteMaterial, x, 0.035, -0.220));
      this.headPivot.add(makeSphere(0.022, this.eyeMaterial, x, 0.033, -0.237, 8, 6));
      this.headPivot.add(makeSphere(0.010, this.pupilMaterial, x, 0.033, -0.249, 6, 4));
      this.headPivot.add(makeBox(0.078, 0.014, 0.015, this.hairMaterial, x, 0.095, -0.220));
    }
    this.headPivot.add(makeBox(0.038, 0.055, 0.050, this.skinShadeMaterial, 0, -0.025, -0.230));
    this.headPivot.add(makeBox(0.085, 0.018, 0.018, this.detailMaterial, 0, -0.112, -0.225));
    this.avatarBody.add(this.headPivot);

    const createArm = (side) => {
      const direction = side === 'left' ? -1 : 1;
      const shoulder = new THREE.Group();
      shoulder.name = `${side}Shoulder`;
      shoulder.position.set(direction * 0.34, 1.38, 0);
      shoulder.add(makeSphere(0.095, this.torsoMaterial, 0, -0.02, 0, 10, 7));
      shoulder.add(makeCapsule(0.078, 0.225, this.torsoMaterial, 0, -0.20, 0));

      const elbow = new THREE.Group();
      elbow.name = `${side}Elbow`;
      elbow.position.set(0, -0.385, 0);
      elbow.add(makeSphere(0.072, this.skinMaterial, 0, 0, 0, 10, 7));
      elbow.add(makeCapsule(0.068, 0.205, this.skinMaterial, 0, -0.19, 0));
      elbow.add(makeSphere(0.085, this.skinMaterial, 0, -0.39, -0.005, 10, 7));
      shoulder.add(elbow);
      this.avatarBody.add(shoulder);
      return { shoulder, elbow };
    };

    const createLeg = (side) => {
      const direction = side === 'left' ? -1 : 1;
      const hip = new THREE.Group();
      hip.name = `${side}Hip`;
      hip.position.set(direction * 0.145, 0.82, 0);
      hip.add(makeSphere(0.112, this.legsMaterial, 0, -0.015, 0, 10, 7));
      hip.add(makeCapsule(0.105, 0.19, this.legsMaterial, 0, -0.205, 0));

      const knee = new THREE.Group();
      knee.name = `${side}Knee`;
      knee.position.set(0, -0.40, 0);
      knee.add(makeSphere(0.095, this.legsMaterial, 0, 0, 0, 10, 7));
      knee.add(makeCapsule(0.09, 0.18, this.legsMaterial, 0, -0.18, 0));
      knee.add(makeBox(0.22, 0.14, 0.35, this.shoesMaterial, 0, -0.40, -0.055));
      hip.add(knee);
      this.avatarBody.add(hip);
      return { hip, knee };
    };

    const leftArm = createArm('left');
    const rightArm = createArm('right');
    const leftLeg = createLeg('left');
    const rightLeg = createLeg('right');

    this.avatarRig = {
      torso: this.torsoPivot,
      head: this.headPivot,
      leftArm: leftArm.shoulder,
      rightArm: rightArm.shoulder,
      leftElbow: leftArm.elbow,
      rightElbow: rightArm.elbow,
      leftLeg: leftLeg.hip,
      rightLeg: rightLeg.hip,
      leftKnee: leftLeg.knee,
      rightKnee: rightLeg.knee
    };

    this.vehicleVisual = new THREE.Group();
    this.vehicleVisual.name = 'VehicleVisual';
    group.add(this.vehicleVisual);
    group.visible = false;
    return group;
  }

  refreshVehicleVisual(type) {
    this.vehicleVisual.clear();
    if (!type) return;

    const dark = new THREE.MeshLambertMaterial({ color: 0x25282d });
    const accentColors = {
      motorcycle: 0xc43c32,
      car: 0x3f72c8,
      plane: 0xe6e9ec,
      jetpack: 0xd48b28
    };
    const accent = new THREE.MeshLambertMaterial({ color: accentColors[type] ?? 0x777777 });

    if (type === 'motorcycle') {
      this.vehicleVisual.add(makeBox(0.82, 0.18, 1.35, accent, 0, 0.18, 0.1));
      this.vehicleVisual.add(makeBox(0.72, 0.48, 0.18, dark, 0, 0.05, -0.52));
      this.vehicleVisual.add(makeBox(0.72, 0.48, 0.18, dark, 0, 0.05, 0.62));
    } else if (type === 'car') {
      this.vehicleVisual.add(makeBox(1.55, 0.45, 2.15, accent, 0, 0.2, 0.15));
      this.vehicleVisual.add(makeBox(1.2, 0.42, 1.0, dark, 0, 0.62, 0.18));
    } else if (type === 'plane') {
      this.vehicleVisual.add(makeBox(0.55, 0.32, 2.35, accent, 0, 0.4, 0.1));
      this.vehicleVisual.add(makeBox(3.1, 0.14, 0.62, accent, 0, 0.38, 0.2));
    } else if (type === 'jetpack') {
      this.vehicleVisual.add(makeBox(0.62, 0.78, 0.34, accent, 0, 0.9, 0.34));
      this.vehicleVisual.add(makeBox(0.18, 0.82, 0.2, dark, -0.25, 0.82, 0.38));
      this.vehicleVisual.add(makeBox(0.18, 0.82, 0.2, dark, 0.25, 0.82, 0.38));
    }
  }

  addEventListener(type, listener) {
    this.events.addEventListener(type, listener);
  }

  start() {
    if (this.active) return;
    this.active = true;
    this.events.dispatchEvent(new Event('active'));
  }

  pause() {
    if (!this.active) return;
    this.active = false;
    this.input.setVirtualMove(0, 0);
    this.input.consumeLookDelta();
    this.events.dispatchEvent(new Event('pause'));
  }

  isActive() {
    return this.active;
  }

  getEyePosition() {
    return this.eyePosition;
  }

  getNetworkState() {
    return {
      x: this.eyePosition.x,
      y: this.eyePosition.y,
      z: this.eyePosition.z,
      yaw: this.avatar.rotation.y,
      pitch: this.camera.rotation.x,
      moving: this.moveVector.lengthSq() > 0.02,
      grounded: this.grounded,
      character: this.characterIndex ?? 0,
      torsoColor: this.torsoMaterial.color.getHex(),
      legsColor: this.legsMaterial.color.getHex()
    };
  }

  setNetworkHealth(value) {
    this.health = THREE.MathUtils.clamp(Number(value) || 0, 0, this.maxHealth);
    this.onHealthChange?.(this.health, this.maxHealth);
  }

  setView(mode) {
    this.viewMode = mode === 'third' ? 'third' : 'first';
    this.updateCameraAndAvatar();
    return this.viewMode;
  }

  toggleView() {
    return this.setView(this.viewMode === 'first' ? 'third' : 'first');
  }

  setAimZoom(value) {
    this.aimZoomed = Boolean(value);
  }

  applyRecoil(amount = 0) {
    const pitchKick = Math.max(0, Number(amount) || 0) * 0.018;
    const yawKick = (Math.random() - 0.5) * pitchKick * 0.55;
    this.pitch = THREE.MathUtils.clamp(this.pitch + pitchKick, -Math.PI / 2 + 0.05, Math.PI / 2 - 0.05);
    this.yaw += yawKick;
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
  }

  // Beta 4.17 : réaction à un coup reçu (paramètres calculés par HitReactionProfiles).
  // Visée déviée (comme un recul), secousse de caméra, poussée amortie, petit saut si explosion,
  // ralentissement bref. La santé n'est pas modifiée ici.
  applyHitReaction(reaction = {}) {
    this.pitch = THREE.MathUtils.clamp(this.pitch + (reaction.kickPitch ?? 0), -Math.PI / 2 + 0.05, Math.PI / 2 - 0.05);
    this.yaw += reaction.kickYaw ?? 0;
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
    this.hitShake = Math.max(this.hitShake ?? 0, reaction.shake ?? 0);
    if (!this.hitPush) this.hitPush = new THREE.Vector2();
    this.hitPush.set((this.hitPush.x + (reaction.pushX ?? 0)), (this.hitPush.y + (reaction.pushZ ?? 0)));
    if (reaction.hop && this.grounded) { this.verticalVelocity = Math.max(this.verticalVelocity, reaction.hop); this.grounded = false; }
    this.staggerUntil = performance.now() + (reaction.stagger ?? 0) * 1000;
    this.staggerSlow = reaction.slow ?? 1;
  }

  // Beta 4.20 : l'avatar adopte un personnage de la galerie. Les pivots du personnage remplissent
  // avatarRig (tronc, tête, bras, coudes, jambes, genoux) : animation et vêtements inchangés.
  setCharacter(index = 0) {
    const safe = Number.isInteger(index) && index >= 0 && index < CHARACTER_ROSTER.length ? index : 0;
    this.characterIndex = safe;
    const model = buildCharacter(rosterCharacter(safe));
    model.name = 'PlayerCharacter';
    for (const child of [...this.avatarBody.children]) this.avatarBody.remove(child);
    this.avatarBody.add(model);
    const pivot = (key, side) => model.children.find((child) => child.userData[key] === side);
    const leftArm = pivot('arm', -1), rightArm = pivot('arm', 1), leftLeg = pivot('leg', -1), rightLeg = pivot('leg', 1);
    const torso = new THREE.Group();
    torso.name = 'TorsoPivot';
    model.add(torso);
    this.torsoPivot = torso;
    this.headPivot = model.userData.headObject;
    this.avatarRig = {
      torso, head: this.headPivot,
      leftArm, rightArm, leftElbow: leftArm.userData.elbow, rightElbow: rightArm.userData.elbow,
      leftLeg, rightLeg, leftKnee: leftLeg.userData.knee, rightKnee: rightLeg.userData.knee
    };
    this.torsoMaterial = model.userData.materials.top;
    this.legsMaterial = model.userData.materials.pants;
    this.skinMaterial = model.userData.materials.skin;
    return rosterCharacter(safe);
  }

  equipClothing(item) {
    if (item.slot === 'torso') {
      this.torsoMaterial.color.setHex(item.color ?? 0x377ec9);
      this.clothingProtection = item.protection ?? 1;
    } else if (item.slot === 'legs') {
      this.legsMaterial.color.setHex(item.color ?? 0x284e7f);
    }
  }

  setVehicle(item) {
    if (this.vehicle?.type === item.type) {
      this.vehicle = null;
      this.invulnerable = false;
      this.bodyRadius = 0.31;
    this.grounding = new GroundingSystem(this.world, {
      maxStep: 0.92,
      footprint: this.bodyRadius,
      walkableTypes: PLAYER_WALKABLE_GROUND
    });
      this.refreshVehicleVisual(null);
      return false;
    }
    this.vehicle = item;
    this.refreshVehicleVisual(item.type);
    return true;
  }

  heal(amount) {
    const before = this.health;
    this.health = Math.min(this.maxHealth, this.health + amount);
    this.onHealthChange?.(this.health, this.maxHealth);
    return Math.round(this.health - before);
  }

  applySpeedBoost(multiplier, duration) {
    this.speedBoostMultiplier = Math.max(1, multiplier);
    this.speedBoostTimer = Math.max(0, duration);
  }

  applyShield(multiplier, duration) {
    this.shieldMultiplier = THREE.MathUtils.clamp(multiplier, 0.1, 1);
    this.shieldTimer = Math.max(0, duration);
  }

  setInvulnerable(value) {
    this.invulnerable = Boolean(value);
  }

  damage(amount) {
    if (this.invulnerable) return 0;
    const reduced = Math.max(1, Math.round(amount * this.clothingProtection * this.shieldMultiplier));
    this.health = Math.max(0, this.health - reduced);
    this.onHealthChange?.(this.health, this.maxHealth);

    if (this.health <= 0) {
      this.respawn();
      this.onDeath?.();
    }
    return reduced;
  }

  healFull() {
    this.health = this.maxHealth;
    this.onHealthChange?.(this.health, this.maxHealth);
  }

  teleportTo(position) {
    this.eyePosition.copy(position);
    this.verticalVelocity = 0;
    this.updateCameraAndAvatar();
  }

  respawn() {
    this.eyePosition.copy(this.spawnPoint);
    this.verticalVelocity = 0;
    this.healFull();
    this.pause();
    this.updateCameraAndAvatar();
  }

  updateLook() {
    const look = this.input.consumeLookDelta();
    if (look.x === 0 && look.y === 0) return;

    const baseSensitivity = this.touchMode ? 0.0032 : 0.0040;
    const sensitivity = this.aimZoomed ? baseSensitivity * 0.36 : baseSensitivity;
    this.yaw -= look.x * sensitivity;
    this.pitch -= look.y * sensitivity;
    this.pitch = THREE.MathUtils.clamp(this.pitch, -Math.PI / 2 + 0.05, Math.PI / 2 - 0.05);
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
  }

  updateCameraAndAvatar() {
    this.forwardVector.set(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const horizontalForward = this.forwardVector.clone();
    horizontalForward.y = 0;
    if (horizontalForward.lengthSq() === 0) horizontalForward.set(0, 0, -1);
    horizontalForward.normalize();

    this.rightVector.set(1, 0, 0).applyQuaternion(this.camera.quaternion);
    this.rightVector.y = 0;
    if (this.rightVector.lengthSq() > 0) this.rightVector.normalize();

    // Beta 4.17 : secousse de caméra après un coup (roulis + petit tremblement), sans toucher au cap visé.
    const shake = this.hitShake ?? 0;
    const time = performance.now() * 0.001;
    this.camera.rotation.z = shake > 0 ? Math.sin(time * 37) * 0.035 * shake : 0;
    if (this.viewMode === 'first') {
      this.camera.position.copy(this.eyePosition);
      if (shake > 0) this.camera.position.add(new THREE.Vector3(Math.sin(time * 53) * 0.03 * shake, Math.sin(time * 41 + 1.3) * 0.03 * shake, 0));
      this.avatar.visible = false;
    } else {
      this.cameraOffset.copy(horizontalForward).multiplyScalar(-4.25);
      this.cameraOffset.addScaledVector(this.rightVector, 0.72);
      this.cameraOffset.y += 1.15;
      this.camera.position.copy(this.eyePosition).add(this.cameraOffset);
      this.avatar.visible = true;
    }

    this.avatar.position.set(
      this.eyePosition.x,
      this.eyePosition.y - this.eyeHeight,
      this.eyePosition.z
    );

    const facing = this.moveVector.lengthSq() > 0.02 ? this.moveVector : horizontalForward;
    this.avatarTargetYaw = Math.atan2(facing.x, facing.z) + Math.PI;
  }

  animateAvatar(delta, movement, currentSpeed) {
    if (!this.avatarRig) return;
    this.avatarTime += delta;

    // Beta 4.11 : la démarche suit le déplacement réel (contre un mur, l'avatar ne marche plus sur place).
    const travelled = this.lastAvatarPosition
      ? Math.hypot(this.eyePosition.x - this.lastAvatarPosition.x, this.eyePosition.z - this.lastAvatarPosition.z) : 0;
    if (!this.lastAvatarPosition) this.lastAvatarPosition = new THREE.Vector3();
    this.lastAvatarPosition.copy(this.eyePosition);
    const measuredSpeed = delta > 0 && travelled < 3 ? travelled / delta : 0;
    this.avatarBody?.userData.hd?.update(delta, this.grounded ? measuredSpeed : 0); // Beta 4.24 : avatar HD
    const movementAmount = THREE.MathUtils.clamp(measuredSpeed / Math.max(0.1, currentSpeed), 0, 1);
    const targetWalkBlend = this.isActive() && this.grounded ? movementAmount : 0;
    this.walkBlend = damp(this.walkBlend, targetWalkBlend, 10, delta);

    if (movementAmount > 0.02 && this.grounded) {
      this.walkCycle += travelled * 1.7;
    }

    const strideWave = Math.sin(this.walkCycle);
    const stride = strideWave * 0.72 * this.walkBlend;
    const kneeLeft = Math.max(0, -strideWave) * 0.48 * this.walkBlend;
    const kneeRight = Math.max(0, strideWave) * 0.48 * this.walkBlend;
    const breathing = Math.sin(this.avatarTime * 2.05) * 0.006;
    const bob = Math.abs(Math.sin(this.walkCycle * 2)) * 0.026 * this.walkBlend;
    const lateralLean = -movement.x * 0.075 * this.walkBlend;

    const airborne = !this.grounded && this.isActive();
    const leftLegTarget = airborne ? -0.24 : stride;
    const rightLegTarget = airborne ? 0.18 : -stride;
    const leftArmTarget = airborne ? -0.48 : -stride * 0.78;
    const rightArmTarget = airborne ? -0.22 : stride * 0.78;
    const leftKneeTarget = airborne ? 0.58 : kneeLeft;
    const rightKneeTarget = airborne ? 0.42 : kneeRight;

    this.avatarBody.position.y = damp(this.avatarBody.position.y, breathing + bob, 12, delta);
    this.avatarRig.torso.rotation.z = damp(this.avatarRig.torso.rotation.z, lateralLean, 10, delta);
    this.avatarRig.torso.rotation.y = damp(this.avatarRig.torso.rotation.y, Math.sin(this.walkCycle) * 0.035 * this.walkBlend, 10, delta);
    this.avatarRig.head.rotation.x = damp(
      this.avatarRig.head.rotation.x,
      THREE.MathUtils.clamp(this.camera.rotation.x * 0.32, -0.28, 0.28),
      10,
      delta
    );
    this.avatarRig.head.rotation.z = damp(this.avatarRig.head.rotation.z, -lateralLean * 0.35, 9, delta);

    this.avatarRig.leftLeg.rotation.x = damp(this.avatarRig.leftLeg.rotation.x, leftLegTarget, 14, delta);
    this.avatarRig.rightLeg.rotation.x = damp(this.avatarRig.rightLeg.rotation.x, rightLegTarget, 14, delta);
    this.avatarRig.leftKnee.rotation.x = damp(this.avatarRig.leftKnee.rotation.x, leftKneeTarget, 15, delta);
    this.avatarRig.rightKnee.rotation.x = damp(this.avatarRig.rightKnee.rotation.x, rightKneeTarget, 15, delta);

    this.avatarRig.leftArm.rotation.x = damp(this.avatarRig.leftArm.rotation.x, leftArmTarget, 13, delta);
    this.avatarRig.rightArm.rotation.x = damp(this.avatarRig.rightArm.rotation.x, rightArmTarget, 13, delta);
    this.avatarRig.leftArm.rotation.z = damp(this.avatarRig.leftArm.rotation.z, 0.055 + lateralLean * 0.25, 10, delta);
    this.avatarRig.rightArm.rotation.z = damp(this.avatarRig.rightArm.rotation.z, -0.055 + lateralLean * 0.25, 10, delta);
    this.avatarRig.leftElbow.rotation.x = damp(this.avatarRig.leftElbow.rotation.x, 0.10 + Math.max(0, stride) * 0.22, 13, delta);
    this.avatarRig.rightElbow.rotation.x = damp(this.avatarRig.rightElbow.rotation.x, 0.10 + Math.max(0, -stride) * 0.22, 13, delta);

    this.avatar.rotation.y = dampAngle(this.avatar.rotation.y, this.avatarTargetYaw, movementAmount > 0.02 ? 12 : 7, delta);
  }

  canOccupy(position) {
    const feetY = position.y - this.eyeHeight + 0.12;
    const samplesY = [feetY + 0.18, feetY + 0.88, feetY + 1.52];
    for (const offsetX of [-this.bodyRadius, this.bodyRadius]) {
      for (const offsetZ of [-this.bodyRadius, this.bodyRadius]) {
        for (const sampleY of samplesY) {
          const block = this.world.getBlock(position.x + offsetX, sampleY, position.z + offsetZ);
          if (block && !['leaves','shrub','tall_grass','flower_red','flower_yellow'].includes(block.type) && this.world.isSolidAt(position.x + offsetX, sampleY, position.z + offsetZ)) return false;
        }
      }
    }
    return true;
  }

  // Beta 4.11 : appui réel sous le corps. Le sol interpolé du GroundingSystem (lissé pour les PNJ)
  // descend en pente entre deux colonnes : au bord d'une marche, les pieds entraient dans le bloc
  // porteur, canOccupy() refusait alors toute position et le joueur restait bloqué sur place.
  supportTop(x, z, feetY) {
    let best = null;
    for (const offsetX of [-this.bodyRadius, 0, this.bodyRadius]) {
      for (const offsetZ of [-this.bodyRadius, 0, this.bodyRadius]) {
        const sample = this.grounding.sample(x + offsetX, z + offsetZ, feetY); // Beta 4.32 : sol sous les surplombs (portail, toit, tunnel)
        if (!this.grounding.isDryGround(sample)) continue;
        if (sample.y > feetY + 0.6) continue;
        if (best === null || sample.y > best) best = sample.y;
      }
    }
    return best;
  }

  // Dégage un joueur déjà pris dans un bloc (apparition, sauvegarde ancienne, bloc posé sur lui).
  unstick() {
    if (this.canOccupy(this.eyePosition)) return;
    const start = this.eyePosition.y;
    for (let lift = 0.1; lift <= 2.6; lift += 0.1) {
      this.eyePosition.y = start + lift;
      if (this.canOccupy(this.eyePosition)) { this.verticalVelocity = 0; return; }
    }
    this.eyePosition.y = start;
  }

  moveWithCollisions(dx, dz) {
    const distance = Math.hypot(dx, dz);
    const steps = Math.max(1, Math.ceil(distance / 0.22));
    const stepX = dx / steps;
    const stepZ = dz / steps;

    for (let index = 0; index < steps; index += 1) {
      const referenceFeet = this.eyePosition.y - this.eyeHeight; // Beta 4.32 : les hauteurs de colonnes se lisent depuis les pieds (surplombs)
      const xCandidate = this.eyePosition.clone();
      xCandidate.x += stepX;
      if (
        this.canOccupy(xCandidate)
        && this.grounding.canStep(this.eyePosition.x, this.eyePosition.z, xCandidate.x, xCandidate.z, 0.92, referenceFeet)
      ) this.eyePosition.x = xCandidate.x;
      else this.tryStepUp(xCandidate);

      const zCandidate = this.eyePosition.clone();
      zCandidate.z += stepZ;
      if (
        this.canOccupy(zCandidate)
        && this.grounding.canStep(this.eyePosition.x, this.eyePosition.z, zCandidate.x, zCandidate.z, 0.92, this.eyePosition.y - this.eyeHeight)
      ) this.eyePosition.z = zCandidate.z;
      else this.tryStepUp(zCandidate);
    }
  }

  // Beta 4.12 : montée automatique d'une marche d'un bloc (relief montagneux). Conditions :
  // joueur au sol, tête dégagée un bloc plus haut, vrai bloc porteur sous la nouvelle position.
  tryStepUp(candidate) {
    if (!this.grounded) return false;
    const feetY = this.eyePosition.y - this.eyeHeight;
    const raised = candidate.clone();
    raised.y += 1.02;
    if (!this.canOccupy(raised)) return false;
    const support = this.supportTop(raised.x, raised.z, feetY + 1.02);
    if (support === null || support < feetY + 0.6 || support > feetY + 1.1) return false;
    this.eyePosition.copy(raised);
    this.eyePosition.y = support + 0.006 + this.eyeHeight;
    return true;
  }

  update(delta) {
    if (!this.isActive()) {
      this.moveVector.set(0, 0, 0);
      this.updateCameraAndAvatar();
      this.animateAvatar(delta, { x: 0, y: 0 }, this.baseSpeed);
      return;
    }

    this.updateLook();
    this.speedBoostTimer = Math.max(0, this.speedBoostTimer - delta);
    this.shieldTimer = Math.max(0, this.shieldTimer - delta);
    if (this.speedBoostTimer <= 0) this.speedBoostMultiplier = 1;
    if (this.shieldTimer <= 0) this.shieldMultiplier = 1;

    this.unstick();
    const movement = this.input.getMovement();
    this.forwardVector.set(0, 0, -1).applyQuaternion(this.camera.quaternion);
    this.forwardVector.y = 0;
    if (this.forwardVector.lengthSq() > 0) this.forwardVector.normalize();

    this.rightVector.set(1, 0, 0).applyQuaternion(this.camera.quaternion);
    this.rightVector.y = 0;
    if (this.rightVector.lengthSq() > 0) this.rightVector.normalize();

    this.moveVector.set(0, 0, 0)
      .addScaledVector(this.forwardVector, movement.y)
      .addScaledVector(this.rightVector, movement.x);

    if (this.moveVector.lengthSq() > 1) this.moveVector.normalize();
    const vehicleSpeed = this.vehicle?.speedMultiplier ?? 1;
    const staggered = (this.staggerUntil ?? 0) > performance.now();
    const currentSpeed = this.baseSpeed * vehicleSpeed * this.speedBoostMultiplier * (staggered ? (this.staggerSlow ?? 1) : 1);
    // Beta 4.29 : en parapente, on avance toujours face au regard ; Z/S règlent la vitesse (accélérateur / freins).
    if (this.gliding) {
      const glideSpeed = THREE.MathUtils.clamp(7 + movement.y * 2.5, 4.5, 9.5);
      this.glideSpeed = glideSpeed;
      this.moveVector.copy(this.forwardVector).multiplyScalar(1).addScaledVector(this.rightVector, movement.x * 0.35);
      this.moveWithCollisions(this.moveVector.x * glideSpeed * delta, this.moveVector.z * glideSpeed * delta);
    } else {
      const horizontalStep = this.moveVector.clone().multiplyScalar(currentSpeed * delta);
      this.moveWithCollisions(horizontalStep.x, horizontalStep.z);
    }
    // Beta 4.17 : poussée d'un coup reçu, amortie (≈ 0,3 s), avec les mêmes collisions que la marche.
    if (this.hitPush && this.hitPush.lengthSq() > 0.0004) {
      this.moveWithCollisions(this.hitPush.x * delta, this.hitPush.y * delta);
      this.hitPush.multiplyScalar(Math.exp(-7 * delta));
    }
    if (this.hitShake > 0) this.hitShake = Math.max(0, this.hitShake - delta * 2.8);

    const solvedGround = this.grounding.groundY(
      this.eyePosition.x,
      this.eyePosition.z,
      0,
      this.bodyRadius,
      this.eyePosition.y - this.eyeHeight // Beta 4.32 : le sol est le bloc praticable à portée des pieds, pas le dessus de la colonne
    );
    const feetY = this.eyePosition.y - this.eyeHeight;
    const support = this.supportTop(this.eyePosition.x, this.eyePosition.z, feetY);
    const standing = support === null ? solvedGround : Math.max(support + 0.006, solvedGround ?? -Infinity);
    const groundY = (standing ?? feetY) + this.eyeHeight;
    const jumpMultiplier = this.vehicle?.jumpMultiplier ?? 1;
    const gravityMultiplier = this.vehicle?.gravityMultiplier ?? 1;

    if (this.grounded && (this.input.consumePress('Space') || this.input.consumeVirtual('jump'))) {
      this.verticalVelocity = this.jumpStrength * jumpMultiplier;
      this.grounded = false;
    }

    // Beta 4.29 : parapente — Espace (ou ↑) en l'air ouvre / referme la voile quand elle est en main.
    if (!this.grounded && this.canGlide && (this.airTime ?? 0) > 0.18 && (this.input.consumePress('Space') || this.input.consumeVirtual('jump'))) {
      this.gliding = !this.gliding;
      this.events.dispatchEvent(new Event(this.gliding ? 'glide-start' : 'glide-end'));
    }
    if (this.gliding && !this.canGlide) { this.gliding = false; this.events.dispatchEvent(new Event('glide-end')); }

    if (this.gliding) {
      // Taux de chute ≈ 1,4 m/s (finesse ≈ 5), plus les ascendances thermiques (glideLift, fourni par le jeu).
      const sink = 1.4 + Math.max(0, (this.glideSpeed ?? 7) - 7) * 0.25;
      this.verticalVelocity = THREE.MathUtils.damp(this.verticalVelocity, -sink + (this.glideLift ?? 0), 2.2, delta);
    } else {
      this.verticalVelocity -= this.gravity * gravityMultiplier * delta;
    }
    this.eyePosition.y += this.verticalVelocity * delta;

    if (this.eyePosition.y <= groundY) {
      this.eyePosition.y = groundY;
      this.verticalVelocity = 0;
      this.grounded = true;
      this.airTime = 0;
      if (this.gliding) { this.gliding = false; this.events.dispatchEvent(new Event('glide-land')); }
    } else {
      this.grounded = false;
      this.airTime = (this.airTime ?? 0) + delta;
    }

    if (this.eyePosition.y < -15) this.respawn();
    this.updateCameraAndAvatar();
    this.animateAvatar(delta, movement, currentSpeed);
  }
}
