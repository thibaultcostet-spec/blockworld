// BlockWorld V3.0 Beta 4.27 — pêche à la canne : bouchon, ligne, touche, ferrage, prise selon le continent.
import * as THREE from 'three';
import { FISHING_RULES, fishingStep, nextBiteDelay, pickFish } from './FishingRules.js';

export class FishingSystem {
  constructor(game) {
    this.game = game;
    this.state = 'idle';
    this.elapsed = 0;
    this.waitTime = 5;
    this.origin = new THREE.Vector3();
    this.spot = new THREE.Vector3();
    this.catches = 0;

    this.bobber = new THREE.Group();
    const top = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xe8352b, roughness: 0.5 }));
    const bottom = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xf5f5f0, roughness: 0.5 }));
    this.bobber.add(top, bottom);
    this.bobber.visible = false;
    this.ring = new THREE.Mesh(new THREE.RingGeometry(0.12, 0.17, 24), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide }));
    this.ring.rotation.x = -Math.PI / 2;
    this.ring.visible = false;
    this.lineGeometry = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    this.line = new THREE.Line(this.lineGeometry, new THREE.LineBasicMaterial({ color: 0xe6e6e6, transparent: true, opacity: 0.75 }));
    this.line.visible = false;
    this.line.frustumCulled = false;
    game.scene.add(this.bobber, this.ring, this.line);
  }

  isActive() { return this.state !== 'idle'; }

  /** Clic droit / ▣ avec la canne : lancer, ou ferrer. */
  use() {
    const g = this.game;
    if (this.state === 'idle') {
      const water = this.findWater();
      const step = fishingStep('idle', { action: 'use', onWater: Boolean(water) });
      if (step.outcome === 'no-water') { g.hud.setStatus(`Vise une étendue d'eau à moins de ${FISHING_RULES.castRange} m pour lancer la ligne`); return; }
      this.state = step.state;
      this.elapsed = 0;
      this.waitTime = nextBiteDelay();
      this.spot.copy(water);
      this.origin.copy(g.player.getEyePosition());
      this.showGear(true);
      g.sfx?.playSplash?.();
      g.hud.setStatus('Ligne lancée · attends que le bouchon plonge');
      return;
    }
    const step = fishingStep(this.state, { action: 'use', elapsed: this.elapsed, waitTime: this.waitTime });
    this.finish(step.outcome);
  }

  // Avance le long du regard par pas de 25 cm : la première case d'eau rencontrée reçoit le bouchon ;
  // un bloc plein avant l'eau arrête le lancer. (L'eau n'est pas toujours une cible du lancer de rayons.)
  findWater() {
    const g = this.game;
    const origin = g.camera.getWorldPosition(new THREE.Vector3());
    const direction = g.camera.getWorldDirection(new THREE.Vector3());
    const probe = new THREE.Vector3();
    for (let t = 1; t <= FISHING_RULES.castRange; t += 0.25) {
      probe.copy(origin).addScaledVector(direction, t);
      const block = g.world.getBlock(Math.round(probe.x), Math.round(probe.y), Math.round(probe.z));
      if (!block) continue;
      if (block.type === 'water') {
        let top = block.y;
        while (g.world.getBlock(block.x, top + 1, block.z)?.type === 'water') top += 1;
        return new THREE.Vector3(block.x, top + 0.45, block.z);
      }
      if (['tall_grass', 'shrub', 'flower_red', 'flower_yellow', 'rail', 'ladder'].includes(block.type)) continue;
      // Berge : le regard touche le bord d'un ruisseau encaissé → on cherche l'eau dans les cases voisines.
      // (rayon de 2 cases autour du point visé, dans le sens du regard d'abord).
      let best = null;
      for (let dx = -2; dx <= 2; dx += 1) for (let dz = -2; dz <= 2; dz += 1) for (const dy of [0, -1, 1, -2]) {
        const near = g.world.getBlock(block.x + dx, block.y + dy, block.z + dz);
        if (near?.type !== 'water' || g.world.getBlock(near.x, near.y + 1, near.z)) continue;
        const ahead = dx * direction.x + dz * direction.z;
        const score = Math.hypot(dx, dz) - ahead * 0.6;
        if (!best || score < best.score) best = { near, score };
      }
      return best ? new THREE.Vector3(best.near.x, best.near.y + 0.45, best.near.z) : null;
    }
    return null;
  }

  finish(outcome) {
    const g = this.game;
    this.state = 'idle';
    this.elapsed = 0;
    this.showGear(false);
    if (outcome === 'catch') {
      const fish = pickFish(g.currentWorldTheme?.() ?? 'europe');
      g.hunger?.addFood?.(fish.portions);
      this.catches += 1;
      g.sfx?.playCatch?.();
      g.hud.setStatus(`🐟 ${fish.name} pêché(e) : +${fish.portions} portion${fish.portions > 1 ? 's' : ''} crue${fish.portions > 1 ? 's' : ''} · cuis-la près d'un feu de camp`);
      g.hud.updateHunger?.(g.hunger, g.hunger?.isActive?.(g.selectedModeId));
    } else if (outcome === 'early') {
      g.hud.setStatus('Trop tôt : le poisson n’avait pas encore mordu');
    } else if (outcome === 'missed') {
      g.hud.setStatus('Le poisson s’est échappé · relance la ligne');
    } else if (outcome === 'reeled') {
      g.hud.setStatus('Ligne remontée');
    }
  }

  cancel() { if (this.state !== 'idle') this.finish('reeled'); }

  showGear(visible) {
    this.bobber.visible = visible;
    this.line.visible = visible;
    this.ring.visible = visible;
    if (visible) this.bobber.position.copy(this.spot);
  }

  update(delta) {
    if (this.state === 'idle') return;
    const g = this.game;
    const eye = g.player.getEyePosition();
    if (g.selectedItem?.type !== 'fishing-rod' || eye.distanceTo(this.origin) > 6 || !g.player.isActive()) { this.cancel(); return; }
    this.elapsed += delta;
    const before = this.state;
    const step = fishingStep(this.state, { elapsed: this.elapsed, waitTime: this.waitTime });
    if (step.state !== before) {
      this.state = step.state;
      this.elapsed = 0;
      if (this.state === 'bite') { g.sfx?.playBite?.(); g.hud.setStatus('🎣 Ça mord ! Ferre vite (clic droit / ▣)'); }
    }
    if (step.outcome === 'missed') { this.finish('missed'); return; }
    // Bouchon : léger balancement, plongée à la touche, ronds dans l'eau.
    const t = performance.now() / 1000;
    const dip = this.state === 'bite' ? -0.16 + Math.sin(t * 22) * 0.04 : Math.sin(t * 2.4) * 0.025;
    this.bobber.position.set(this.spot.x, this.spot.y + dip, this.spot.z);
    this.ring.position.set(this.spot.x, this.spot.y - 0.02, this.spot.z);
    const pulse = (t * (this.state === 'bite' ? 2.4 : 0.8)) % 1;
    this.ring.scale.setScalar(1 + pulse * (this.state === 'bite' ? 5 : 2.5));
    this.ring.material.opacity = (1 - pulse) * (this.state === 'bite' ? 0.7 : 0.35);
    // Ligne : du bout de la canne (devant la caméra, en bas à droite) jusqu'au bouchon.
    const tip = new THREE.Vector3(0.38, -0.12, -0.9).applyQuaternion(g.camera.quaternion).add(g.camera.position);
    const positions = this.lineGeometry.attributes.position;
    positions.setXYZ(0, tip.x, tip.y, tip.z);
    positions.setXYZ(1, this.bobber.position.x, this.bobber.position.y + 0.06, this.bobber.position.z);
    positions.needsUpdate = true;
  }
}
