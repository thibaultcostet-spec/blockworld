// BlockWorld V3.0 Beta 4.27 — pêche : règles pures (testables sous Node).
// Lancer la ligne sur l'eau (clic droit / ▣ avec la canne), attendre la touche (le bouchon plonge et un « plop »
// retentit), puis ferrer (clic droit / ▣) dans la seconde et demie. Chaque continent a ses poissons.

export const FISHING_RULES = { minWait: 3, maxWait: 8, biteWindow: 1.5, castRange: 14, maxCastDistance: 18 };

export const FISH_BY_THEME = {
  europe: [{ name: 'truite', portions: 1 }, { name: 'perche', portions: 1 }, { name: 'brochet', portions: 2 }],
  africa: [{ name: 'tilapia', portions: 1 }, { name: 'poisson-chat', portions: 2 }, { name: 'perche du Nil', portions: 2 }],
  asia: [{ name: 'carpe koï', portions: 1 }, { name: 'poisson-serpent', portions: 1 }, { name: 'silure', portions: 2 }],
  americas: [{ name: 'saumon', portions: 2 }, { name: 'bar', portions: 1 }, { name: 'tilapia', portions: 1 }],
  oceania: [{ name: 'barramundi', portions: 2 }, { name: 'vivaneau', portions: 1 }, { name: 'poisson-perroquet', portions: 1 }]
};

/** Délai avant la touche, en secondes (3 à 8 s). `random` ∈ [0, 1[. */
export function nextBiteDelay(random = Math.random()) {
  const r = Math.min(0.999999, Math.max(0, Number(random) || 0));
  return FISHING_RULES.minWait + r * (FISHING_RULES.maxWait - FISHING_RULES.minWait);
}

/** Poisson pris selon le continent. */
export function pickFish(theme, random = Math.random()) {
  const list = FISH_BY_THEME[theme] ?? FISH_BY_THEME.europe;
  const index = Math.min(list.length - 1, Math.floor(Math.max(0, Number(random) || 0) * list.length));
  return list[index];
}

/**
 * Machine d'états de la ligne : idle → waiting → bite → idle.
 * `action` vaut 'use' (clic droit / ▣) ; `elapsed` = temps passé dans l'état courant.
 * Renvoie { state, outcome } avec outcome ∈ '', 'cast', 'early', 'catch', 'missed', 'reeled'.
 */
export function fishingStep(state, { action = '', elapsed = 0, waitTime = 5, onWater = true } = {}) {
  if (state === 'idle') {
    if (action !== 'use') return { state, outcome: '' };
    return onWater ? { state: 'waiting', outcome: 'cast' } : { state: 'idle', outcome: 'no-water' };
  }
  if (state === 'waiting') {
    if (action === 'use') return { state: 'idle', outcome: 'early' };
    return elapsed >= waitTime ? { state: 'bite', outcome: '' } : { state, outcome: '' };
  }
  if (state === 'bite') {
    if (action === 'use') return { state: 'idle', outcome: 'catch' };
    return elapsed > FISHING_RULES.biteWindow ? { state: 'idle', outcome: 'missed' } : { state, outcome: '' };
  }
  return { state: 'idle', outcome: '' };
}
