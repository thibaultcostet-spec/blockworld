// BlockWorld V3.0 Beta 4.22 — faim (modes Survie et Missions).
// La faim baisse d'un point toutes les 6 s (≈ 10 min de 100 à 0). À 0, le joueur perd 2 PV toutes les 5 s.
// Manger une portion de viande (touche G, bouton B de la manette, ou toucher la jauge) : +30 faim, +5 PV.
// Beta 4.27 : cuisine. Près d'un feu de camp, la viande et le poisson crus cuisent (une portion toutes les 4 s) ;
// une portion cuite nourrit presque deux fois plus (+55 faim, +12 PV). On mange toujours le cuit en premier.
// Module sans dépendance (testable sous Node).

export const HUNGER_RULES = { max: 100, decayPerSecond: 1 / 6, starvingDamage: 2, starvingInterval: 5, mealHunger: 30, mealHeal: 5, cookedHunger: 55, cookedHeal: 12, cookSeconds: 4 };
export const HUNGER_MODES = ['survival', 'missions'];

export class HungerSystem {
  constructor({ rules = HUNGER_RULES } = {}) {
    this.rules = rules;
    this.hunger = rules.max;
    this.food = 0;      // portions crues (viande, poisson)
    this.cooked = 0;    // portions cuites (Beta 4.27)
    this.cookTimer = 0;
    this.starvingTimer = 0;
  }

  reset() { this.hunger = this.rules.max; this.food = 0; this.cooked = 0; this.cookTimer = 0; this.starvingTimer = 0; }

  isActive(modeId) { return HUNGER_MODES.includes(modeId); }

  /** Avance la faim ; renvoie les PV à retirer (0 si le joueur n'est pas affamé). */
  update(delta, modeId) {
    if (!this.isActive(modeId) || !(delta > 0)) return 0;
    this.hunger = Math.max(0, this.hunger - this.rules.decayPerSecond * delta);
    if (this.hunger > 0) { this.starvingTimer = 0; return 0; }
    this.starvingTimer += delta;
    if (this.starvingTimer < this.rules.starvingInterval) return 0;
    this.starvingTimer -= this.rules.starvingInterval;
    return this.rules.starvingDamage;
  }

  addFood(portions, { cooked = false } = {}) {
    const amount = Math.max(0, Math.round(portions));
    if (cooked) this.cooked += amount; else this.food += amount;
    return this.food + this.cooked;
  }

  /** Cuisson près d'un feu : renvoie le nombre de portions cuites pendant ce pas de temps. */
  cook(delta, nearFire) {
    if (!nearFire || this.food <= 0 || !(delta > 0)) { this.cookTimer = 0; return 0; }
    this.cookTimer += delta;
    let done = 0;
    while (this.cookTimer >= this.rules.cookSeconds && this.food > 0) {
      this.cookTimer -= this.rules.cookSeconds;
      this.food -= 1; this.cooked += 1; done += 1;
    }
    return done;
  }

  /** Mange une portion si possible (cuite d'abord). Renvoie { ok, heal, reason, cooked }. */
  eat() {
    if (this.food <= 0 && this.cooked <= 0) return { ok: false, heal: 0, reason: 'empty', cooked: false };
    if (this.hunger >= this.rules.max - 1) return { ok: false, heal: 0, reason: 'full', cooked: false };
    if (this.cooked > 0) {
      this.cooked -= 1;
      this.hunger = Math.min(this.rules.max, this.hunger + this.rules.cookedHunger);
      return { ok: true, heal: this.rules.cookedHeal, reason: '', cooked: true };
    }
    this.food -= 1;
    this.hunger = Math.min(this.rules.max, this.hunger + this.rules.mealHunger);
    return { ok: true, heal: this.rules.mealHeal, reason: '', cooked: false };
  }

  get ratio() { return this.hunger / this.rules.max; }
}
