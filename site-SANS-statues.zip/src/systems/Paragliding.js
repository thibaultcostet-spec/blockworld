// BlockWorld V3.0 Beta 4.29 — parapente : voile au-dessus du joueur, ascendances visibles sur les sommets,
// variomètre (altitude au-dessus du sol, vitesse verticale) et sifflement du vent.
import * as THREE from 'three';
import { THERMAL_RULES, findThermals, formatVario, thermalLift } from './ParaglidingRules.js';

function buildCanopy() {
  const group = new THREE.Group();
  group.name = 'ParagliderCanopy';
  const cells = 9;
  const colors = [0xf2542d, 0xffffff, 0xf2b134, 0xffffff, 0x2b7bd8, 0xffffff, 0xf2b134, 0xffffff, 0xf2542d];
  for (let i = 0; i < cells; i += 1) {
    const a = (i / (cells - 1) - 0.5) * 2.2;          // arc de la voile (≈ 126°)
    const cell = new THREE.Mesh(new THREE.BoxGeometry(0.98, 0.16, 1.5), new THREE.MeshStandardMaterial({ color: colors[i], emissive: colors[i], emissiveIntensity: 0.38, roughness: 0.7, side: THREE.DoubleSide }) /* tissu translucide : l'intrados reste coloré */);
    cell.position.set(Math.sin(a) * 4.1, Math.cos(a) * 1.6, 0);
    cell.rotation.z = -a * 0.42;
    group.add(cell);
  }
  const points = [];
  for (let i = 0; i < cells; i += 2) {
    const a = (i / (cells - 1) - 0.5) * 2.2;
    for (const z of [-0.5, 0.5]) points.push(new THREE.Vector3(Math.sin(a) * 4.1, Math.cos(a) * 1.6 - 0.08, z), new THREE.Vector3(Math.sign(Math.sin(a)) * 0.25, -3.1, 0));
  }
  group.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(points), new THREE.LineBasicMaterial({ color: 0x2a2a2a, transparent: true, opacity: 0.7 })));
  group.scale.setScalar(0.78);
  group.visible = false;
  return group;
}

function buildThermalColumn(thermal) {
  const count = 36;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i += 1) {
    const a = i * 2.4, r = (i % 6) / 6 * thermal.radius * 0.8;
    positions[i * 3] = Math.cos(a) * r; positions[i * 3 + 1] = (i / count) * (thermal.top - thermal.ground); positions[i * 3 + 2] = Math.sin(a) * r;
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const points = new THREE.Points(geometry, new THREE.PointsMaterial({ color: 0xffffff, size: 0.35, transparent: true, opacity: 0.32, depthWrite: false }));
  points.position.set(thermal.x, thermal.ground + 1, thermal.z);
  points.userData.height = thermal.top - thermal.ground;
  return points;
}

export class ParaglidingSystem {
  constructor(game) {
    this.game = game;
    this.thermals = [];
    this.canopy = buildCanopy();
    this.columns = new THREE.Group();
    this.columns.name = 'Thermals';
    game.scene.add(this.canopy, this.columns);
    this.chip = document.getElementById('glide-chip');
    this.windTimer = 0;
    const player = game.player;
    player.addEventListener('glide-start', () => { this.canopy.visible = true; game.hud.setStatus('🪂 Voile ouverte · regarde où aller, Z accélère, S freine · cherche les colonnes blanches au-dessus des sommets'); game.sfx?.playSplash?.(); });
    player.addEventListener('glide-end', () => { this.canopy.visible = false; game.hud.setStatus('Voile refermée'); });
    player.addEventListener('glide-land', () => { this.canopy.visible = false; game.hud.setStatus('Atterrissage réussi 🪂'); });
  }

  setWorld(definition) {
    const world = this.game.world;
    this.thermals = findThermals((x, z) => world.getSurfaceHeight(x, z), definition.size || 224);
    this.columns.clear();
    for (const thermal of this.thermals) this.columns.add(buildThermalColumn(thermal));
  }

  /** Le joueur peut-il ouvrir la voile ? (parapente en main) */
  setEquipped(equipped) {
    this.game.player.canGlide = Boolean(equipped);
  }

  update(delta, eye) {
    const g = this.game;
    const player = g.player;
    const daylight = g.atmosphere?.daylight ?? 1;
    // Colonnes thermiques : particules qui montent, visibles le jour.
    const t = performance.now() * 0.001;
    this.columns.visible = daylight > 0.3;
    for (const column of this.columns.children) {
      column.rotation.y = t * 0.4;
      column.material.opacity = 0.32 * Math.min(1, (daylight - 0.3) / 0.3);
      const attribute = column.geometry.getAttribute('position');
      for (let i = 0; i < attribute.count; i += 1) {
        let y = attribute.getY(i) + delta * 2.2;
        if (y > column.userData.height) y = 0;
        attribute.setY(i, y);
      }
      attribute.needsUpdate = true;
    }
    player.glideLift = player.gliding ? thermalLift(eye, this.thermals, daylight) : 0;
    if (player.gliding) {
      // Voile au-dessus du pilote, orientée vers la marche, légèrement inclinée en virage.
      const yaw = player.yaw ?? g.camera.rotation.y;
      this.canopy.position.set(eye.x, eye.y + 2.2, eye.z); // assez bas pour rester visible en vue extérieure
      this.canopy.rotation.set(0, yaw, 0);
      this.windTimer -= delta;
      if (this.windTimer <= 0) { this.windTimer = 0.9; g.sfx?.playWind?.(player.glideSpeed ?? 7); }
    }
    if (this.chip) {
      this.chip.classList.toggle('hidden', !player.gliding);
      if (player.gliding) {
        const ground = g.world.getSurfaceHeight(Math.round(eye.x), Math.round(eye.z));
        const height = Math.max(0, eye.y - (Number.isFinite(ground) ? ground + 0.5 : eye.y) - (player.eyeHeight ?? 1.6));
        this.chip.textContent = `🪂 ${Math.round(height)} m · ${formatVario(player.verticalVelocity)}${player.glideLift > 0.4 ? ' · ascendance !' : ''}`;
      }
    }
  }
}

export { THERMAL_RULES };
