// BlockWorld V3.0 Beta 4.29 — parapente : règles pures (testables sous Node).
// Les ascendances thermiques naissent au-dessus des sommets ensoleillés : colonnes de 7 m de rayon qui portent
// jusqu'à 45 m au-dessus du relief, d'autant plus fort que le soleil est haut. Pas d'ascendance la nuit.

export const THERMAL_RULES = { step: 6, minRelief: 14, radius: 7, strength: 3.4, ceiling: 45, max: 10, spacing: 24, border: 22 };

/**
 * Repère les sommets (maximum local sur une grille de 6 m, au moins 14 m au-dessus du point le plus bas de la carte).
 * `heightAt(x, z)` renvoie l'altitude du sol ; `size` la largeur de la carte (centrée sur 0).
 */
export function findThermals(heightAt, size, rules = THERMAL_RULES) {
  // Pas d'ascendance sur le massif de bordure (inatteignable) : on reste à 22 m du bord de la carte.
  const half = Math.floor(size / 2) - Math.max(rules.step, rules.border ?? 0);
  const samples = [];
  let lowest = Infinity;
  for (let x = -half; x <= half; x += rules.step) {
    for (let z = -half; z <= half; z += rules.step) {
      const h = heightAt(x, z);
      if (!Number.isFinite(h)) continue;
      samples.push({ x, z, h });
      lowest = Math.min(lowest, h);
    }
  }
  const byKey = new Map(samples.map((s) => [`${s.x}|${s.z}`, s.h]));
  const peaks = samples.filter((s) => {
    if (s.h - lowest < rules.minRelief) return false;
    for (const dx of [-rules.step, 0, rules.step]) for (const dz of [-rules.step, 0, rules.step]) {
      if (!dx && !dz) continue;
      const n = byKey.get(`${s.x + dx}|${s.z + dz}`);
      if (Number.isFinite(n) && n > s.h) return false;
    }
    return true;
  }).sort((a, b) => b.h - a.h);
  const chosen = [];
  for (const peak of peaks) {
    if (chosen.length >= rules.max) break;
    if (chosen.some((c) => Math.hypot(c.x - peak.x, c.z - peak.z) < rules.spacing)) continue;
    chosen.push({ x: peak.x, z: peak.z, ground: peak.h, radius: rules.radius, top: peak.h + rules.ceiling });
  }
  return chosen;
}

/** Portance (m/s) au point donné : maximale au centre de la colonne, nulle au bord, au-dessus du plafond et la nuit. */
export function thermalLift(position, thermals, daylight = 1, rules = THERMAL_RULES) {
  if (daylight < 0.3) return 0;
  let lift = 0;
  for (const t of thermals) {
    const d = Math.hypot(position.x - t.x, position.z - t.z);
    if (d > t.radius || position.y > t.top) continue;
    const core = 1 - (d / t.radius) ** 2;
    const fade = Math.min(1, (t.top - position.y) / 8);
    lift = Math.max(lift, rules.strength * core * fade * Math.min(1, (daylight - 0.3) / 0.4));
  }
  return lift;
}

/** Variomètre lisible : « +2,1 m/s » ou « −1,4 m/s ». */
export function formatVario(verticalSpeed) {
  const v = Math.round(verticalSpeed * 10) / 10;
  return `${v >= 0 ? '+' : '−'}${Math.abs(v).toFixed(1).replace('.', ',')} m/s`;
}
