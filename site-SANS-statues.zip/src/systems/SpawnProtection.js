import * as THREE from 'three';

export class SpawnProtection {
  constructor(scene, player, monsters, hud) {
    this.scene = scene;
    this.player = player;
    this.monsters = monsters;
    this.hud = hud;
    this.remaining = 0;
    this.radius = 5.25;
    this.active = false;

    const geometry = new THREE.SphereGeometry(this.radius, 28, 18);
    const material = new THREE.MeshBasicMaterial({
      color: 0x69dcff,
      transparent: true,
      opacity: 0.18,
      side: THREE.DoubleSide,
      depthWrite: false
    });
    this.bubble = new THREE.Mesh(geometry, material);
    this.bubble.name = 'SpawnProtectionBubble';
    this.bubble.visible = false;
    this.scene.add(this.bubble);

    const ringMaterial = new THREE.MeshBasicMaterial({ color: 0xbff6ff, transparent: true, opacity: 0.72 });
    this.ring = new THREE.Mesh(new THREE.TorusGeometry(this.radius, 0.045, 8, 80), ringMaterial);
    this.ring.rotation.x = Math.PI / 2;
    this.bubble.add(this.ring);
  }

  start(seconds = 7) {
    if (seconds <= 0) {
      this.stop();
      return;
    }
    this.remaining = seconds;
    this.active = true;
    this.bubble.visible = true;
    this.player.setInvulnerable(true);
    this.monsters.setHighlighted(true);
    this.hud.setStatus(`Bulle de protection active pendant ${seconds} secondes`);
  }

  stop() {
    this.remaining = 0;
    this.active = false;
    this.bubble.visible = false;
    this.player.setInvulnerable(false);
    this.monsters.setHighlighted(false);
    this.hud.updateProtection(0, false);
    this.hud.updateRadar([]);
  }

  update(delta) {
    if (!this.active) return;
    this.remaining = Math.max(0, this.remaining - delta);
    const eye = this.player.getEyePosition();
    this.bubble.position.set(eye.x, eye.y - 0.9, eye.z);
    this.bubble.rotation.y += delta * 0.22;
    this.bubble.material.opacity = 0.14 + Math.sin(performance.now() * 0.004) * 0.035;

    this.monsters.keepOutsideBubble(this.bubble.position, this.radius);
    this.hud.updateProtection(this.remaining, true);
    this.hud.updateRadar(this.monsters.getRadarEntries(eye, 6));

    if (this.remaining <= 0) {
      this.stop();
      this.hud.setStatus('La bulle de protection est désactivée');
    }
  }
}
