// BlockWorld V3.0 Beta 4.29 — inventaire illustré : chaque bloc est rendu en 3D (cube en vue isométrique, avec les
// matériaux et textures du monde) une seule fois au démarrage, comme les portraits de personnages.
import * as THREE from 'three';

export function renderBlockIcons(materials, size = 64) {
  const icons = {};
  let renderer = null;
  try {
    const canvas = document.createElement('canvas');
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setSize(size, size, false);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const scene = new THREE.Scene();
    scene.add(new THREE.HemisphereLight(0xffffff, 0x6b6050, 2.2));
    const key = new THREE.DirectionalLight(0xffffff, 2.4); key.position.set(-2, 3, 2.5); scene.add(key);
    const camera = new THREE.OrthographicCamera(-0.95, 0.95, 0.95, -0.95, 0.1, 10);
    camera.position.set(-2, 1.65, 2); camera.lookAt(0, 0, 0);
    const geometry = new THREE.BoxGeometry(1, 1, 1);
    const cube = new THREE.Mesh(geometry);
    scene.add(cube);
    for (const [type, material] of Object.entries(materials ?? {})) {
      if (!material || material.visible === false) continue;
      cube.material = material;
      renderer.render(scene, camera);
      icons[type] = canvas.toDataURL('image/png');
    }
    geometry.dispose();
  } catch (error) {
    console.warn('[inventaire] icônes 3D indisponibles', error?.message);
  } finally {
    renderer?.dispose();
    renderer?.forceContextLoss?.();
  }
  return icons;
}
