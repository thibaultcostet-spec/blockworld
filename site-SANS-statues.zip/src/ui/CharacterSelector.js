import * as THREE from 'three';
import { CHARACTER_ROSTER, buildCharacter } from '../characters/CharacterFactory.js';

// BlockWorld V3.0 Beta 4.20 — choix du personnage sur l'écran de démarrage.
// Portraits rendus une fois par le moteur 3D (petit rendu hors écran → image data:, autorisée par la CSP).

export const CHARACTER_STORAGE_KEY = 'blockworld-character';

export function readCharacterChoice() {
  try {
    const value = Number(globalThis.localStorage?.getItem(CHARACTER_STORAGE_KEY));
    return Number.isInteger(value) && value >= 0 && value < CHARACTER_ROSTER.length ? value : 0;
  } catch (_error) { return 0; }
}

function renderPortraits(width = 132, height = 168) {
  const portraits = [];
  let renderer = null;
  try {
    const canvas = document.createElement('canvas');
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setSize(width, height, false);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    const camera = new THREE.PerspectiveCamera(24, width / height, 0.1, 20);
    for (const spec of CHARACTER_ROSTER) {
      const scene = new THREE.Scene();
      scene.add(new THREE.HemisphereLight(0xdfeaff, 0x5a4a3a, 1.6));
      const key = new THREE.DirectionalLight(0xfff1dd, 2.6); key.position.set(-1.2, 2.4, -2.2); scene.add(key);
      const rim = new THREE.DirectionalLight(0x9fc8ff, 1.2); rim.position.set(1.6, 1.8, 2); scene.add(rim);
      const model = buildCharacter(spec);
      scene.add(model);
      const headY = model.userData.headObject.getWorldPosition(new THREE.Vector3()).y;
      camera.position.set(0.35, headY - 0.12, -2.1);
      camera.lookAt(0, headY - 0.28, 0);
      renderer.render(scene, camera);
      portraits.push(canvas.toDataURL('image/png'));
      model.traverse((object) => { if (object.isMesh) { object.geometry.dispose(); object.material.map?.dispose?.(); object.material.dispose(); } });
    }
  } catch (error) {
    console.warn('[personnages] portraits indisponibles', error?.message);
  } finally {
    renderer?.dispose();
    renderer?.forceContextLoss?.();
  }
  return portraits;
}

function renderHDPortraits({ roster, library }, width = 132, height = 168) {
  const portraits = [];
  let renderer = null;
  try {
    const canvas = document.createElement('canvas');
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true });
    renderer.setSize(width, height, false);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    const camera = new THREE.PerspectiveCamera(24, width / height, 0.1, 20);
    roster.forEach((spec, index) => {
      const scene = new THREE.Scene();
      scene.add(new THREE.HemisphereLight(0xdfeaff, 0x5a4a3a, 1.5));
      const key = new THREE.DirectionalLight(0xfff1dd, 2.4); key.position.set(-1.2, 2.4, -2.2); scene.add(key);
      const model = library.instantiate(index);
      scene.add(model);
      model.userData.hdController.update(0.5, 0);
      model.updateMatrixWorld(true);
      let headY = 1.6;
      model.traverse((object) => { if (object.name === 'Bip01 Head') headY = object.getWorldPosition(new THREE.Vector3()).y; });
      camera.position.set(0.35, headY - 0.1, -2.1);
      camera.lookAt(0, headY - 0.26, 0);
      renderer.render(scene, camera);
      portraits.push(canvas.toDataURL('image/png'));
    });
  } catch (error) { console.warn('[personnages HD] portraits', error?.message); }
  finally { renderer?.dispose(); renderer?.forceContextLoss?.(); }
  return portraits;
}

export class CharacterSelector {
  constructor(container, { onSelect = () => {}, initial = readCharacterChoice() } = {}) {
    this.container = container;
    this.onSelect = onSelect;
    this.index = initial;
    this.locked = false;
    if (!container) return;
    this.render([]);
    // Portraits rendus après l'affichage de l'écran d'accueil, pour ne pas retarder le démarrage.
    setTimeout(() => { this.portraits = renderPortraits(); this.render(this.portraits); }, 60);
  }

  // Beta 4.24 : en Élevée / Ultra, les cartes présentent les personnages HD (même numérotation 0–7).
  setRoster(hd) {
    this.hd = hd;
    if (!this.container) return;
    if (!hd) { this.render(this.portraits ?? []); return; }
    this.hdPortraits ??= renderHDPortraits(hd);
    this.render(this.hdPortraits);
  }

  render(portraits) {
    const roster = this.hd?.roster ?? CHARACTER_ROSTER;
    this.container.replaceChildren();
    roster.forEach((spec, index) => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = `character-card${index === this.index ? ' selected' : ''}`;
      card.dataset.characterIndex = String(index);
      card.title = `${spec.name} — ${spec.profession}`;
      if (portraits[index]) {
        const image = document.createElement('img');
        image.src = portraits[index];
        image.alt = spec.name;
        card.append(image);
      } else {
        const placeholder = document.createElement('span');
        placeholder.className = 'character-placeholder';
        placeholder.textContent = spec.sex === 'f' ? '♀' : '♂';
        card.append(placeholder);
      }
      const name = document.createElement('strong');
      name.textContent = spec.name;
      const job = document.createElement('small');
      job.textContent = spec.profession;
      card.append(name, job);
      card.addEventListener('click', () => this.select(index));
      this.container.append(card);
    });
  }

  select(index) {
    if (this.locked) return;
    this.index = index;
    try { globalThis.localStorage?.setItem(CHARACTER_STORAGE_KEY, String(index)); } catch (_error) { /* stockage indisponible */ }
    // Cartes reconstruites : le surlignage suit toujours le choix courant.
    if (this.container) this.render(this.hd ? (this.hdPortraits ?? []) : (this.portraits ?? []));
    this.onSelect(index, (this.hd?.roster ?? CHARACTER_ROSTER)[index]);
  }
}
