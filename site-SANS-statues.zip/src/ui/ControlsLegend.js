import { GAMEPAD_BINDINGS } from '../core/GamepadInput.js';

// BlockWorld V3.0 Beta 4.22 — légende des commandes (touche L, bouton Select de la manette, bouton « Commandes »).

export const KEYBOARD_BINDINGS = [
  ['Z Q S D / flèches', 'Se déplacer'], ['Espace', 'Sauter'], ['Clic droit glissé', 'Regarder autour'],
  ['Clic gauche', 'Tirer · frapper · casser un bloc'], ['Clic droit bref', 'Poser un bloc · utiliser'],
  ['Molette · E / R', 'Objet suivant / précédent'], ['1 à 9', 'Choisir un objet'], ['F', 'Viser (lunette)'],
  ['Bord d’un bloc', 'Clic droit sur le bord, face au vide : pose sur le côté (passerelle)'], ['T', 'Recharger'], ['G', 'Manger (cuit d’abord)'], ['C', 'Mode photo · carnet de voyage'], ['X', 'Compagnon : assis / au pied'], ['Espace en l’air avec 🪂', 'Ouvrir / refermer le parapente'], ['K (ou toucher la mini-carte)', 'Grande carte en relief'], ['Clic droit sur un chien', 'Le nourrir (l’apprivoiser)'], ['Clic droit avec 🎣', 'Lancer la ligne · ferrer'], ['Clic droit avec 🔥', 'Poser un feu de camp (cuisson)'], ['Q (près d’un habitant)', 'Parler'], ['I / Tab', 'Inventaire'],
  ['J', 'Passeport des monuments'], ['B', 'Analyse de stabilité'], ['O', 'Défis d’ingénieur : ponts et convoi'], ['V', 'Changer de vue'],
  ['H', 'Lancer un événement climatique'], ['M / N', 'Musique / effets sonores'], ['P', 'Plein écran'],
  ['L', 'Cette légende'], ['Échap', 'Pause']
];

export class ControlsLegend {
  constructor() {
    this.panel = document.getElementById('controls-legend');
    if (!this.panel) return;
    const columns = [
      ['⌨️ Clavier et souris', KEYBOARD_BINDINGS],
      ['🎮 Manette', [['Stick gauche', 'Se déplacer'], ['Stick droit', 'Regarder autour'], ...GAMEPAD_BINDINGS.map((b) => [b.label, b.description])]]
    ];
    const grid = this.panel.querySelector('.legend-grid');
    for (const [title, rows] of columns) {
      const section = document.createElement('section');
      const heading = document.createElement('h3');
      heading.textContent = title;
      const list = document.createElement('dl');
      for (const [key, action] of rows) {
        const dt = document.createElement('dt'); dt.textContent = key;
        const dd = document.createElement('dd'); dd.textContent = action;
        list.append(dt, dd);
      }
      section.append(heading, list);
      grid.append(section);
    }
    this.panel.querySelector('.legend-close')?.addEventListener('click', () => this.toggle(false));
    for (const button of document.querySelectorAll('[data-open-legend]')) button.addEventListener('click', () => this.toggle(true));
  }

  toggle(force = null) {
    if (!this.panel) return;
    const open = force ?? this.panel.classList.contains('hidden');
    this.panel.classList.toggle('hidden', !open);
  }
}
