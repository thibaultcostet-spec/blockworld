import {
  DEFAULT_QUICKBAR,
  ITEM_CATALOG,
  ITEM_CATEGORIES,
  getItem
} from '../items/ItemCatalog.js';
import { STATUS_FADE_SECONDS, adaptStatusForTouch, filterRadarEntries } from './HudContext.js';

const QUICKBAR_PREFIX = 'blockworld-v0.7-quickbar';

export class Hud {
  constructor(elements) {
    Object.assign(this, elements);
    this.selectedIndex = 0;
    this.onSelect = null;
    this.activeCategory = ITEM_CATEGORIES[0].id;
    this.modeId = 'creative';
    this.allowedItemIds = null;
    this.quickbarIds = [...DEFAULT_QUICKBAR];
  }

  quickbarKey() {
    return `${QUICKBAR_PREFIX}-${this.modeId}`;
  }

  loadQuickbar(template = DEFAULT_QUICKBAR) {
    try {
      const saved = JSON.parse(localStorage.getItem(this.quickbarKey()) ?? 'null');
      if (Array.isArray(saved) && saved.length === 9) {
        return saved.map((id, index) => getItem(id)?.id ?? template[index] ?? DEFAULT_QUICKBAR[index]);
      }
    } catch (error) {
      console.warn('Barre rapide illisible :', error);
    }
    return [...template];
  }

  setModeInventory(modeId, allowedItemIds = null, template = null) {
    this.modeId = modeId;
    this.allowedItemIds = allowedItemIds ? new Set(allowedItemIds) : null;
    const fallbackTemplate = template?.length === 9 ? template : DEFAULT_QUICKBAR;
    this.quickbarIds = this.loadQuickbar(fallbackTemplate);
    this.ensureQuickbarAvailability(fallbackTemplate);
    this.selectedIndex = Math.min(this.selectedIndex, 8);
    this.renderHotbar();
    this.renderCatalog();
    this.onSelect?.(this.getSelectedItem());
  }

  setItemAvailability(allowedItemIds) {
    this.allowedItemIds = allowedItemIds ? new Set(allowedItemIds) : null;
    this.ensureQuickbarAvailability(DEFAULT_QUICKBAR);
    this.renderHotbar();
    this.renderCatalog();
    this.onSelect?.(this.getSelectedItem());
  }

  ensureQuickbarAvailability(template) {
    if (!this.allowedItemIds) return;
    const firstAllowed = ITEM_CATALOG.find((item) => this.allowedItemIds.has(item.id))?.id ?? 'block-grass';
    this.quickbarIds = this.quickbarIds.map((id, index) => {
      if (this.allowedItemIds.has(id)) return id;
      const preferred = template[index];
      return this.allowedItemIds.has(preferred) ? preferred : firstAllowed;
    });
    this.saveQuickbar();
  }

  isItemAllowed(item) {
    return !this.allowedItemIds || this.allowedItemIds.has(item.id);
  }

  saveQuickbar() {
    localStorage.setItem(this.quickbarKey(), JSON.stringify(this.quickbarIds));
  }

  init(onSelect) {
    this.onSelect = onSelect;
    this.renderHotbar();
    this.renderCategories();
    this.renderCatalog();
    this.updateHealth(100, 100);

    this.inventorySearch?.addEventListener('input', () => this.renderCatalog());

    window.addEventListener('keydown', (event) => {
      const index = Number(event.key) - 1;
      if (Number.isInteger(index) && index >= 0 && index < 9) this.select(index);
      if (!document.body.classList.contains('playing')) return;
      if (event.code === 'BracketRight' || event.code === 'KeyE') this.selectNext(1);
      if (event.code === 'BracketLeft' || event.code === 'KeyR') this.selectNext(-1);
    });

    window.addEventListener('wheel', (event) => {
      if (!document.body.classList.contains('playing') || Math.abs(event.deltaY) < 1) return;
      event.preventDefault();
      this.selectNext(event.deltaY > 0 ? 1 : -1);
    }, { passive: false });

    this.onSelect?.(this.getSelectedItem());
  }

  getSelectedItem() {
    return getItem(this.quickbarIds[this.selectedIndex]);
  }

  // Beta 4.29 : icônes 3D des blocs (rendues une fois par BlockIcons.js).
  setBlockIcons(icons) {
    this.blockIcons = icons ?? {};
    this.renderHotbar();
    if (this.inventoryScreen && !this.inventoryScreen.classList.contains('hidden')) { this.renderCatalog(); this.renderInventoryQuickbar(); }
  }

  makeVisual(item, className = 'slot-visual') {
    const visual = document.createElement('div');
    visual.className = className;
    const icon = item.kind === 'block' ? this.blockIcons?.[item.type] : null;
    if (icon) {
      visual.classList.add('block-icon');
      visual.style.backgroundImage = `url(${icon})`;
    } else if (item.kind === 'block') {
      visual.classList.add('slot-swatch');
      visual.style.background = `#${Number(item.color ?? 0x888888).toString(16).padStart(6, '0')}`;
      visual.textContent = item.icon ?? '';
      if (['crystal', 'lantern'].includes(item.type)) visual.classList.add('glowing');
    } else {
      visual.classList.add('tool-icon');
      visual.textContent = item.icon ?? '•';
    }
    return visual;
  }

  renderHotbar() {
    if (!this.hotbarElement) return;
    this.hotbarElement.replaceChildren();
    this.quickbarIds.forEach((id, index) => {
      const item = getItem(id);
      const slot = document.createElement('button');
      slot.type = 'button';
      slot.className = `slot${index === this.selectedIndex ? ' selected' : ''}`;
      slot.tabIndex = -1;
      slot.title = `${index + 1} · ${item.label} — ${item.description}`;
      const label = document.createElement('div');
      label.className = 'slot-label';
      label.textContent = `${index + 1} ${item.label}`;
      slot.append(this.makeVisual(item), label);
      slot.addEventListener('click', () => this.select(index));
      this.hotbarElement.append(slot);
    });
  }

  renderCategories() {
    if (!this.inventoryCategories) return;
    this.inventoryCategories.replaceChildren();
    for (const category of ITEM_CATEGORIES) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `category-button${category.id === this.activeCategory ? ' active' : ''}`;
      button.textContent = `${category.icon} ${category.label}`;
      button.addEventListener('click', () => {
        this.activeCategory = category.id;
        this.renderCategories();
        this.renderCatalog();
      });
      this.inventoryCategories.append(button);
    }
  }

  renderCatalog() {
    if (!this.inventoryGrid) return;
    const query = (this.inventorySearch?.value ?? '').trim().toLocaleLowerCase('fr');
    const items = ITEM_CATALOG.filter((item) => {
      const categoryMatch = item.category === this.activeCategory;
      const queryMatch = !query || `${item.label} ${item.description}`.toLocaleLowerCase('fr').includes(query);
      return categoryMatch && queryMatch;
    });
    this.inventoryGrid.replaceChildren();

    if (!items.length) {
      const empty = document.createElement('p');
      empty.className = 'inventory-empty';
      empty.textContent = 'Aucun élément dans cette catégorie pour cette recherche.';
      this.inventoryGrid.append(empty);
      return;
    }

    for (const item of items) {
      const allowed = this.isItemAllowed(item);
      const card = document.createElement('button');
      card.type = 'button';
      card.disabled = !allowed;
      card.className = `inventory-card${allowed ? '' : ' locked'}`;
      card.title = allowed ? item.description : 'Objet verrouillé : accomplis les missions précédentes.';

      const text = document.createElement('span');
      text.className = 'inventory-card-text';
      const label = document.createElement('strong');
      label.textContent = `${allowed ? '' : '🔒 '}${item.label}`;
      const description = document.createElement('small');
      description.textContent = allowed ? item.description : 'À débloquer dans le mode Missions.';
      text.append(label, description);
      card.append(this.makeVisual(item, 'inventory-icon'), text);
      if (allowed) {
        card.addEventListener('click', () => { this.assignToActiveSlot(item); this.renderInventoryQuickbar(); });
        // Beta 4.29 : glisser une carte sur un emplacement de la barre rapide de l'inventaire.
        card.draggable = true;
        card.addEventListener('dragstart', (event) => { event.dataTransfer?.setData('text/plain', item.id); card.classList.add('dragging'); });
        card.addEventListener('dragend', () => card.classList.remove('dragging'));
      }
      this.inventoryGrid.append(card);
    }
  }

  assignToActiveSlot(item) {
    if (!this.isItemAllowed(item)) return;
    this.quickbarIds[this.selectedIndex] = item.id;
    this.saveQuickbar();
    this.renderHotbar();
    this.onSelect?.(item);
    this.setStatus(`${item.label} ajouté à l’emplacement ${this.selectedIndex + 1}`);
    if (this.inventorySelection) {
      this.inventorySelection.textContent = `Emplacement ${this.selectedIndex + 1} : ${item.icon} ${item.label}`;
    }
  }

  // Beta 4.22 : jauge de faim (viande en réserve) ; masquée hors Survie / Missions.
  updateHunger(hunger, active = true) {
    const element = document.getElementById('hunger');
    if (!element || !hunger) return;
    element.classList.toggle('hidden', !active);
    const percent = Math.round(hunger.ratio * 100);
    element.textContent = hunger.cooked > 0 ? `🍗 ${percent} % · ${hunger.cooked} 🍢 ${hunger.food} 🍖` : `🍗 ${percent} % · ${hunger.food} 🍖`; // Beta 4.27 : 🍢 cuit, 🍖 cru
    element.dataset.state = percent <= 15 ? 'danger' : percent <= 40 ? 'warning' : 'safe';
    element.title = 'Faim · touche G (ou toucher ici) pour manger · 🍢 cuit (+55) avant 🍖 cru (+30)';
  }

  select(index) {
    this.selectedIndex = (index + this.quickbarIds.length) % this.quickbarIds.length;
    this.renderHotbar();
    const item = this.getSelectedItem();
    this.onSelect?.(item);
    if (this.inventorySelection) {
      this.inventorySelection.textContent = `Emplacement ${this.selectedIndex + 1} : ${item.icon} ${item.label}`;
    }
  }

  selectNext(direction) {
    this.select(this.selectedIndex + direction);
  }

  // Beta 4.29 : barre rapide reproduite dans l'inventaire (clic = emplacement actif, dépôt = y ranger l'objet).
  renderInventoryQuickbar() {
    const bar = document.getElementById('inventory-quickbar');
    if (!bar) return;
    bar.replaceChildren();
    this.quickbarIds.forEach((id, index) => {
      const item = getItem(id);
      const slot = document.createElement('button');
      slot.type = 'button';
      slot.className = `slot${index === this.selectedIndex ? ' selected' : ''}`;
      slot.title = `${index + 1} · ${item.label}`;
      const label = document.createElement('div');
      label.className = 'slot-label';
      label.textContent = `${index + 1}`;
      slot.append(this.makeVisual(item), label);
      slot.addEventListener('click', () => { this.select(index); this.renderInventoryQuickbar(); });
      slot.addEventListener('dragover', (event) => { event.preventDefault(); slot.classList.add('drop-target'); });
      slot.addEventListener('dragleave', () => slot.classList.remove('drop-target'));
      slot.addEventListener('drop', (event) => {
        event.preventDefault();
        const dropped = getItem(event.dataTransfer?.getData('text/plain'));
        if (!dropped || !this.isItemAllowed(dropped)) return;
        this.selectedIndex = index;
        this.assignToActiveSlot(dropped);
        this.renderInventoryQuickbar();
      });
      bar.append(slot);
    });
  }

  setInventoryVisible(visible) {
    this.inventoryScreen?.classList.toggle('hidden', !visible);
    this.inventoryScreen?.setAttribute('aria-hidden', visible ? 'false' : 'true');
    if (visible) {
      this.renderInventoryQuickbar();
      const item = this.getSelectedItem();
      if (this.inventorySelection) this.inventorySelection.textContent = `Emplacement ${this.selectedIndex + 1} : ${item.icon} ${item.label}`;
      this.renderCategories();
      this.renderCatalog();
      window.setTimeout(() => this.inventorySearch?.focus(), 20);
    }
  }

  updateHealth(current, maximum) {
    if (!this.healthElement) return;
    this.healthElement.textContent = `PV ${Math.round(current)} / ${maximum}`;
    const ratio = maximum > 0 ? current / maximum : 0;
    this.healthElement.dataset.state = ratio <= 0.25 ? 'danger' : ratio <= 0.55 ? 'warning' : 'safe';
  }

  updateLoot(crystals) {
    if (this.lootElement) this.lootElement.textContent = `◆ ${crystals}`;
  }

  setMode(label, icon) {
    if (this.modeElement) this.modeElement.textContent = `${icon} ${label}`;
  }

  setModeTimer(text) {
    if (this.modeTimerElement) this.modeTimerElement.textContent = text;
  }

  setObjective(text) {
    if (this.objectiveElement) this.objectiveElement.textContent = text;
  }

  updateProtection(seconds, active) {
    if (!this.protectionElement) return;
    this.protectionElement.classList.toggle('hidden', !active);
    this.protectionElement.textContent = active ? `🫧 Protection ${Math.max(0, Math.ceil(seconds))} s` : '';
  }

  updateRadar(allEntries) {
    if (!this.radarElement) return;
    // Beta 4.26 : seulement les monstres à moins de 20 m (le radar listait 6 monstres à 30–60 m).
    const entries = filterRadarEntries(allEntries);
    this.radarElement.classList.toggle('hidden', entries.length === 0);
    this.radarElement.replaceChildren();
    if (!entries.length) return;
    const title = document.createElement('strong');
    title.textContent = 'Monstres proches';
    this.radarElement.append(title);
    for (const entry of entries) {
      const line = document.createElement('span');
      line.textContent = `${entry.direction} · ${entry.label} · ${entry.distance.toFixed(1)} m`;
      this.radarElement.append(line);
    }
  }

  // Beta 4.26 : une seule ligne de message, effacée après 4 s ; aides souris/clavier retirées sur tactile.
  setStatus(text) {
    if (!this.statusElement) return;
    this.statusElement.textContent = this.touchMode ? adaptStatusForTouch(text) : String(text ?? '');
    this.statusElement.classList.remove('status-faded');
    if (this.statusTimer) clearTimeout(this.statusTimer);
    this.statusTimer = setTimeout(() => this.statusElement?.classList.add('status-faded'), STATUS_FADE_SECONDS * 1000);
  }
}
