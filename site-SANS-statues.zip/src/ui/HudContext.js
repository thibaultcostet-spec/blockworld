// BlockWorld V3.0 Beta 4.26 — HUD contextuel : un panneau ne s'affiche que lorsqu'il sert.
// Fonctions pures testables sous Node (aucune dépendance à Three.js ni au DOM au chargement).

export const STATUS_FADE_SECONDS = 4;        // ligne de message : effacée après 4 s
export const RADAR_RANGE = 20;               // radar : seulement les monstres à moins de 20 m
export const STABILITY_PULSE_SECONDS = 8;    // panneau Stabilité : 8 s après une pose ou une casse

// Aides propres à la souris ou au clavier, inutiles (et trompeuses) sur un écran tactile.
const DESKTOP_HINT = /(clic (droit|gauche)|molette|échap|\b[A-Z] ?: |touche [A-Z0-9]\b|\(([A-Z]|[A-Z]\/[A-Z])\)|\bF, )/i;

/** Retire d'un message les segments « · clic droit glissé : regarder · Échap : pause » sur tactile. */
export function adaptStatusForTouch(text) {
  const source = String(text ?? '')
    .replace(/F, clic droit ou 🔭/g, '🔭')
    .replace(/clic droit ou ▣/g, '▣')
    .replace(/mange \(G\)/g, 'touche la jauge 🍗');
  const parts = source.split(' · ');
  if (parts.length === 1) return source.replace(/\s*\((touche )?[A-Z]\)\s*$/, '');
  const kept = parts.filter((part, index) => index === 0 || !DESKTOP_HINT.test(part));
  return kept.join(' · ');
}

/** Radar : monstres vivants à portée, du plus proche au plus lointain. */
export function filterRadarEntries(entries, range = RADAR_RANGE) {
  return (entries ?? []).filter((entry) => Number.isFinite(entry?.distance) && entry.distance < range);
}

/** Visibilité du panneau Stabilité : inspection active, ou quelques secondes après un changement de bloc. */
export function stabilityPanelVisible({ inspecting = false, pulseRemaining = 0 } = {}) {
  return Boolean(inspecting) || pulseRemaining > 0;
}

export class HudContext {
  constructor({ stabilityPanel = null } = {}) {
    this.stabilityPanel = stabilityPanel;
    this.pulseRemaining = 0;
    this.inspecting = false;
    this.apply();
  }

  /** Appelé après chaque pose / casse confirmée (solo ou serveur). */
  pulseStability(seconds = STABILITY_PULSE_SECONDS) {
    this.pulseRemaining = Math.max(this.pulseRemaining, seconds);
    this.apply();
  }

  setInspecting(value) {
    this.inspecting = Boolean(value);
    this.apply();
  }

  update(delta) {
    if (this.pulseRemaining <= 0) return;
    this.pulseRemaining = Math.max(0, this.pulseRemaining - delta);
    if (this.pulseRemaining === 0) this.apply();
  }

  apply() {
    const visible = stabilityPanelVisible({ inspecting: this.inspecting, pulseRemaining: this.pulseRemaining });
    this.stabilityPanel?.classList?.toggle('context-hidden', !visible);
  }
}
