// BlockWorld V3.0 Beta 4.26 — menu Pause dédié : une fois la partie lancée, Échap (ou Ⅱ / Start)
// n'affiche plus tout l'écran d'accueil mais un menu court.

export const PAUSE_ACTIONS = ['resume', 'settings', 'controls', 'home']; // Sauvegarder et Nouveau monde gardent leurs identifiants historiques

export class PauseMenu {
  constructor(root, handlers = {}) {
    this.root = root;
    this.handlers = handlers;
    this.summary = root?.querySelector('#pause-summary') ?? null;
    for (const button of root?.querySelectorAll('[data-pause-action]') ?? []) {
      button.addEventListener('click', () => this.handlers[button.dataset.pauseAction]?.());
    }
  }

  isOpen() {
    return Boolean(this.root && !this.root.classList.contains('hidden'));
  }

  show(summary = '') {
    if (!this.root) return;
    this.setSummary(summary);
    this.root.classList.remove('hidden');
    this.root.setAttribute('aria-hidden', 'false');
    document.body.classList.add('pause-open');
    window.setTimeout(() => this.root.querySelector('[data-pause-action="resume"]')?.focus(), 20);
  }

  hide() {
    if (!this.root) return;
    this.root.classList.add('hidden');
    this.root.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('pause-open');
  }

  setSummary(text) {
    if (this.summary) this.summary.textContent = text;
  }
}
