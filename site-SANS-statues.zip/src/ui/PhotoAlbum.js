// BlockWorld V3.0 Beta 4.27 — carnet de voyage : album de photos local au navigateur (jamais envoyé au serveur).
// Stockage borné : 16 photos JPEG de 400 px de large (≈ 25 Ko chacune) ; la plus ancienne part quand c'est plein.

export const PHOTO_ALBUM_KEY = 'blockworld-v4.27-album';
export const PHOTO_ALBUM_MAX = 16;
export const PHOTO_WIDTH = 400;

export function readAlbum(storage = globalThis.localStorage) {
  try {
    const parsed = JSON.parse(storage?.getItem(PHOTO_ALBUM_KEY) ?? '[]');
    return Array.isArray(parsed) ? parsed.filter((p) => p && typeof p.src === 'string' && p.src.startsWith('data:image/')) : [];
  } catch (_error) { return []; }
}

/** Ajoute une photo en tête ; enlève les plus anciennes si l'album est plein ou si le stockage refuse. */
export function addPhoto(entry, storage = globalThis.localStorage, max = PHOTO_ALBUM_MAX) {
  let album = [entry, ...readAlbum(storage)].slice(0, max);
  while (album.length) {
    try { storage?.setItem(PHOTO_ALBUM_KEY, JSON.stringify(album)); return album; }
    catch (_error) { album = album.slice(0, -1); if (album.length === 0) break; }
  }
  return album;
}

export function removePhoto(id, storage = globalThis.localStorage) {
  const album = readAlbum(storage).filter((photo) => photo.id !== id);
  try { storage?.setItem(PHOTO_ALBUM_KEY, JSON.stringify(album)); } catch (_error) {}
  return album;
}

/** Légende lisible : « Europe · près de Tour Eiffel · 19/10/2026 14:05 ». */
export function photoCaption({ worldLabel = '', landmark = '', takenAt = Date.now() } = {}) {
  const date = new Date(takenAt);
  const pad = (n) => String(n).padStart(2, '0');
  const when = `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  return [worldLabel, landmark ? `près de ${landmark}` : '', when].filter(Boolean).join(' · ');
}
