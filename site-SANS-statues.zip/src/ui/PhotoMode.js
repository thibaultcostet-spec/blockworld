// BlockWorld V3.0 Beta 4.27 — mode photo et carnet de voyage.
// Touche C (ou 📷) : l'interface s'efface, un cadre apparaît ; clic, Entrée ou 📸 déclenche, C ou Échap ressort.
// Les photos (400 px de large) sont rangées dans le carnet, affiché en tête du passeport (J).
import { PHOTO_WIDTH, addPhoto, photoCaption, readAlbum, removePhoto } from './PhotoAlbum.js';

export class PhotoMode {
  constructor(game, { overlay, albumElement } = {}) {
    this.game = game;
    this.overlay = overlay;
    this.albumElement = albumElement;
    this.active = false;
    this.flash = overlay?.querySelector('.photo-flash') ?? null;
    overlay?.querySelector('[data-photo-action="shoot"]')?.addEventListener('click', (event) => { event.stopPropagation(); this.shoot(); });
    overlay?.querySelector('[data-photo-action="exit"]')?.addEventListener('click', (event) => { event.stopPropagation(); this.toggle(false); });
    this.renderAlbum();
  }

  toggle(force = null) {
    const next = force ?? !this.active;
    if (next && !this.game.player?.isActive?.()) return false;
    this.active = next;
    document.body.classList.toggle('photo-mode', next);
    this.overlay?.classList.toggle('hidden', !next);
    if (next) this.game.hud?.setStatus?.('Mode photo · clic, Entrée ou 📸 pour déclencher · C pour sortir');
    else this.game.weaponView?.setItem?.(this.game.selectedItem, { firstPerson: this.game.player?.viewMode === 'first' });
    return next;
  }

  /** Capture l'image 3D telle qu'affichée (sans interface), réduite à 400 px, puis la range dans le carnet. */
  shoot() {
    const g = this.game;
    if (!this.active) return null;
    let src = '';
    try {
      if (g.renderPipeline) g.renderPipeline.render(0); else g.renderer.render(g.scene, g.camera);
      const source = g.renderer.domElement;
      const ratio = source.height / Math.max(1, source.width);
      const canvas = document.createElement('canvas');
      canvas.width = PHOTO_WIDTH;
      canvas.height = Math.round(PHOTO_WIDTH * ratio);
      canvas.getContext('2d').drawImage(source, 0, 0, canvas.width, canvas.height);
      src = canvas.toDataURL('image/jpeg', 0.74);
    } catch (error) {
      console.warn('[photo]', error?.message);
    }
    if (!src.startsWith('data:image/jpeg') || src.length < 2000) { g.hud?.setStatus?.('Photo impossible sur cet appareil'); return null; }
    const worldLabel = g.currentWorldLabel?.() ?? '';
    const near = g.lastNearestLandmark; // { point, distance } fourni par le passeport
    const landmark = near && near.distance < 70 ? (near.point?.name ?? '') : '';
    const entry = { id: `p${Date.now().toString(36)}`, src, takenAt: Date.now(), caption: photoCaption({ worldLabel, landmark }) };
    const album = addPhoto(entry);
    g.sfx?.playShutter?.();
    if (this.flash) { this.flash.classList.remove('on'); void this.flash.offsetWidth; this.flash.classList.add('on'); }
    g.hud?.setStatus?.(`📸 Photo rangée dans le carnet (${album.length}) · passeport J`);
    this.renderAlbum();
    return entry;
  }

  renderAlbum() {
    const root = this.albumElement;
    if (!root) return;
    const album = readAlbum();
    root.replaceChildren();
    const header = document.createElement('header');
    const title = document.createElement('h3');
    title.textContent = `📷 Carnet de voyage · ${album.length} photo${album.length > 1 ? 's' : ''}`;
    const hint = document.createElement('small');
    hint.textContent = album.length ? 'Les photos restent dans ce navigateur.' : 'En jeu, touche C (ou 📷) pour passer en mode photo.';
    header.append(title, hint);
    root.append(header);
    if (!album.length) return;
    const grid = document.createElement('div');
    grid.className = 'album-grid';
    for (const photo of album) {
      const figure = document.createElement('figure');
      const image = document.createElement('img');
      image.src = photo.src;
      image.alt = photo.caption || 'Photo du carnet';
      image.loading = 'lazy';
      const caption = document.createElement('figcaption');
      caption.textContent = photo.caption || '';
      const actions = document.createElement('div');
      actions.className = 'album-actions';
      const save = document.createElement('a');
      save.href = photo.src;
      save.download = `blockworld-${photo.id}.jpg`;
      save.textContent = '⬇ Enregistrer';
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.textContent = '✕';
      remove.title = 'Retirer du carnet';
      remove.addEventListener('click', () => { removePhoto(photo.id); this.renderAlbum(); });
      actions.append(save, remove);
      figure.append(image, caption, actions);
      grid.append(figure);
    }
    root.append(grid);
  }
}
