// BlockWorld V3.0 Beta 4.29 — accueil en assistant : « Continuer » en un clic, puis 3 étapes (continent,
// personnage, mode). Le multijoueur et les réglages sont repliés dans deux tiroirs.

export const LAST_SESSION_KEY = 'blockworld-v4.29-last-session';
export const WIZARD_STEPS = 3;

/** Libellé du bouton « Continuer » à partir de la dernière session mémorisée. */
export function continueLabel(session, { begun = false } = {}) {
  if (begun) return '▶ Reprendre la partie';
  if (!session?.mode || !session?.world) return '';
  return `▶ Continuer · ${[session.mode, session.world, session.character].filter(Boolean).join(' · ')}`;
}

/** Étape suivante bornée. */
export function clampStep(step) {
  return Math.min(WIZARD_STEPS, Math.max(1, Math.round(Number(step) || 1)));
}

export class StartWizard {
  constructor(root, { onContinue } = {}) {
    this.root = root;
    this.onContinue = onContinue;
    this.step = 1;
    this.panes = [...(root?.querySelectorAll('.wizard-pane') ?? [])];
    this.tabs = [...(root?.querySelectorAll('[data-wizard-step]') ?? [])];
    this.prev = root?.querySelector('#wizard-prev');
    this.next = root?.querySelector('#wizard-next');
    this.continuePanel = root?.querySelector('#continue-panel');
    this.continueButton = root?.querySelector('#continue-button');
    for (const tab of this.tabs) tab.addEventListener('click', () => this.show(Number(tab.dataset.wizardStep)));
    this.prev?.addEventListener('click', () => this.show(this.step - 1));
    this.next?.addEventListener('click', () => this.show(this.step + 1));
    this.continueButton?.addEventListener('click', () => this.onContinue?.());
    this.show(1);
  }

  show(step) {
    this.step = clampStep(step);
    this.panes.forEach((pane) => { pane.hidden = Number(pane.dataset.step) !== this.step; });
    this.tabs.forEach((tab) => {
      const n = Number(tab.dataset.wizardStep);
      tab.classList.toggle('active', n === this.step);
      tab.classList.toggle('done', n < this.step);
    });
    if (this.prev) this.prev.hidden = this.step === 1;
    if (this.next) this.next.hidden = this.step === WIZARD_STEPS;
  }

  readSession() {
    try { return JSON.parse(localStorage.getItem(LAST_SESSION_KEY) ?? 'null'); } catch (_error) { return null; }
  }

  rememberSession(session) {
    try { localStorage.setItem(LAST_SESSION_KEY, JSON.stringify(session)); } catch (_error) {}
  }

  /** Met à jour le bouton « Continuer » (masqué s'il n'y a rien à reprendre). */
  refresh({ begun = false, multiplayer = false } = {}) {
    const label = multiplayer ? '' : continueLabel(this.readSession(), { begun });
    this.continuePanel?.classList.toggle('hidden', !label);
    if (this.continueButton && label) this.continueButton.textContent = label;
    if (begun) this.show(3);
  }

  openSettings() {
    const details = this.root?.querySelector('#more-settings');
    if (details) details.open = true;
    window.setTimeout(() => details?.scrollIntoView({ block: 'start', behavior: 'smooth' }), 30);
  }
}
