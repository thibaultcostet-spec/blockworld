export class TouchControls {
  constructor({
    input, joystick, joystickKnob, lookZone,
    attackButton, placeButton, jumpButton, pauseButton, inventoryButton, cameraButton,
    zoomButton, reloadButton,
    onPrimary, onPrimaryStart, onPrimaryEnd, onSecondary, onPause, onInventory, onCamera, onZoom, onReload
  }) {
    Object.assign(this, {
      input, joystick, joystickKnob, lookZone,
      attackButton, placeButton, jumpButton, pauseButton, inventoryButton, cameraButton,
      zoomButton, reloadButton,
      onPrimary, onPrimaryStart, onPrimaryEnd, onSecondary, onPause, onInventory, onCamera, onZoom, onReload
    });
    this.movePointerId = null;
    this.lookPointerId = null;
    this.lastLook = { x: 0, y: 0 };
  }

  connect() {
    this.joystick.addEventListener('pointerdown', (event) => this.startMove(event));
    this.joystick.addEventListener('pointermove', (event) => this.move(event));
    this.joystick.addEventListener('pointerup', (event) => this.endMove(event));
    this.joystick.addEventListener('pointercancel', (event) => this.endMove(event));
    this.lookZone.addEventListener('pointerdown', (event) => this.startLook(event));
    this.lookZone.addEventListener('pointermove', (event) => this.look(event));
    this.lookZone.addEventListener('pointerup', (event) => this.endLook(event));
    this.lookZone.addEventListener('pointercancel', (event) => this.endLook(event));
    this.bindHoldAction(this.attackButton, this.onPrimary, this.onPrimaryStart, this.onPrimaryEnd);
    this.bindAction(this.placeButton, this.onSecondary);
    this.bindAction(this.jumpButton, () => this.input.pressVirtual('jump'));
    this.bindAction(this.pauseButton, this.onPause);
    this.bindAction(this.inventoryButton, this.onInventory);
    this.bindAction(this.cameraButton, this.onCamera);
    this.bindAction(this.zoomButton, this.onZoom);
    this.bindAction(this.reloadButton, this.onReload);
  }

  bindAction(element, callback) {
    element?.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      event.stopPropagation();
      callback?.();
    });
  }

  bindHoldAction(element, callback, onStart, onEnd) {
    if (!element) return;
    const start = (event) => {
      event.preventDefault();
      event.stopPropagation();
      element.setPointerCapture?.(event.pointerId);
      onStart?.();
      callback?.();
    };
    const end = (event) => {
      event.preventDefault();
      event.stopPropagation();
      onEnd?.();
    };
    element.addEventListener('pointerdown', start);
    element.addEventListener('pointerup', end);
    element.addEventListener('pointercancel', end);
    element.addEventListener('lostpointercapture', () => onEnd?.());
  }

  startMove(event) {
    event.preventDefault();
    this.movePointerId = event.pointerId;
    this.joystick.setPointerCapture(event.pointerId);
    this.updateMoveFromEvent(event);
  }

  move(event) {
    if (event.pointerId !== this.movePointerId) return;
    event.preventDefault();
    this.updateMoveFromEvent(event);
  }

  updateMoveFromEvent(event) {
    const rect = this.joystick.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const radius = Math.max(1, rect.width * 0.36);
    let dx = event.clientX - centerX;
    let dy = event.clientY - centerY;
    const distance = Math.hypot(dx, dy);
    if (distance > radius) {
      dx = dx / distance * radius;
      dy = dy / distance * radius;
    }
    this.joystickKnob.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
    this.input.setVirtualMove(dx / radius, -dy / radius);
  }

  endMove(event) {
    if (event.pointerId !== this.movePointerId) return;
    this.movePointerId = null;
    this.input.setVirtualMove(0, 0);
    this.joystickKnob.style.transform = 'translate(-50%, -50%)';
  }

  startLook(event) {
    event.preventDefault();
    this.lookPointerId = event.pointerId;
    this.lastLook = { x: event.clientX, y: event.clientY };
    this.lookZone.setPointerCapture(event.pointerId);
  }

  look(event) {
    if (event.pointerId !== this.lookPointerId) return;
    event.preventDefault();
    const dx = event.clientX - this.lastLook.x;
    const dy = event.clientY - this.lastLook.y;
    this.lastLook = { x: event.clientX, y: event.clientY };
    this.input.addLookDelta(dx, dy);
  }

  endLook(event) {
    if (event.pointerId === this.lookPointerId) this.lookPointerId = null;
  }
}
