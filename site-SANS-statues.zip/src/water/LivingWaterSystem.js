import * as THREE from 'three';

const REFLECTION_SKIP=['LifeCitizensV3','LivingFaunaV3','AtmosphericClouds','AmbientDetailsV3Beta3'];

function pushQuad(buffers, corners, shore = 0) {
  const base = buffers.positions.length / 3;
  for (const [x,y,z,u,v] of corners) {
    buffers.positions.push(x,y,z);
    buffers.uvs.push(u,v);
    buffers.shores.push(shore);
  }
  buffers.indices.push(base,base+1,base+2,base,base+2,base+3);
}

function buildGeometry(buffers) {
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(buffers.positions,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(buffers.uvs,2));
  geometry.setAttribute('aShore',new THREE.Float32BufferAttribute(buffers.shores,1));
  geometry.setIndex(buffers.indices);
  geometry.computeVertexNormals();
  geometry.computeBoundingSphere();
  return geometry;
}

/**
 * Eau V3 Beta 3 : surface continue, deux trains de vagues, Fresnel, réflexion
 * dynamique du décor en Élevé/Ultra, absorption chromatique et écume de rive.
 * Le système reste strictement visuel et ne modifie jamais les blocs.
 */
export class LivingWaterSystem {
  constructor(scene,world,{touchMode=false,renderer=null}={}){
    this.scene=scene;
    this.world=world;
    this.renderer=renderer;
    this.touchMode=touchMode;
    this.qualityDensity=touchMode?.24:.82;
    this.qualityId=touchMode?'mobile':'high';
    this.elapsed=0;
    this.nextReflectionAt=0;
    this.group=new THREE.Group();
    this.group.name='LivingWaterV3Beta3';
    scene.add(this.group);
    this.surfaceMaterial=this.createSurfaceMaterial();
    this.foamMaterial=this.createFoamMaterial();
    this.reflectionTarget=null;
    this.cubeCamera=null;
    this.fallbackSky=new THREE.Color(0x8fc8ff);
    this.hslScratch={h:0,s:0,l:0};
    this.sunLight=null;
    this.baseMaterialTuned=null;
  }

  createSurfaceMaterial(){
    return new THREE.ShaderMaterial({
      transparent:true,depthWrite:false,side:THREE.DoubleSide,fog:true,
      uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,{
        uTime:{value:0},uDeep:{value:new THREE.Color(0x03223f)},uMid:{value:new THREE.Color(0x087a9f)},
        uShallow:{value:new THREE.Color(0x77d9ce)},uSky:{value:new THREE.Color(0x8fc8ff)},
        uSunColor:{value:new THREE.Color(0xffedc2)},uSunDir:{value:new THREE.Vector3(.3,.8,.2).normalize()},
        uOpacity:{value:.80},uQuality:{value:1},uNight:{value:0},uEnvMap:{value:null},
        uUseEnv:{value:0},uEnvStrength:{value:0},uCameraHeight:{value:2}
      }]),
      vertexShader:/* glsl */`
        #include <fog_pars_vertex>
        attribute float aShore;
        uniform float uTime;
        uniform float uQuality;
        varying vec3 vWorld;
        varying vec3 vNormalW;
        varying vec2 vWorldUv;
        varying float vShore;
        varying float vWave;
        void main(){
          vec4 wp=modelMatrix*vec4(position,1.0);
          float a=sin(dot(wp.xz,vec2(.72,.38))+uTime*1.18);
          float b=sin(dot(wp.xz,vec2(-.41,.91))-uTime*.87);
          float c=sin(dot(wp.xz,vec2(1.43,1.19))+uTime*1.83)*.42;
          float amplitude=mix(.010,.105,uQuality);
          float wave=(a*.46+b*.37+c*.17);
          wp.y+=wave*amplitude;
          float dx=(cos(dot(wp.xz,vec2(.72,.38))+uTime*1.18)*.72*.46
                   +cos(dot(wp.xz,vec2(-.41,.91))-uTime*.87)*-.41*.37
                   +cos(dot(wp.xz,vec2(1.43,1.19))+uTime*1.83)*1.43*.071)*amplitude;
          float dz=(cos(dot(wp.xz,vec2(.72,.38))+uTime*1.18)*.38*.46
                   +cos(dot(wp.xz,vec2(-.41,.91))-uTime*.87)*.91*.37
                   +cos(dot(wp.xz,vec2(1.43,1.19))+uTime*1.83)*1.19*.071)*amplitude;
          vNormalW=normalize(vec3(-dx,1.0,-dz));
          vWorld=wp.xyz;
          vWorldUv=wp.xz;
          vShore=aShore;
          vWave=wave;
          vec4 mvPosition=viewMatrix*wp;
          gl_Position=projectionMatrix*mvPosition;
          #include <fog_vertex>
        }`,
      fragmentShader:/* glsl */`
        #include <fog_pars_fragment>
        uniform float uTime;
        uniform float uQuality;
        uniform float uOpacity;
        uniform float uNight;
        uniform float uUseEnv;
        uniform float uEnvStrength;
        uniform float uCameraHeight;
        uniform samplerCube uEnvMap;
        uniform vec3 uDeep;
        uniform vec3 uMid;
        uniform vec3 uShallow;
        uniform vec3 uSky;
        uniform vec3 uSunColor;
        uniform vec3 uSunDir;
        varying vec3 vWorld;
        varying vec3 vNormalW;
        varying vec2 vWorldUv;
        varying float vShore;
        varying float vWave;
        float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
        float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
        void main(){
          vec3 n=normalize(vNormalW);
          vec3 viewDir=normalize(cameraPosition-vWorld);
          float ndv=clamp(dot(n,viewDir),0.0,1.0);
          float fres=pow(1.0-ndv,3.4);
          float broad=noise(vWorldUv*.115+vec2(uTime*.018,-uTime*.014));
          float detail=noise(vWorldUv*.82+vec2(-uTime*.055,uTime*.036));
          float ripples=sin(vWorldUv.x*4.3+uTime*2.1)*sin(vWorldUv.y*3.7-uTime*1.7);
          float shoreNoise=noise(vWorldUv*1.5+vec2(uTime*.04,0.0));
          float shallow=clamp(vShore*.68+broad*.24+.06,0.0,1.0);
          vec3 water=mix(uDeep,uMid,.42+broad*.22+detail*.055);
          water=mix(water,uShallow,shallow*.72);
          float absorption=clamp((uCameraHeight-vWorld.y)*.025,0.0,.18);
          water=mix(water,uDeep,absorption);

          vec3 reflected=reflect(-viewDir,n);
          vec3 envColor=uSky;
          if(uUseEnv>.5) envColor=textureCube(uEnvMap,reflected).rgb;
          envColor=mix(envColor,uSky,.18+uNight*.18);
          float reflectionAmount=.10+fres*(.60+uEnvStrength*.24)+uEnvStrength*.08;
          water=mix(water,envColor,clamp(reflectionAmount,0.0,.86));

          vec3 halfDir=normalize(viewDir+normalize(uSunDir));
          float spec=pow(max(dot(n,halfDir),0.0),mix(58.0,220.0,uQuality));
          float sparkle=pow(max(0.0,sin((vWorldUv.x-vWorldUv.y)*9.0+uTime*3.3)),38.0)*uQuality;
          water+=uSunColor*(spec*1.65+sparkle*.070)*(1.0-uNight*.58);
          float caustic=pow(abs(sin(vWorldUv.x*2.35+uTime)*cos(vWorldUv.y*2.72-uTime*.8)),7.0);
          water+=uShallow*caustic*.072*(1.0-shallow*.25);

          float shoreBand=smoothstep(.35,.82,vShore)*smoothstep(.43,.80,shoreNoise+.20*sin(uTime*1.4+vWorldUv.x*2.0));
          float foam=shoreBand*(.12+.26*abs(vWave))*(.35+.65*uQuality);
          water=mix(water,vec3(.90,.985,1.0),foam);
          float alpha=uOpacity*(.64+fres*.29+shallow*.075);
          gl_FragColor=vec4(water,alpha);
          #include <fog_fragment>
        }`
    });
  }

  createFoamMaterial(){
    return new THREE.ShaderMaterial({
      transparent:true,depthWrite:false,side:THREE.DoubleSide,fog:true,
      uniforms:THREE.UniformsUtils.merge([THREE.UniformsLib.fog,{uTime:{value:0},uOpacity:{value:.65}}]),
      vertexShader:/* glsl */`#include <fog_pars_vertex>
varying vec2 vUv;uniform float uTime;void main(){vUv=uv;vec3 p=position;p.y+=(sin(uv.x*13.0+uTime*2.0)+sin(uv.x*27.0-uTime*1.4))*.006;vec4 mvPosition=modelViewMatrix*vec4(p,1.0);gl_Position=projectionMatrix*mvPosition;
#include <fog_vertex>
}`,
      fragmentShader:/* glsl */`#include <fog_pars_fragment>
varying vec2 vUv;uniform float uTime;uniform float uOpacity;float h(float n){return fract(sin(n)*43758.5453);}void main(){float bubbles=smoothstep(.58,.95,h(floor(vUv.x*42.0)+floor(vUv.y*10.0)*17.0+floor(uTime*2.0)));float edge=sin(vUv.x*18.0+uTime*1.5)*.08;float band=smoothstep(0.0,.26+edge,vUv.y)*(1.0-smoothstep(.56+edge,1.0,vUv.y));float pulse=.70+.30*sin(vUv.x*25.0-uTime*2.5);float a=band*(.30+bubbles*.70)*pulse*uOpacity;gl_FragColor=vec4(vec3(.91,.99,1.0),a);
#include <fog_fragment>
}`
    });
  }

  clear(){
    for(const child of [...this.group.children]){this.group.remove(child);child.geometry?.dispose?.();}
  }

  disposeReflection(){
    if(this.cubeCamera)this.scene.remove(this.cubeCamera);
    this.reflectionTarget?.dispose?.();
    this.cubeCamera=null;
    this.reflectionTarget=null;
    this.surfaceMaterial.uniforms.uEnvMap.value=null;
    this.surfaceMaterial.uniforms.uUseEnv.value=0;
  }

  configureReflection(){
    this.disposeReflection();
    if(!this.renderer||!['high','ultra'].includes(this.qualityId))return;
    const size=this.qualityId==='ultra'?256:128;
    this.reflectionTarget=new THREE.WebGLCubeRenderTarget(size,{
      type:THREE.HalfFloatType,
      generateMipmaps:true,
      minFilter:THREE.LinearMipmapLinearFilter,
      colorSpace:THREE.SRGBColorSpace
    });
    this.cubeCamera=new THREE.CubeCamera(.5,360,this.reflectionTarget);
    this.cubeCamera.name='WaterEnvironmentCapture';
    this.scene.add(this.cubeCamera);
    this.surfaceMaterial.uniforms.uEnvMap.value=this.reflectionTarget.texture;
    this.surfaceMaterial.uniforms.uUseEnv.value=1;
    this.surfaceMaterial.uniforms.uEnvStrength.value=this.qualityId==='ultra'?1:.64;
    this.nextReflectionAt=0;
  }

  setQuality(value,qualityId=this.qualityId){
    this.qualityDensity=Math.max(.18,Math.min(1,Number(value)||.55));
    const changed=this.qualityId!==qualityId;
    this.qualityId=qualityId;
    if(changed||(!this.cubeCamera&&['high','ultra'].includes(this.qualityId)))this.configureReflection();
    this.setWorld();
  }

  isWater(x,y,z){return this.world.blocks?.get?.(`${x}|${y}|${z}`)?.type==='water';}

  setWorld(){
    this.clear();
    const water=[...this.world.blocks.values()].filter((block)=>block.type==='water'&&!this.isWater(block.x,block.y+1,block.z));
    if(!water.length)return;
    const surface={positions:[],uvs:[],shores:[],indices:[]};
    const foam={positions:[],uvs:[],shores:[],indices:[]};
    const half=.505;
    for(const block of water){
      const y=block.y+.497;
      const missing=[
        !this.isWater(block.x+1,block.y,block.z),!this.isWater(block.x-1,block.y,block.z),
        !this.isWater(block.x,block.y,block.z+1),!this.isWater(block.x,block.y,block.z-1)
      ];
      const shore=missing.filter(Boolean).length/4;
      pushQuad(surface,[
        [block.x-half,y,block.z-half,block.x*.16,block.z*.16],
        [block.x+half,y,block.z-half,(block.x+1)*.16,block.z*.16],
        [block.x+half,y,block.z+half,(block.x+1)*.16,(block.z+1)*.16],
        [block.x-half,y,block.z+half,block.x*.16,(block.z+1)*.16]
      ],shore);
      if(this.qualityDensity>.34){
        const w=this.qualityId==='ultra'?.22:.17;
        if(missing[0])pushQuad(foam,[[block.x+half-w,y+.018,block.z-half,0,0],[block.x+half,y+.018,block.z-half,1,0],[block.x+half,y+.018,block.z+half,1,1],[block.x+half-w,y+.018,block.z+half,0,1]],1);
        if(missing[1])pushQuad(foam,[[block.x-half,y+.018,block.z-half,0,0],[block.x-half+w,y+.018,block.z-half,1,0],[block.x-half+w,y+.018,block.z+half,1,1],[block.x-half,y+.018,block.z+half,0,1]],1);
        if(missing[2])pushQuad(foam,[[block.x-half,y+.018,block.z+half-w,0,0],[block.x+half,y+.018,block.z+half-w,1,0],[block.x+half,y+.018,block.z+half,1,1],[block.x-half,y+.018,block.z+half,0,1]],1);
        if(missing[3])pushQuad(foam,[[block.x-half,y+.018,block.z-half,0,0],[block.x+half,y+.018,block.z-half,1,0],[block.x+half,y+.018,block.z-half+w,1,1],[block.x-half,y+.018,block.z-half+w,0,1]],1);
      }
    }
    const surfaceMesh=new THREE.Mesh(buildGeometry(surface),this.surfaceMaterial);
    surfaceMesh.name='UnifiedWaterSurface';
    surfaceMesh.frustumCulled=true;
    surfaceMesh.renderOrder=1;
    this.group.add(surfaceMesh);
    if(foam.positions.length){
      const foamMesh=new THREE.Mesh(buildGeometry(foam),this.foamMaterial);
      foamMesh.name='ShoreFoam';
      foamMesh.renderOrder=2;
      this.group.add(foamMesh);
    }
  }

  update(delta,playerPosition){
    this.elapsed+=delta;
    this.surfaceMaterial.uniforms.uTime.value=this.elapsed;
    this.surfaceMaterial.uniforms.uOpacity.value=.66+this.qualityDensity*.18;
    this.surfaceMaterial.uniforms.uQuality.value=.16+this.qualityDensity*.84;
    this.surfaceMaterial.uniforms.uSky.value.copy(this.scene.background?.isColor?this.scene.background:this.fallbackSky);
    this.surfaceMaterial.uniforms.uCameraHeight.value=playerPosition?.y??2;
    // Beta 4.10 : la lumière est mise en cache (avant : parcours complet de la scène à chaque image).
    if(!this.sunLight||!this.sunLight.parent)this.sunLight=this.scene.getObjectByProperty('isDirectionalLight',true);
    const sun=this.sunLight;
    if(sun)this.surfaceMaterial.uniforms.uSunDir.value.copy(sun.position).normalize();
    this.surfaceMaterial.uniforms.uNight.value=this.scene.background?.isColor?THREE.MathUtils.clamp((.52-this.scene.background.getHSL(this.hslScratch).l)*2.2,0,1):0;
    this.foamMaterial.uniforms.uTime.value=this.elapsed;
    this.foamMaterial.uniforms.uOpacity.value=.40+this.qualityDensity*.38;

    if(this.cubeCamera&&playerPosition&&this.elapsed>=this.nextReflectionAt){
      this.nextReflectionAt=this.elapsed+(this.qualityId==='ultra'?1.25:2.5);
      this.cubeCamera.position.set(playerPosition.x,playerPosition.y+1.5,playerPosition.z);
      // Beta 4.10 : capture allégée. Les petits objets animés (habitants, faune, nuages)
      // sont invisibles dans une réflexion 128 px mais coûtaient des centaines d'appels
      // de dessin × 6 faces ; la carte d'ombres n'est pas recalculée 6 fois.
      const hidden=[this.group];
      for(const name of REFLECTION_SKIP)for(const child of this.scene.children)if(child.name===name)hidden.push(child);
      const states=hidden.map((object)=>object.visible);
      for(const object of hidden)object.visible=false;
      const shadowAuto=this.renderer.shadowMap.autoUpdate;
      this.renderer.shadowMap.autoUpdate=false;
      this.cubeCamera.update(this.renderer,this.scene);
      this.renderer.shadowMap.autoUpdate=shadowAuto;
      hidden.forEach((object,index)=>{object.visible=states[index];});
    }

    // Beta 4.10 : réglage appliqué une seule fois par matériau. Avant, needsUpdate=true
    // à chaque image forçait Three.js à réévaluer le programme GPU de tous les blocs d'eau.
    const base=this.world.materials?.water;
    if(base&&this.baseMaterialTuned!==base){
      base.opacity=this.touchMode?.25:.14;
      base.color?.setHex?.(0x176b94);
      base.roughness=.06;
      base.metalness=.02;
      base.depthWrite=false;
      base.needsUpdate=true;
      this.baseMaterialTuned=base;
    }
  }
}
