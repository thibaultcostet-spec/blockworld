export class WeaponSystem {
  constructor({ onChange } = {}) {
    this.onChange = onChange;
    this.states = new Map();
    this.selectedItem = null;
  }

  stateFor(item) {
    if (!item?.magazineSize) return null;
    if (!this.states.has(item.id)) {
      this.states.set(item.id, {
        ammo: item.magazineSize,
        magazineSize: item.magazineSize,
        reloading: false,
        reloadRemaining: 0
      });
    }
    return this.states.get(item.id);
  }

  select(item) {
    this.selectedItem = item;
    this.stateFor(item);
    this.emit();
  }

  consumeShot(item = this.selectedItem) {
    const state = this.stateFor(item);
    if (!state) return { ok: true, ammo: null };
    if (state.reloading) return { ok: false, reason: 'reloading', state };
    if (state.ammo <= 0) return { ok: false, reason: 'empty', state };
    state.ammo -= 1;
    this.emit();
    return { ok: true, ammo: state.ammo, state };
  }

  reload(item = this.selectedItem) {
    const state = this.stateFor(item);
    if (!state) return { ok: false, reason: 'not-needed' };
    if (state.reloading) return { ok: false, reason: 'already-reloading', state };
    if (state.ammo >= state.magazineSize) return { ok: false, reason: 'full', state };
    state.reloading = true;
    state.reloadRemaining = Math.max(0.35, Number(item.reloadTime) || 1.4);
    this.emit();
    return { ok: true, state };
  }

  update(delta) {
    let changed = false;
    const completed = [];
    for (const [itemId, state] of this.states.entries()) {
      if (!state.reloading) continue;
      state.reloadRemaining = Math.max(0, state.reloadRemaining - delta);
      if (state.reloadRemaining <= 0) {
        state.reloading = false;
        state.ammo = state.magazineSize;
        completed.push(itemId);
      }
      changed = true;
    }
    if (changed) this.emit();
    return completed;
  }

  getDisplay(item = this.selectedItem) {
    const state = this.stateFor(item);
    if (!item || !state) return null;
    if (state.reloading) return `Rechargement ${state.reloadRemaining.toFixed(1)} s`;
    return `${state.ammo} / ${state.magazineSize}`;
  }

  emit() {
    this.onChange?.(this.selectedItem, this.stateFor(this.selectedItem));
  }
}
