import * as THREE from 'three';

function box(group, size, position, material, rotation = [0, 0, 0]) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), material);
  mesh.position.set(...position);
  mesh.rotation.set(...rotation);
  group.add(mesh);
  return mesh;
}

function cylinder(group, radius, length, position, material, rotation = [Math.PI / 2, 0, 0]) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius, radius, length, 10), material);
  mesh.position.set(...position);
  mesh.rotation.set(...rotation);
  group.add(mesh);
  return mesh;
}

export class WeaponViewModel {
  constructor(camera) {
    this.camera = camera;
    this.group = new THREE.Group();
    this.group.name = 'FirstPersonWeapon';
    this.group.position.set(0.42, -0.36, -0.72);
    this.group.rotation.set(-0.08, -0.12, 0.02);
    this.group.visible = false;
    this.camera.add(this.group);
    this.currentType = null;
    this.recoil = 0;
    this.time = 0;

    this.dark = new THREE.MeshStandardMaterial({ color: 0x222832, roughness: 0.54, metalness: 0.48 });
    this.metal = new THREE.MeshStandardMaterial({ color: 0x59616b, roughness: 0.34, metalness: 0.72 });
    this.wood = new THREE.MeshStandardMaterial({ color: 0x704425, roughness: 0.76, metalness: 0.05 });
    this.accent = new THREE.MeshStandardMaterial({ color: 0x2d3f54, roughness: 0.48, metalness: 0.38 });
    this.glass = new THREE.MeshStandardMaterial({ color: 0x78b8d4, emissive: 0x153d55, emissiveIntensity: 0.45, roughness: 0.12, metalness: 0.18 });
  }

  clear() {
    for (const child of [...this.group.children]) {
      this.group.remove(child);
      child.geometry?.dispose?.();
    }
  }

  setItem(item, { firstPerson = true } = {}) {
    const type = item?.kind === 'weapon' || item?.type === 'fishing-rod' ? item.type : null; // Beta 4.27 : canne visible
    if (type !== this.currentType) {
      this.currentType = type;
      this.build(type);
    }
    this.group.visible = Boolean(type && firstPerson);
  }

  build(type) {
    this.clear();
    if (!type) return;

    if (type === 'fishing-rod') {
      // Beta 4.27 : manche en liège, scion fin incliné vers l'avant, moulinet.
      box(this.group, [0.06, 0.06, 0.30], [0, -0.14, 0.10], this.wood, [0.35, 0, 0]);
      const blank = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.02, 1.3, 6), this.metal);
      blank.rotation.x = -Math.PI / 2 + 0.35;
      blank.position.set(0, 0.06, -0.55);
      this.group.add(blank);
      const reel = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.05, 10), this.accent);
      reel.rotation.z = Math.PI / 2;
      reel.position.set(0.05, -0.17, 0.02);
      this.group.add(reel);
      return;
    }

    if (type === 'sword') {
      box(this.group, [0.10, 0.10, 0.34], [0, -0.15, 0.06], this.wood, [0.25, 0, 0]);
      box(this.group, [0.42, 0.07, 0.08], [0, 0.01, -0.05], this.metal);
      box(this.group, [0.09, 0.07, 0.92], [0, 0.04, -0.53], this.metal);
      return;
    }

    if (type === 'grenade') {
      const body = new THREE.Mesh(new THREE.SphereGeometry(0.16, 10, 8), this.accent);
      body.scale.set(0.86, 1.08, 0.86);
      this.group.add(body);
      box(this.group, [0.10, 0.09, 0.10], [0, 0.18, 0], this.metal);
      return;
    }

    if (['pistol', 'revolver'].includes(type)) {
      box(this.group, [0.16, 0.18, 0.42], [0, 0, -0.08], this.dark);
      box(this.group, [0.13, 0.30, 0.14], [0, -0.20, 0.07], this.accent, [0.18, 0, 0]);
      cylinder(this.group, type === 'revolver' ? 0.105 : 0.07, 0.18, [0, 0.01, -0.18], this.metal, [0, 0, Math.PI / 2]);
      if (type === 'revolver') cylinder(this.group, 0.13, 0.17, [0, 0.01, 0.01], this.metal, [0, 0, Math.PI / 2]);
      return;
    }

    if (type === 'shotgun') {
      box(this.group, [0.22, 0.19, 0.78], [0, 0, -0.20], this.wood);
      cylinder(this.group, 0.052, 1.12, [0, 0.045, -0.58], this.metal, [Math.PI / 2, 0, 0]);
      box(this.group, [0.16, 0.18, 0.30], [0, -0.17, 0.20], this.wood, [0.26, 0, 0]);
      return;
    }

    const long = ['sniper', 'dmr'].includes(type);
    const compact = type === 'smg';
    const barrelLength = long ? 1.10 : compact ? 0.56 : 0.82;
    box(this.group, [0.22, 0.22, compact ? 0.56 : 0.74], [0, 0, -0.12], type === 'ak47' ? this.wood : this.dark);
    box(this.group, [0.15, 0.34, 0.18], [0, -0.23, 0.04], this.accent, [0.18, 0, 0]);
    cylinder(this.group, long ? 0.037 : 0.046, barrelLength, [0, 0.04, -0.55], this.metal, [Math.PI / 2, 0, 0]);
    box(this.group, [0.16, 0.13, 0.34], [0, -0.02, 0.37], type === 'ak47' ? this.wood : this.accent, [-0.15, 0, 0]);
    if (long) {
      cylinder(this.group, 0.075, 0.48, [0, 0.19, -0.17], this.dark, [Math.PI / 2, 0, 0]);
      cylinder(this.group, 0.058, 0.49, [0, 0.19, -0.17], this.glass, [Math.PI / 2, 0, 0]);
    }
  }

  kick(amount = 1) {
    this.recoil = Math.min(1.4, this.recoil + Math.max(0.15, amount));
  }

  update(delta, { moving = false, zoomed = false, firstPerson = true } = {}) {
    this.time += delta;
    this.recoil = THREE.MathUtils.damp(this.recoil, 0, 13, delta);
    const bob = moving ? Math.sin(this.time * 8) * 0.012 : Math.sin(this.time * 2) * 0.003;
    const targetX = zoomed ? 0.015 : 0.42;
    const targetY = zoomed ? -0.12 : -0.36 + bob;
    const targetZ = zoomed ? -0.62 : -0.72 + this.recoil * 0.08;
    this.group.position.x = THREE.MathUtils.damp(this.group.position.x, targetX, 10, delta);
    this.group.position.y = THREE.MathUtils.damp(this.group.position.y, targetY, 10, delta);
    this.group.position.z = THREE.MathUtils.damp(this.group.position.z, targetZ, 14, delta);
    this.group.rotation.x = THREE.MathUtils.damp(this.group.rotation.x, -0.08 + this.recoil * 0.11, 14, delta);
    this.group.rotation.y = THREE.MathUtils.damp(this.group.rotation.y, zoomed ? 0 : -0.12, 10, delta);
    this.group.visible = Boolean(this.currentType && firstPerson && !zoomed);
  }
}
