export const BLOCK_TYPES = {
  grass: { label: 'Herbe', color: 0x62a84a, hardness: 1, preferredTool: 'shovel', solid: true },
  dirt: { label: 'Terre', color: 0x8a5a36, hardness: 1, preferredTool: 'shovel', solid: true },
  stone: { label: 'Pierre', color: 0x8b929a, hardness: 3, preferredTool: 'pickaxe', solid: true },
  sand: { label: 'Sable', color: 0xd7c27a, hardness: 1, preferredTool: 'shovel', solid: true },
  snow: { label: 'Neige', color: 0xeef6ff, hardness: 1, preferredTool: 'shovel', solid: true },
  water: {
    label: 'Eau', color: 0x3e8ed0, hardness: 0, preferredTool: null, solid: false,
    transparent: true, opacity: 0.58
  },
  wood: { label: 'Bois', color: 0x8b5a2b, hardness: 2, preferredTool: 'axe', solid: true },
  tall_grass: { label: 'Herbes hautes', color: 0x73b84f, hardness: 0, preferredTool: null, solid: false, transparent: true, opacity: 0.78 },
  shrub: { label: 'Arbuste', color: 0x397b35, hardness: 1, preferredTool: 'axe', solid: false, transparent: true, opacity: 0.9 },
  flower_red: { label: 'Fleur rouge', color: 0xe84f5f, hardness: 0, preferredTool: null, solid: false, emissive: 0x4b0710, emissiveIntensity: 0.12 },
  flower_yellow: { label: 'Fleur jaune', color: 0xf4ce45, hardness: 0, preferredTool: null, solid: false, emissive: 0x4d3a05, emissiveIntensity: 0.12 },
  bamboo: { label: 'Bambou', color: 0x7aa84d, hardness: 1, preferredTool: 'axe', solid: true },
  leaves: {
    label: 'Feuilles', color: 0x3f8f3b, hardness: 1, preferredTool: 'axe', solid: true,
    transparent: true, opacity: 0.82
  },
  planks: { label: 'Planches', color: 0xb57a3f, hardness: 2, preferredTool: 'axe', solid: true },
  bricks: { label: 'Briques', color: 0xa84f43, hardness: 3, preferredTool: 'hammer', solid: true },
  concrete: { label: 'Béton', color: 0xb9bec3, hardness: 4, preferredTool: 'hammer', solid: true },
  glass: {
    label: 'Verre', color: 0xb9e9f2, hardness: 1, preferredTool: 'pickaxe', solid: true,
    transparent: true, opacity: 0.42
  },
  window: {
    label: 'Fenêtre', color: 0x8dd6eb, hardness: 1, preferredTool: 'pickaxe', solid: true,
    transparent: true, opacity: 0.32
  },
  door: { label: 'Porte', color: 0x7b4d27, hardness: 2, preferredTool: 'axe', solid: true },
  roof: { label: 'Toiture', color: 0x7f3030, hardness: 3, preferredTool: 'hammer', solid: true },
  road: { label: 'Route', color: 0x6a6660, hardness: 3, preferredTool: 'hammer', solid: true },
  rail: { label: 'Rail', color: 0x666b70, hardness: 3, preferredTool: 'pickaxe', solid: false },
  ladder: { label: 'Échelle', color: 0xc6924b, hardness: 2, preferredTool: 'axe', solid: false },
  fence: { label: 'Barrière', color: 0x9a6536, hardness: 2, preferredTool: 'axe', solid: true },
  obsidian: {
    label: 'Obsidienne', color: 0x2f2446, hardness: 5, preferredTool: 'hammer', solid: true,
    emissive: 0x120a26, emissiveIntensity: 0.45
  },
  crystal: {
    label: 'Cristal', color: 0x62d9ff, hardness: 2, preferredTool: 'pickaxe', solid: true,
    transparent: true, opacity: 0.78, emissive: 0x126a88, emissiveIntensity: 0.9
  },
  lantern: {
    label: 'Lanterne', color: 0xffc34d, hardness: 1, preferredTool: 'pickaxe', solid: true,
    emissive: 0xff8c1a, emissiveIntensity: 1.2
  },
  crate: { label: 'Caisse', color: 0x9a6835, hardness: 2, preferredTool: 'axe', solid: true },
  // Beta 4.30 : poutre en acier (défis d'ingénieur : très résistante, 3 points de budget).
  steel: { label: 'Acier', color: 0x6d7c8c, hardness: 4, preferredTool: 'hammer', solid: true },
  // Beta 4.14 : collision des arbres en mini-blocs (invisible, non constructible, protégée).
  tree_trunk: { label: 'Tronc (collision)', color: 0x5b3d24, hardness: 99, preferredTool: 'axe', solid: true, hidden: true }
};

export const BUILDABLE_BLOCKS = Object.keys(BLOCK_TYPES).filter((type) => !BLOCK_TYPES[type].hidden);
