// BlockWorld V3.0 Beta 4.27 — feux de camp : objet posé (pas un bloc), flammes animées, éclairage de nuit, cuisson.
// Mémorisés par continent dans le navigateur (12 au maximum). En multijoueur, chaque joueur voit ses propres feux.
import * as THREE from 'three';

export const CAMPFIRE_STORAGE_PREFIX = 'blockworld-v4.27-campfires-';
export const CAMPFIRE_MAX = 12;
export const CAMPFIRE_COOK_RADIUS = 3.5;

const LOG_MATERIAL = new THREE.MeshStandardMaterial({ color: 0x5a3a20, roughness: 0.95 });
const CHAR_MATERIAL = new THREE.MeshStandardMaterial({ color: 0x2a1c12, roughness: 1, emissive: 0x3a1200, emissiveIntensity: 0.6 });
const STONE_MATERIAL = new THREE.MeshStandardMaterial({ color: 0x77736c, roughness: 0.92 });

function buildCampfire() {
  const group = new THREE.Group();
  group.name = 'Campfire';
  const logGeometry = new THREE.CylinderGeometry(0.07, 0.08, 0.78, 7);
  for (let i = 0; i < 4; i += 1) {
    const log = new THREE.Mesh(logGeometry, i % 2 ? LOG_MATERIAL : CHAR_MATERIAL);
    log.rotation.z = Math.PI / 2 - 0.42;
    log.rotation.y = (i / 4) * Math.PI * 2;
    log.position.set(Math.cos((i / 4) * Math.PI * 2) * 0.16, 0.16, Math.sin((i / 4) * Math.PI * 2) * 0.16);
    log.castShadow = true;
    group.add(log);
  }
  const stoneGeometry = new THREE.DodecahedronGeometry(0.11, 0);
  for (let i = 0; i < 9; i += 1) {
    const stone = new THREE.Mesh(stoneGeometry, STONE_MATERIAL);
    const a = (i / 9) * Math.PI * 2;
    stone.position.set(Math.cos(a) * 0.42, 0.06, Math.sin(a) * 0.42);
    stone.scale.set(1.1, 0.75, 1);
    stone.rotation.set(a, a * 0.7, 0);
    group.add(stone);
  }
  const flames = [];
  const flameColors = [0xff6a1a, 0xff9a2e, 0xffd45c];
  flameColors.forEach((color, index) => {
    const flame = new THREE.Mesh(
      new THREE.ConeGeometry(0.2 - index * 0.05, 0.62 - index * 0.12, 7, 1, true),
      new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.82 - index * 0.12, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide })
    );
    flame.position.y = 0.36 - index * 0.04;
    flame.userData.phase = index * 1.7;
    flames.push(flame);
    group.add(flame);
  });
  group.userData.flames = flames;
  return group;
}

export class CampfireSystem {
  constructor(game) {
    this.game = game;
    this.group = new THREE.Group();
    this.group.name = 'Campfires';
    game.scene.add(this.group);
    this.fires = [];
    this.worldId = null;
    this.elapsed = 0;
    this.crackleTimer = 0;
  }

  storageKey() { return `${CAMPFIRE_STORAGE_PREFIX}${this.worldId}`; }

  setWorld(worldId) {
    this.clear();
    this.worldId = worldId;
    let saved = [];
    try { saved = JSON.parse(localStorage.getItem(this.storageKey()) ?? '[]'); } catch (_error) { saved = []; }
    for (const spot of Array.isArray(saved) ? saved.slice(0, CAMPFIRE_MAX) : []) {
      if ([spot?.x, spot?.y, spot?.z].every(Number.isFinite)) this.spawn(new THREE.Vector3(spot.x, spot.y, spot.z), { persist: false });
    }
  }

  persist() {
    try { localStorage.setItem(this.storageKey(), JSON.stringify(this.fires.map((f) => ({ x: f.position.x, y: f.position.y, z: f.position.z })))); } catch (_error) {}
  }

  clear() {
    for (const fire of this.fires) this.group.remove(fire.group);
    this.fires = [];
  }

  /** Pose un feu sur la face supérieure d'un bloc (coordonnées du bloc porteur). */
  placeOnBlock(blockPosition) {
    const position = new THREE.Vector3(Math.round(blockPosition.x), Math.round(blockPosition.y) + 0.5, Math.round(blockPosition.z));
    if (this.fires.some((fire) => fire.position.distanceTo(position) < 1.2)) return { ok: false, reason: 'occupied' };
    if (this.fires.length >= CAMPFIRE_MAX) return { ok: false, reason: 'full' };
    this.spawn(position);
    return { ok: true, position };
  }

  spawn(position, { persist = true } = {}) {
    const group = buildCampfire();
    group.position.copy(position);
    for (const child of group.children) child.userData.campfire = true;
    this.group.add(group);
    const fire = { group, position: position.clone() };
    group.userData.fire = fire;
    this.fires.push(fire);
    if (persist) this.persist();
    return fire;
  }

  remove(fire) {
    const index = this.fires.indexOf(fire);
    if (index < 0) return false;
    this.group.remove(fire.group);
    this.fires.splice(index, 1);
    this.persist();
    return true;
  }

  getRaycastTargets() { return this.group.children; }

  fireFromHit(hit) {
    let node = hit?.object;
    while (node && !node.userData?.fire) node = node.parent;
    return node?.userData?.fire ?? null;
  }

  nearestDistance(point) {
    let best = Infinity;
    for (const fire of this.fires) best = Math.min(best, fire.position.distanceTo(point));
    return best;
  }

  /** Sources de lumière pour l'éclairage de nuit. */
  lightSources() {
    return this.fires.map((fire) => ({ position: fire.position.clone().setY(fire.position.y + 0.6), color: 0xff8a3a, intensity: 2.4 + Math.sin(this.elapsed * 13 + fire.position.x) * 0.35, distance: 11, flicker: true }));
  }

  update(delta, eye) {
    this.elapsed += delta;
    for (const fire of this.fires) {
      for (const flame of fire.group.userData.flames) {
        const t = this.elapsed * 9 + flame.userData.phase + fire.position.x;
        flame.scale.set(1 + Math.sin(t) * 0.08, 1 + Math.sin(t * 1.7) * 0.18, 1 + Math.cos(t) * 0.08);
        flame.rotation.y += delta * 1.6;
      }
    }
    if (eye && this.fires.length && this.nearestDistance(eye) < 6) {
      this.crackleTimer -= delta;
      if (this.crackleTimer <= 0) { this.crackleTimer = 0.18 + Math.random() * 0.5; this.game.sfx?.playCrackle?.(); }
    }
  }
}
