import { BLOCK_TYPES } from './BlockTypes.js';

const NON_WALKABLE = new Set([
  'water','leaves','wood','tree_trunk','bamboo','shrub','tall_grass','flower_red','flower_yellow',
  'lantern','crystal','fence','ladder','glass','window','door'
]);
// Beta 4.32 : portée verticale du sol « conscient des surplombs » (une marche d'un bloc + une marge) au-dessus du niveau des pieds.
export const STEP_REACH = 1.2;
const NATURAL_GROUND = new Set(['grass','dirt','stone','sand','snow','road','rail']);
export const PLAYER_WALKABLE_GROUND = new Set([
  ...NATURAL_GROUND,'planks','bricks','concrete','roof','obsidian','crate'
]);

/**
 * Solveur de contact au sol commun aux entités.
 * Les végétaux sont exclus du terrain praticable. Le profil joueur peut en plus
 * autoriser les constructions, sans transformer les arbres en plateformes.
 */
export class GroundingSystem {
  constructor(world, {
    maxStep = 1.15,
    clearance = 0.006,
    footprint = 0.24,
    walkableTypes = NATURAL_GROUND
  } = {}) {
    this.world = world;
    this.maxStep = maxStep;
    this.clearance = clearance;
    this.footprint = footprint;
    this.walkableTypes = walkableTypes instanceof Set ? walkableTypes : new Set(walkableTypes);
  }

  isWalkableType(type) {
    return this.walkableTypes.has(type) && !NON_WALKABLE.has(type) && Boolean(BLOCK_TYPES[type]?.solid);
  }

  /**
   * Bloc praticable le plus haut de la colonne. Avec `referenceY` (niveau des pieds), seuls comptent les blocs dont le dessus
   * reste à portée d'une marche : un linteau, un toit ou le plafond d'un tunnel ne sont plus pris pour le sol. Sans
   * `referenceY` : comportement historique (dessus de la colonne), utilisé par les monstres, animaux et habitants.
   */
  walkableTop(ix, iz, referenceY = null) {
    const limit = Number.isFinite(referenceY) ? referenceY + STEP_REACH : Infinity;
    const column = this.world.columns?.get?.(this.world.columnKey?.(ix, iz) ?? `${ix}|${iz}`);
    if (column) {
      let best = null;
      for (const block of column.values()) {
        if (!this.isWalkableType(block.type)) continue;
        if (block.y + 0.48 > limit) continue;
        if (!best || block.y > best.y) best = block;
      }
      return best;
    }
    const top = this.world.getTopBlock(ix, iz, { solidOnly: true });
    return top && this.isWalkableType(top.type) && top.y + 0.48 <= limit ? top : null;
  }

  sample(x, z, referenceY = null) {
    const ix = Math.floor(x + 0.5);
    const iz = Math.floor(z + 0.5);
    const top = this.walkableTop(ix, iz, referenceY);
    if (!top) return null;
    return {
      x: ix,
      z: iz,
      y: top.y + 0.48,
      type: top.type,
      solid: Boolean(BLOCK_TYPES[top.type]?.solid)
    };
  }

  continuousSample(x, z, referenceY = null) {
    const x0 = Math.floor(x);
    const z0 = Math.floor(z);
    const tx = x - x0;
    const tz = z - z0;
    const probes = [[x0,z0],[x0+1,z0],[x0,z0+1],[x0+1,z0+1]]
      .map(([px,pz]) => this.sample(px,pz,referenceY));
    const valid = probes.filter((sample) => this.isDryGround(sample));
    if (!valid.length) return null;
    const fallback = valid.map((sample) => sample.y).sort((a,b) => a-b)[Math.floor(valid.length / 2)];
    const heights = probes.map((sample) => this.isDryGround(sample) ? sample.y : fallback);
    const a = heights[0] * (1 - tx) + heights[1] * tx;
    const b = heights[2] * (1 - tx) + heights[3] * tx;
    return { y: a * (1 - tz) + b * tz, type: valid[0].type, solid: true };
  }

  isDryGround(sample) {
    return Boolean(sample?.solid && this.isWalkableType(sample.type));
  }

  canStep(fromX, fromZ, toX, toZ, maxStep = this.maxStep, referenceY = null) {
    const from = this.continuousSample(fromX, fromZ, referenceY);
    const to = this.continuousSample(toX, toZ, referenceY);
    if (!this.isDryGround(to)) return false;
    if (!from) return true;
    return Math.abs(to.y - from.y) <= maxStep;
  }

  groundY(x, z, offset = 0, footprint = this.footprint, referenceY = null) {
    const probes = footprint > 0 ? [
      [x,z], [x-footprint,z-footprint], [x+footprint,z-footprint],
      [x-footprint,z+footprint], [x+footprint,z+footprint]
    ] : [[x,z]];
    const samples = probes
      .map(([px,pz]) => this.continuousSample(px,pz,referenceY))
      .filter((sample) => this.isDryGround(sample));
    if (!samples.length) return null;
    const heights = samples.map((sample) => sample.y).sort((a,b) => a-b);
    return heights[Math.floor(heights.length / 2)] + this.clearance + offset;
  }

  /**
   * Calcule la translation verticale qui place le point géométrique le plus bas
   * exactement sur le terrain. Une valeur négative est volontaire : elle corrige
   * les modèles dont l'origine se trouve sous les sabots et supprimait le flottement.
   */
  calibrate(entity) {
    const oldPosition = entity.position.clone();
    const oldRotation = entity.rotation.clone();
    entity.position.set(0, 0, 0);
    entity.updateMatrixWorld(true);
    let markerMinimum = Infinity;
    let geometryMinimum = Infinity;
    let hasGeometry = false;
    let hasFootMarker = false;
    entity.traverse((object) => {
      if (object.userData?.footMarker) {
        markerMinimum = Math.min(markerMinimum, object.matrixWorld.elements[13]);
        hasFootMarker = true;
        return;
      }
      if (!object.isMesh || object.userData?.contactShadow) return;
      object.geometry?.computeBoundingBox?.();
      if (!object.geometry?.boundingBox) return;
      const bounds = object.geometry.boundingBox.clone().applyMatrix4(object.matrixWorld);
      geometryMinimum = Math.min(geometryMinimum, bounds.min.y);
      hasGeometry = true;
    });
    entity.position.copy(oldPosition);
    entity.rotation.copy(oldRotation);
    entity.updateMatrixWorld(true);
    const minimum = hasFootMarker && Number.isFinite(markerMinimum)
      ? markerMinimum
      : hasGeometry && Number.isFinite(geometryMinimum) ? geometryMinimum : 0;
    const footOffset = -minimum;
    entity.userData.footOffset = footOffset;
    entity.userData.modelBottom = minimum;
    return footOffset;
  }

  settle(entity, x = entity.position.x, z = entity.position.z, extraOffset = 0) {
    const footprint = entity.userData.groundFootprint ?? this.footprint;
    let ground = this.groundY(x, z, 0, footprint);
    if (ground === null) return false;
    // Beta 4.19 : appui réel. Le sol interpolé descend en pente entre deux colonnes : au bord d'une
    // marche, les pieds passaient sous le bloc porteur (personnage enfoncé de 30 à 40 cm).
    // Beta 4.22 : appui pris sous le centre du corps seulement. Avec toute l'empreinte (4.19), un grand
    // animal au pied d'une marche était hissé sur le bloc voisin et flottait d'environ 1 m.
    const center = this.sample(x, z);
    if (this.isDryGround(center) && Math.abs(center.y - ground) <= 1.05) ground = center.y; // ni enfoncé, ni flottant
    const footOffset = Number.isFinite(entity.userData.footOffset)
      ? entity.userData.footOffset
      : this.calibrate(entity);
    entity.position.set(x, ground + footOffset + extraOffset, z);
    entity.userData.lastGroundY = ground;
    return true;
  }

  place(entity, x = entity.position.x, z = entity.position.z, offset = 0) {
    return this.settle(entity, x, z, offset);
  }
}
