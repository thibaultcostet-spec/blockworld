// BlockWorld V3.0 Beta 4.32 (révision 4) — où se pose un bloc : au-dessus, ou sur le côté pour prolonger une passerelle.
// Module pur (testable sous Node).
//
// Problème corrigé : depuis le bord d'un bloc ou debout sur un tablier, le rayon de visée touche le DESSUS du bloc, jamais sa face qui
// donne sur le vide ; le seul emplacement possible était au-dessus, donc on ne pouvait pas prolonger une passerelle vers l'avant.
// Règle : si le point visé est sur le pourtour du dessus (les 0,3 m extérieurs), si l'on regarde vers ce bord, et si la case voisine
// est libre ET n'a pas de sol dessous (vide, eau, fossé), le bloc se pose sur cette case, au même niveau. Partout ailleurs (centre du
// dessus, faces latérales, sol continu), la pose est inchangée.

export const EDGE = { zone: 0.3, minAlign: 0.3 };

/**
 * @param hit     point visé (monde) ou null
 * @param block   centre du bloc visé (coordonnées entières)
 * @param normal  normale de la face visée
 * @param view    direction du regard projetée sur XZ et normalisée
 * @param isSolid (x, y, z) => la case est-elle pleine ?
 * @returns { target: {x,y,z}, extended: boolean, direction?: {x,z} }
 */
export function resolvePlacement({ hit, block, normal, view, isSolid }) {
  const above = { x: block.x + normal.x, y: block.y + normal.y, z: block.z + normal.z };
  const normalPlacement = { target: above, extended: false };
  if (!hit || normal.y < 0.5) return normalPlacement;
  const localX = hit.x - block.x, localZ = hit.z - block.z;
  const inner = 0.5 - EDGE.zone;
  if (Math.abs(localX) <= inner && Math.abs(localZ) <= inner) return normalPlacement; // centre du dessus : on construit vers le haut
  const alongX = Math.abs(localX) >= Math.abs(localZ);
  const direction = alongX ? { x: Math.sign(localX), z: 0 } : { x: 0, z: Math.sign(localZ) };
  if (view.x * direction.x + view.z * direction.z < EDGE.minAlign) return normalPlacement; // on ne regarde pas vers ce bord
  const side = { x: block.x + direction.x, y: block.y, z: block.z + direction.z };
  if (isSolid(side.x, side.y, side.z)) return normalPlacement; // la case voisine est déjà prise
  if (isSolid(side.x, side.y - 1, side.z)) return normalPlacement; // sol dessous : pose ordinaire
  return { target: side, extended: true, direction };
}
