import * as THREE from 'three';
import { BLOCK_TYPES } from './BlockTypes.js';
import { createBlockMaterial } from '../graphics/TextureFactory.js';
import { DEFAULT_WORLD_ID, getWorldDefinition } from '../worlds/WorldRegistry.js';

// Beta 4.12 : relief montagneux et cartes 224 × 224. Les sauvegardes stockent des écarts au terrain
// généré ; appliquées au nouveau relief, les anciennes placeraient les blocs au hasard.
const SAVE_PREFIX = 'blockworld-v4.12-world-';
const CHUNK_SIZE = 16;

function blockVariation(type, x, y, z) {
  let seed = 2166136261;
  const text = `${type}:${x}:${y}:${z}`;
  for (const character of text) {
    seed ^= character.charCodeAt(0);
    seed = Math.imul(seed, 16777619);
  }
  const random = (seed >>> 0) / 4294967295;
  const color = new THREE.Color(1, 1, 1);
  if (type === 'grass') color.setHSL(0.25 + (random - 0.5) * 0.04, 0.36 + random * 0.10, 0.72 + random * 0.12); // Beta 4.13 : vert moins fluo, plus olive
  else if (type === 'sand') color.setHSL(0.12 + (random - 0.5) * 0.018, 0.30, 0.90 + random * 0.10);
  else if (type === 'stone') {
    // Beta 4.13 : roche de montagne. Strates selon l'altitude, alternance à grande échelle entre
    // roche chaude (ocre) et froide (gris-bleu), grain bloc par bloc.
    const warm = 0.5 + 0.5 * Math.sin(x * 0.043 + z * 0.031) * Math.cos(z * 0.052 - x * 0.017);
    const strata = Math.sin(y * 1.35 + Math.sin(x * 0.11 + z * 0.07) * 1.6);
    color.setHSL(0.58 - warm * 0.50 + (random - 0.5) * 0.025, 0.10 + warm * 0.26, 0.60 + strata * 0.08 + random * 0.13);
  }
  else if (type === 'concrete') color.setHSL(0.58 + (random - 0.5) * 0.018, 0.035, 0.84 + random * 0.16);
  else if (type === 'snow') color.setHSL(0.58, 0.18 + random * 0.08, 0.90 + random * 0.08);
  else if (type === 'dirt') color.setHSL(0.07 + (random - 0.5) * 0.02, 0.28, 0.80 + random * 0.16);
  else color.setRGB(0.90 + random * 0.16, 0.90 + random * 0.16, 0.90 + random * 0.16);
  return color;
}

export class World {
  constructor(scene) {
    this.scene = scene;
    this.group = new THREE.Group();
    this.group.name = 'VoxelWorld';
    this.scene.add(this.group);

    this.currentWorldId = DEFAULT_WORLD_ID;
    this.currentDefinition = getWorldDefinition(DEFAULT_WORLD_ID);
    this.blocks = new Map();
    this.columns = new Map();
    this.chunks = new Map();
    this.blockMeshes = [];
    this.baseBlocks = new Map();
    this.removedBaseBlocks = new Set();
    this.addedBlocks = new Map();
    this.geometry = new THREE.BoxGeometry(0.96, 0.96, 0.96);
    this.materials = Object.fromEntries(
      Object.entries(BLOCK_TYPES).map(([name, config]) => { const material = createBlockMaterial(name, config); if (config.hidden) material.visible = false; return [name, material]; })
    );
    this.isBatching = false;
    this.lastVisibleChunkKey = '';
    this.tempMatrix = new THREE.Matrix4();
    this.tempColor = new THREE.Color();
  }

  key(x, y, z) {
    return `${x}|${y}|${z}`;
  }

  columnKey(x, z) {
    return `${x}|${z}`;
  }

  chunkCoords(x, z) {
    return { x: Math.floor(x / CHUNK_SIZE), z: Math.floor(z / CHUNK_SIZE) };
  }

  chunkKey(x, z) {
    const chunk = this.chunkCoords(x, z);
    return `${chunk.x}|${chunk.z}`;
  }

  getOrCreateChunk(x, z) {
    const key = this.chunkKey(x, z);
    let chunk = this.chunks.get(key);
    if (!chunk) {
      const coords = this.chunkCoords(x, z);
      const group = new THREE.Group();
      group.name = `Chunk_${coords.x}_${coords.z}`;
      group.userData.chunk = coords;
      this.group.add(group);
      chunk = { key, x: coords.x, z: coords.z, group, blockKeys: new Set(), meshes: [] };
      this.chunks.set(key, chunk);
    }
    return chunk;
  }

  saveKey(worldId = this.currentWorldId) {
    return `${SAVE_PREFIX}${worldId}`;
  }

  hasBlock(x, y, z) {
    return this.blocks.has(this.key(Math.round(x), Math.round(y), Math.round(z)));
  }

  getBlock(x, y, z) {
    return this.blocks.get(this.key(Math.round(x), Math.round(y), Math.round(z))) ?? null;
  }

  isSolidAt(x, y, z) {
    const block = this.getBlock(x, y, z);
    return Boolean(block && BLOCK_TYPES[block.type]?.solid);
  }

  getConstructionBlocks() {
    return [...this.addedBlocks.values()]
      .map((snapshot) => this.getBlock(snapshot.x, snapshot.y, snapshot.z))
      .filter(Boolean);
  }

  indexBlock(block) {
    const key = this.columnKey(block.x, block.z);
    let column = this.columns.get(key);
    if (!column) {
      column = new Map();
      this.columns.set(key, column);
    }
    column.set(block.y, block);
  }

  unindexBlock(block) {
    const key = this.columnKey(block.x, block.z);
    const column = this.columns.get(key);
    if (!column) return;
    column.delete(block.y);
    if (column.size === 0) this.columns.delete(key);
  }

  snapshotBlock(block) {
    return {
      x: block.x,
      y: block.y,
      z: block.z,
      type: block.type,
      protectedBlock: Boolean(block.protectedBlock)
    };
  }

  captureBaseState() {
    this.baseBlocks = new Map(
      [...this.blocks.entries()].map(([key, block]) => [key, this.snapshotBlock(block)])
    );
    this.removedBaseBlocks.clear();
    this.addedBlocks.clear();
  }

  syncDeltaForKey(key) {
    const base = this.baseBlocks.get(key);
    const current = this.blocks.get(key);
    if (base && !current) {
      this.removedBaseBlocks.add(key);
      this.addedBlocks.delete(key);
      return;
    }
    if (!base && current) {
      this.removedBaseBlocks.delete(key);
      this.addedBlocks.set(key, this.snapshotBlock(current));
      return;
    }
    if (base && current) {
      const unchanged = base.type === current.type
        && Boolean(base.protectedBlock) === Boolean(current.protectedBlock);
      if (unchanged) {
        this.removedBaseBlocks.delete(key);
        this.addedBlocks.delete(key);
      } else {
        this.removedBaseBlocks.add(key);
        this.addedBlocks.set(key, this.snapshotBlock(current));
      }
      return;
    }
    this.removedBaseBlocks.delete(key);
    this.addedBlocks.delete(key);
  }

  rebuildDeltaState() {
    this.removedBaseBlocks.clear();
    this.addedBlocks.clear();
    const keys = new Set([...this.baseBlocks.keys(), ...this.blocks.keys()]);
    for (const key of keys) this.syncDeltaForKey(key);
  }

  addBlock(x, y, z, type = 'grass', { persist = true, protectedBlock = false } = {}) {
    x = Math.round(x);
    y = Math.round(y);
    z = Math.round(z);
    const key = this.key(x, y, z);
    if (this.blocks.has(key) || !this.materials[type]) return false;

    const chunk = this.getOrCreateChunk(x, z);
    const block = { x, y, z, type, protectedBlock, chunkKey: chunk.key };
    this.blocks.set(key, block);
    this.indexBlock(block);
    chunk.blockKeys.add(key);

    if (!this.isBatching) {
      this.rebuildChunk(chunk.key);
      this.syncDeltaForKey(key);
    }
    if (persist) this.save();
    return true;
  }

  removeBlock(x, y, z, { persist = true, force = false } = {}) {
    const key = this.key(Math.round(x), Math.round(y), Math.round(z));
    const block = this.blocks.get(key);
    if (!block || (block.protectedBlock && !force)) return false;

    this.blocks.delete(key);
    this.unindexBlock(block);
    const chunk = this.chunks.get(block.chunkKey);
    chunk?.blockKeys.delete(key);
    if (!this.isBatching) {
      this.rebuildChunk(block.chunkKey);
      this.syncDeltaForKey(key);
    }
    if (persist) this.save();
    return true;
  }

  clearChunkMeshes(chunk) {
    for (const mesh of chunk.meshes) chunk.group.remove(mesh);
    chunk.meshes.length = 0;
  }

  rebuildChunk(chunkKey) {
    const chunk = this.chunks.get(chunkKey);
    if (!chunk) return;
    this.clearChunkMeshes(chunk);

    if (chunk.blockKeys.size === 0) {
      this.group.remove(chunk.group);
      this.chunks.delete(chunkKey);
      this.refreshBlockMeshes();
      return;
    }

    const byType = new Map();
    for (const key of chunk.blockKeys) {
      const block = this.blocks.get(key);
      if (!block) continue;
      if (!byType.has(block.type)) byType.set(block.type, []);
      byType.get(block.type).push(block);
    }

    for (const [type, blocks] of byType) {
      const mesh = new THREE.InstancedMesh(this.geometry, this.materials[type], blocks.length);
      mesh.name = `Chunk_${chunk.x}_${chunk.z}_${type}`;
      mesh.userData.instanceBlocks = blocks;
      mesh.userData.chunkKey = chunk.key;
      mesh.castShadow = BLOCK_TYPES[type].solid && !['grass', 'dirt', 'sand', 'snow', 'leaves', 'glass', 'window', 'crystal', 'lantern'].includes(type);
      mesh.receiveShadow = type !== 'water';
      for (let index = 0; index < blocks.length; index += 1) {
        const block = blocks[index];
        this.tempMatrix.makeTranslation(block.x, block.y, block.z);
        mesh.setMatrixAt(index, this.tempMatrix);
        mesh.setColorAt(index, blockVariation(type, block.x, block.y, block.z));
      }
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      mesh.computeBoundingSphere();
      chunk.group.add(mesh);
      chunk.meshes.push(mesh);
    }
    this.refreshBlockMeshes();
  }

  rebuildAllChunks() {
    for (const key of this.chunks.keys()) this.rebuildChunk(key);
    this.refreshBlockMeshes();
  }

  refreshBlockMeshes() {
    this.blockMeshes = [...this.chunks.values()].flatMap((chunk) => chunk.meshes);
  }

  clear() {
    for (const chunk of this.chunks.values()) this.group.remove(chunk.group);
    this.blocks.clear();
    this.columns.clear();
    this.chunks.clear();
    this.blockMeshes.length = 0;
    this.baseBlocks.clear();
    this.removedBaseBlocks.clear();
    this.addedBlocks.clear();
    this.decorTrees = []; // Beta 4.32 : les arbres décoratifs appartiennent au continent généré ; sans cela, charger une sauvegarde laissait ceux de l'ancien continent en l'air
    this.lastVisibleChunkKey = '';
  }

  generatePreset(worldId = DEFAULT_WORLD_ID, { persist = true } = {}) {
    this.clear();
    this.currentDefinition = getWorldDefinition(worldId);
    this.currentWorldId = this.currentDefinition.id;
    this.isBatching = true;
    this.decorTrees = [];
    this.currentDefinition.generate(this);
    this.isBatching = false;
    this.rebuildAllChunks();
    this.captureBaseState();
    if (persist) this.save();
    return this.currentDefinition;
  }

  generate(_size = 34, { persist = true, worldId = this.currentWorldId } = {}) {
    return this.generatePreset(worldId, { persist });
  }

  getTopBlock(x, z, { solidOnly = false } = {}) {
    const column = this.columns.get(this.columnKey(Math.round(x), Math.round(z)));
    if (!column) return null;
    let highest = null;
    for (const block of column.values()) {
      if (solidOnly && !BLOCK_TYPES[block.type]?.solid) continue;
      if (!highest || block.y > highest.y) highest = block;
    }
    return highest;
  }

  getSurfaceHeight(x, z) {
    const highest = this.getTopBlock(x, z, { solidOnly: true });
    return highest ? highest.y + 0.5 : 0;
  }

  getSpawnPoint(index = 0) {
    const definition = this.currentDefinition ?? getWorldDefinition(this.currentWorldId);
    const source = index > 0 && definition.battleSpawns?.length
      ? definition.battleSpawns[index % definition.battleSpawns.length]
      : definition.spawn;
    const x = source?.x ?? 0;
    const z = source?.z ?? 12;
    return new THREE.Vector3(x, this.getSurfaceHeight(x, z) + 1.35, z);
  }

  findSpawnPosition(minDistance = 12, maxDistance = 42) {
    for (let attempt = 0; attempt < 90; attempt += 1) {
      const angle = Math.random() * Math.PI * 2;
      const distance = minDistance + Math.random() * (maxDistance - minDistance);
      const x = Math.round(Math.cos(angle) * distance);
      const z = Math.round(Math.sin(angle) * distance);
      const top = this.getTopBlock(x, z, { solidOnly: true });
      if (!top || ['sand', 'water', 'lantern', 'crystal', 'road', 'rail'].includes(top.type)) continue;
      return new THREE.Vector3(x, top.y + 0.5, z);
    }
    return this.getSpawnPoint();
  }

  updateVisibleChunks(position, renderDistance = 64) {
    if (!position) return;
    const center = this.chunkCoords(position.x, position.z);
    const radius = Math.ceil(renderDistance / CHUNK_SIZE);
    const stateKey = `${center.x}|${center.z}|${radius}`;
    if (stateKey === this.lastVisibleChunkKey) return;
    this.lastVisibleChunkKey = stateKey;
    for (const chunk of this.chunks.values()) {
      const dx = Math.abs(chunk.x - center.x);
      const dz = Math.abs(chunk.z - center.z);
      chunk.group.visible = dx <= radius && dz <= radius;
    }
  }

  getRaycastMeshes() {
    return this.blockMeshes.filter((mesh) => mesh.parent?.visible !== false);
  }

  resolveRaycastHit(hit) {
    if (!hit) return null;
    if (hit.object?.isInstancedMesh && Number.isInteger(hit.instanceId)) {
      const block = hit.object.userData.instanceBlocks?.[hit.instanceId];
      if (!block) return null;
      return { block, position: new THREE.Vector3(block.x, block.y, block.z) };
    }
    const block = hit.object?.userData?.block;
    if (!block) return null;
    return { block, position: hit.object.position.clone() };
  }

  serialize() {
    return [...this.blocks.values()].map((block) => this.snapshotBlock(block));
  }

  save() {
    const payload = {
      version: 3,
      worldId: this.currentWorldId,
      removed: [...this.removedBaseBlocks],
      added: [...this.addedBlocks.values()]
    };
    localStorage.setItem(this.saveKey(), JSON.stringify(payload));
  }

  applyDeltaSave(definition, parsed) {
    this.clear();
    this.currentWorldId = definition.id;
    this.currentDefinition = definition;

    this.isBatching = true;
    definition.generate(this);
    this.isBatching = false;
    this.rebuildAllChunks();
    this.captureBaseState();

    this.isBatching = true;
    for (const key of Array.isArray(parsed.removed) ? parsed.removed : []) {
      const [x, y, z] = String(key).split('|').map(Number);
      if ([x, y, z].every(Number.isFinite)) this.removeBlock(x, y, z, { persist: false, force: true });
    }
    for (const block of Array.isArray(parsed.added) ? parsed.added : []) {
      if (![block?.x, block?.y, block?.z].every(Number.isFinite)) continue;
      const existing = this.getBlock(block.x, block.y, block.z);
      if (existing) this.removeBlock(block.x, block.y, block.z, { persist: false, force: true });
      this.addBlock(block.x, block.y, block.z, block.type, {
        persist: false,
        protectedBlock: Boolean(block.protectedBlock)
      });
    }
    this.isBatching = false;
    this.rebuildAllChunks();
    this.rebuildDeltaState();
    return true;
  }

  load(worldId = DEFAULT_WORLD_ID) {
    const definition = getWorldDefinition(worldId);
    const raw = localStorage.getItem(this.saveKey(definition.id));
    if (!raw) return false;
    try {
      const parsed = JSON.parse(raw);
      if (parsed?.version >= 3) return this.applyDeltaSave(definition, parsed);

      const blocks = Array.isArray(parsed) ? parsed : parsed.blocks;
      if (!Array.isArray(blocks)) return false;
      this.clear();
      this.currentWorldId = definition.id;
      this.currentDefinition = definition;
      this.isBatching = true;
      for (const block of blocks) {
        this.addBlock(block.x, block.y, block.z, block.type, {
          persist: false,
          protectedBlock: Boolean(block.protectedBlock)
        });
      }
      this.isBatching = false;
      this.rebuildAllChunks();
      this.captureBaseState();
      return true;
    } catch (error) {
      this.isBatching = false;
      console.warn(`Sauvegarde illisible (${definition.id}) :`, error);
      return false;
    }
  }

  reset(worldId = this.currentWorldId) {
    localStorage.removeItem(this.saveKey(worldId));
    this.generatePreset(worldId);
  }
}
