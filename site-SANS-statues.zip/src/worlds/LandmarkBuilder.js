export function groundY(world, x, z) {
  const top = world.getTopBlock(Math.round(x), Math.round(z), { solidOnly: true });
  return top ? top.y + 1 : 1;
}

export function setBlock(world, x, y, z, type, options = {}) {
  return world.addBlock(Math.round(x), Math.round(y), Math.round(z), type, { persist: false, ...options });
}

export function fillRect(world, x1, x2, y, z1, z2, type, options = {}) {
  for (let x = Math.min(x1, x2); x <= Math.max(x1, x2); x += 1) {
    for (let z = Math.min(z1, z2); z <= Math.max(z1, z2); z += 1) setBlock(world, x, y, z, type, options);
  }
}

export function fillBox(world, x1, x2, y1, y2, z1, z2, type, options = {}) {
  for (let y = Math.min(y1, y2); y <= Math.max(y1, y2); y += 1) fillRect(world, x1, x2, y, z1, z2, type, options);
}

export function wall(world, x1, z1, x2, z2, baseY, height, type, { openings = [], options = {} } = {}) {
  const dx = x2 - x1;
  const dz = z2 - z1;
  const steps = Math.max(Math.abs(dx), Math.abs(dz), 1);
  for (let step = 0; step <= steps; step += 1) {
    const x = Math.round(x1 + dx * (step / steps));
    const z = Math.round(z1 + dz * (step / steps));
    for (let y = 0; y < height; y += 1) {
      if (openings.some((opening) => opening(step, y, x, z))) continue;
      setBlock(world, x, baseY + y, z, type, options);
    }
  }
}

export function boxShell(world, cx, baseY, cz, width, height, depth, type, { openings = [], options = {} } = {}) {
  const hx = Math.floor(width / 2);
  const hz = Math.floor(depth / 2);
  const isOpening = (x, y, z) => openings.some((opening) => opening(x, y, z));
  for (let y = 0; y < height; y += 1) {
    for (let x = -hx; x <= hx; x += 1) {
      for (let z = -hz; z <= hz; z += 1) {
        if (Math.abs(x) !== hx && Math.abs(z) !== hz) continue;
        if (!isOpening(x, y, z)) setBlock(world, cx + x, baseY + y, cz + z, type, options);
      }
    }
  }
}

export function column(world, x, baseY, z, height, type, topType = null, options = {}) {
  for (let y = 0; y < height; y += 1) setBlock(world, x, baseY + y, z, y === height - 1 && topType ? topType : type, options);
}

export function line3D(world, start, end, type, options = {}) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const dz = end.z - start.z;
  const steps = Math.max(Math.abs(dx), Math.abs(dy), Math.abs(dz), 1);
  for (let index = 0; index <= steps; index += 1) {
    const t = index / steps;
    setBlock(world, start.x + dx * t, start.y + dy * t, start.z + dz * t, type, options);
  }
}

export function steppedPyramid(world, cx, baseY, cz, size, height, type, capType = type, options = {}) {
  for (let level = 0; level < height; level += 1) {
    const half = Math.max(0, Math.floor(size / 2) - level);
    if (half <= 0) {
      setBlock(world, cx, baseY + level, cz, capType, options);
      continue;
    }
    fillRect(world, cx - half, cx + half, baseY + level, cz - half, cz + half, level === height - 1 ? capType : type, options);
  }
}

export function terracedPlatform(world, cx, baseY, cz, width, depth, levels, type, step = 1) {
  for (let level = 0; level < levels; level += 1) {
    const hx = Math.max(1, Math.floor(width / 2) - level * step);
    const hz = Math.max(1, Math.floor(depth / 2) - level * step);
    fillRect(world, cx - hx, cx + hx, baseY + level, cz - hz, cz + hz, type);
  }
}

export function disc(world, cx, y, cz, radius, type, options = {}) {
  for (let x = -radius; x <= radius; x += 1) {
    for (let z = -radius; z <= radius; z += 1) {
      if (x * x + z * z <= radius * radius + 0.35) setBlock(world, cx + x, y, cz + z, type, options);
    }
  }
}

export function dome(world, cx, baseY, cz, radius, type, capType = type, options = {}) {
  const height = Math.max(2, radius + 1);
  for (let level = 0; level < height; level += 1) {
    const normalized = level / Math.max(1, height - 1);
    const layerRadius = Math.max(0, Math.round(radius * Math.sqrt(Math.max(0, 1 - normalized * normalized))));
    disc(world, cx, baseY + level, cz, layerRadius, level === height - 1 ? capType : type, options);
  }
}

export function spire(world, cx, baseY, cz, height, baseRadius, type, capType = 'lantern') {
  for (let level = 0; level < height; level += 1) {
    const ratio = 1 - level / Math.max(1, height - 1);
    const radius = Math.max(0, Math.floor(baseRadius * ratio));
    if (radius === 0) setBlock(world, cx, baseY + level, cz, level === height - 1 ? capType : type);
    else disc(world, cx, baseY + level, cz, radius, type);
  }
}

export function ellipseRing(world, cx, y, cz, rx, rz, type, { thickness = 0.42, skip = null, options = {} } = {}) {
  const seen = new Set();
  const steps = Math.ceil(Math.PI * Math.max(rx, rz) * 6);
  for (let index = 0; index < steps; index += 1) {
    const angle = (index / steps) * Math.PI * 2;
    const x = Math.round(cx + Math.cos(angle) * rx);
    const z = Math.round(cz + Math.sin(angle) * rz);
    const key = `${x}|${z}`;
    if (seen.has(key) || (skip && skip(x, z, angle, index))) continue;
    seen.add(key);
    setBlock(world, x, y, z, type, options);
    if (thickness > 0.7) {
      const innerX = Math.round(cx + Math.cos(angle) * Math.max(0, rx - 1));
      const innerZ = Math.round(cz + Math.sin(angle) * Math.max(0, rz - 1));
      setBlock(world, innerX, y, innerZ, type, options);
    }
  }
}

export function ellipseWall(world, cx, baseY, cz, rx, rz, height, type, { archEvery = 0, archHeight = 2 } = {}) {
  for (let level = 0; level < height; level += 1) {
    ellipseRing(world, cx, baseY + level, cz, rx, rz, type, {
      thickness: 0.85,
      skip: archEvery > 0
        ? (_x, _z, _angle, index) => level < archHeight && Math.floor(index / 2) % archEvery === 0
        : null
    });
  }
}

export function arch(world, cx, baseY, cz, width, height, type, axis = 'x') {
  const half = Math.floor(width / 2);
  for (let offset = -half; offset <= half; offset += 1) {
    const normalized = offset / Math.max(1, half);
    const curve = Math.sqrt(Math.max(0, 1 - normalized * normalized));
    const openingTop = Math.round(baseY + 1 + curve * (height - 2));
    for (let y = openingTop; y <= baseY + height; y += 1) {
      if (axis === 'x') setBlock(world, cx + offset, y, cz, type);
      else setBlock(world, cx, y, cz + offset, type);
    }
  }
}

export function arcadeWall(world, x1, z1, x2, z2, baseY, height, type, bays = 5) {
  const dx = x2 - x1;
  const dz = z2 - z1;
  const steps = Math.max(Math.abs(dx), Math.abs(dz), 1);
  const bayWidth = Math.max(3, Math.floor(steps / bays));
  for (let step = 0; step <= steps; step += 1) {
    const x = Math.round(x1 + dx * (step / steps));
    const z = Math.round(z1 + dz * (step / steps));
    const local = step % bayWidth;
    const centerDistance = Math.abs(local - bayWidth / 2) / Math.max(1, bayWidth / 2);
    const openingTop = Math.round(1 + Math.sqrt(Math.max(0, 1 - centerDistance * centerDistance)) * (height - 3));
    for (let y = 0; y < height; y += 1) {
      if (local > 0 && local < bayWidth - 1 && y < openingTop) continue;
      setBlock(world, x, baseY + y, z, type);
    }
  }
}

export function staircase(world, start, direction, steps, width, type) {
  for (let step = 0; step < steps; step += 1) {
    for (let lateral = -Math.floor(width / 2); lateral <= Math.floor(width / 2); lateral += 1) {
      const x = start.x + direction.x * step + (direction.z !== 0 ? lateral : 0);
      const z = start.z + direction.z * step + (direction.x !== 0 ? lateral : 0);
      setBlock(world, x, start.y + step, z, type);
    }
  }
}

export function addLabelBeacon(world, x, y, z, colorType = 'lantern') {
  setBlock(world, x, y, z, colorType);
  setBlock(world, x, y - 1, z, 'obsidian');
}

// Beta 4.12 : la route remplace la surface naturelle au lieu de s'y poser. Avant, chaque
// route ajoutait un bloc au-dessus du précédent : au point de départ, où les routes vers
// tous les monuments se croisent, elles formaient une pile de 4 à 5 blocs (joueur coincé).
const PAVABLE = new Set(['grass', 'dirt', 'sand', 'snow', 'stone']);
function paveRoad(world, x, z) {
  const top = world.getTopBlock(Math.round(x), Math.round(z), { solidOnly: true });
  if (top?.type === 'road') return;
  if (top && PAVABLE.has(top.type) && typeof world.removeBlock === 'function') {
    world.removeBlock(top.x, top.y, top.z, { persist: false, force: true });
    setBlock(world, x, top.y, z, 'road');
    return;
  }
  setBlock(world, x, groundY(world, x, z), z, 'road');
}

export function addRoad(world, points, width = 1) {
  for (let index = 0; index < points.length - 1; index += 1) {
    const a = points[index];
    const b = points[index + 1];
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const steps = Math.max(Math.abs(dx), Math.abs(dz), 1);
    for (let step = 0; step <= steps; step += 1) {
      const x = Math.round(a.x + dx * (step / steps));
      const z = Math.round(a.z + dz * (step / steps));
      for (let lateral = -width; lateral <= width; lateral += 1) {
        const rx = Math.abs(dx) >= Math.abs(dz) ? x : x + lateral;
        const rz = Math.abs(dx) >= Math.abs(dz) ? z + lateral : z;
        paveRoad(world, rx, rz);
      }
    }
  }
}
