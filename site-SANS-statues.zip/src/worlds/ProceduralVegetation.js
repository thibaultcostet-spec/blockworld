import { setBlock } from './LandmarkBuilder.js';

export const VEGETATION_STORAGE_KEY = 'blockworld-vegetation-density-v2.1';
export const DEFAULT_VEGETATION_DENSITY = 100;

function hash2D(x, z, seed = 0) {
  const value = Math.sin((x + seed * 19.13) * 127.1 + (z - seed * 7.71) * 311.7) * 43758.5453123;
  return value - Math.floor(value);
}

export function normalizeVegetationDensity(value) {
  if (value === null || value === undefined || value === '') return DEFAULT_VEGETATION_DENSITY;
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return DEFAULT_VEGETATION_DENSITY;
  return Math.max(40, Math.min(160, Math.round(numeric)));
}

export function readVegetationDensity() {
  try {
    return normalizeVegetationDensity(globalThis.localStorage?.getItem(VEGETATION_STORAGE_KEY));
  } catch (_error) {
    return DEFAULT_VEGETATION_DENSITY;
  }
}

function insideReserved(x, z, reservedZones) {
  return reservedZones.some((zone) => Math.hypot(x - zone.x, z - zone.z) <= zone.radius);
}

// Beta 4.26 : esplanades dégagées. Aucun arbre dans le rayon de découverte élargi d'un monument,
// ni dans un couloir de vue le long de la route d'arrivée (départ → monument), comme une zone non aedificandi.
export const MONUMENT_TREE_MARGIN = 6;      // m au-delà du rayon de découverte
export const APPROACH_LENGTH = 44;          // m de couloir dégagé avant le monument
export const APPROACH_HALF_WIDTH = 6;       // m de part et d'autre de l'axe d'arrivée

function distanceToSegment(px, pz, a, b) {
  const dx = b.x - a.x, dz = b.z - a.z;
  const lengthSq = dx * dx + dz * dz || 1;
  const t = Math.max(0, Math.min(1, ((px - a.x) * dx + (pz - a.z) * dz) / lengthSq));
  return Math.hypot(px - (a.x + dx * t), pz - (a.z + dz * t));
}

export function monumentViewZones(definition) {
  const hub = definition.spawn ?? { x: 0, z: 0 };
  return (definition.pointsOfInterest || []).map((poi) => {
    const length = Math.hypot(hub.x - poi.x, hub.z - poi.z) || 1;
    const reach = Math.min(APPROACH_LENGTH, length);
    const start = { x: poi.x + ((hub.x - poi.x) / length) * reach, z: poi.z + ((hub.z - poi.z) / length) * reach };
    return { poi, radius: (poi.discoveryRadius || 16) + MONUMENT_TREE_MARGIN, corridor: { a: start, b: { x: poi.x, z: poi.z }, halfWidth: APPROACH_HALF_WIDTH } };
  });
}

export function insideMonumentView(x, z, zones) {
  return zones.some((zone) => Math.hypot(x - zone.poi.x, z - zone.poi.z) <= zone.radius
    || distanceToSegment(x, z, zone.corridor.a, zone.corridor.b) <= zone.corridor.halfWidth);
}

function canGrowOn(block, allowed = ['grass']) {
  return Boolean(block && allowed.includes(block.type));
}

function placeLeaves(world, x, y, z, radius, { flat = false } = {}) {
  for (let dx = -radius; dx <= radius; dx += 1) {
    for (let dz = -radius; dz <= radius; dz += 1) {
      const distance = flat ? Math.abs(dx) + Math.abs(dz) * 0.8 : Math.hypot(dx, dz);
      if (distance > radius + 0.25) continue;
      setBlock(world, x + dx, y, z + dz, 'leaves');
      if (!flat && distance <= radius - 0.55) setBlock(world, x + dx, y + 1, z + dz, 'leaves');
    }
  }
}

function growOak(world, x, baseY, z, variant) {
  const trunk = variant > 0.82 ? 5 : 4;
  for (let y = 1; y <= trunk; y += 1) setBlock(world, x, baseY + y, z, 'wood');
  placeLeaves(world, x, baseY + trunk, z, 2);
  setBlock(world, x, baseY + trunk + 2, z, 'leaves');
}

function growPine(world, x, baseY, z, variant) {
  const trunk = variant > 0.75 ? 7 : 6;
  for (let y = 1; y <= trunk; y += 1) setBlock(world, x, baseY + y, z, 'wood');
  for (let level = 0; level < 4; level += 1) {
    const radius = Math.max(1, 3 - level);
    placeLeaves(world, x, baseY + trunk - 2 + level, z, radius);
  }
}

function growAcacia(world, x, baseY, z, variant) {
  const trunk = variant > 0.7 ? 5 : 4;
  for (let y = 1; y <= trunk; y += 1) setBlock(world, x, baseY + y, z, 'wood');
  const lean = variant > 0.5 ? 1 : -1;
  setBlock(world, x + lean, baseY + trunk, z, 'wood');
  placeLeaves(world, x + lean, baseY + trunk + 1, z, 3, { flat: true });
}

function growPalm(world, x, baseY, z, variant) {
  const trunk = variant > 0.7 ? 6 : 5;
  for (let y = 1; y <= trunk; y += 1) {
    const lean = y > trunk / 2 ? (variant > 0.5 ? 1 : 0) : 0;
    setBlock(world, x + lean, baseY + y, z, 'wood');
  }
  const crownX = x + (variant > 0.5 ? 1 : 0);
  setBlock(world, crownX, baseY + trunk + 1, z, 'leaves');
  for (let offset = 1; offset <= 3; offset += 1) {
    setBlock(world, crownX + offset, baseY + trunk + 1, z, 'leaves');
    setBlock(world, crownX - offset, baseY + trunk + 1, z, 'leaves');
    setBlock(world, crownX, baseY + trunk + 1, z + offset, 'leaves');
    setBlock(world, crownX, baseY + trunk + 1, z - offset, 'leaves');
  }
}

function growBamboo(world, x, baseY, z, variant) {
  const height = variant > 0.75 ? 7 : 5;
  for (let y = 1; y <= height; y += 1) setBlock(world, x, baseY + y, z, 'bamboo');
  setBlock(world, x + 1, baseY + height - 1, z, 'leaves');
  setBlock(world, x - 1, baseY + height - 2, z, 'leaves');
}

function growEucalyptus(world, x, baseY, z, variant) {
  const trunk = variant > 0.76 ? 7 : 6;
  for (let y = 1; y <= trunk; y += 1) setBlock(world, x, baseY + y, z, 'wood');
  placeLeaves(world, x, baseY + trunk, z, 2, { flat: true });
  placeLeaves(world, x + 1, baseY + trunk + 1, z, 1);
}

function chooseTree(theme, climate, variant) {
  if (theme === 'africa') return 'acacia';
  if (theme === 'oceania') return climate > 0.48 ? 'palm' : 'eucalyptus';
  if (theme === 'asia') return climate > 0.72 ? 'pine' : variant > 0.82 ? 'bamboo' : 'oak';
  if (theme === 'americas') return climate > 0.65 ? 'pine' : 'oak';
  return climate > 0.72 ? 'pine' : 'oak';
}

// Beta 4.14 : les arbres sont dessinés en mini-blocs par MicroVoxelDecor. Le monde ne reçoit plus
// que leur description et une colonne de collision invisible et protégée à l'emplacement du tronc.
const COLLIDER_HEIGHT = { oak: 3, pine: 3, acacia: 2, palm: 4, bamboo: 4, eucalyptus: 4 };
function growTree(world, species, x, baseY, z, variant) {
  if (!world.decorTrees) world.decorTrees = [];
  world.decorTrees.push({ species, x, y: baseY, z, variant });
  for (let y = 1; y <= (COLLIDER_HEIGHT[species] ?? 3); y += 1) setBlock(world, x, baseY + y, z, 'tree_trunk', { protectedBlock: true });
}

function growVoxelTree(world, species, x, baseY, z, variant) {
  if (species === 'pine') growPine(world, x, baseY, z, variant);
  else if (species === 'acacia') growAcacia(world, x, baseY, z, variant);
  else if (species === 'palm') growPalm(world, x, baseY, z, variant);
  else if (species === 'bamboo') growBamboo(world, x, baseY, z, variant);
  else if (species === 'eucalyptus') growEucalyptus(world, x, baseY, z, variant);
  else growOak(world, x, baseY, z, variant);
}

export function generateProceduralVegetation(world, definition, reservedZones = [], options = {}) {
  const density = normalizeVegetationDensity(options.density ?? readVegetationDensity());
  const densityFactor = density / 100;
  const half = Math.floor(definition.size / 2) - 3;
  const seed = definition.seed + 210;
  const treeThreshold = Math.max(0.86, 0.965 - densityFactor * 0.055);
  const groundThreshold = Math.max(0.61, 0.84 - densityFactor * 0.12);
  const stats = { density, trees: 0, shrubs: 0, herbs: 0, flowers: 0, species: {} };
  // Beta 4.14 : espacement minimal entre arbres (auparavant assuré par les feuilles en blocs).
  const treeCells = new Set();
  const viewZones = monumentViewZones(definition);

  for (let x = -half; x <= half; x += 2) {
    for (let z = -half; z <= half; z += 2) {
      if (insideReserved(x, z, reservedZones)) continue;
      const clearing=hash2D(Math.floor(x/14),Math.floor(z/14),seed+91); if(clearing<.22) continue;
      const top = world.getTopBlock(x, z, { solidOnly: true });
      if (!top || ['road', 'water', 'snow', 'stone'].includes(top.type)) continue;

      const climate = hash2D(Math.floor(x / 9), Math.floor(z / 9), seed + 9);
      const treeChance = hash2D(x, z, seed);
      const groundChance = hash2D(x + 31, z - 17, seed + 3);
      const variant = hash2D(x - 13, z + 29, seed + 7);

      const treeSurfaceAllowed = definition.theme === 'oceania'
        ? canGrowOn(top, ['grass', 'sand'])
        : canGrowOn(top, ['grass']);
      const crowded = treeCells.has(`${x}|${z}`);
      const inView = insideMonumentView(x, z, viewZones);
      if (treeSurfaceAllowed && treeChance > treeThreshold && !crowded && !inView) {
        for (let dx = -2; dx <= 2; dx += 2) for (let dz = -2; dz <= 2; dz += 2) treeCells.add(`${x + dx}|${z + dz}`);
        const species = chooseTree(definition.theme, climate, variant);
        growTree(world, species, x, top.y, z, variant);
        stats.trees += 1;
        stats.species[species] = (stats.species[species] ?? 0) + 1;
        continue;
      }

      if (!canGrowOn(top, ['grass']) || groundChance <= groundThreshold) continue;
      const y = top.y + 1;
      if (variant > 0.88) {
        setBlock(world, x, y, z, variant > 0.95 ? 'flower_red' : 'flower_yellow');
        stats.flowers += 1;
      } else if (variant > 0.72) {
        setBlock(world, x, y, z, 'shrub');
        stats.shrubs += 1;
      } else {
        setBlock(world, x, y, z, 'tall_grass');
        stats.herbs += 1;
      }
    }
  }

  world.vegetationStats = stats;
  return stats;
}
