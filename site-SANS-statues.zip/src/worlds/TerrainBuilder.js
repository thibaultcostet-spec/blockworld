import { setBlock } from './LandmarkBuilder.js';

function noise2D(x, z, seed = 0) {
  const value = Math.sin((x + seed * 17) * 127.1 + (z - seed * 11) * 311.7) * 43758.5453;
  return value - Math.floor(value);
}

function smoothNoise(x, z, seed) {
  const large = Math.sin((x + seed) * 0.075) * 0.9 + Math.cos((z - seed) * 0.068) * 0.8;
  const medium = Math.sin((x - z) * 0.13 + seed) * 0.45;
  const warpX=Math.sin(z*.031+seed)*6,warpZ=Math.cos(x*.027-seed)*6;
  const ridge=Math.abs(Math.sin((x+warpX)*.041)+Math.cos((z+warpZ)*.037))*.85;
  const rough=(noise2D(x,z,seed)-.5)*.85;
  return large+medium+ridge+rough;
}

function smoothstep(edge0, edge1, value) {
  const t = Math.max(0, Math.min(1, (value - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

function segmentDistance(px, pz, a, b) {
  const dx = b.x - a.x, dz = b.z - a.z;
  const lengthSq = dx * dx + dz * dz || 1;
  const t = Math.max(0, Math.min(1, ((px - a.x) * dx + (pz - a.z) * dz) / lengthSq));
  return Math.hypot(px - (a.x + dx * t), pz - (a.z + dz * t));
}

/**
 * Beta 4.12 — relief montagneux.
 * Chaque monument et le point de départ forment une vallée ; les crêtes naissent à
 * mi-distance entre deux vallées voisines (frontière de Voronoï) et un massif ferme
 * la carte. Des cols plats sont creusés le long des routes départ → monument.
 * Renvoie un facteur 0..1 (0 = vallée, 1 = crête) et l'amplitude locale.
 */
function mountainField(x, z, definition, half) {
  const hub = definition.spawn ?? { x: 0, z: 0 };
  const sites = [
    { x: hub.x, z: hub.z, radius: 16 },
    ...(definition.pointsOfInterest || []).map((poi) => ({ x: poi.x, z: poi.z, radius: (poi.discoveryRadius || 16) + 7 }))
  ];
  let first = Infinity, second = Infinity;
  for (const site of sites) {
    const distance = Math.hypot(x - site.x, z - site.z) - site.radius;
    if (distance < first) { second = first; first = distance; }
    else if (distance < second) second = distance;
  }
  const valley = smoothstep(2, 16, first);
  const ridge = 1 - smoothstep(0, 26, second - first);
  let passes = 1;
  for (const poi of definition.pointsOfInterest || []) passes = Math.min(passes, smoothstep(4, 13, segmentDistance(x, z, hub, poi)));
  const edge = definition.theme === 'oceania' ? 0 : smoothstep(half - 34, half - 4, Math.max(Math.abs(x), Math.abs(z)));
  const peaks = 0.62 + 0.38 * Math.abs(Math.sin(x * 0.083 + definition.seed) * Math.cos(z * 0.071 - definition.seed));
  return { factor: Math.max(ridge * valley * passes, edge), peaks };
}

const MOUNTAIN_AMPLITUDE = { europe: 30, asia: 34, americas: 36, africa: 22, oceania: 18 };

export function buildContinentTerrain(world, definition) {
  const half = Math.floor(definition.size / 2);
  const theme = definition.theme;
  const hub = definition.spawn ?? { x: 0, z: 0 };
  const width = half * 2 + 1;
  const index = (x, z) => (x + half) * width + (z + half);
  const heights = new Int16Array(width * width);
  const cells = new Array(width * width);

  for (let x = -half; x <= half; x += 1) {
    for (let z = -half; z <= half; z += 1) {
      const relief = smoothNoise(x, z, definition.seed);
      let height = Math.max(1, Math.min(12, Math.round(2.1 + relief * 1.55)));
      if (Math.hypot(x - hub.x, z - hub.z) < 13) height = Math.min(height, 3);
      let surface = 'grass';
      let sub = 'dirt';
      let water = false;

      if (theme === 'africa') {
        height = Math.max(1, Math.min(5, Math.round(2 + relief * 0.45)));
        surface = noise2D(x + 9, z - 3, definition.seed) > 0.82 ? 'grass' : 'sand';
        sub = 'sand';
      } else if (theme === 'oceania') {
        height = Math.max(1, Math.min(5, height));
        surface = noise2D(x, z, 7) > 0.84 ? 'sand' : 'grass';
      }

      // Relief montagneux (hors eau), puis aplanissement des esplanades de monuments.
      const { factor, peaks } = mountainField(x, z, definition, half);
      const amplitude = MOUNTAIN_AMPLITUDE[theme] ?? 28;
      const rough = (noise2D(x * 0.5, z * 0.5, definition.seed + 5) - 0.5) * 3;
      height += Math.round(factor * factor * amplitude * peaks + factor * rough);
      for (const poi of definition.pointsOfInterest || []) {
        const inner = (poi.discoveryRadius || 16) * 0.8;
        const blend = smoothstep(inner, inner + 9, Math.hypot(x - poi.x, z - poi.z));
        if (blend < 1) height = Math.round(Math.min(height, 4) * (1 - blend) + height * blend);
      }
      height = Math.max(1, Math.min(48, height));

      // Eau et spécificités de chaque continent (coordonnées d'origine conservées).
      if (theme === 'africa') {
        const oasis = Math.hypot(x + 5, z - 3) < 7.5;
        const river = Math.abs(x - Math.sin(z * 0.09) * 6) <= 1 && z > -45 && z < 35;
        if ((oasis || river) && height <= 8) { height = 1; water = true; surface = 'sand'; }
      } else if (theme === 'asia') {
        if (z > 30 && factor < 0.4) height = Math.min(12, height + Math.round((z - 30) / 9));
        const lake = Math.hypot(x - 11, z + 9) < 6.5;
        if (lake) { height = 1; water = true; surface = 'sand'; }
      } else if (theme === 'americas') {
        if (z > 25 && factor < 0.4) height = Math.min(14, height + Math.round((z - 25) / 7));
        const river = Math.abs(x + 4 + Math.round(Math.sin(z * 0.1) * 3)) <= 1 && z < 25;
        if (river) { height = 1; water = true; surface = 'sand'; }
      } else if (theme === 'oceania') {
        const edge = Math.max(Math.abs(x), Math.abs(z));
        const lagoon = Math.hypot(x + 13, z - 11) < 7;
        if (edge > half - 7 || lagoon) { height = 0; water = true; surface = 'sand'; }
      } else {
        // Rivière européenne : elle creuse une gorge à travers les crêtes.
        const river = Math.abs(x + Math.round(Math.sin(z * 0.07) * 7)) <= 1 && z > -half + 12 && z < half - 12;
        if (river) { height = 1; water = true; surface = 'sand'; }
      }

      // Étagement : prairie → roche → neige (sable puis roche en Afrique et en Océanie).
      if (!water) {
        if (theme === 'africa' || theme === 'oceania') {
          if (height >= 13) { surface = 'stone'; sub = 'stone'; }
        } else if (height >= 30 - Math.round(noise2D(x, z, definition.seed + 9) * 3)) { surface = 'snow'; sub = 'stone'; }
        else if (height >= 15) { surface = 'grass'; sub = 'stone'; }
      }
      heights[index(x, z)] = height;
      cells[index(x, z)] = { surface, sub, water };
    }
  }

  for (let x = -half; x <= half; x += 1) {
    for (let z = -half; z <= half; z += 1) {
      const height = heights[index(x, z)];
      let { surface, sub, water } = cells[index(x, z)];
      // Beta 4.12 : versants pleins. Le terrain reste creux, sauf les faces exposées
      // (plus haut qu'un voisin) : sans cela, falaises et montagnes seraient trouées.
      let lowest = height;
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = x + dx, nz = z + dz;
        if (nx < -half || nx > half || nz < -half || nz > half) continue;
        lowest = Math.min(lowest, heights[index(nx, nz)]);
      }
      // Beta 4.13 : en montagne, l'herbe ne tient que sur les replats ; roche nue sur les pentes.
      if (!water && height >= 10 && height - lowest >= 2 && surface === 'grass') { surface = 'stone'; sub = 'stone'; }
      setBlock(world, x, 0, z, 'stone');
      if (height > 1) setBlock(world, x, height - 1, z, sub);
      setBlock(world, x, height, z, surface);
      for (let y = Math.max(1, lowest); y <= height - 2; y += 1) setBlock(world, x, y, z, y >= height - 3 ? sub : 'stone');
      if (water) for (let y = height + 1; y <= 2; y += 1) setBlock(world, x, y, z, 'water');
    }
  }
}

export { generateProceduralVegetation as addVegetation } from './ProceduralVegetation.js';
