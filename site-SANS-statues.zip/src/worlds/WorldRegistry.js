import { EUROPE_WORLD } from './continents/EuropeWorld.js';
import { AFRICA_WORLD } from './continents/AfricaWorld.js';
import { ASIA_WORLD } from './continents/AsiaWorld.js';
import { AMERICAS_WORLD } from './continents/AmericasWorld.js';
import { OCEANIA_WORLD } from './continents/OceaniaWorld.js';

export const WORLD_DEFINITIONS = [EUROPE_WORLD, AFRICA_WORLD, ASIA_WORLD, AMERICAS_WORLD, OCEANIA_WORLD];
export const WORLD_BY_ID = new Map(WORLD_DEFINITIONS.map((world) => [world.id, world]));
export const DEFAULT_WORLD_ID = 'europe';

export function getWorldDefinition(id) {
  return WORLD_BY_ID.get(id) ?? WORLD_BY_ID.get(DEFAULT_WORLD_ID);
}
