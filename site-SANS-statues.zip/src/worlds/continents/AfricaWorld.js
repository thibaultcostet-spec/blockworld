import { buildContinentTerrain, addVegetation } from '../TerrainBuilder.js';
import { buildCaves } from '../../caves/CaveBuilder.js';
import { placeBlueprint } from '../monuments/MonumentKit.js';
import { gizaBlueprint } from '../monuments/Giza.js';
import {
  groundY, setBlock, fillRect, fillBox, column, line3D, boxShell, dome,
  addRoad, steppedPyramid, spire, arcadeWall, staircase, terracedPlatform
} from '../LandmarkBuilder.js';

// Beta 4.30 : pont Maputo–Katembe retravaillé (premier monument « ingénierie »). Pont suspendu au-dessus d'une
// baie : deux pylônes en béton en H, tablier caisson en acier, viaducs d'accès sur piles, massifs d'ancrage et
// rampes. Les câbles porteurs et les suspentes (fins) sont dessinés par MonumentVisualEnhancer d'après MAPUTO_BRIDGE.
export const MAPUTO_BRIDGE = Object.freeze({ cx: 0, cz: -27, deckY: 9, pylonX: 22, topY: 31, legZ: [5, 6], cableZ: 4.4, sagY: 3.2, anchorX: 41, endX: 46, bay: { rx: 24, rz: 12 } });

function maputoBridge(world, cx, cz) {
  const B = MAPUTO_BRIDGE;
  const yd = B.deckY;
  const clearColumn = (x, z, fromY) => {
    for (let guard = 0; guard < 96; guard += 1) {
      const top = world.getTopBlock(x, z);
      if (!top || top.y < fromY || !world.removeBlock(x, top.y, z, { persist: false, force: true })) break;
    }
  };
  // 1. La baie : fond de sable, une couche d'eau, plage en pente douce autour.
  for (let x = -Math.ceil(B.bay.rx * 1.35); x <= Math.ceil(B.bay.rx * 1.35); x += 1) {
    for (let z = -Math.ceil(B.bay.rz * 1.35); z <= Math.ceil(B.bay.rz * 1.35); z += 1) {
      const r = Math.hypot(x / B.bay.rx, z / B.bay.rz);
      if (r > 1.32) continue;
      const wx = cx + x, wz = cz + z;
      if (r <= 1) {
        clearColumn(wx, wz, 1);
        setBlock(world, wx, 1, wz, 'sand');
        setBlock(world, wx, 2, wz, 'water');
      } else {
        const target = 2 + Math.floor((r - 1) * 14);
        const top = groundY(world, wx, wz) - 1;
        if (top > target) { clearColumn(wx, wz, target + 1); world.removeBlock(wx, target, wz, { persist: false, force: true }); setBlock(world, wx, target, wz, 'sand'); }
      }
    }
  }
  // 2. Tablier : chaussée à 5 voies de large, trottoirs en béton, poutres de rive et caisson en acier dessous.
  for (let x = -B.endX; x <= B.endX; x += 1) {
    for (let z = -4; z <= 4; z += 1) {
      const type = Math.abs(z) === 4 ? 'steel' : Math.abs(z) === 3 ? 'concrete' : 'road';
      world.removeBlock(cx + x, yd, cz + z, { persist: false, force: true });
      setBlock(world, cx + x, yd, cz + z, type);
      if (Math.abs(z) <= 3) setBlock(world, cx + x, yd - 1, cz + z, 'steel');
    }
    for (const z of [-4, 4]) {
      const atPylon = Math.abs(Math.abs(x) - B.pylonX - 0.5) <= 1;
      if (!atPylon) setBlock(world, cx + x, yd + 1, cz + z, x % 8 === 0 ? 'lantern' : 'glass'); // garde-corps vitré
    }
  }
  // 3. Pylônes en H : deux jambes 2 × 2, traverse sous le tablier et traverse haute, feux de balisage.
  for (const side of [-1, 1]) {
    const px = side * B.pylonX;
    for (const dx of [0, side]) {
      for (const zs of [-1, 1]) for (const dz of B.legZ) {
        const z = zs * dz;
        for (let y = 1; y <= B.topY; y += 1) { world.removeBlock(cx + px + dx, y, cz + z, { persist: false, force: true }); setBlock(world, cx + px + dx, y, cz + z, 'concrete'); }
        if (dx === 0) setBlock(world, cx + px, B.topY + 1, cz + z, 'lantern');
      }
      for (let z = -6; z <= 6; z += 1) {
        for (const y of [yd - 2, B.topY - 2, B.topY - 1]) setBlock(world, cx + px + dx, y, cz + z, 'concrete');
      }
    }
    // Semelle de fondation dans la baie.
    for (let dx = -1; dx <= 2; dx += 1) for (let z = -7; z <= 7; z += 1) { const x = cx + px + (side > 0 ? dx : -dx); world.removeBlock(x, 2, cz + z, { persist: false, force: true }); setBlock(world, x, 2, cz + z, 'concrete'); }
  }
  // 4. Massifs d'ancrage des câbles, de chaque côté du tablier.
  for (const side of [-1, 1]) {
    for (let x = B.anchorX; x <= B.anchorX + 4; x += 1) for (const zs of [-1, 1]) for (const dz of [5, 6]) {
      const wx = cx + side * x, wz = cz + zs * dz;
      for (let y = groundY(world, wx, wz); y <= yd + 2; y += 1) setBlock(world, wx, y, wz, 'concrete');
    }
  }
  // 5. Piles des viaducs d'accès (décalées si une route passe dessous).
  for (const side of [-1, 1]) {
    for (const base of [29, 35]) {
      let x = side * base;
      for (const shift of [0, 2, -2, 4]) {
        const tx = side * (base + shift);
        const blocked = [-3, 0, 3].some((z) => world.getTopBlock(cx + tx, cz + z)?.type === 'road');
        if (!blocked) { x = tx; break; }
      }
      for (const z of [-3, -2, 2, 3]) column(world, cx + x, groundY(world, cx + x, cz + z), cz + z, Math.max(1, yd - 1 - groundY(world, cx + x, cz + z)), 'concrete');
      for (let z = -3; z <= 3; z += 1) setBlock(world, cx + x, yd - 2, cz + z, 'concrete');
    }
  }
  // 6. Rampes d'accès (une marche tous les deux blocs) jusqu'au terrain.
  for (const side of [-1, 1]) {
    for (let i = 1; i <= 24; i += 1) {
      const x = cx + side * (B.endX + i);
      const level = yd - Math.ceil(i / 2);
      const ground = Math.max(...[-3, 0, 3].map((z) => groundY(world, x, cz + z) - 1));
      if (level <= ground) break;
      for (let z = -3; z <= 3; z += 1) {
        for (let y = groundY(world, x, cz + z); y < level; y += 1) setBlock(world, x, y, cz + z, 'stone');
        const below = world.getTopBlock(x, cz + z);
        const onRoad = below?.type === 'road' && below.y === level - 1; // pas deux routes empilées
        setBlock(world, x, level, cz + z, Math.abs(z) === 3 || onRoad ? 'concrete' : 'road');
      }
    }
  }
}

function djenne(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 12, cx + 12, y, cz - 10, cz + 10, 'sand');
  boxShell(world, cx, y + 1, cz, 21, 10, 17, 'dirt', {
    openings: [
      (x, yy, z) => z === -8 && Math.abs(x) <= 2 && yy < 6,
      (x, yy, z) => Math.abs(z) === 8 && x % 5 === 0 && yy >= 3 && yy <= 5
    ]
  });
  for (const x of [-8, -4, 0, 4, 8]) {
    column(world, cx + x, y + 1, cz - 7, 15 + (x === 0 ? 3 : 0), 'dirt');
    spire(world, cx + x, y + 16 + (x === 0 ? 3 : 0), cz - 7, 4, 1, 'dirt', 'lantern');
    for (let yy = 4; yy < 14; yy += 3) {
      setBlock(world, cx + x - 1, y + yy, cz - 9, 'wood');
      setBlock(world, cx + x + 1, y + yy, cz - 9, 'wood');
    }
  }
  for (let x = -10; x <= 10; x += 3) {
    for (let yy = 3; yy <= 8; yy += 3) setBlock(world, cx + x, y + yy, cz + 9, 'wood');
  }
  staircase(world, { x: cx, y: y + 1, z: cz - 13 }, { x: 0, z: 1 }, 5, 5, 'sand');
}

function axum(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 13, cx + 13, y, cz - 11, cz + 11, 'grass');
  const obelisks = [[-7, -1, 24], [1, -5, 19], [8, 4, 14]];
  for (const [x, z, h] of obelisks) {
    terracedPlatform(world, cx + x, y + 1, cz + z, 7, 7, 3, 'stone');
    fillBox(world, cx + x - 1, cx + x + 1, y + 4, y + h, cz + z - 1, cz + z + 1, 'stone');
    for (let yy = 6; yy < h; yy += 4) {
      setBlock(world, cx + x, y + yy, cz + z - 2, 'obsidian');
      setBlock(world, cx + x, y + yy, cz + z + 2, 'obsidian');
    }
    spire(world, cx + x, y + h + 1, cz + z, 4, 1, 'stone', 'lantern');
  }
  // Ruines et stèles secondaires.
  for (let x = -11; x <= 11; x += 4) column(world, cx + x, y + 1, cz + 9, 5 + Math.abs(x % 3), 'stone');
}

function basilica(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 15, cx + 15, y, cz - 13, cz + 13, 'concrete');
  boxShell(world, cx, y + 1, cz, 23, 10, 19, 'concrete', {
    openings: [
      (x, yy, z) => z === -9 && Math.abs(x) <= 3 && yy < 7,
      (x, yy, z) => Math.abs(z) === 9 && x % 5 === 0 && yy >= 3 && yy <= 6
    ]
  });
  for (let x = -10; x <= 10; x += 4) {
    column(world, cx + x, y + 1, cz - 11, 10, 'concrete');
    setBlock(world, cx + x, y + 7, cz - 12, 'window');
  }
  dome(world, cx, y + 11, cz, 9, 'concrete', 'lantern');
  spire(world, cx, y + 21, cz, 5, 1, 'rail', 'lantern');
  for (const [x, z] of [[-11, -9], [11, -9], [-11, 9], [11, 9]]) spire(world, cx + x, y + 11, cz + z, 6, 2, 'concrete', 'lantern');
  arcadeWall(world, cx - 12, cz - 10, cx + 12, cz - 10, y + 2, 7, 'concrete', 7);
}

export const AFRICA_WORLD = {
  id: 'africa', label: 'Afrique', icon: '🌍', accent: '#e4a64f', theme: 'africa', seed: 23, size: 224,
  description: 'Grande carte africaine : désert, savane, fleuve et monuments détaillés.',
  landmarks: ['Pyramides de Gizeh et Sphinx', 'Pont Maputo–Katembe', 'Grande Mosquée de Djenné', 'Obélisques d’Axoum', 'Basilique Notre-Dame de la Paix'],
  pointsOfInterest: [
    { id: 'giza', name: 'Pyramides de Gizeh et Sphinx', icon: '🔺', x: -54, z: -51, region: 'Gizeh · Égypte', discoveryRadius: 20, passportText: 'Un ensemble de pyramides monumentales gardé par une grande silhouette de sphinx.' },
    { id: 'maputo', name: 'Pont Maputo–Katembe', icon: '🌉', x: 0, z: -27, region: 'Maputo · Mozambique', discoveryRadius: 18, viewpoint: { x: 14, z: -6 }, passportText: 'Le plus long pont suspendu d’Afrique : deux pylônes de béton portent les câbles qui soutiennent le tablier au-dessus de la baie.' },
    { id: 'djenne', name: 'Grande Mosquée de Djenné', icon: '🕌', x: 54, z: -51, region: 'Djenné · Mali', discoveryRadius: 18, passportText: 'Une architecture de terre reconnaissable à ses tours et à ses poutres de bois apparentes.' },
    { id: 'axum', name: 'Obélisques d’Axoum', icon: '🗿', x: -54, z: 52, region: 'Axoum · Éthiopie', discoveryRadius: 17, passportText: 'De hautes stèles de pierre dressées sur des plateformes, décorées de motifs géométriques.' },
    { id: 'yamoussoukro', name: 'Basilique Notre-Dame de la Paix', icon: '⛪', x: 54, z: 52, region: 'Yamoussoukro · Côte d’Ivoire', discoveryRadius: 20, passportText: 'Une vaste basilique à grand dôme, entourée de colonnades et de larges parvis.' }
  ],
  spawn: { x: 0, z: 22 },
  battleSpawns: [{ x: -68, z: -66 }, { x: 68, z: -66 }, { x: -68, z: 66 }, { x: 68, z: 66 }],
  generate(world) {
    buildContinentTerrain(world, this);
    const places = [{ x: -54, z: -51 }, { x: 0, z: -27 }, { x: 54, z: -51 }, { x: -54, z: 52 }, { x: 54, z: 52 }];
    // Beta 4.30 : la route du pont Maputo arrive par la rampe est (le centre du pont est au-dessus de la baie).
    for (const point of places) addRoad(world, [{ x: 0, z: 22 }, point === places[1] ? { x: 60, z: -27 } : point], 2);
    placeBlueprint(world, gizaBlueprint(), places[0].x, places[0].z); // Beta 4.33 : Gizeh retravaillé (plan pur, voir monuments/Giza.js)
    maputoBridge(world, places[1].x, places[1].z);
    djenne(world, places[2].x, places[2].z);
    axum(world, places[3].x, places[3].z);
    basilica(world, places[4].x, places[4].z);
    const bridgeZones = [-52, -36, 36, 52].map((x) => ({ x, z: -27, radius: 12 }));
    addVegetation(world, this, [...places.map((p) => ({ ...p, radius: p === places[1] ? 30 : 18 })), ...bridgeZones, { x: 0, z: 22, radius: 12 }]);
    buildCaves(world, this); // Beta 4.32 : grotte du continent (tunnel dans la montagne, salles, lac, trésors)
  }
};
