import { buildContinentTerrain, addVegetation } from '../TerrainBuilder.js';
import { buildCaves } from '../../caves/CaveBuilder.js';
import { placeBlueprint } from '../monuments/MonumentKit.js';
import { goldenGateBlueprint, BRIDGE_BASE_Y, GOLDEN_GATE } from '../monuments/Bridges.js';
import {
  groundY, setBlock, fillRect, fillBox, column, line3D, boxShell, dome,
  addRoad, steppedPyramid, spire, arcadeWall, staircase, terracedPlatform
} from '../LandmarkBuilder.js';

function liberty(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 10, cx + 10, y, cz - 10, cz + 10, 'water');
  terracedPlatform(world, cx, y + 1, cz, 13, 13, 5, 'stone');
  fillBox(world, cx - 3, cx + 3, y + 6, y + 12, cz - 3, cz + 3, 'concrete');
  // Robe et torse.
  terracedPlatform(world, cx, y + 13, cz, 9, 7, 5, 'grass');
  fillBox(world, cx - 2, cx + 2, y + 18, y + 25, cz - 2, cz + 2, 'grass');
  fillBox(world, cx - 2, cx + 2, y + 26, y + 29, cz - 2, cz + 2, 'sand');
  // Bras, tablette et torche.
  line3D(world, { x: cx - 2, y: y + 23, z: cz }, { x: cx - 7, y: y + 22, z: cz }, 'grass');
  fillBox(world, cx - 9, cx - 6, y + 20, y + 24, cz - 1, cz + 1, 'stone');
  line3D(world, { x: cx + 2, y: y + 24, z: cz }, { x: cx + 7, y: y + 31, z: cz }, 'grass');
  column(world, cx + 7, y + 31, cz, 6, 'rail', 'lantern');
  // Couronne.
  for (let index = 0; index < 7; index += 1) {
    const angle = index / 7 * Math.PI * 2;
    line3D(world,
      { x: cx + Math.cos(angle) * 2, y: y + 29, z: cz + Math.sin(angle) * 2 },
      { x: cx + Math.cos(angle) * 5, y: y + 33, z: cz + Math.sin(angle) * 5 },
      'rail');
  }
  addRoad(world, [{ x: cx, z: cz + 10 }, { x: cx, z: cz + 16 }], 1);
}

function christ(world, cx, cz) {
  const y = groundY(world, cx, cz);
  terracedPlatform(world, cx, y, cz, 17, 13, 6, 'stone');
  fillBox(world, cx - 3, cx + 3, y + 6, y + 14, cz - 3, cz + 3, 'concrete');
  // Corps et tête.
  fillBox(world, cx - 2, cx + 2, y + 15, y + 28, cz - 2, cz + 2, 'concrete');
  fillBox(world, cx - 2, cx + 2, y + 29, y + 33, cz - 2, cz + 2, 'sand');
  setBlock(world, cx - 1, y + 31, cz - 3, 'obsidian');
  setBlock(world, cx + 1, y + 31, cz - 3, 'obsidian');
  // Bras étendus et drapé.
  line3D(world, { x: cx - 2, y: y + 26, z: cz }, { x: cx - 16, y: y + 25, z: cz }, 'concrete');
  line3D(world, { x: cx + 2, y: y + 26, z: cz }, { x: cx + 16, y: y + 25, z: cz }, 'concrete');
  for (let x = -14; x <= 14; x += 3) setBlock(world, cx + x, y + 24, cz + 1, 'concrete');
  staircase(world, { x: cx, y: y, z: cz - 15 }, { x: 0, z: 1 }, 8, 5, 'stone');
}

function machu(world, cx, cz) {
  const y = groundY(world, cx, cz);
  for (let level = 0; level < 9; level += 1) {
    const hx = 16 - level;
    const hz = 13 - level;
    fillRect(world, cx - hx, cx + hx, y + level, cz - hz, cz + hz, level % 2 === 0 ? 'grass' : 'stone');
  }
  // Maisons, temples et murs en pierre.
  const houses = [[-10, -5], [-4, -6], [4, -5], [10, -4], [-8, 3], [0, 4], [8, 5]];
  for (const [x, z] of houses) {
    boxShell(world, cx + x, y + 9, cz + z, 6, 5, 5, 'stone', {
      openings: [(xx, yy, zz) => zz === -2 && xx === 0 && yy < 3]
    });
    steppedPyramid(world, cx + x, y + 14, cz + z, 7, 3, 'roof', 'roof');
  }
  fillBox(world, cx - 4, cx + 4, y + 9, y + 15, cz + 8, cz + 11, 'stone');
  for (let x = -15; x <= 15; x += 4) line3D(world, { x: cx + x, y: y + 2, z: cz - 13 }, { x: cx + x, y: y + 8, z: cz - 6 }, 'stone');
  staircase(world, { x: cx, y: y, z: cz - 18 }, { x: 0, z: 1 }, 10, 5, 'stone');
}

function chichen(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 15, cx + 15, y, cz - 15, cz + 15, 'grass');
  steppedPyramid(world, cx, y + 1, cz, 25, 12, 'stone');
  boxShell(world, cx, y + 13, cz, 9, 7, 9, 'stone', {
    openings: [(x, yy, z) => z === -4 && Math.abs(x) <= 1 && yy < 5]
  });
  steppedPyramid(world, cx, y + 20, cz, 11, 4, 'stone', 'lantern');
  // Quatre escaliers et temple des guerriers.
  staircase(world, { x: cx, y: y + 1, z: cz - 13 }, { x: 0, z: 1 }, 12, 3, 'sand');
  staircase(world, { x: cx - 13, y: y + 1, z: cz }, { x: 1, z: 0 }, 12, 3, 'sand');
  staircase(world, { x: cx + 13, y: y + 1, z: cz }, { x: -1, z: 0 }, 12, 3, 'sand');
  for (let x = -12; x <= 12; x += 2) column(world, cx + x, y + 1, cz + 18, 5, 'stone');
  arcadeWall(world, cx - 13, cz + 20, cx + 13, cz + 20, y + 1, 6, 'stone', 7);
}

export const AMERICAS_WORLD = {
  id: 'americas', label: 'Amériques', icon: '🗽', accent: '#5aa9e6', theme: 'americas', seed: 51, size: 224,
  description: 'Grande carte des Amériques : fleuve, montagne, ponts, statues et cités anciennes.',
  landmarks: ['Statue de la Liberté', 'Golden Gate Bridge', 'Christ Rédempteur', 'Machu Picchu', 'Chichén Itzá'],
  pointsOfInterest: [
    { id: 'liberty', name: 'Statue de la Liberté', icon: '🗽', x: -54, z: -51, region: 'New York · États-Unis', discoveryRadius: 18, passportText: 'Une statue dressée sur un socle, tenant une torche visible de très loin.' },
    { id: 'golden-gate', name: 'Golden Gate Bridge', icon: '🌉', x: 0, z: -28, region: 'San Francisco · États-Unis', discoveryRadius: 19, viewpoint: GOLDEN_GATE.viewpoint, passportText: 'Un pont suspendu à deux grandes tours, traversant un large passage maritime.' },
    { id: 'christ', name: 'Christ Rédempteur', icon: '🗿', x: 54, z: -51, region: 'Rio de Janeiro · Brésil', discoveryRadius: 18, passportText: 'Une statue monumentale aux bras ouverts, installée sur un haut promontoire.' },
    { id: 'machu-picchu', name: 'Machu Picchu', icon: '⛰️', x: -54, z: 52, region: 'Andes · Pérou', discoveryRadius: 22, passportText: 'Une cité de pierre étagée sur la montagne, composée de terrasses, murs et maisons.' },
    { id: 'chichen-itza', name: 'Chichén Itzá', icon: '🔺', x: 54, z: 52, region: 'Yucatán · Mexique', discoveryRadius: 19, passportText: 'Une pyramide à degrés dotée de quatre grands escaliers et d’un temple au sommet.' }
  ],
  spawn: { x: 0, z: 22 },
  battleSpawns: [{ x: -68, z: -66 }, { x: 68, z: -66 }, { x: -68, z: 66 }, { x: 68, z: 66 }],
  generate(world) {
    buildContinentTerrain(world, this);
    const places = [{ x: -54, z: -51 }, { x: 0, z: -28 }, { x: 54, z: -51 }, { x: -54, z: 52 }, { x: 54, z: 52 }];
    // Beta 4.34 : la route du Golden Gate arrive par la rampe est (le centre du pont est au-dessus de la baie).
    for (const point of places) addRoad(world, [{ x: 0, z: 22 }, point === places[1] ? { x: 60, z: places[1].z } : point], 2);
    liberty(world, places[0].x, places[0].z);
    placeBlueprint(world, goldenGateBlueprint(), places[1].x, places[1].z, { baseY: BRIDGE_BASE_Y }); // Beta 4.34 : pont suspendu retravaillé (plan pur, voir monuments/Bridges.js)
    christ(world, places[2].x, places[2].z);
    machu(world, places[3].x, places[3].z);
    chichen(world, places[4].x, places[4].z);
    const bridgeZones = [-52, -36, 36, 52].map((x) => ({ x, z: places[1].z, radius: 12 }));
    addVegetation(world, this, [...places.map((p) => ({ ...p, radius: p === places[1] ? 30 : 19 })), ...bridgeZones, { x: 0, z: 22, radius: 12 }]);
    buildCaves(world, this); // Beta 4.32 : grotte du continent (tunnel dans la montagne, salles, lac, trésors)
  }
};
