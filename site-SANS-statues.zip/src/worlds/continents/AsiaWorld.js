import { buildContinentTerrain, addVegetation } from '../TerrainBuilder.js';
import { buildCaves } from '../../caves/CaveBuilder.js';
import {
  groundY, setBlock, fillRect, fillBox, column, line3D, boxShell, dome,
  addRoad, steppedPyramid, spire, arcadeWall, staircase, terracedPlatform
} from '../LandmarkBuilder.js';

function taj(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 15, cx + 15, y, cz - 14, cz + 14, 'concrete');
  // Bassin et allée centrale.
  fillRect(world, cx - 2, cx + 2, y + 1, cz - 21, cz - 10, 'water');
  addRoad(world, [{ x: cx, z: cz - 24 }, { x: cx, z: cz - 10 }], 2);
  terracedPlatform(world, cx, y + 1, cz, 25, 21, 3, 'concrete');
  boxShell(world, cx, y + 4, cz, 19, 10, 15, 'concrete', {
    openings: [
      (x, yy, z) => z === -7 && Math.abs(x) <= 3 && yy < 8,
      (x, yy, z) => Math.abs(z) === 7 && Math.abs(x) === 6 && yy >= 3 && yy <= 7
    ]
  });
  dome(world, cx, y + 14, cz, 7, 'concrete', 'lantern');
  spire(world, cx, y + 22, cz, 6, 1, 'rail', 'lantern');
  for (const [x, z] of [[-12, -10], [12, -10], [-12, 10], [12, 10]]) {
    column(world, cx + x, y + 4, cz + z, 20, 'concrete');
    for (let yy = 7; yy < 20; yy += 4) setBlock(world, cx + x, y + yy, cz + z - Math.sign(z), 'window');
    dome(world, cx + x, y + 24, cz + z, 2, 'concrete', 'lantern');
    spire(world, cx + x, y + 27, cz + z, 4, 1, 'rail', 'lantern');
  }
  for (let x = -7; x <= 7; x += 4) {
    setBlock(world, cx + x, y + 8, cz - 8, 'window');
    setBlock(world, cx + x, y + 11, cz - 8, 'window');
  }
  arcadeWall(world, cx - 9, cz - 8, cx + 9, cz - 8, y + 4, 9, 'concrete', 5);
}

function greatWall(world, cx, cz) {
  const points = [
    { x: cx - 46, z: cz - 8 }, { x: cx - 34, z: cz - 1 }, { x: cx - 22, z: cz - 7 },
    { x: cx - 10, z: cz + 3 }, { x: cx + 2, z: cz - 5 }, { x: cx + 14, z: cz + 4 },
    { x: cx + 27, z: cz - 2 }, { x: cx + 45, z: cz + 7 }
  ];
  const path = [];
  const used = new Set();
  for (let segment = 0; segment < points.length - 1; segment += 1) {
    const a = points[segment];
    const b = points[segment + 1];
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const steps = Math.max(Math.abs(dx), Math.abs(dz));
    for (let step = 0; step <= steps; step += 1) {
      const x = Math.round(a.x + dx * step / steps);
      const z = Math.round(a.z + dz * step / steps);
      const key = `${x}|${z}`;
      if (used.has(key)) continue;
      used.add(key);
      path.push({ x, z, gy: groundY(world, x, z), tower: path.length % 14 === 0 });
    }
  }
  // Les hauteurs sont relevées avant construction, afin que le mur ne s'empile pas sur lui-même.
  for (const point of path) {
    fillBox(world, point.x - 1, point.x + 1, point.gy, point.gy + 3, point.z - 1, point.z + 1, 'bricks');
    if ((point.x + point.z) % 2 === 0) {
      setBlock(world, point.x - 1, point.gy + 4, point.z, 'stone');
      setBlock(world, point.x + 1, point.gy + 4, point.z, 'stone');
    }
    if (point.tower) {
      fillBox(world, point.x - 3, point.x + 3, point.gy, point.gy + 7, point.z - 3, point.z + 3, 'stone');
      boxShell(world, point.x, point.gy + 8, point.z, 7, 4, 7, 'bricks', {
        openings: [(xx, yy, zz) => zz === -3 && Math.abs(xx) <= 1 && yy < 3]
      });
      steppedPyramid(world, point.x, point.gy + 12, point.z, 9, 3, 'roof', 'lantern');
    }
  }
}
function angkor(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 17, cx + 17, y, cz - 15, cz + 15, 'grass');
  // Douves.
  for (let x = -17; x <= 17; x += 1) {
    setBlock(world, cx + x, y + 1, cz - 15, 'water');
    setBlock(world, cx + x, y + 1, cz + 15, 'water');
  }
  for (let z = -15; z <= 15; z += 1) {
    setBlock(world, cx - 17, y + 1, cz + z, 'water');
    setBlock(world, cx + 17, y + 1, cz + z, 'water');
  }
  addRoad(world, [{ x: cx, z: cz - 20 }, { x: cx, z: cz - 10 }], 2);
  terracedPlatform(world, cx, y + 1, cz, 27, 23, 5, 'stone');
  boxShell(world, cx, y + 6, cz, 21, 7, 17, 'stone', {
    openings: [
      (x, yy, z) => z === -8 && Math.abs(x) <= 2 && yy < 5,
      (x, yy, z) => Math.abs(z) === 8 && Math.abs(x) === 7 && yy >= 2 && yy <= 5
    ]
  });
  const towers = [[0, 0, 17], [-8, -5, 13], [8, -5, 13], [-8, 5, 12], [8, 5, 12]];
  for (const [x, z, h] of towers) {
    terracedPlatform(world, cx + x, y + 7, cz + z, 7, 7, 3, 'stone');
    column(world, cx + x, y + 10, cz + z, h - 5, 'stone');
    steppedPyramid(world, cx + x, y + h + 5, cz + z, 7, 4, 'roof', 'lantern');
  }
  staircase(world, { x: cx, y: y + 1, z: cz - 13 }, { x: 0, z: 1 }, 6, 5, 'stone');
}

function petronas(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 15, cx + 15, y, cz - 12, cz + 12, 'road');
  for (const x of [-7, 7]) {
    terracedPlatform(world, cx + x, y + 1, cz, 11, 11, 3, 'concrete');
    for (let level = 0; level < 34; level += 1) {
      const radius = level < 18 ? 4 : level < 27 ? 3 : level < 32 ? 2 : 1;
      const type = level % 4 === 0 ? 'concrete' : 'glass';
      fillRect(world, cx + x - radius, cx + x + radius, y + 4 + level, cz - radius, cz + radius, type);
      if (level % 6 === 0) {
        fillRect(world, cx + x - radius - 1, cx + x + radius + 1, y + 4 + level, cz - radius - 1, cz + radius + 1, 'concrete');
      }
    }
    spire(world, cx + x, y + 38, cz, 10, 1, 'rail', 'lantern');
  }
  // Passerelle aérienne sur deux niveaux.
  for (let x = -6; x <= 6; x += 1) {
    setBlock(world, cx + x, y + 22, cz, 'glass');
    setBlock(world, cx + x, y + 23, cz, 'concrete');
  }
  for (let z = -5; z <= 5; z += 2) {
    setBlock(world, cx - 12, y + 2, cz + z, 'lantern');
    setBlock(world, cx + 12, y + 2, cz + z, 'lantern');
  }
}

export const ASIA_WORLD = {
  id: 'asia', label: 'Asie', icon: '⛩️', accent: '#e15f5f', theme: 'asia', seed: 37, size: 224,
  description: 'Grande carte asiatique : temples, montagne, lac et métropole verticale.',
  landmarks: ['Taj Mahal', 'Grande Muraille', 'Angkor Vat', 'Tours Petronas'],
  pointsOfInterest: [
    { id: 'taj-mahal', name: 'Taj Mahal', icon: '🕌', x: -52, z: -51, region: 'Agra · Inde', discoveryRadius: 19, passportText: 'Un mausolée blanc très symétrique, coiffé d’un grand dôme et entouré de minarets.' },
    { id: 'great-wall', name: 'Grande Muraille', icon: '🧱', x: 0, z: -6, region: 'Chine', discoveryRadius: 24, passportText: 'Une fortification sinueuse qui suit le relief et relie plusieurs tours de guet.' },
    { id: 'angkor', name: 'Angkor Vat', icon: '🛕', x: -51, z: 51, region: 'Siem Reap · Cambodge', discoveryRadius: 21, passportText: 'Un temple à terrasses, douves, escaliers et tours centrales en forme de lotus.' },
    { id: 'petronas', name: 'Tours Petronas', icon: '🏙️', x: 52, z: 51, region: 'Kuala Lumpur · Malaisie', discoveryRadius: 19, passportText: 'Deux tours jumelles reliées par une passerelle aérienne au-dessus de la ville.' }
  ],
  spawn: { x: 0, z: 24 },
  battleSpawns: [{ x: -68, z: -66 }, { x: 68, z: -66 }, { x: -68, z: 66 }, { x: 68, z: 66 }],
  generate(world) {
    buildContinentTerrain(world, this);
    const tajPlace = { x: -52, z: -51 };
    const angkorPlace = { x: -51, z: 51 };
    const towersPlace = { x: 52, z: 51 };
    addRoad(world, [{ x: 0, z: 24 }, tajPlace], 2);
    addRoad(world, [{ x: 0, z: 24 }, angkorPlace], 2);
    addRoad(world, [{ x: 0, z: 24 }, towersPlace], 2);
    taj(world, tajPlace.x, tajPlace.z);
    greatWall(world, 0, -6);
    angkor(world, angkorPlace.x, angkorPlace.z);
    petronas(world, towersPlace.x, towersPlace.z);
    addVegetation(world, this, [
      { ...tajPlace, radius: 19 }, { x: 0, z: -6, radius: 50 },
      { ...angkorPlace, radius: 20 }, { ...towersPlace, radius: 18 }, { x: 0, z: 24, radius: 12 }
    ]);
    buildCaves(world, this); // Beta 4.32 : grotte du continent (tunnel dans la montagne, salles, lac, trésors)
  }
};
