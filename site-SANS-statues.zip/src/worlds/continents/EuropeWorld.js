import { buildContinentTerrain, addVegetation } from '../TerrainBuilder.js';
import { buildCaves } from '../../caves/CaveBuilder.js';
import { placeBlueprint } from '../monuments/MonumentKit.js';
import { colosseumBlueprint } from '../monuments/Colosseum.js';
import { sagradaBlueprint } from '../monuments/Sagrada.js';
import { bigBenBlueprint } from '../monuments/BigBen.js';
import {
  groundY, setBlock, fillRect, fillBox, column, line3D, ellipseWall,
  boxShell, dome, addRoad, steppedPyramid, spire, arcadeWall, staircase
} from '../LandmarkBuilder.js';

function eiffel(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 9, cx + 9, y, cz - 9, cz + 9, 'road');
  for (let x = -8; x <= 8; x += 2) {
    setBlock(world, cx + x, y + 1, cz - 8, 'fence');
    setBlock(world, cx + x, y + 1, cz + 8, 'fence');
  }
  for (let z = -8; z <= 8; z += 2) {
    setBlock(world, cx - 8, y + 1, cz + z, 'fence');
    setBlock(world, cx + 8, y + 1, cz + z, 'fence');
  }

  const legs = [[-6, -6], [6, -6], [-6, 6], [6, 6]];
  for (const [lx, lz] of legs) {
    line3D(world, { x: cx + lx, y: y + 1, z: cz + lz }, { x: cx + Math.sign(lx) * 3, y: y + 10, z: cz + Math.sign(lz) * 3 }, 'rail');
    line3D(world, { x: cx + lx - Math.sign(lx), y: y + 1, z: cz + lz }, { x: cx + Math.sign(lx) * 2, y: y + 10, z: cz + Math.sign(lz) * 3 }, 'rail');
  }
  // Grandes arches et croisillons.
  for (let offset = -5; offset <= 5; offset += 1) {
    const archTop = y + 3 + Math.round(4 * Math.sqrt(Math.max(0, 1 - (offset / 5) ** 2)));
    setBlock(world, cx + offset, archTop, cz - 6, 'rail');
    setBlock(world, cx + offset, archTop, cz + 6, 'rail');
    setBlock(world, cx - 6, archTop, cz + offset, 'rail');
    setBlock(world, cx + 6, archTop, cz + offset, 'rail');
  }
  for (let level = 3; level <= 9; level += 2) {
    const radius = level < 7 ? 5 : 3;
    for (let x = -radius; x <= radius; x += 1) {
      setBlock(world, cx + x, y + level, cz - radius, 'rail');
      setBlock(world, cx + x, y + level, cz + radius, 'rail');
    }
    for (let z = -radius; z <= radius; z += 1) {
      setBlock(world, cx - radius, y + level, cz + z, 'rail');
      setBlock(world, cx + radius, y + level, cz + z, 'rail');
    }
  }
  fillRect(world, cx - 4, cx + 4, y + 10, cz - 4, cz + 4, 'rail');
  for (const [lx, lz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) {
    line3D(world, { x: cx + lx, y: y + 11, z: cz + lz }, { x: cx + Math.sign(lx), y: y + 21, z: cz + Math.sign(lz) }, 'rail');
  }
  fillRect(world, cx - 2, cx + 2, y + 21, cz - 2, cz + 2, 'rail');
  column(world, cx, y + 22, cz, 10, 'rail', 'lantern');
}

export const EUROPE_WORLD = {
  id: 'europe',
  label: 'Europe',
  icon: '🏰',
  accent: '#5fc77a',
  theme: 'europe',
  seed: 11,
  size: 224,
  description: 'Grande carte européenne : plaines, rivière, forêts et monuments détaillés.',
  landmarks: ['Tour Eiffel', 'Colisée de Rome', 'Sagrada Família de Barcelone', 'Big Ben et Parlement'],
  pointsOfInterest: [
    { id: 'eiffel', name: 'Tour Eiffel', icon: '🗼', x: -52, z: -51, region: 'Paris · France', discoveryRadius: 16, passportText: 'Une grande structure métallique à quatre pieds, conçue pour dominer le paysage parisien.' },
    { id: 'colosseum', name: 'Colisée de Rome', icon: '🏟️', x: 52, z: -50, region: 'Rome · Italie', discoveryRadius: 17, passportText: 'Un amphithéâtre antique reconnaissable à sa forme ovale et à ses rangées d’arcades.' },
    { id: 'sagrada', name: 'Sagrada Família', icon: '⛪', x: -52, z: 51, region: 'Barcelone · Espagne', discoveryRadius: 18, passportText: 'Une basilique aux nombreuses tours élancées et aux volumes inspirés par la nature.' },
    { id: 'big-ben', name: 'Big Ben et Parlement', icon: '🕰️', x: 52, z: 52, region: 'Londres · Royaume-Uni', discoveryRadius: 16, passportText: 'Une grande tour horloge accolée au palais du Parlement britannique.' }
  ],
  spawn: { x: 0, z: 21 },
  battleSpawns: [{ x: -68, z: -66 }, { x: 68, z: -66 }, { x: -68, z: 66 }, { x: 68, z: 66 }],
  generate(world) {
    buildContinentTerrain(world, this);
    const positions = [{ x: -52, z: -51 }, { x: 52, z: -50 }, { x: -52, z: 51 }, { x: 52, z: 52 }];
    for (const point of positions) addRoad(world, [{ x: 0, z: 21 }, point], 2);
    eiffel(world, positions[0].x, positions[0].z);
    placeBlueprint(world, colosseumBlueprint(), positions[1].x, positions[1].z); // Beta 4.33 : Colisée retravaillé (plan pur, voir monuments/Colosseum.js)
    placeBlueprint(world, sagradaBlueprint(), positions[2].x, positions[2].z, { apron: 6 }); // Beta 4.35 : Sagrada Família retravaillée (plan pur, voir monuments/Sagrada.js)
    placeBlueprint(world, bigBenBlueprint(), positions[3].x, positions[3].z, { apron: 6 }); // Beta 4.35 : Big Ben et Parlement retravaillés (plan pur, voir monuments/BigBen.js)
    addVegetation(world, this, [
      ...positions.map((p, i) => ({ ...p, radius: i >= 2 ? 23 : 16 })), // la Sagrada et le Parlement sont plus grands
      { x: 0, z: 21, radius: 12 }
    ]);
    buildCaves(world, this); // Beta 4.32 : grotte du continent (tunnel dans la montagne, salles, lac, trésors)
  }
};
