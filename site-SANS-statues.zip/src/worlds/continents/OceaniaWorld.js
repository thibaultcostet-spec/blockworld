import { buildContinentTerrain, addVegetation } from '../TerrainBuilder.js';
import { buildCaves } from '../../caves/CaveBuilder.js';
import { placeBlueprint } from '../monuments/MonumentKit.js';
import { harbourBridgeBlueprint, BRIDGE_BASE_Y, HARBOUR_BRIDGE } from '../monuments/Bridges.js';
import {
  groundY, setBlock, fillRect, fillBox, column, line3D, boxShell,
  addRoad, steppedPyramid, spire, staircase, terracedPlatform
} from '../LandmarkBuilder.js';

function opera(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 15, cx + 15, y, cz - 12, cz + 12, 'water');
  terracedPlatform(world, cx, y + 1, cz, 27, 19, 4, 'concrete');
  // Coques principales de l’opéra.
  const shells = [
    { x: -8, h: 13, w: 6 }, { x: -2, h: 18, w: 8 },
    { x: 5, h: 16, w: 7 }, { x: 10, h: 10, w: 5 }
  ];
  for (const shell of shells) {
    for (let level = 0; level < shell.h; level += 1) {
      const width = Math.max(1, Math.round(shell.w * (1 - level / shell.h)));
      const z = cz + Math.round(level * 0.45) - 5;
      for (let x = -width; x <= width; x += 1) setBlock(world, cx + shell.x + x, y + 5 + level, z, 'concrete');
      if (level % 3 === 0) setBlock(world, cx + shell.x, y + 5 + level, z - 1, 'glass');
    }
  }
  // Façades vitrées et promenade.
  for (let x = -11; x <= 11; x += 2) setBlock(world, cx + x, y + 5, cz - 7, 'glass');
  addRoad(world, [{ x: cx, z: cz + 12 }, { x: cx, z: cz + 20 }], 2);
}

function uluru(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 17, cx + 17, y, cz - 13, cz + 13, 'sand');
  for (let level = 0; level < 12; level += 1) {
    const rx = Math.max(3, 15 - level);
    const rz = Math.max(2, 9 - Math.floor(level / 2));
    for (let x = -rx; x <= rx; x += 1) {
      for (let z = -rz; z <= rz; z += 1) {
        const wave = Math.sin((x + z) * 0.7 + level) * 0.12;
        if ((x * x) / (rx * rx) + (z * z) / (rz * rz) <= 1 + wave) {
          setBlock(world, cx + x, y + 1 + level, cz + z, level % 4 === 0 ? 'sand' : 'bricks');
        }
      }
    }
  }
  // Sentier autour du rocher.
  for (let step = 0; step < 80; step += 1) {
    const angle = step / 80 * Math.PI * 2;
    setBlock(world, cx + Math.cos(angle) * 18, y + 1, cz + Math.sin(angle) * 14, 'road');
  }
}

function skyTower(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 11, cx + 11, y, cz - 11, cz + 11, 'road');
  terracedPlatform(world, cx, y + 1, cz, 11, 11, 4, 'concrete');
  column(world, cx, y + 5, cz, 28, 'concrete');
  // Plateforme panoramique arrondie.
  for (let level = 0; level < 6; level += 1) {
    const radius = level < 2 ? 5 : level < 4 ? 6 : 4;
    fillRect(world, cx - radius, cx + radius, y + 22 + level, cz - radius, cz + radius, level % 2 === 0 ? 'glass' : 'concrete');
  }
  column(world, cx, y + 33, cz, 14, 'rail');
  spire(world, cx, y + 47, cz, 8, 1, 'rail', 'lantern');
  for (let z = -7; z <= 7; z += 3) setBlock(world, cx - 8, y + 2, cz + z, 'lantern');
}

function moai(world, cx, cz) {
  const y = groundY(world, cx, cz);
  fillRect(world, cx - 18, cx + 18, y, cz - 11, cz + 11, 'grass');
  const statues = [[-13, 0, 13], [-7, -2, 16], [0, 1, 19], [8, -1, 15], [14, 2, 12]];
  for (const [x, z, h] of statues) {
    terracedPlatform(world, cx + x, y + 1, cz + z, 7, 5, 2, 'stone');
    fillBox(world, cx + x - 2, cx + x + 2, y + 3, y + h - 5, cz + z - 2, cz + z + 2, 'stone');
    fillBox(world, cx + x - 3, cx + x + 3, y + h - 4, y + h, cz + z - 2, cz + z + 2, 'stone');
    fillBox(world, cx + x - 2, cx + x + 2, y + h + 1, y + h + 4, cz + z - 1, cz + z + 1, 'stone');
    setBlock(world, cx + x - 1, y + h + 2, cz + z - 2, 'obsidian');
    setBlock(world, cx + x + 1, y + h + 2, cz + z - 2, 'obsidian');
    line3D(world, { x: cx + x - 2, y: y + h, z: cz + z - 2 }, { x: cx + x + 2, y: y + h, z: cz + z - 2 }, 'stone');
    setBlock(world, cx + x, y + h - 1, cz + z - 3, 'stone');
  }
  staircase(world, { x: cx, y: y + 1, z: cz - 15 }, { x: 0, z: 1 }, 7, 5, 'stone');
}

export const OCEANIA_WORLD = {
  id: 'oceania', label: 'Océanie', icon: '🌊', accent: '#43c6b8', theme: 'oceania', seed: 69, size: 224,
  description: 'Grande carte océanienne : îles, lagon, littoral et architectures monumentales.',
  landmarks: ['Opéra de Sydney', 'Sydney Harbour Bridge', 'Uluru', 'Sky Tower d’Auckland', 'Moai du Pacifique'],
  pointsOfInterest: [
    { id: 'sydney-opera', name: 'Opéra de Sydney', icon: '🎭', x: -54, z: -51, region: 'Sydney · Australie', discoveryRadius: 18, passportText: 'Un bâtiment au bord de l’eau, couvert de grandes coques blanches semblables à des voiles.' },
    { id: 'harbour-bridge', name: 'Sydney Harbour Bridge', icon: '🌉', x: 0, z: -27, region: 'Sydney · Australie', discoveryRadius: 19, viewpoint: HARBOUR_BRIDGE.viewpoint, passportText: 'Un grand pont métallique en arc qui traverse le port de Sydney.' },
    { id: 'uluru', name: 'Uluru', icon: '🪨', x: 54, z: -51, region: 'Territoire du Nord · Australie', discoveryRadius: 22, passportText: 'Un immense rocher rouge isolé, entouré d’un paysage désertique.' },
    { id: 'sky-tower', name: 'Sky Tower d’Auckland', icon: '🗼', x: -54, z: 52, region: 'Auckland · Nouvelle-Zélande', discoveryRadius: 18, passportText: 'Une tour très élancée, dotée d’une plateforme panoramique circulaire.' },
    { id: 'moai', name: 'Moai du Pacifique', icon: '🗿', x: 54, z: 52, region: 'Île de Pâques · Pacifique', discoveryRadius: 20, passportText: 'Un alignement de grandes statues de pierre aux visages allongés.' }
  ],
  spawn: { x: 0, z: 22 },
  battleSpawns: [{ x: -66, z: -64 }, { x: 66, z: -64 }, { x: -66, z: 64 }, { x: 66, z: 64 }],
  generate(world) {
    buildContinentTerrain(world, this);
    const places = [{ x: -54, z: -51 }, { x: 0, z: -27 }, { x: 54, z: -51 }, { x: -54, z: 52 }, { x: 54, z: 52 }];
    // Beta 4.34 : la route du Harbour Bridge arrive par la rampe est (le centre du pont est au-dessus du port).
    for (const point of places) addRoad(world, [{ x: 0, z: 22 }, point === places[1] ? { x: 56, z: places[1].z } : point], 2);
    opera(world, places[0].x, places[0].z);
    placeBlueprint(world, harbourBridgeBlueprint(), places[1].x, places[1].z, { baseY: BRIDGE_BASE_Y }); // Beta 4.34 : pont en arc retravaillé (plan pur, voir monuments/Bridges.js)
    uluru(world, places[2].x, places[2].z);
    skyTower(world, places[3].x, places[3].z);
    moai(world, places[4].x, places[4].z);
    const bridgeZones = [-50, -34, 34, 50].map((x) => ({ x, z: places[1].z, radius: 12 }));
    addVegetation(world, this, [...places.map((p) => ({ ...p, radius: p === places[1] ? 30 : 20 })), ...bridgeZones, { x: 0, z: 22, radius: 12 }]);
    buildCaves(world, this); // Beta 4.32 : grotte du continent (tunnel dans la montagne, salles, lac, trésors)
  }
};
