import { Blueprint } from './MonumentKit.js';

// BlockWorld V3.0 Beta 4.35 — Big Ben et Palais de Westminster retravaillés (plan pur, relatif au centre ; y = 0 : première case au-dessus du sol).
//
// Le joueur arrive par l'OUEST : on lui montre la longue façade du Parlement (axe nord-sud) avec la tour Elizabeth à son extrémité nord (z < 0) et
// la tour Victoria au sud. Grès doré (sable) rehaussé de pierre claire (béton), toits sombres, pinacles à pointe dorée.
//   Palais : 8 × 21, trames de 3 blocs rythmées par des pilastres, deux rangs de fenêtres, toit en trois niveaux, et une grande salle (Westminster Hall)
//            où l'on entre par la porte ouest ;
//   Tour Elizabeth : 5 × 5, 36 de haut : fût, corniche, étage des cadrans (quatre cadrans de 3 × 3 en blocs : fond de lanternes dorées qui brillent
//            la nuit, aiguilles d'obsidienne ; des disques collés à 3 cm de la paroi ne s'affichaient pas), beffroi à ouïes, flèche en gradins et pointe dorée ;
//   Tour Victoria : 5 × 5, plus basse et plus massive.
export const BIG_BEN = Object.freeze({
  palace: { x1: -2, x2: 5, z1: -8, z2: 12, top: 6 },
  tower: { cx: 2, cz: -11, half: 2, clockRel: 18, dial: 3 },
  victoria: { cx: 2, cz: 15, half: 2, height: 17 }
});

function shell(bp, cx, cz, half, y1, y2, type) {
  for (let y = y1; y <= y2; y += 1) for (let x = -half; x <= half; x += 1) for (let z = -half; z <= half; z += 1) if (Math.abs(x) === half || Math.abs(z) === half) bp.set(cx + x, y, cz + z, type);
}

function tower(bp, { cx, cz, half }, { height, clockRel = null, windows = [4, 7, 10], roofLevels = 6 }) {
  shell(bp, cx, cz, half, 0, height, 'sand');
  for (const [dx, dz] of [[-half, -half], [half, -half], [-half, half], [half, half]]) for (let y = 0; y <= height; y += 1) bp.set(cx + dx, y, cz + dz, 'concrete'); // chaînes d'angle
  for (const y of windows) for (const [dx, dz] of [[0, -half], [0, half], [-half, 0], [half, 0]]) bp.set(cx + dx, y, cz + dz, 'window');
  // corniche (7 × 7) puis retrait
  // corniche (7 × 7) et plafond du fût : SURPLOMBS (`hang`), sans fondation dessous (sinon une gaine de pierre cachait tout le fût)
  for (let x = -half - 1; x <= half + 1; x += 1) for (let z = -half - 1; z <= half + 1; z += 1) if (Math.abs(x) === half + 1 || Math.abs(z) === half + 1) bp.set(cx + x, height + 1, cz + z, 'concrete', { hang: true });
  for (let x = -half; x <= half; x += 1) for (let z = -half; z <= half; z += 1) bp.set(cx + x, height + 1, cz + z, 'concrete', { hang: true }); // plafond du fût
  if (clockRel !== null) {
    // cadrans : u vers la droite de l'observateur placé en face (ouest : +z, est : −z, nord : −x, sud : +x), v vers le haut ; aiguilles vers 12 h et 3 h
    for (const [dx, dz, rx, rz] of [[-half, 0, 0, 1], [half, 0, 0, -1], [0, -half, -1, 0], [0, half, 1, 0]]) for (let u = -1; u <= 1; u += 1) for (let v = -1; v <= 1; v += 1) {
      const hand = (u === 0 && v >= 0) || (u === 1 && v === 0);
      bp.set(cx + dx + rx * u, clockRel + v, cz + dz + rz * u, hand ? 'obsidian' : 'lantern');
    }
  }
  return height + 2;
}

export function bigBenBlueprint(spec = BIG_BEN) {
  const bp = new Blueprint('big-ben');
  const { palace: P, tower: T, victoria: V } = spec;
  // Palais : volume plein, grande salle creusée, façades à trames de 3 blocs
  bp.box(P.x1, P.x2, -1, -1, P.z1, P.z2, 'stone');
  for (let x = P.x1; x <= P.x2; x += 1) for (let z = P.z1; z <= P.z2; z += 1) for (let y = 0; y <= P.top; y += 1) {
    const edge = x === P.x1 || x === P.x2 || z === P.z1 || z === P.z2;
    if (edge || y >= 5) bp.set(x, y, z, 'sand'); // plein sous les toits, creux au milieu
  }
  bp.carveBox(P.x1 + 1, P.x2 - 1, 0, 4, P.z1 + 1, P.z2 - 1); // Westminster Hall : 6 × 19 × 5
  bp.box(P.x1 + 1, P.x2 - 1, 5, 5, P.z1 + 1, P.z2 - 1, 'planks'); // plafond de bois
  for (const side of ['west', 'east']) {
    const x = side === 'west' ? P.x1 : P.x2;
    for (let z = P.z1; z <= P.z2; z += 1) {
      const pilaster = (z - P.z1) % 3 === 0;
      for (let y = 0; y <= P.top; y += 1) {
        if (pilaster) bp.set(x, y, z, 'concrete');
        else if ((y === 2 || y === 4) && z > P.z1 && z < P.z2) bp.set(x, y, z, 'window');
      }
      if (side === 'west' && (z - P.z1) % 6 === 0 && z > P.z1 - 1) { for (let y = P.top + 1; y <= P.top + 4; y += 1) bp.set(x, y, z, 'concrete'); bp.set(x, P.top + 5, z, 'lantern'); } // pinacles
    }
  }
  // porte ouest (z = 0..2, 4 de haut) et marche
  bp.carveBox(P.x1, P.x1, 0, 3, 0, 2); for (let z = -1; z <= 3; z += 1) bp.set(P.x1, 4, z, 'concrete'); bp.carveBox(P.x1 - 1, P.x1 - 1, 0, 0, 0, 2);
  // toits : trois niveaux
  bp.box(P.x1, P.x2, 7, 7, P.z1, P.z2, 'roof'); bp.box(P.x1 + 1, P.x2 - 1, 8, 8, P.z1 + 1, P.z2 - 1, 'roof'); bp.box(P.x1 + 3, P.x2 - 3, 9, 9, P.z1 + 2, P.z2 - 2, 'roof');
  // tour Elizabeth
  const topY = tower(bp, T, { height: 24, clockRel: T.clockRel });
  for (let y = 25; y <= 25; y += 1) shell(bp, T.cx, T.cz, T.half, y, y, 'window'); // beffroi : ouïes
  for (let k = 0; k < 6; k += 1) { const half = Math.max(0, T.half - Math.floor(k / 2)); bp.box(T.cx - half, T.cx + half, 26 + k, 26 + k, T.cz - half, T.cz + half, 'roof'); }
  for (let y = 32; y <= 34; y += 1) bp.set(T.cx, y, T.cz, 'lantern'); // pointe dorée
  for (const [dx, dz] of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) { for (let y = 0; y <= 24; y += 1) bp.set(T.cx + dx, y, T.cz + dz, 'concrete'); bp.set(T.cx + dx, 25, T.cz + dz, 'lantern'); } // contreforts d'angle, du sol à la corniche
  void topY;
  // tour Victoria
  tower(bp, V, { height: V.height, windows: [4, 8, 12] });
  for (let k = 0; k < 4; k += 1) { const half = Math.max(0, V.half - Math.floor(k / 2)); bp.box(V.cx - half, V.cx + half, V.height + 2 + k, V.height + 2 + k, V.cz - half, V.cz + half, 'roof'); }
  bp.set(V.cx, V.height + 6, V.cz, 'lantern');
  return bp;
}
