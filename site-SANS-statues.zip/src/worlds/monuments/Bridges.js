import { Blueprint } from './MonumentKit.js';

// BlockWorld V3.0 Beta 4.34 — Golden Gate Bridge (pont suspendu) et Sydney Harbour Bridge (pont en arc) retravaillés.
// Plans purs, comme le Colisée et Gizeh, mais en hauteurs ABSOLUES comme le pont Maputo : y = 0 du plan est le niveau de l'eau (y absolu 2),
// y = −1 le fond de sable de la baie (y absolu 1). Se posent avec `placeBlueprint(world, plan, cx, cz, { baseY: BRIDGE_BASE_Y })`.
// Les fiches *_BRIDGE (hauteurs absolues, comme MAPUTO_BRIDGE) servent aussi à l'embellisseur pour tracer les câbles du Golden Gate.
export const BRIDGE_BASE_Y = 2;

export const GOLDEN_GATE = Object.freeze({
  id: 'golden-gate', cx: 0, cz: -28, deckY: 9, pylonX: 20, topY: 33, legZ: [5, 6], cableZ: 4.4, sagY: 3.0, anchorX: 37, endX: 42, bay: { rx: 22, rz: 11 },
  viewpoint: { x: 12, z: -11 }
});

export const HARBOUR_BRIDGE = Object.freeze({
  id: 'harbour-bridge', cx: 0, cz: -27, deckY: 9, archX: 22, crownY: 31, ribZ: 5, endX: 38, pylonX: [25, 28], pylonZ: [5, 8], pylonTopY: 24, bay: { rx: 24, rz: 12 },
  viewpoint: { x: 12, z: -10 }
});

/** Hauteur ABSOLUE du dessus de la nervure de l'arche en x (même formule pour le plan et pour les suspentes dessinées par l'embellisseur). */
export function archRibY(B, x) {
  return B.deckY + 1 + Math.round((B.crownY - B.deckY - 1) * (1 - (x / B.archX) ** 2) ** 0.85);
}

const TOP = 18; // hauteur d'air déblayée au-dessus de l'eau (rel.) : le relief qui dépasse est coupé

/** La baie : eau sur un fond de sable, rives en pente douce, relief déblayé au-dessus. */
function bay(bp, { rx, rz }) {
  const mx = Math.ceil(rx * 1.35), mz = Math.ceil(rz * 1.35);
  for (let x = -mx; x <= mx; x += 1) {
    for (let z = -mz; z <= mz; z += 1) {
      const r = Math.hypot(x / rx, z / rz);
      if (r > 1.32) continue;
      if (r <= 1) {
        for (let y = 1; y <= TOP; y += 1) bp.carve(x, y, z);
        bp.set(x, 0, z, 'water');
        bp.set(x, -1, z, 'sand');
      } else {
        const target = Math.floor((r - 1) * 14); // plage : 0 à 4 blocs au-dessus de l'eau
        for (let y = target + 1; y <= TOP; y += 1) bp.carve(x, y, z);
        bp.set(x, target, z, 'sand');
      }
    }
  }
}

/** Tablier : chaussée de 5 voies, trottoirs de béton, poutres de rive d'acier, caisson d'acier dessous, garde-corps vitré à lanternes. */
function deck(bp, deckRel, endX, rail = (x) => (x % 8 === 0 ? 'lantern' : 'glass'), gaps = () => false) {
  for (let x = -endX; x <= endX; x += 1) {
    for (let z = -4; z <= 4; z += 1) {
      const type = Math.abs(z) === 4 ? 'steel' : Math.abs(z) === 3 ? 'concrete' : 'road';
      bp.set(x, deckRel, z, type);
      if (Math.abs(z) <= 3) bp.set(x, deckRel - 1, z, 'steel');
    }
    for (const z of [-4, 4]) if (!gaps(x)) bp.set(x, deckRel + 1, z, rail(x));
  }
}

/** Piles des viaducs hors de la baie : une tous les 6 blocs, sous le tablier. */
function piers(bp, deckRel, fromX, endX, type = 'concrete') {
  for (const side of [-1, 1]) {
    for (let x = fromX; x <= endX - 2; x += 6) {
      for (const z of [-3, -2, 2, 3]) for (let y = 1; y < deckRel - 1; y += 1) bp.set(side * x, y, z, type);
      for (let z = -3; z <= 3; z += 1) bp.set(side * x, deckRel - 2, z, type);
    }
  }
}

/** Rampes d'accès : une marche d'un bloc tous les deux blocs, de la fin du tablier au sol (supposé à 1 au-dessus de l'eau). */
function ramps(bp, deckRel, endX) {
  for (const side of [-1, 1]) {
    for (let i = 1; i <= (deckRel - 1) * 2; i += 1) {
      const level = deckRel - Math.ceil(i / 2);
      for (let z = -3; z <= 3; z += 1) bp.set(side * (endX + i), level, z, Math.abs(z) === 3 ? 'concrete' : 'road');
    }
  }
}

/** Golden Gate : tours à deux jambes de briques rouges avec quatre entretoises, massifs d'ancrage ; les câbles sont dessinés par l'embellisseur. */
export function goldenGateBlueprint(B = GOLDEN_GATE) {
  const bp = new Blueprint('golden-gate');
  const deckRel = B.deckY - BRIDGE_BASE_Y, topRel = B.topY - BRIDGE_BASE_Y;
  bay(bp, B.bay);
  deck(bp, deckRel, B.endX, (x) => (x % 8 === 0 ? 'lantern' : 'glass'), (x) => Math.abs(Math.abs(x) - B.pylonX - 0.5) <= 1);
  piers(bp, deckRel, B.bay.rx + 4, B.endX);
  for (const side of [-1, 1]) {
    const px = side * B.pylonX;
    for (const dx of [0, side]) {
      for (const zs of [-1, 1]) for (const dz of B.legZ) {
        for (let y = -1; y <= topRel; y += 1) bp.set(px + dx, y, zs * dz, 'bricks');
        if (dx === 0) bp.set(px, topRel + 1, zs * dz, 'lantern');
      }
      for (let z = -6; z <= 6; z += 1) for (const y of [deckRel - 2, deckRel + 8, deckRel + 15, topRel - 2, topRel - 1]) bp.set(px + dx, y, z, 'bricks'); // entretoises
    }
    for (let dx = -1; dx <= 2; dx += 1) for (let z = -7; z <= 7; z += 1) bp.set(px + (side > 0 ? dx : -dx), 0, z, 'concrete'); // semelle dans la baie
    for (let x = B.anchorX; x <= B.anchorX + 4; x += 1) for (const zs of [-1, 1]) for (const dz of [5, 6]) for (let y = 0; y <= deckRel + 2; y += 1) bp.set(side * x, y, zs * dz, 'concrete'); // massifs d'ancrage
  }
  ramps(bp, deckRel, B.endX);
  return bp;
}

/** Harbour Bridge : arche d'acier à deux nervures, suspentes, quatre pylônes de pierre à couronne de briques, culées de pierre. */
export function harbourBridgeBlueprint(B = HARBOUR_BRIDGE) {
  const bp = new Blueprint('harbour-bridge');
  const deckRel = B.deckY - BRIDGE_BASE_Y;
  bay(bp, B.bay);
  deck(bp, deckRel, B.endX, (x) => (x % 8 === 0 ? 'lantern' : 'glass'));
  piers(bp, deckRel, B.bay.rx + 4, B.endX, 'stone'); // piles de pierre, comme les pylônes et les culées du vrai pont
  const archY = (x) => archRibY(B, x) - BRIDGE_BASE_Y;
  for (let x = -B.archX; x <= B.archX; x += 1) {
    for (const zs of [-1, 1]) {
      const z = zs * B.ribZ;
      bp.set(x, archY(x), z, 'steel');
      bp.set(x, archY(x) - 1, z, 'steel'); // la nervure fait deux blocs d'épaisseur
      if (x % 2 === 0 && Math.abs(x) < B.archX) {
        bp.set(x, deckRel, z, 'steel'); // poutre de rive prolongée jusqu'à la suspente (le fil de la suspente est dessiné par MonumentVisualEnhancer)
      }
    }
    if (x % 4 === 0 && Math.abs(x) <= 16) for (let z = -B.ribZ + 1; z <= B.ribZ - 1; z += 1) bp.set(x, archY(x), z, 'steel'); // entretoise de contreventement
  }
  for (const side of [-1, 1]) {
    for (let x = B.archX; x <= B.pylonX[1] + 1; x += 1) for (let z = -6; z <= 6; z += 1) for (let y = -1; y < deckRel; y += 1) bp.set(side * x, y, z, 'stone'); // culées
    for (const zs of [-1, 1]) {
      for (let x = B.pylonX[0]; x <= B.pylonX[1]; x += 1) for (let z = B.pylonZ[0]; z <= B.pylonZ[1]; z += 1) {
        for (let y = deckRel; y <= B.pylonTopY - BRIDGE_BASE_Y; y += 1) bp.set(side * x, y, zs * z, y >= B.pylonTopY - BRIDGE_BASE_Y - 1 ? 'bricks' : 'stone');
      }
      bp.set(side * ((B.pylonX[0] + B.pylonX[1]) >> 1), B.pylonTopY - BRIDGE_BASE_Y + 1, zs * ((B.pylonZ[0] + B.pylonZ[1]) >> 1), 'lantern');
    }
  }
  ramps(bp, deckRel, B.endX);
  return bp;
}
