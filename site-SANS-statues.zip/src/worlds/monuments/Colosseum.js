import { Blueprint, hash2 } from './MonumentKit.js';

// BlockWorld V3.0 Beta 4.33 — Colisée de Rome retravaillé (plan pur, relatif au centre ; y = 0 : première case au-dessus du sol).
//
// Ellipse de 26 × 21 blocs (rapport réel 188 × 156 m ≈ 1,2). De l'extérieur vers l'arène, par « profondeur » d (anneaux elliptiques de 1 bloc) :
//   d 0-1  façade en travertin (sable) : deux niveaux d'arcades (arches 1 × 3), attique à fenêtres, corniche de pierre ;
//   d 2    déambulatoire (couloir de 1 bloc, plafonné aux étages) ;
//   d 3    mur intérieur en briques, arcades au rez-de-chaussée ;
//   d 4-7  gradins : quatre marches d'un bloc (4, 3, 2, 1 de haut), praticables (le joueur ne monte qu'un bloc à la fois) ;
//   d ≥ 8  arène de sable, à l'ellipse de 10 × 5.
// Deux grandes portes sur l'axe long (x), de l'extérieur à l'arène, au niveau du sol. Le côté sud (+z, celui que voit le joueur qui arrive) est
// éboulé, comme le vrai Colisée : on y voit les briques du mur intérieur et les gradins.
export const COLOSSEUM = Object.freeze({
  a: 13, b: 10.5, arches: 36, wallTop: 11, ruinCenter: 100, ruinHalf: 55, seed: 7
});

export function colosseumBlueprint(spec = COLOSSEUM) {
  const { a, b, arches, wallTop, ruinCenter, ruinHalf, seed } = spec;
  const bp = new Blueprint('colosseum');
  const R = Math.ceil(Math.max(a, b)) + 3;
  const inside = (x, z, r) => (x / (a - r)) ** 2 + (z / (b - r)) ** 2 <= 1;
  const depthOf = (x, z) => {
    if (!inside(x, z, 0)) return -1;
    let r = 0;
    while (r < 8 && inside(x, z, r + 1)) r += 1;
    return r;
  };
  const TAU = Math.PI * 2;
  for (let x = -R; x <= R; x += 1) {
    for (let z = -R; z <= R; z += 1) {
      const depth = depthOf(x, z);
      const theta = (Math.atan2(z / b, x / a) + TAU) % TAU; // angle paramétrique
      const pitch = (theta / TAU) * arches;
      const arch = pitch - Math.floor(pitch);
      const opening = arch >= 0.25 && arch <= 0.75;
      const degrees = (theta * 180) / Math.PI;
      const spread = Math.min(Math.abs(degrees - ruinCenter), 360 - Math.abs(degrees - ruinCenter));
      const phase = spread < ruinHalf ? spread / ruinHalf : 1; // 0 au centre de l'éboulement, 1 hors éboulement
      const noise = hash2(x, z, seed);
      const outerCap = phase >= 1 ? wallTop + 2 : Math.max(0, Math.min(wallTop, 1 + Math.round(phase ** 1.4 * 10 + (noise - 0.5) * 2.4)));
      const innerCap = phase >= 1 ? 8 : Math.max(3, 7 - Math.round((1 - phase) * 3 + noise * 1.5));
      const gate = Math.abs(z) <= 1 && Math.abs(x) >= 3; // grandes portes sur l'axe long
      const gatePost = Math.abs(z) === 2 && Math.abs(x) >= 3;

      if (depth < 0) {
        // Marche d'accueil autour du monument (sauf aux portes et dans l'éboulement) et gravats.
        if (inside(x, z, -1) && !gate && phase > 0.45) bp.set(x, 0, z, 'stone');
        else if (inside(x, z, -2.2) && phase < 0.9 && noise > 0.78) bp.set(x, 0, z, noise > 0.9 ? 'stone' : 'sand');
        continue;
      }
      // Sol : déambulatoire en pierre, arène en sable, motif de l'hypogée (lignes de pierre).
      if (depth >= 8) bp.set(x, -1, z, (x + 7) % 4 === 0 || (Math.abs(z) <= 1 && x % 2 === 0) ? 'stone' : 'sand');
      else bp.set(x, -1, z, depth <= 3 ? 'stone' : 'sand');

      if (depth <= 1) { // façade
        for (let y = 0; y <= wallTop; y += 1) {
          if (y > outerCap) break;
          if (gate && y <= 3) continue;
          let type = 'sand';
          if (gatePost) type = 'stone';
          else if (y === 3 || y === 7 || y === wallTop) type = 'stone'; // linteaux et corniche
          else if (y <= 2 && opening && !gate) continue; // arcades du rez-de-chaussée
          else if (y >= 4 && y <= 6 && opening) continue; // arcades de l'étage
          else if (y === 9 && arch >= 0.35 && arch <= 0.65 && Math.floor(pitch) % 2 === 0) continue; // fenêtres de l'attique
          bp.set(x, y, z, type);
        }
        if (depth === 0 && !gate && phase >= 1 && y0Lantern(pitch, arch, noise)) bp.set(x, wallTop + 1, z, 'lantern');
      } else if (depth === 2) { // déambulatoire : plafonds de pierre aux étages
        if (gate) continue;
        for (const level of [3, 7]) if (level <= outerCap) bp.set(x, level, z, 'stone');
      } else if (depth === 3) { // mur intérieur en briques
        for (let y = 0; y <= innerCap; y += 1) {
          if (gate && y <= 3) continue;
          if (y <= 2 && opening) continue;
          if (y >= 4 && y <= 6 && opening && y < innerCap) continue;
          bp.set(x, y, z, 'bricks');
        }
      } else if (depth <= 7) { // gradins : 4, 3, 2 puis 1 bloc de haut
        if (gate) continue; // couloir de plain-pied jusqu'à l'arène
        const rows = 8 - depth; // d4 → 4, d5 → 3, d6 → 2, d7 → 1
        for (let y = 0; y < rows; y += 1) bp.set(x, y, z, depth === 5 && y === rows - 1 ? 'stone' : 'sand');
      }
    }
  }
  return bp;
}

// Une lanterne sur la corniche, une arcade sur six (hors éboulement) : accents dorés qui s'allument la nuit.
function y0Lantern(pitch, arch, noise) {
  return Math.floor(pitch) % 6 === 0 && arch >= 0.4 && arch <= 0.6 && noise >= 0;
}
