import { Blueprint } from './MonumentKit.js';

// BlockWorld V3.0 Beta 4.33 — Pyramides de Gizeh et Sphinx retravaillés (plan pur, relatif au centre ; y = 0 : première case au-dessus du sol).
//
// Trois pyramides de tailles décroissantes (Khéops 19 × 13, Khéphren 17 × 12 avec son sommet en calcaire, Mykérinos 9 × 6), pentes de 1 bloc par
// palier, pyramidion doré. Khéops s'ouvre sur sa face sud par un couloir de 2 × 3 qui monte d'un bloc tous les deux pas jusqu'à la chambre du roi
// (sarcophage d'obsidienne, quatre lanternes) : on peut y entrer et en ressortir à pied. Le Sphinx, de 12 blocs de long, regarde vers le sud (+z),
// du côté d'où arrive le joueur.
export const GIZA = Object.freeze({
  khufu: { cx: -8, cz: -8, base: 19, height: 13 },
  khafre: { cx: 10, cz: -8, base: 17, height: 12, casing: 4 },
  menkaure: { cx: 14, cz: 9, base: 9, height: 6 }, // à l'est du Sphinx : l'accès à l'entrée de Khéops (face sud) reste libre
  sphinx: { cx: 6, z0: 3 }
});

function pyramid(bp, { cx, cz, base, height, casing = 0 }, type = 'sand') {
  const half0 = (base - 1) / 2;
  for (let k = 0; k < height; k += 1) {
    const half = Math.round(half0 * (1 - k / height));
    bp.box(cx - half, cx + half, k, k, cz - half, cz + half, k >= height - casing ? 'stone' : type);
  }
  bp.set(cx, height, cz, 'lantern'); // pyramidion doré
  bp.box(cx - half0, cx + half0, -1, -1, cz - half0, cz + half0, 'stone'); // plinthe : la base ne flotte jamais
}

/** Couloir ascendant de la face sud de Khéops jusqu'à la chambre du roi. */
function kingsChamber(bp, { cx, cz }) {
  const rise = 6; // 6 pas : le sol monte de 1 bloc tous les 2 pas
  for (let i = 0; i < rise + 3; i += 1) {
    const z = cz + 8 - i; // la face sud de la pyramide, au niveau 1, est à cz + 8
    const floor = 1 + Math.min(3, Math.floor(i / 2));
    bp.carveBox(cx - 1, cx, floor, floor + 2, z, z);
  }
  const floor = 4;
  bp.carveBox(cx - 2, cx + 1, floor, floor + 3, cz - 2, cz + 2); // la chambre : 4 × 5 × 4
  bp.box(cx - 1, cx, floor, floor, cz - 1, cz - 1, 'obsidian'); // sarcophage
  for (const [x, z] of [[cx - 2, cz - 2], [cx + 1, cz - 2], [cx - 2, cz + 2], [cx + 1, cz + 2]]) bp.set(x, floor + 2, z, 'lantern');
  bp.box(cx - 1, cx, 0, 0, cz + 9, cz + 11, 'stone'); // parvis pavé devant l'entrée
  bp.set(cx - 2, 1, cz + 9, 'lantern'); bp.set(cx + 1, 1, cz + 9, 'lantern'); // deux lanternes dorées encadrent l'entrée : on la repère de loin
}

function sphinx(bp, { cx, z0 }) {
  const at = (v, u) => [cx + v, z0 + u]; // u : longueur (0 = arrière, 11 = pattes), v : travers
  const box = (v1, v2, u1, u2, y1, y2, type) => { for (let v = v1; v <= v2; v += 1) for (let u = u1; u <= u2; u += 1) for (let y = y1; y <= y2; y += 1) bp.set(cx + v, y, z0 + u, type); void at; };
  box(-2, 2, 0, 8, 0, 1, 'sand'); // corps de lion couché
  box(-2, 2, 1, 4, 2, 2, 'sand'); // croupe
  box(-1, 1, 7, 9, 2, 4, 'sand'); // poitrail et cou
  box(-1, 1, 8, 10, 3, 5, 'sand'); // tête
  box(-2, 2, 8, 9, 4, 4, 'stone'); // coiffe (némès) : volets latéraux
  box(-1, 1, 8, 10, 6, 6, 'stone'); // sommet de la coiffe
  box(-2, -1, 9, 11, 0, 0, 'sand'); box(1, 2, 9, 11, 0, 0, 'sand'); // pattes avant, écartées
  box(-2, -1, 12, 12, 0, 0, 'stone'); box(1, 2, 12, 12, 0, 0, 'stone'); // griffes
  bp.set(cx - 1, 5, z0 + 11, 'obsidian'); bp.set(cx + 1, 5, z0 + 11, 'obsidian'); // yeux
  bp.set(cx, 4, z0 + 11, 'sand'); // nez
}

export function gizaBlueprint(spec = GIZA) {
  const bp = new Blueprint('giza');
  pyramid(bp, spec.menkaure);
  pyramid(bp, spec.khafre);
  pyramid(bp, spec.khufu);
  kingsChamber(bp, spec.khufu);
  sphinx(bp, spec.sphinx);
  return bp;
}
