// BlockWorld V3.0 Beta 4.33 — kit commun des monuments retravaillés (module pur, testable sous Node).
//
// Un monument retravaillé est un PLAN : une liste de blocs {x, y, z, type} relatifs à son centre, où y = 0 est la première case libre
// au-dessus du sol (y = −1 : le sol lui-même). Le plan se teste sans le jeu (dimensions, matériaux, symétrie, accessibilité à pied) et se
// réutilisera pour le chantier de la tour Eiffel (plans de construction à remplir bloc par bloc). `placeBlueprint` le pose dans le monde.

export const MONUMENT_AIR = 'air'; // dans un plan : retire le bloc existant (couloir, chambre, passage)

export class Blueprint {
  constructor(name = '') {
    this.name = name;
    this.cells = new Map();
  }

  key(x, y, z) { return `${x}|${y}|${z}`; }

  /**
   * Pose un bloc (les coordonnées sont arrondies). Retourne true si la case a changé.
   * `hang: true` déclare un SURPLOMB (corniche, plafond de fût, encorbellement) : `placeBlueprint` ne comble pas la colonne dessous.
   * Sans cela, la fondation remplirait de pierre tout le vide sous un surplomb, jusqu'au sol (une gaine de pierre autour du fût d'une tour).
   */
  set(x, y, z, type, { hang = false } = {}) {
    x = Math.round(x); y = Math.round(y); z = Math.round(z);
    const key = this.key(x, y, z);
    const previous = this.cells.get(key);
    this.cells.set(key, { x, y, z, type, hang });
    return previous?.type !== type;
  }

  /** Vide une case : au placement, le bloc existant (terrain, arbre) est retiré. */
  carve(x, y, z) { return this.set(x, y, z, MONUMENT_AIR); }

  get(x, y, z) { return this.cells.get(this.key(Math.round(x), Math.round(y), Math.round(z)))?.type ?? null; }

  /** La case est-elle pleine dans le plan ? (air et cases absentes : non) */
  solid(x, y, z) { const type = this.get(x, y, z); return type !== null && type !== MONUMENT_AIR; }

  box(x1, x2, y1, y2, z1, z2, type) {
    for (let x = Math.min(x1, x2); x <= Math.max(x1, x2); x += 1) for (let y = Math.min(y1, y2); y <= Math.max(y1, y2); y += 1) for (let z = Math.min(z1, z2); z <= Math.max(z1, z2); z += 1) this.set(x, y, z, type);
  }

  carveBox(x1, x2, y1, y2, z1, z2) { this.box(x1, x2, y1, y2, z1, z2, MONUMENT_AIR); }

  /** Blocs réels (sans les cases d'air). */
  blocks() { return [...this.cells.values()].filter((cell) => cell.type !== MONUMENT_AIR); }

  get count() { return this.blocks().length; }

  types() {
    const counts = new Map();
    for (const cell of this.blocks()) counts.set(cell.type, (counts.get(cell.type) ?? 0) + 1);
    return counts;
  }

  /** Boîte englobante des blocs réels : { minX, maxX, minY, maxY, minZ, maxZ, width, depth, height }. */
  bounds() {
    const b = { minX: Infinity, maxX: -Infinity, minY: Infinity, maxY: -Infinity, minZ: Infinity, maxZ: -Infinity };
    for (const { x, y, z } of this.blocks()) {
      b.minX = Math.min(b.minX, x); b.maxX = Math.max(b.maxX, x); b.minY = Math.min(b.minY, y); b.maxY = Math.max(b.maxY, y); b.minZ = Math.min(b.minZ, z); b.maxZ = Math.max(b.maxZ, z);
    }
    return { ...b, width: b.maxX - b.minX + 1, depth: b.maxZ - b.minZ + 1, height: b.maxY + 1 }; // hauteur au-dessus du sol (y = 0)
  }
}

/** Bruit déterministe 0..1 (mêmes plans à chaque génération). */
export function hash2(x, z, seed = 0) {
  const v = Math.sin((x + seed * 17.3) * 127.1 + (z - seed * 3.1) * 311.7) * 43758.5453;
  return v - Math.floor(v);
}

/**
 * Pose un plan dans le monde, centré en (cx, cz), sur le sol existant. Les blocs du plan remplacent ce qui s'y trouve (terrain, arbres),
 * les cases « air » retirent les blocs, et une fondation comble le vide sous les cases basses (pas de monument suspendu en terrain irrégulier).
 * `world` doit fournir addBlock, removeBlock, getTopBlock.
 */
export function placeBlueprint(world, blueprint, cx, cz, { foundation = 'stone', baseY = null, apron = 0 } = {}) {
  const topOf = (x, z) => world.getTopBlock(Math.round(x), Math.round(z), { solidOnly: true })?.y ?? 0;
  // Lecture tolérante : le vrai monde a getBlock ; certains mondes factices n'ont qu'une table `blocks` (clé fournie par `key` ou « x|y|z »).
  const blockAt = (x, y, z) => world.getBlock?.(x, y, z) ?? world.blocks?.get?.(typeof world.key === 'function' ? world.key(x, y, z) : `${x}|${y}|${z}`);
  const y0 = baseY ?? (topOf(cx, cz) + 1);
  // Hauteur du sol de chaque colonne, relevée AVANT toute modification (sinon on lirait le sommet du monument).
  const terrain = new Map();
  for (const { x, z } of blueprint.cells.values()) {
    const wx = Math.round(cx + x), wz = Math.round(cz + z), column = `${wx}|${wz}`;
    if (!terrain.has(column)) terrain.set(column, topOf(wx, wz));
  }
  const lowest = new Map(); // plus basse case pleine de chaque colonne
  const opened = new Map(); // plus basse case d'air (vide voulu : porte, couloir) de chaque colonne
  for (const { x, y, z, type } of blueprint.cells.values()) if (type === MONUMENT_AIR) { const column = `${Math.round(cx + x)}|${Math.round(cz + z)}`; opened.set(column, Math.min(opened.get(column) ?? Infinity, y0 + y)); }
  for (const { x, y, z, type, hang } of blueprint.cells.values()) {
    const wx = Math.round(cx + x), wy = y0 + y, wz = Math.round(cz + z);
    const existing = blockAt(wx, wy, wz);
    if (existing && !existing.protectedBlock) world.removeBlock(wx, wy, wz, { persist: false });
    if (type === MONUMENT_AIR) continue;
    world.addBlock(wx, wy, wz, type, { persist: false });
    const column = `${wx}|${wz}`;
    if (!lowest.has(column) || wy < lowest.get(column).y) lowest.set(column, { y: wy, hang: Boolean(hang) });
  }
  if (foundation) {
    for (const [column, { y: lowY, hang }] of lowest) {
      if (hang) continue; // surplomb : on ne comble pas le vide dessous
      // vide voulu sous le bloc le plus bas (portail sous son linteau) : on ne comble que jusqu'au plancher du vide, pas le vide lui-même
      const airMin = opened.get(column);
      const fillTo = airMin !== undefined && airMin < lowY ? airMin : lowY;
      const [wx, wz] = column.split('|').map(Number);
      for (let wy = terrain.get(column) + 1; wy < fillTo; wy += 1) if (!blockAt(wx, wy, wz)) world.addBlock(wx, wy, wz, foundation, { persist: false });
    }
  }
  // Talus : raccorde le terrain voisin au niveau du monument (le plan se cale sur le sol du centre ; le terrain est bosselé de 1 à 3 blocs).
  // Au pied de l'emprise le sol monte au niveau du plancher, puis redescend d'un bloc tous les deux blocs ; la route y reste une route.
  if (apron > 0) {
    const floor = y0 - 1;
    const footprint = new Set(); for (const { x, y, z } of blueprint.cells.values()) if (y <= 3) footprint.add(`${Math.round(cx + x)}|${Math.round(cz + z)}`);
    const dist = new Map([...footprint].map((k) => [k, 0])); let frontier = [...footprint];
    for (let d = 1; d <= apron; d += 1) { const next = []; for (const k of frontier) { const [x, z] = k.split('|').map(Number); for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) { const n = `${x + dx}|${z + dz}`; if (!dist.has(n)) { dist.set(n, d); next.push(n); } } } frontier = next; }
    for (const [column, d] of dist) {
      if (d === 0) continue;
      const [wx, wz] = column.split('|').map(Number); const top = world.getTopBlock(wx, wz, { solidOnly: true }); const topY = top?.y ?? 0;
      const target = floor - Math.floor((d - 1) / 2);
      if (topY >= target || topY < 1) continue;
      const surface = top?.type === 'road' ? 'road' : (top?.type ?? 'grass');
      if (top) world.removeBlock(wx, topY, wz, { persist: false });
      for (let wy = topY; wy < target; wy += 1) if (!blockAt(wx, wy, wz)) world.addBlock(wx, wy, wz, 'dirt', { persist: false });
      if (!blockAt(wx, target, wz)) world.addBlock(wx, target, wz, surface, { persist: false });
    }
  }
  return { y0, count: blueprint.count };
}
