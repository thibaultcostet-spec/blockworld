import { Blueprint } from './MonumentKit.js';

// BlockWorld V3.0 Beta 4.35 — Sagrada Família retravaillée (plan pur, relatif au centre ; y = 0 : première case au-dessus du sol).
//
// Plan en croix : transept est-ouest (21 de long), nef nord-sud (25 de long). Le joueur arrive par l'EST : il voit la façade de la Nativité, un écran de
// 19 de large percé d'un grand portail et couronné de QUATRE clochers de 22 à 25 blocs aux pointes colorées. La façade de la Passion (ouest) est plus
// austère ; la nef s'ouvre au sud par la façade de la Gloire. Au-dessus du carré du transept, la tour de Jésus (39 de haut, croix lumineuse), entourée
// des quatre tours des évangélistes ; la tour de Marie à l'abside. Intérieur praticable : colonnes arborescentes, lanternes suspendues, vitraux ('crystal').
export const SAGRADA = Object.freeze({
  nave: { x: 4, z: 12 }, transept: { x: 10, z: 4 }, wallTop: 8,
  nativity: { x: 12, towers: [[-8, 22], [-4, 25], [4, 25], [8, 22]] }, passion: { x: -12, towers: [[-8, 20], [-4, 22], [4, 22], [8, 20]] },
  jesus: { cx: 0, cz: 0, height: 38 }, evangelists: [[-3, -3], [3, -3], [-3, 3], [3, 3]], mary: { cx: 0, cz: -9 }
});

function tower(bp, cx, cz, y0, top, { finial = 'lantern', slits = true, type = 'sand' } = {}) {
  for (let y = y0; y <= top - 3; y += 1) for (let dx = -1; dx <= 1; dx += 1) for (let dz = -1; dz <= 1; dz += 1) if (dx !== 0 || dz !== 0) {
    const slit = slits && (y - y0) % 4 === 2 && ((dx === 0) !== (dz === 0));
    bp.set(cx + dx, y, cz + dz, slit ? 'window' : (Math.abs(dx) === 1 && Math.abs(dz) === 1 ? 'concrete' : type));
  }
  bp.box(cx - 1, cx + 1, top - 2, top - 2, cz - 1, cz + 1, 'roof'); bp.set(cx, top - 1, cz, 'roof'); bp.set(cx, top, cz, finial); bp.set(cx, top + 1, cz, 'lantern');
}

export function sagradaBlueprint(spec = SAGRADA) {
  const bp = new Blueprint('sagrada');
  const { nave, transept, wallTop } = spec;
  const union = (x, z) => (Math.abs(x) <= nave.x && Math.abs(z) <= nave.z) || (Math.abs(x) <= transept.x && Math.abs(z) <= transept.z);
  const inner = (x, z) => (Math.abs(x) <= nave.x - 1 && Math.abs(z) <= nave.z - 1) || (Math.abs(x) <= transept.x - 1 && Math.abs(z) <= transept.z - 1);
  for (let x = -14; x <= 14; x += 1) for (let z = -16; z <= 16; z += 1) {
    if (!union(x, z)) continue;
    bp.set(x, -1, z, 'stone');
    if (inner(x, z)) { for (let y = 0; y <= wallTop; y += 1) bp.carve(x, y, z); }
    else for (let y = 0; y <= wallTop; y += 1) { // mur de ceinture : contreforts, vitraux
      const buttress = (x + z) % 4 === 0;
      const glazed = !buttress && y >= 4 && y <= 6 && (x + z) % 4 === 2;
      bp.set(x, y, z, buttress ? 'concrete' : glazed ? ((x + z) % 12 === 2 ? 'crystal' : 'window') : 'sand');
    }
    bp.set(x, wallTop + 1, z, 'roof'); // voûte
    if ((Math.abs(x) <= 1 && Math.abs(z) <= nave.z - 1) || (Math.abs(z) <= 1 && Math.abs(x) <= transept.x - 1)) bp.set(x, wallTop + 2, z, 'roof'); // faîtage
  }
  // colonnes arborescentes et lanternes (le passage central, large de 3, reste libre)
  for (const z of [-9, -6, 6, 9]) for (const x of [-2, 2]) { for (let y = 0; y <= wallTop; y += 1) bp.set(x, y, z, 'stone'); bp.set(x > 0 ? 1 : -1, wallTop, z, 'concrete'); }
  for (const x of [-8, -6, 6, 8]) for (const z of [-2, 2]) { for (let y = 0; y <= wallTop; y += 1) bp.set(x, y, z, 'stone'); bp.set(x, wallTop, z > 0 ? 1 : -1, 'concrete'); }
  for (const z of [-9, -4, 4, 9]) bp.set(0, 7, z, 'lantern');
  for (const x of [-8, -5, 5, 8]) bp.set(x, 7, 0, 'lantern');
  // façades à quatre tours : Nativité (est, sable, pointes colorées) et Passion (ouest, béton, pointes simples)
  for (const [side, facade, colors, type] of [[1, spec.nativity, ['lantern', 'bricks', 'crystal', 'lantern'], 'sand'], [-1, spec.passion, ['lantern', 'lantern', 'lantern', 'lantern'], 'concrete']]) {
    const x0 = side * 11, x1 = side * 13;
    const height = side > 0 ? 13 : 11;
    for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x += 1) for (let z = -9; z <= 9; z += 1) for (let y = 0; y <= height; y += 1) bp.set(x, y, z, type);
    for (const [z0, h] of facade.towers) tower(bp, side * 12, z0, height + 1, h, { finial: colors[facade.towers.findIndex(([zz]) => zz === z0)], type });
    for (const z of [-6, 6]) { for (let y = height + 1; y <= height + 4; y += 1) bp.set(side * 12, y, z, 'concrete'); bp.set(side * 12, height + 5, z, 'lantern'); } // pinacles entre les tours
    for (const z of [-6, 6]) for (let y = 5; y <= 9; y += 1) bp.set(side * 13, y, z, y % 2 ? 'window' : 'crystal'); // vitraux de la façade
    for (const z of [-2, 2]) for (let y = 0; y <= height; y += 1) for (let x = Math.min(x0, x1); x <= Math.max(x0, x1); x += 1) bp.set(x, y, z, 'concrete'); // montants du portail
    bp.carveBox(Math.min(side * 10, x1), Math.max(side * 10, x1), 0, 4, -1, 1); // portail : 3 × 5
    for (let x = Math.min(side * 10, x1); x <= Math.max(side * 10, x1); x += 1) for (let z = -2; z <= 2; z += 1) bp.set(x, 5, z, 'concrete');
  }
  // façade de la Gloire (sud) : écran bas percé du portail, pinacles
  for (let x = -4; x <= 4; x += 1) for (let z = 13; z <= 14; z += 1) for (let y = 0; y <= 8; y += 1) bp.set(x, y, z, x % 2 === 0 ? 'concrete' : 'sand');
  bp.carveBox(-1, 1, 0, 3, 12, 14); for (let x = -2; x <= 2; x += 1) for (let z = 12; z <= 14; z += 1) bp.set(x, 4, z, 'concrete');
  for (const x of [-4, 0, 4]) { for (let y = 9; y <= 12; y += 1) bp.set(x, y, 14, 'concrete'); bp.set(x, 13, 14, 'lantern'); }
  // tours centrales : Jésus (croix lumineuse), quatre évangélistes, Marie à l'abside
  const J = spec.jesus; const base = wallTop + 2;
  for (let y = base; y <= 30; y += 1) for (let dx = -1; dx <= 1; dx += 1) for (let dz = -1; dz <= 1; dz += 1) if (dx || dz) bp.set(J.cx + dx, y, J.cz + dz, Math.abs(dx) === 1 && Math.abs(dz) === 1 ? 'concrete' : (y - base) % 5 === 3 ? 'window' : 'sand');
  bp.box(-1, 1, 31, 31, -1, 1, 'roof');
  for (let y = 32; y <= 35; y += 1) bp.set(0, y, 0, 'concrete');
  for (const [dx, dz] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) bp.set(dx, 35, dz, 'concrete');
  for (let y = 36; y <= J.height; y += 1) bp.set(0, y, 0, 'lantern'); bp.set(0, J.height + 1, 0, 'lantern');
  for (const [i, [ex, ez]] of spec.evangelists.entries()) tower(bp, ex, ez, base, 24, { finial: ['lantern', 'bricks', 'crystal', 'bricks'][i] });
  tower(bp, spec.mary.cx, spec.mary.cz, base, 26, { finial: 'crystal' });
  return bp;
}
